extends Area2D
## Bullet. Weapons configure it through setup(), so every weapon can have its
## own damage, speed, range and knockback.

var direction := Vector2.RIGHT
var speed := 900.0
var damage := 10
var knockback := 80.0
var max_range := 900.0
var _last_zone := "torso"
var shooter: Node = null          # who fired it, so it never hits its owner

var net_visual := false           # network match: a cosmetic copy on a client (the host's copy does the damage)
var _travelled := 0.0


func setup(weapon: WeaponData, dir: Vector2, who: Node) -> void:
	direction = dir
	rotation = dir.angle()
	speed = weapon.projectile_speed
	damage = roundi(weapon.damage * MatchSession.damage_mult_for(who))
	knockback = weapon.knockback
	max_range = weapon.max_range
	shooter = who
	modulate = weapon.bullet_color
	if weapon.pellets > 1 and has_node("Sprite2D"):
		$Sprite2D.scale *= 0.55      # shotgun pellets are short sparks, not long streaks


func _ready() -> void:
	if Net.match_active():
		collision_mask |= 2         # remote players' puppets live on layer 2
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)


func _physics_process(delta: float) -> void:
	var step := direction * speed * delta
	global_position += step
	_travelled += step.length()
	if _travelled >= max_range:
		queue_free()


func _on_body_entered(body: Node) -> void:
	if body == shooter:
		return
	if net_visual:
		queue_free()                # cosmetic: no damage, no kill credit
		return
	if body.has_method("take_damage"):
		if "last_attacker" in body:
			body.last_attacker = shooter if is_instance_valid(shooter) else null      # kill credit
		var hp_before: float = float(body.get("health")) if "health" in body else float(damage)
		var zone := HitZones.zone_at(body, global_position)         # head / torso / legs from where the bullet is
		var dealt_dmg := maxi(1, roundi(damage * HitZones.mult(zone)))
		body.take_damage(dealt_dmg, direction * knockback)
		if is_instance_valid(shooter) and shooter.is_in_group("player"):
			MatchSession.note_hit()
		_last_zone = zone
		_hit_feedback(body, hp_before)
	queue_free()


# Damage number over the target + a haptic tick, only for bullets YOU fired.
func _hit_feedback(body: Node, hp_before: float) -> void:
	if not is_instance_valid(shooter) or not ("hud" in shooter) or shooter.hud == null:
		return
	var hp_after: float = float(body.get("health")) if "health" in body else hp_before - float(damage)
	var dealt := int(round(hp_before - hp_after))
	if dealt <= 0:
		return
	var killed: bool = ("is_dead" in body and body.is_dead) or hp_after <= 0.0
	var parent := get_tree().current_scene
	DamageNumber.spawn(parent, global_position, dealt, killed or _last_zone == HitZones.HEAD)
	UITheme.haptic(45 if killed else 14)
