# v38 – character & cosmetic art quality upgrade

Procedural painting upgraded for richer, more volumetric, cleaner character customisation art (and all cosmetic looks).

## Core improvements (`tools/artlib.py`)
- Higher internal supersampling (SS=5, was 3) → cleaner anti-aliased edges and smoother normals (final pixel sizes / pivots unchanged).
- Better height / volume model: soft Gaussian volume + distance-transform bevel.
- Improved lighting: soft wrap, ambient occlusion from height, fresnel-aware specular, warm subsurface scattering on skin, stronger rim.
- Softer anti-aliased outlines.
- Extra material presets (plastic, rubber) and better tuned cloth / metal / skin / chitin responses.

## Character body & outfits
- Bare body parts regenerated with the new skin shading.
- All garment generators inherit the improved paint.

## Heads, hair, eyes, headgear, jetpacks
- All modular generators now use SS=5 and the upgraded paint().
- Re-run to refresh every piece:
  ```
  python3 -I tools/gen_head_parts.py
  python3 -I tools/gen_gear.py
  python3 -I tools/gen_jetpack_art.py
  python3 -I tools/gen_outfit_art.py all
  ```

## Cosmetics (Lumen, Insectoid, Guardian …)
- gen_cosmetic_art.py / gen_character_art.py use higher supersampling (S=6) and improved soft-shading / highlight routine.

## Compatibility
- File names, sizes and pivots unchanged – drop-in.
- Appearance / save codes stay the same.

Regenerate after pulling, then re-import the project in Godot.
