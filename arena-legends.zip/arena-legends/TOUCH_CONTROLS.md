# Mobile / touch controls

The touch UI is built by `player.gd` (see `art/scripts/touch_controls.gd`). It turns on by itself on
phones and tablets. PC keyboard + mouse still work. On PC press **F9** to show the touch UI for a layout
check (the mouse acts as a single finger, and mouse aim/shoot is ignored while it is on; F9 again to leave).

| Touch | What it does | PC equivalent |
|---|---|---|
| Left stick left/right | Run / walk. Never turns the character: facing comes only from the right (aim) stick | A / D |
| Left stick **drag up** | Start flying (thrust). Keep dragging and steer in ANY direction. Lift to fall | W / Space + A/S/D |
| Left stick down (on ground) | Crouch + shield | S |
| Left stick flick sideways twice (in air) | Flip | Double-tap A/D |
| Right stick | Move the knob inside the small inner circle to aim; drag it out past that circle to aim AND shoot (same finger). Back inside or lift = stop | Mouse |
| ZOOM + / ZOOM - (top right, hold to repeat) | Camera closer / farther, within the weapon's range | Mouse wheel, `-` / `=`, D-pad down / up |
| HOVER | Toggle hover (stays in place, left stick still steers) | jetpack key |
| FLIP | Air flip | Shift |
| Weapon box | Tap to switch weapon (shows ammo) | E |
| THROW | Throw the selected grenade where you aim | G |
| Grenade icon (small circle) | Cycle grenade type | T |
| RELOAD | | R |
| PICK UP (only shown when a gun is within reach) | | F / controller X |
| DUAL WIELD (only shown when holding a one-handed gun with another one-handed gun within reach) | | Q / controller Y |

## Settings menu
Open the pause menu (MENU button, top-left, or Esc) > **SETTINGS**. Changes show live on the sticks and are saved
to `user://settings.cfg` (`art/scripts/game_settings.gd`):
- **Fixed analog sticks** ON (default: sticks stay put; touch on or near a ring to grab it) or OFF (floating sticks that appear under your thumb).
  APPEAR ON TOUCH (the old floating sticks).
- Stick size, button size, control opacity, stick dead zone, stick labels on/off, RESET.

Tuning: `touch_fly_start` (export on the Player) sets how far up you must pull to start flying; stick size,
dead zone and button layout are constants / `_layout()` in `touch_controls.gd`.

## Exporting to Android
1. Editor > Manage Export Templates (install), and set up the Android SDK/JDK in Editor Settings > Export > Android.
2. Project > Export > Add... > Android, enable Gradle build if you want, press **Export Project** (APK) or
   **One-Click Deploy** with USB debugging on.
3. Project settings already set for mobile: landscape (sensor) orientation, ETC2/ASTC texture import,
   `emulate_mouse_from_touch` off (otherwise every tap would also fire the gun).

**EDIT LAYOUT** (in settings): the menu hides and every control gets a yellow ring. Drag any stick or button
where you want it. Tap a control to select it, then **-** / **+** (bottom centre) resize it and **OPACITY -** / **OPACITY +** fade it. Size, opacity and position are stored per control (`sizes`, `opacities`, `offsets` in `settings.cfg`, keyed by control id such as `stick_l`, `stick_r`, `hover`, `throw`), so changing one control never touches another. The Settings-menu sliders (stick size, button size, control opacity) are still global multipliers applied on top of each control's own value. **MIRROR** swaps left and right (lefty layout). DONE saves, RESET puts everything back. Positions are saved as offsets in `settings.cfg`.

## Camera zoom
Ranges live in `art/scripts/zoom_config.gd` (lower number = camera closer). Each weapon remembers its own zoom for the match;
dual wield uses the higher-maximum gun's range and remembers a zoom per pair. Settings > **Start with Maximum Weapon Zoom** (OFF by default).

## Match end
After a win / loss, tap the screen (Enter, mouse click or controller A also work) to start a new match on the same map.
