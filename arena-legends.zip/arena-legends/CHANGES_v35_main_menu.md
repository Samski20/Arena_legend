# v35: Main Menu, Modes, Custom Match, Loadouts & Presets

## New systems
- **MainMenu** (`art/scripts/main_menu.gd`): PLAY GAME / MULTIPLAYER / SETTINGS entry screen using the v34 Android UI (green accent, Inter, pop-in).
- **MatchConfig** (`art/scripts/match_config.gd`): single reusable configuration for offline (and shared fields for LAN host). Mode, map, duration, kill limit, bots, weapons, throwables, loadouts, modifiers.
- **MatchSetupUI** (`art/scripts/match_setup_ui.gd`): tabbed setup (Rules, Map, Weapons, Throwables, Bots, Loadouts, Modifiers, Presets) with ALL / NONE / CUSTOM selection for weapons and throwables.
- **LoadoutStore** (`art/scripts/loadout_store.gd`): 5 builtin editable loadouts + up to 5 custom saved loadouts.
- **PresetStore** (`art/scripts/preset_store.gd`): save / load / rename / delete custom match presets; 10 builtin starting presets (Classic, Quick Match, Weapon Frenzy, Portal Chaos, Unlimited Fun, etc.).
- **RecordsStore** (`art/scripts/records_store.gd`): per-mode / map / difficulty personal records (kills, deaths, streak, best survival time, highest score).

## Offline modes
- Survival, Deathmatch, Training, Custom Match — all route through MatchSetupUI so duration, kill limit, bots, weapons, throwables and modifiers are configurable.
- Match ends on kill limit **or** time limit (whichever comes first). Unlimited options supported.
- MatchManager tracks time remaining offline and saves records on match end.

## Integration
- ArenaController shows MainMenu on boot (instead of the old map-select pause menu).
- `pending_config` / `active_config` apply spawn rates, bot count/difficulty/respawn, weapon pools, throwable intervals, and experimental modifiers before the match starts.
- Existing LAN multiplayer, settings menu, touch controls, maps, catalogs and networking are preserved. MULTIPLAYER still opens the existing LanMenu.

## Not changed
- Networking architecture, discovery, lobby, host-authoritative gameplay.
- Core combat, jetpack, maps, weapon/throwable behaviour.
