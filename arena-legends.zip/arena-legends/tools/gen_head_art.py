#!/usr/bin/env python3
"""Head, eye, hair, facial-hair and new headgear art for the modular character creator.
Writes tintable (white) pictures into art/player/{heads,eyes,hair,facial,gear}/ and the per-head-shape attachment data
into art/scripts/look/head_anchors.gd.
Canvases (tex px; the head is drawn at 2.5x): heads/eyes 108x100 | hair + gear 108x130 (head shifted down 30 so crests,
hats and afros have room) | facial 108x130 (extra room under the chin for long beards).
Each head shape records its own anchors, so hair, eyes, beards and hats sit on THAT head (see HeadAnchors).
Run from the project root:  python3 tools/gen_head_art.py"""
import importlib.util, os, math, random, json
from PIL import Image, ImageDraw, ImageFilter, ImageChops
spec = importlib.util.spec_from_file_location("g", "tools/gen_character_art.py")
g = importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
S = g.S; P = g.P; E = g.E
random.seed(7)
ROOT = "art/player/"
HY = 30                                        # hair / gear canvases: head shifted down by this many tex px
REF = {"x0": 7, "y0": 3, "x1": 103, "y1": 97, "eye": (73, 66), "chin": (62, 99)}
CX, CY, RX, RY = 55, 51, 48, 48                # the round reference head

def folder(name):
    os.makedirs(ROOT + name, exist_ok=True); g.OUT = ROOT + name + "/"

def save_img(img, name, w, h): g.save(img, name, w, h)

def strands(img, mask, fn_dark, fn_light, dark=(20, 14, 12, 110), light=(255, 255, 255, 120)):
    g.line_on(img, mask, fn_dark, dark, 0.45); g.line_on(img, mask, fn_light, light, 0.7)

# ============================================================================ HEAD SHAPES
def head_shape(name, fn, eye, chin):
    folder("heads")
    img = g.canvas(108, 100)
    m = g.mask_of(108, 100, lambda d: (fn(d), d.rounded_rectangle(P([(42, 90), (72, 104)]), radius=4 * S, fill=255)))
    g.solid(img, m, outline=2.2, shade=0.3)
    # ear (ring + inner), drawn into the picture so it belongs to the skull
    lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); dd = ImageDraw.Draw(lay)
    ex0 = int(g.mask_of(108, 100, fn).getbbox()[0] / S)
    ey = int((eye[1] + 4))
    dd.ellipse(E((ex0 + 14, ey - 6, ex0 + 30, ey + 16)), outline=(22, 28, 42, 255), width=int(2.2 * S))
    dd.ellipse(E((ex0 + 18, ey - 1, ex0 + 26, ey + 10)), fill=(22, 28, 42, 70))
    img.alpha_composite(lay)
    g.save(img, "head_%s.png" % name, 108, 100)
    bb = g.mask_of(108, 100, fn).getbbox(); bx0, by0, bx1, by1 = [v / S for v in bb]
    by1 = min(by1, 97)
    sx = max(0.88, min(1.14, (bx1 - bx0) / 96.0)); sy = max(0.88, min(1.14, (by1 - by0) / 94.0))
    cx, cy = (bx0 + bx1) / 2 - 55, (by0 + by1) / 2 - 50
    return {"hair": [round(cx / 2.5, 2), round(cy / 2.5, 2), round(sx, 3), round(sy, 3)],
            "eye": [round((eye[0] - 73) / 2.5, 2), round((eye[1] - 66) / 2.5, 2)],
            "beard": [round((chin[0] - 62) / 2.5, 2), round((chin[1] - 99) / 2.5, 2), round(sx, 3), round(sy, 3)]}

def all_heads():
    A = {}
    A["round"] = head_shape("round", lambda d: d.ellipse(E((7, 3, 103, 97)), fill=255), (73, 66), (62, 99))
    A["oval"] = head_shape("oval", lambda d: d.ellipse(E((16, 0, 100, 98)), fill=255), (72, 62), (60, 99))
    A["square"] = head_shape("square", lambda d: d.rounded_rectangle(P([(8, 6), (102, 94)]), radius=20 * S, fill=255), (76, 64), (62, 97))
    A["angular"] = head_shape("angular", lambda d: d.polygon(P([(12, 22), (32, 4), (80, 4), (102, 26), (100, 66), (84, 96), (34, 98), (8, 70)]), fill=255), (78, 62), (60, 98))
    A["long"] = head_shape("long", lambda d: (d.ellipse(E((20, -2, 98, 80)), fill=255), d.polygon(P([(34, 56), (92, 52), (84, 92), (58, 100), (36, 90)]), fill=255)), (73, 58), (62, 100))
    A["broad"] = head_shape("broad", lambda d: d.ellipse(E((2, 14, 106, 94)), fill=255), (80, 66), (62, 94))
    A["narrow"] = head_shape("narrow", lambda d: d.ellipse(E((26, 2, 94, 98)), fill=255), (70, 62), (60, 99))
    A["strong_jaw"] = head_shape("strong_jaw", lambda d: (d.ellipse(E((8, 2, 102, 72)), fill=255), d.polygon(P([(14, 50), (102, 48), (101, 88), (86, 99), (34, 99), (14, 78)]), fill=255)), (79, 62), (66, 98))
    return A

# ============================================================================ EYES
def eye_path(kind, cx, cy, w, h, tilt=0.0):
    """Outline points of one eye (facing right: the outer corner is on the left)."""
    pts = []
    if kind in ("round", "large", "small", "heavy"):
        for i in range(28):
            a = i / 28 * 2 * math.pi
            pts.append((cx + math.cos(a) * w / 2, cy + math.sin(a) * h / 2))
    elif kind in ("almond", "narrow"):
        for i in range(24):
            t = i / 23
            x = cx - w / 2 + t * w
            y1 = cy - math.sin(t * math.pi) * h / 2 - (1 - t) * tilt
            pts.append((x, y1))
        for i in range(24):
            t = 1 - i / 23
            x = cx - w / 2 + t * w
            y2 = cy + math.sin(t * math.pi) * h / 2 * 0.8 - (1 - t) * tilt
            pts.append((x, y2))
    elif kind == "angular":
        pts = [(cx - w / 2, cy - tilt - h * 0.1), (cx - w * 0.1, cy - h / 2 - tilt * 0.4), (cx + w / 2, cy - h * 0.25), (cx + w * 0.3, cy + h / 2), (cx - w * 0.3, cy + h * 0.35)]
    elif kind == "cyber":
        pts = [(cx - w / 2, cy - h / 2), (cx + w / 2, cy - h / 2), (cx + w / 2 - 4, cy + h / 2), (cx - w / 2 + 4, cy + h / 2)]
    return pts

EYE_STYLES = {
    "round": ("Round", dict(w=17, h=17, kind="round", iris=6.2)),
    "narrow": ("Narrow", dict(w=19, h=8, kind="narrow", iris=3.6, tilt=1)),
    "almond": ("Almond", dict(w=20, h=12, kind="almond", iris=4.8, tilt=3)),
    "angular": ("Angular", dict(w=19, h=13, kind="angular", iris=4.6, tilt=3)),
    "heavy": ("Heavy-lidded", dict(w=18, h=14, kind="heavy", iris=5.4, lid=0.5)),
    "large": ("Large", dict(w=22, h=22, kind="large", iris=8.6)),
    "small": ("Small", dict(w=11, h=11, kind="small", iris=4.2)),
    "cyber": ("Futuristic", dict(w=22, h=7, kind="cyber", iris=3.0)),
}

def eyes():
    folder("eyes")
    for key, (nm, p) in EYE_STYLES.items():
        s_img, i_img, l_img = g.canvas(108, 100), g.canvas(108, 100), g.canvas(108, 100)
        smask_all = Image.new("L", s_img.size, 0)
        for (cx, cy, k) in ((66, 67, 1.0), (91, 65, 0.78)):
            w, h = p["w"] * k, p["h"] * k
            pts = eye_path(p["kind"], cx, cy, w, h, p.get("tilt", 0) * k)
            m = g.mask_of(108, 100, lambda d, pts=pts: d.polygon(P(pts), fill=255))
            smask_all = ImageChops.lighter(smask_all, m)
            white = (236, 244, 255, 255) if key != "cyber" else (10, 14, 24, 255)
            g.solid(s_img, m, fill=white, outline=1.5, shade=0.1, hl=False)
            # iris + pupil + catch-light, clipped to the eye opening
            ir = p["iris"] * k
            ix = cx + (w * 0.12)
            layer = Image.new("RGBA", s_img.size, (0, 0, 0, 0)); dd = ImageDraw.Draw(layer)
            if key == "cyber":
                dd.rectangle(E((cx - w * 0.42, cy - h * 0.18, cx + w * 0.42, cy + h * 0.18)), fill=(255, 255, 255, 255))
            else:
                dd.ellipse(E((ix - ir, cy - ir, ix + ir, cy + ir)), fill=(255, 255, 255, 255))
                dd.ellipse(E((ix - ir * 0.45, cy - ir * 0.45, ix + ir * 0.45, cy + ir * 0.45)), fill=(14, 16, 24, 255))
                dd.ellipse(E((ix - ir * 0.55, cy - ir * 0.7, ix - ir * 0.05, cy - ir * 0.2)), fill=(255, 255, 255, 255))
            layer.putalpha(ImageChops.multiply(layer.getchannel("A"), m)); i_img.alpha_composite(layer)
            # lids: heavy upper lid, or a strong upper line (+ small lash for the narrow / almond looks)
            ll = Image.new("RGBA", s_img.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(ll)
            top = [(x, y) for (x, y) in pts if y < cy - 0.2 * h] or pts[:6]
            top.sort()
            if len(top) > 1:
                ld.line(P(top), fill=(18, 22, 34, 255), width=int(2.4 * S))
            if p.get("lid"):
                ld.chord(E((cx - w / 2 - 1, cy - h / 2 - 1, cx + w / 2 + 1, cy + h / 2 + 1)), 180, 360, fill=(110, 80, 70, 215))
                ld.line(P([(cx - w / 2, cy), (cx + w / 2, cy - 1)]), fill=(18, 22, 34, 255), width=int(2.6 * S))
            ll.putalpha(ImageChops.multiply(ll.getchannel("A"), ImageChops.lighter(m, m.filter(ImageFilter.MaxFilter(7))))); l_img.alpha_composite(ll)
        save_img(s_img, "%s_s.png" % key, 108, 100); save_img(i_img, "%s_i.png" % key, 108, 100); save_img(l_img, "%s_l.png" % key, 108, 100)

# ============================================================================ HAIR (108x130, head at y+30)
def arc(a0, a1, rad_add=0, n=18, cy_add=HY, sq=1.0):
    pts = []
    for i in range(n + 1):
        a = math.radians(a0 + (a1 - a0) * i / n)
        pts.append((CX + math.cos(a) * (RX + rad_add), CY + cy_add + math.sin(a) * (RY + rad_add) * sq))
    return pts

def hairline(depth=0.0):
    """Inner edge of a cap: from the forehead over the temple to behind the ear."""
    return [(CX + RX * 0.80, CY + HY - RY * (0.42 - depth)), (CX + RX * 0.46, CY + HY - RY * (0.62 - depth * 0.5)), (CX + RX * 0.12, CY + HY - RY * 0.30), (CX - RX * 0.18, CY + HY - RY * 0.10), (CX - RX * 0.62, CY + HY + RY * 0.18)]

def cap_mask(rad=4, a0=192, a1=322, depth=0.0):
    # outer edge: back of the head -> over the top -> forehead; then the hairline back along the temple and behind the ear
    return lambda d: d.polygon(P(arc(a0, a1, rad, 22) + hairline(depth)), fill=255)


def curls(d, cx, cy, r, n, rr):
    for i in range(n):
        a = i / n * 2 * math.pi
        d.ellipse(E((cx + math.cos(a) * r - rr, cy + math.sin(a) * r - rr, cx + math.cos(a) * r + rr, cy + math.sin(a) * r + rr)), fill=255)

def rope(d, pts, w):
    d.line(P(pts), fill=255, width=int(w * S), joint="curve")
    for (x, y) in (pts[0], pts[-1]):
        d.ellipse(E((x - w / 2, y - w / 2, x + w / 2, y + w / 2)), fill=255)

HAIR = {}
def hair(key, name, mask_fn, flows=False, flow_lines=None, high=None, dark_lines=None):
    folder("hair")
    img = g.canvas(108, 130); m = g.mask_of(108, 130, mask_fn)
    g.solid(img, m, outline=1.8, shade=0.34)
    cy0 = CY + HY
    fl = flow_lines or (lambda d, c: [d.arc(E((CX - RX - 2 + i * 7, cy0 - RY - 8 + i * 3, CX + RX - i * 5, cy0 + 8)), 205, 330, fill=c, width=int(1.4 * S)) for i in range(5)])
    strands(img, m, dark_lines or fl, high or (lambda d, c: d.arc(E((CX - RX + 12, cy0 - RY - 4, CX + RX - 6, cy0 + 14)), 215, 285, fill=c, width=int(2.4 * S))))
    save_img(img, "hair_%s.png" % key, 108, 130)
    HAIR[key] = {"name": name, "flows": flows}

def all_hair():
    hair("crop", "Short Crop", cap_mask(3, depth=0.0))
    hair("fade", "Fade", lambda d: (cap_mask(4, depth=0.18)(d), d.polygon(P(arc(192, 250, 1, 8) + list(reversed(arc(192, 250, -9, 8)))), fill=255)))
    def afro(d):
        d.ellipse(E((CX - 58, CY + HY - 66, CX + 40, CY + HY + 4)), fill=255); curls(d, CX - 9, CY + HY - 31, 45, 16, 8)
    hair("afro", "Afro", afro, high=lambda d, c: [d.arc(E((CX - 52 + i * 9, CY + HY - 66 + i * 6, CX + 30 - i * 5, CY + HY - 6)), 200, 300, fill=c, width=int(2 * S)) for i in range(2)])
    def braids(d):
        cap_mask(4, depth=0.1)(d)
        for i, y in enumerate((CY + HY - 8, CY + HY + 8, CY + HY + 24, CY + HY + 38)):
            rope(d, [(CX - 44 + i * 4, y), (CX - 52 + i * 3, y + 22), (CX - 46 + i * 5, y + 42)], 7)
    hair("braids", "Braids", braids, flows=True, flow_lines=lambda d, c: [d.line(P([(CX - 46 + i * 4, CY + HY + 2 + i * 14 + k * 5), (CX - 52 + i * 3, CY + HY + 8 + i * 14 + k * 5)]), fill=c, width=S) for i in range(4) for k in range(4)])
    def dreads(d):
        cap_mask(5, depth=0.05)(d)
        for i in range(6):
            x = CX - 40 + i * 6; y = CY + HY - 28 + i * 7
            rope(d, [(x, y), (x - 10 - i, y + 20), (x - 6 - i * 2, y + 50 + i * 3)], 8)
    hair("dreads", "Dreadlocks", dreads, flows=True)
    def long_(d):
        cap_mask(5, depth=0.05)(d)
        d.polygon(P([(CX - 46, CY + HY - 20), (CX - 8, CY + HY - 40), (CX - 10, CY + HY + 10), (CX - 18, CY + HY + 38), (CX - 40, CY + HY + 44), (CX - 62, CY + HY + 36), (CX - 54, CY + HY + 8)]), fill=255)
    hair("long", "Long Flowing", long_, flows=True)
    def curly(d):
        cap_mask(6, depth=0.1)(d); curls(d, CX, CY + HY, RX + 6, 20, 6)
    hair("curly", "Curly", curly)
    def wavy(d):
        cap_mask(5, depth=0.08)(d)
        pts = [(CX - 40, CY + HY - 22), (CX - 52, CY + HY), (CX - 44, CY + HY + 20), (CX - 54, CY + HY + 36), (CX - 46, CY + HY + 52)]
        d.line(P(pts), fill=255, width=int(18 * S), joint="curve")
    hair("wavy", "Wavy", wavy, flows=True)
    def spiky(d):
        cap_mask(3, depth=0.05)(d)
        for i in range(6):
            x = CX - 30 + i * 12
            d.polygon(P([(x - 7, CY + HY - RY + 2), (x + 2, CY + HY - RY - 22 - (i % 2) * 6), (x + 9, CY + HY - RY + 4)]), fill=255)
    hair("spiky", "Spiky", spiky)
    def pony(d):
        cap_mask(4, depth=0.08)(d)
        d.ellipse(E((CX - 62, CY + HY - 24, CX - 36, CY + HY + 30)), fill=255); d.ellipse(E((CX - 46, CY + HY - 32, CX - 34, CY + HY - 18)), fill=255)
    hair("pony", "Ponytail", pony, flows=True)
    def mohawk(d):
        d.polygon(P([(CX - 30, CY + HY - RY + 6), (CX - 26, CY + HY - RY - 18), (CX - 16, CY + HY - RY - 4), (CX - 8, CY + HY - RY - 26), (CX + 2, CY + HY - RY - 6),
                     (CX + 12, CY + HY - RY - 24), (CX + 20, CY + HY - RY - 2), (CX + 32, CY + HY - RY - 16), (CX + 34, CY + HY - RY + 10), (CX + 20, CY + HY - RY + 12), (CX - 20, CY + HY - RY + 14)]), fill=255)
    hair("mohawk", "Mohawk", mohawk)
    def future(d):
        d.polygon(P([(CX + 38, CY + HY - 32), (CX + 10, CY + HY - RY - 12), (CX - 30, CY + HY - RY - 6), (CX - 64, CY + HY - 24), (CX - 38, CY + HY - 22), (CX - 10, CY + HY - 30)]), fill=255)
    hair("future", "Swept Blade", future, flows=True)

# ============================================================================ FACIAL HAIR (108x130)
def band(a0, a1, tmin, tmax, inner=12, n=18):
    """A beard crescent hugging the jaw: thickest at the chin, tapering to nothing at the cheek and under the ear."""
    outer, inn = [], []
    for i in range(n + 1):
        f = i / n; a = math.radians(a0 + (a1 - a0) * f); sn = math.sin(math.pi * f) ** 0.7
        outer.append((CX + math.cos(a) * (RX + tmin + (tmax - tmin) * sn), CY + math.sin(a) * (RY + tmin + (tmax - tmin) * sn)))
        inn.append((CX + math.cos(a) * (RX - inner * (0.25 + 0.75 * sn)), CY + math.sin(a) * (RY - inner * (0.25 + 0.75 * sn))))
    return outer + list(reversed(inn))

def facial(key, name, mask_fn, stubble=False):
    folder("facial")
    img = g.canvas(108, 130); m = g.mask_of(108, 130, mask_fn)
    if stubble:
        img2 = g.canvas(108, 130)
        lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); dd = ImageDraw.Draw(lay)
        for _ in range(520):
            x, y = random.uniform(30, 104), random.uniform(52, 104)
            if m.getpixel((int(x * S), int(y * S))) > 0: dd.ellipse(E((x, y, x + 1.4, y + 1.4)), fill=(255, 255, 255, 235))
        img.alpha_composite(lay)
        g.save(img, "facial_%s.png" % key, 108, 130)
    else:
        g.solid(img, m, outline=1.6, shade=0.3)
        g.line_on(img, m, lambda d, c: [d.arc(E((CX - RX - 6 + i * 4, CY - RY + 8, CX + RX + 8 - i * 3, CY + RY + 14 - i * 2)), 20 + i * 4, 140 - i * 3, fill=c, width=S) for i in range(4)], (20, 14, 12, 110), 0.4)
        g.save(img, "facial_%s.png" % key, 108, 130)
    HAIR_F[key] = {"name": name}
HAIR_F = {}

def all_facial():
    facial("stubble", "Stubble", lambda d: d.polygon(P(band(22, 128, 1, 3, 5)), fill=255), True)
    facial("short_beard", "Short Beard", lambda d: d.polygon(P(band(18, 130, 3, 9, 13)), fill=255))
    facial("full_beard", "Full Beard", lambda d: (d.polygon(P(band(10, 135, 5, 16, 20)), fill=255), d.ellipse(E((CX - 18, CY + RY - 6, CX + 34, CY + RY + 26)), fill=255)))
    facial("goatee", "Goatee", lambda d: (d.ellipse(E((CX + 4, CY + RY - 8, CX + 32, CY + RY + 14)), fill=255), d.polygon(P([(CX + 10, CY + RY + 8), (CX + 20, CY + RY + 22), (CX + 28, CY + RY + 6)]), fill=255)))
    facial("mustache", "Mustache", lambda d: (d.polygon(P([(CX + 34, CY + 24), (CX + 50, CY + 22), (CX + 54, CY + 30), (CX + 44, CY + 34), (CX + 36, CY + 31)]), fill=255), d.polygon(P([(CX + 50, CY + 25), (CX + 56, CY + 34), (CX + 50, CY + 36)]), fill=255)))
    facial("mustache_beard", "Mustache + Beard", lambda d: (d.polygon(P(band(18, 130, 3, 9, 13)), fill=255), d.polygon(P([(CX + 32, CY + 22), (CX + 52, CY + 20), (CX + 57, CY + 30), (CX + 44, CY + 35), (CX + 34, CY + 31)]), fill=255)))
    facial("long_beard", "Long Beard", lambda d: (d.polygon(P(band(10, 135, 5, 15, 20)), fill=255), d.polygon(P([(CX - 16, CY + RY - 4), (CX + 36, CY + RY - 6), (CX + 28, CY + RY + 36), (CX + 6, CY + RY + 48), (CX - 12, CY + RY + 30)]), fill=255)))

# ============================================================================ NEW HEADGEAR (108x130, head at y+30)
def gear(name, mask_fn, detail=None, fill=g.WHITE, outline=2.0):
    folder("gear")
    img = g.canvas(108, 130); m = g.mask_of(108, 130, mask_fn)
    g.solid(img, m, fill=fill, outline=outline, shade=0.32)
    if detail: detail(img, m)
    g.save(img, "%s.png" % name, 108, 130)

def all_gear():
    cy0 = CY + HY
    gear("cap", lambda d: (d.pieslice(E((CX - RX - 3, cy0 - RY - 8, CX + RX + 3, cy0 + RY - 12)), 180, 360, fill=255),
                          d.polygon(P([(CX + 8, cy0 - 18), (CX + RX + 22, cy0 - 12), (CX + RX + 16, cy0 - 6), (CX + 6, cy0 - 8)]), fill=255)),
         lambda img, m: g.line_on(img, m, lambda d, c: ([d.line(P([(CX - 20 + i * 18, cy0 - RY - 6), (CX - 6 + i * 14, cy0 - 14)]), fill=c, width=S) for i in range(3)], d.arc(E((CX - RX, cy0 - RY - 4, CX + RX, cy0 + RY - 16)), 200, 340, fill=c, width=int(1.6 * S))), (20, 24, 40, 120), 0.4))
    gear("beanie", lambda d: (d.pieslice(E((CX - RX - 4, cy0 - RY - 14, CX + RX + 4, cy0 + RY - 6)), 180, 360, fill=255), d.rounded_rectangle(P([(CX - RX - 4, cy0 - 20), (CX + RX + 4, cy0 - 4)]), radius=5 * S, fill=255), d.ellipse(E((CX - 10, cy0 - RY - 26, CX + 8, cy0 - RY - 8)), fill=255)),
         lambda img, m: g.line_on(img, m, lambda d, c: ([d.line(P([(CX - RX + i * 8, cy0 - 20), (CX - RX + i * 8, cy0 - 4)]), fill=c, width=S) for i in range(12)], [d.arc(E((CX - RX + i * 3, cy0 - RY - 12 + i * 5, CX + RX - i * 3, cy0 + RY - 8)), 200, 340, fill=c, width=S) for i in range(3)]), (20, 24, 40, 100), 0.4))
    def cowl(d):
        d.ellipse(E((CX - RX - 3, cy0 - RY - 4, CX + RX + 3, cy0 + 26)), fill=255)
        d.polygon(P([(CX - 30, cy0 - RY + 8), (CX - 40, cy0 - RY - 24), (CX - 12, cy0 - RY - 2)]), fill=255)
        d.polygon(P([(CX + 8, cy0 - RY - 2), (CX + 18, cy0 - RY - 26), (CX + 34, cy0 - RY + 8)]), fill=255)
    def cowl_det(img, m):
        g.line_on(img, m, lambda d, c: d.arc(E((CX - RX + 6, cy0 - RY + 2, CX + RX - 4, cy0 + 12)), 205, 330, fill=c, width=int(1.6 * S)), (255, 255, 255, 80), 0.6)
    gear("cowl", cowl, cowl_det)
    # eye lenses are a separate picture so they stay white instead of taking the cowl's colour
    folder("gear")
    lens = g.canvas(108, 130); dd = ImageDraw.Draw(lens)
    for pts in ([(CX + 2, cy0 + 8), (CX + 24, cy0 + 4), (CX + 22, cy0 + 16), (CX + 4, cy0 + 18)], [(CX + 28, cy0 + 4), (CX + 50, cy0 + 9), (CX + 48, cy0 + 19), (CX + 30, cy0 + 16)]):
        dd.polygon(P(pts), fill=(255, 255, 255, 255))
    g.save(lens.filter(ImageFilter.GaussianBlur(0.3 * S)), "cowl_lens.png", 108, 130)

# ============================================================================ anchors file
def write_anchors(A):
    # species heads are baked pictures: their anchors are set by hand (hats / hair sit a little higher on a tall skull)
    A["sau_smooth"] = {"hair": [1.0, -0.8, 0.94, 1.04], "eye": [0.0, 0.0], "beard": [0.0, 0.0, 0.94, 1.0]}
    A["sau_crest"] = {"hair": [1.0, -0.8, 0.94, 1.04], "eye": [0.0, 0.0], "beard": [0.0, 0.0, 0.94, 1.0]}
    A["insect"] = {"hair": [0.0, 0.0, 1.0, 1.0], "eye": [0.0, 0.0], "beard": [0.0, 0.0, 1.0, 1.0]}
    A["lumen"] = {"hair": [0.0, -1.0, 0.9, 1.1], "eye": [0.0, 0.0], "beard": [0.0, 0.0, 0.9, 1.0]}
    lines = ["class_name HeadAnchors", "extends RefCounted", "## GENERATED by tools/gen_head_art.py. Per head shape: where eyes, hair/hats and beards sit on THAT head.",
             "## hair/gear = [offset x, offset y (game px), scale x, scale y]; eye = [offset x, y]; beard = [off x, y, scale x, y].", "", "const DATA := {"]
    for k, v in A.items():
        lines.append('\t"%s": %s,' % (k, json.dumps(v).replace('"hair"', '"hair"').replace("true", "true")))
    lines.append("}")
    open("art/scripts/look/head_anchors.gd", "w").write("\n".join(lines) + "\n")

if __name__ == "__main__":
    A = all_heads(); eyes(); all_hair(); all_facial(); all_gear(); write_anchors(A)
    print("hair:", json.dumps(HAIR)); print("facial:", json.dumps(HAIR_F))
