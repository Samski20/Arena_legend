#!/usr/bin/env python3
"""Body and clothing art for the human character (2x resolution, same picture sizes and joints as the old parts).

Every clothing piece is painted as a set of layers that the game tints separately (see PlayerRig.apply_garments):
  m  main colour      a / b / c  second / third / fourth colour (camouflage blotches, trim, pockets)
  g  glow lines       d  details that keep their own colours (straps, buckles, zips, patches)
Shading, folds and outlines are baked white-based so any colour swatch still looks like cloth, leather or metal.
Run through tools/gen_outfit_art.py (project root).
"""
import os
import numpy as np
import cv2
import artlib as A

import bodykit as BK

OUT = "art/outfits/"
BODY = "art/body/"

DARK = (14, 18, 30)
LEATHER = (112, 78, 48)
LEATHER_D = (66, 44, 28)
METAL = (176, 184, 196)
METAL_D = (92, 100, 114)
BRASS = (214, 176, 80)


def canvas(slot):
    BK.canvas(slot)


# silhouettes: the shared body kit (tools/bodykit.py). Garments are cut from the same shapes as the skin, so they always fit.
def sil_torso(female=False, neck=False):
    return BK.sil_torso(female, neck)


sil_waist = BK.sil_waist
sil_thigh = BK.sil_thigh
sil_shin = BK.sil_shin
sil_foot = BK.sil_foot
sil_upper_arm = BK.sil_upper_arm
sil_forearm = BK.sil_forearm
sil_hand = BK.sil_hand
SIL = dict(BK.SIL)
SIL["torso"] = lambda: BK.sil_torso(False, False)      # garments stop at the neckline (collar pieces cover the rest)


# ------------------------------------------------------------------------------------------------- piece painter
class Piece:
    """One clothing piece on one body slot. All masks are in the slot's design units (the old picture's pixels)."""

    def __init__(self, slot, sil=None, material="cloth", bevel=4.5, outline=1.05, ambient=0.5, spec=0.12, texture=None, ol_color=None, pad=0.55, cut=True):
        canvas(slot)
        self.slot = slot
        self.sil = SIL[slot]() if sil is None else sil
        if pad > 0:
            self.sil = A.grow(self.sil, pad)         # a hair bigger than the body, so no skin edge shows around the clothes
        self.img = A.paint(self.sil, (255, 255, 255), material, bevel=bevel, outline=outline, ambient=ambient, spec=spec,
                           texture=texture, ol_color=ol_color, ol_cut=BK.joint_cut(slot) if cut else None)
        self.layers = {}                 # name -> RGBA float image (own colours / own tints), built on save
        self.masks = {"a": None, "b": None, "c": None}
        self.glow = None
        self.detail = A.blank()

    # ---- shading on the white-based image
    def shade(self, m, s=0.3, color=DARK, within=True):
        self.img = A.over(A.tint_layer(m, color, s, within=self.sil if within else None), self.img)

    def light(self, m, s=0.3, within=True):
        self.img = A.over(A.tint_layer(m, (255, 255, 255), s, within=self.sil if within else None), self.img)

    def seam(self, pts, w=0.7, s=0.55, curve=True):
        pts = A.curve_pts(pts, 12) if curve else pts
        m = A.line(pts, w)
        self.shade(m, s)
        # a faint highlight just below the seam gives it depth
        self.light(A.shift(m, 0.3, 0.7), 0.16)

    def stitch(self, pts, w=0.35, gap=3.2, s=0.45):
        """dashed line"""
        pts = np.array(A.curve_pts(pts, 20))
        m = A.empty()
        d = np.cumsum(np.r_[0, np.hypot(*np.diff(pts, axis=0).T)])
        for i in range(int(d[-1] / gap) + 1):
            a, b = i * gap, i * gap + gap * 0.55
            sel = pts[(d >= a) & (d <= b)]
            if len(sel) >= 2:
                A.line([tuple(p) for p in sel], w, m)
        self.shade(m, s)

    def fold(self, pts, w=1.1, s=0.3):
        """soft crease: dark stroke with a light edge, blurred"""
        m = A.line(A.curve_pts(pts, 12), w)
        self.shade(A.blur(m, 0.5), s)
        self.light(A.blur(A.shift(m, 0.6, 0.6), 0.5), 0.18)

    def panel(self, mask, bevel=2.2, outline=0.7, s_in=0.0, material="cloth", ambient=0.55, spec=0.1, texture=None, to_layer=None, color=(255, 255, 255)):
        """A raised piece (pocket, plate, flap) painted on top: own bevel and outline."""
        mask = A.inter(mask, A.grow(self.sil, 1.2)) if to_layer is None else mask
        im = A.paint(mask, color, material, bevel=bevel, outline=outline, ambient=ambient, spec=spec, texture=texture)
        if to_layer is None:
            self.img = A.over(im, self.img)
        else:
            self.detail = A.over(im, self.detail)
        return im

    # ---- baked-colour details (straps, buckles, zips ...)
    def d_paint(self, mask, color, material="leather", bevel=1.6, outline=0.7, spec=None, ambient=None, texture=None):
        im = A.paint(mask, color, material, bevel=bevel, outline=outline, spec=spec, ambient=ambient, texture=texture)
        self.detail = A.over(im, self.detail)
        return im

    def d_line(self, pts, w, color, curve=True, alpha=1.0):
        pts = A.curve_pts(pts, 12) if curve else pts
        self.detail = A.over(A.tint_layer(A.line(pts, w), color, alpha), self.detail)

    def d_flat(self, mask, color, alpha=1.0):
        self.detail = A.over(A.tint_layer(mask, color, alpha), self.detail)

    # ---- tint layers
    def blotch(self, name, mask):
        self.masks[name] = mask

    def glow_lines(self, polylines, w=0.9):
        m = A.empty()
        for pl in polylines:
            A.line(A.curve_pts(pl, 14) if len(pl) > 2 else pl, w, m)
        m = A.inter(m, A.grow(self.sil, -0.8))
        halo = A.blur(m, 1.6)
        g = np.zeros((A.IH, A.IW, 4), np.float32)
        g[..., :3] = 1.0
        g[..., 3] = np.clip(np.maximum(m, halo * 0.55), 0, 1)
        self.glow = g

    def save(self, owner, oid, slot=None):
        d = OUT + "%s_%s/" % (owner, oid)
        os.makedirs(d, exist_ok=True)
        slot = slot or self.slot
        canvas(self.slot)
        inner = A.grow(self.sil, -1.1)
        A.save(self.img, d + "%s_m.png" % slot)
        for name, m in self.masks.items():
            if m is None:
                continue
            lay = self.img.copy()
            lay[..., 3] = np.clip(self.img[..., 3] * np.clip(m * inner, 0, 1), 0, 1)
            A.save(lay, d + "%s_%s.png" % (slot, name))
        if self.glow is not None:
            A.save(self.glow, d + "%s_g.png" % slot)
        if self.detail[..., 3].max() > 0.01:
            A.save(self.detail, d + "%s_d.png" % slot)


# ------------------------------------------------------------------------------------------------- patterns
def camo(seed, scale=6.0, kind="woodland"):
    """Returns three masks (a, b, c) for a camouflage pattern, continuous across the canvas.
    woodland: big irregular blobs of three tones; digital: blocky pixel pattern."""
    if kind == "digital":
        out = []
        for i, (th, px) in enumerate([(0.55, 3.0), (0.62, 2.2), (0.7, 1.6)]):
            rng = np.random.default_rng(seed * 7 + i)
            gw, gh = int(A.W / px / 2) + 2, int(A.H / px / 2) + 2
            g = rng.random((gh, gw)).astype(np.float32)
            g = cv2.GaussianBlur(g, (0, 0), 1.0)
            g = (g > np.quantile(g, th)).astype(np.float32)
            m = cv2.resize(g, (A.IW, A.IH), interpolation=cv2.INTER_NEAREST)
            out.append(m)
        return out
    n1 = A.noise(seed, scale)
    n2 = A.noise(seed + 11, scale * 0.8)
    n3 = A.noise(seed + 23, scale * 0.55)
    ma = A.smooth((n1 > 0.15).astype(np.float32), 0.5, 18)
    mb = A.smooth((n2 > 0.45).astype(np.float32), 0.45, 18)
    mc = A.smooth((n3 > 0.62).astype(np.float32), 0.4, 18)
    return ma, mb, mc


def fabric_weave(seed=3, strength=0.5):
    """fine cross-hatch texture for the lighting pass (values in [-1,1])"""
    t = np.zeros((A.IH, A.IW), np.float32)
    step = 2.4 * A.F
    for x in np.arange(0, A.IW, step):
        cv2.line(t, (int(x), 0), (int(x), A.IH), 0.5, 1)
    for y in np.arange(0, A.IH, step):
        cv2.line(t, (0, int(y)), (A.IW, int(y)), -0.5, 1)
    t = cv2.GaussianBlur(t, (0, 0), 0.8)
    return t * strength


def knit_texture(strength=0.5):
    t = np.zeros((A.IH, A.IW), np.float32)
    step = 2.2 * A.F
    for x in np.arange(0, A.IW, step):
        cv2.line(t, (int(x), 0), (int(x), A.IH), 0.6, max(1, int(0.6 * A.F)))
    return cv2.GaussianBlur(t, (0, 0), 0.9) * strength


def rect(x0, y0, x1, y1):
    return A.poly([(x0, y0), (x1, y0), (x1, y1), (x0, y1)])


def rrect(x0, y0, x1, y1, r=1.2):
    return A.smooth(rect(x0, y0, x1, y1), r)
