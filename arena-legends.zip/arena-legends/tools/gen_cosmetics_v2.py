#!/usr/bin/env python3
"""Generates the painted body sets of the cosmetic characters into art/cosmetics/<folder>/ (slot pictures only; wings, capes,
halos ... keep their own files). Run from the project root: python3 -I tools/gen_cosmetics_v2.py [night_guardian void_hunter ...]"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cosmlib as C

if __name__ == "__main__":
    ids = sys.argv[1:] or list(C.CHARS)
    for i in ids:
        C.CHARS[i]()
        print("done", i, flush=True)
