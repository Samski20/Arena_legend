#!/usr/bin/env python3
"""Generates art/head/mouths/<style>.png and the style list. Run from the project root: python3 -I tools/gen_mouths.py"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import artlib as A, mouthlib as M

OUT = "art/head/mouths/"
if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    for sid in M.IDS:
        img = M.make(sid)
        A.save(img, OUT + sid + ".png")
        print(sid, flush=True)
    # contact sheet for review
    from PIL import Image
    ims = [Image.open(OUT + s + ".png") for s in M.IDS]
    sh = Image.new("RGBA", (104 * 5 * 2, 72 * 3 * 2), (214, 170, 140, 255))
    for n, im in enumerate(ims):
        im = im.resize((im.width * 2, im.height * 2), Image.LANCZOS)
        sh.alpha_composite(im, ((n % 5) * 208, (n // 5) * 144))
    sh.save("/tmp/claude-0/shots/mouths.png")
