#!/usr/bin/env python3
"""Regenerates only the headgear pictures. usage (project root): python3 tools/gen_gear.py [shape ...]"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from multiprocessing import Pool
import artlib as A, headlib as HL, gearlib as GL
from gen_head_parts import save, OUT, SPECIES_GEAR

def one(sid):
    h = HL.Head(sid)
    gids = SPECIES_GEAR if sid in HL.SPECIES_IDS else GL.GEAR_IDS
    for gid in gids:
        r = GL.make_gear(h, gid)
        for layer, img in (r or {}).items():
            save(img, OUT + sid + "/gear_%s_%s.png" % (gid, layer))
    return sid

if __name__ == "__main__":
    shapes = sys.argv[1:] or HL.SHAPE_IDS + HL.SPECIES_IDS
    with Pool(2) as p:
        for s in p.imap_unordered(one, shapes):
            print("done", s, flush=True)
