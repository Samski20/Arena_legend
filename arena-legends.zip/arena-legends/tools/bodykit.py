#!/usr/bin/env python3
"""The shared BODY KIT of the human character: slot canvases, joint pivots and the anatomical silhouettes.

Every piece of art that sits on a body slot (bare skin, every garment, creature and hero bodies) is drawn on the canvas
listed in SLOTS, so one rig (art/scripts/player_rig.gd, BodySlots) can place all of them identically.

Units
  px  = in-game pixels, measured from the slot's joint pivot ("joint space": +x forward, +y down, the limb axis runs
        along +y for legs and along +x for arms)
  du  = design units used by the painters (2 du = 1 px). The painters were written against the OLD canvases, so they keep
        their old coordinates ("old frame"): canvas() shifts the new canvas so old coordinates still land on the same
        place of the body. J() converts joint-space px into that old frame.
Output pictures are 4 picture pixels per in-game pixel (set_canvas k=2).
"""
import numpy as np
import artlib as A

# slot: canvas size (px), pivot inside the canvas (px). The pivot is where the slot's node sits in the rig.
SLOTS = {
    "torso": ((50, 58), (25, 33)),      # node (0,-21): hips are the rig origin, the neck runs up into the head
    "waist": ((36, 18), (15, 8)),       # node (0, 2): pelvis block the legs hang from
    "thigh": ((17, 33), (8.5, 8)),      # node = hip joint
    "shin": ((14, 31), (7, 7)),         # node = knee joint
    "foot": ((27, 17), (8, 6)),         # node = ankle joint
    "upper_arm": ((37, 14), (7, 7)),    # node = shoulder joint
    "forearm": ((35, 12), (6, 6)),      # node = elbow joint
    "hand": ((14, 14), (7, 7)),         # node = wrist
}
# pivots (du) of the OLD canvases the painters were written for
OLD_PIVOT = {"torso": (44, 46), "waist": (24, 10), "thigh": (18, 10), "shin": (20, 4), "foot": (18, 6),
             "upper_arm": (12, 13), "forearm": (12, 12), "hand": (14, 14)}
# bone lengths (px)
UPPER_ARM = 24.0
FOREARM = 24.0
THIGH = 18.5
SHIN = 19.0
ANKLE_TO_SOLE = 9.6                      # ankle joint -> underside of the sole
NECK_X = (-3.2, 9.8)                     # neck column in rig px (matches the bottom of every head picture)
NECK_BASE_Y = -44.2


def size_du(slot):
    (w, h), _ = SLOTS[slot]
    return int(round(w * 2)), int(round(h * 2))


def offset_du(slot):
    """new pivot (du) - old pivot (du): shifts the old coordinates onto the new canvas."""
    _, (px, py) = SLOTS[slot]
    ox, oy = OLD_PIVOT[slot]
    return px * 2 - ox, py * 2 - oy


def canvas(slot):
    w, h = size_du(slot)
    ox, oy = offset_du(slot)
    A.set_canvas(w, h, ox, oy, 2, 3)


def J(slot, x, y):
    """joint-space px -> old-frame du"""
    ox, oy = OLD_PIVOT[slot]
    return ox + 2.0 * x, oy + 2.0 * y


def JP(slot, pts):
    return [J(slot, x, y) for x, y in pts]


# rig px -> old-frame du for the body-centred slots (their nodes sit at rig (0,-21) / (0,2))
def R(slot, x, y):
    ox, oy = OLD_PIVOT[slot]
    ny = {"torso": -21.0, "waist": 2.0}[slot]
    return ox + 2.0 * x, oy + 2.0 * (y - ny)


def RP(slot, pts):
    return [R(slot, x, y) for x, y in pts]


# ------------------------------------------------------------------------------------------------- tubes (limbs)
def _smooth_side(pts, n=10):
    return A.curve_pts(pts, n) if len(pts) > 2 else pts


def tube(slot, axis, stations, round_start=True, round_end=True, soft=0.5):
    """A limb as a tapered, asymmetric tube. stations = [(t, w_a, w_b)] along the limb axis (px from the joint);
    legs (axis 'y'): a = back (-x), b = front (+x); arms (axis 'x'): a = top (-y), b = underside (+y).
    The ends are round caps centred ON the joint (start) and on the next joint (end)."""
    A_side, B_side = [], []
    for t, wa, wb in stations:
        if axis == "y":
            A_side.append((-wa, t)); B_side.append((wb, t))
        else:
            A_side.append((t, -wa)); B_side.append((t, wb))
    A_c = _smooth_side(A_side)
    B_c = _smooth_side(B_side)
    # outline: A side forward, end cap, B side backward, start cap
    pts = list(A_c)
    t_end, wa_e, wb_e = stations[-1]
    t0, wa_0, wb_0 = stations[0]
    n = 14
    if round_end:
        r = 0.5 * (wa_e + wb_e)
        for k in range(1, n):
            a = np.pi * k / n
            if axis == "y":
                cx = 0.5 * (wb_e - wa_e)
                pts.append((cx - np.cos(a) * r, t_end + np.sin(a) * r))
            else:
                cy = 0.5 * (wb_e - wa_e)
                pts.append((t_end + np.sin(a) * r, cy - np.cos(a) * r))
    pts += list(reversed(B_c))
    if round_start:
        r = 0.5 * (wa_0 + wb_0)
        for k in range(1, n):
            a = np.pi * k / n
            if axis == "y":
                cx = 0.5 * (wb_0 - wa_0)
                pts.append((cx + np.cos(a) * r, t0 - np.sin(a) * r))
            else:
                cy = 0.5 * (wb_0 - wa_0)
                pts.append((t0 - np.sin(a) * r, cy + np.cos(a) * r))
    return A.smooth(A.poly(JP(slot, pts)), soft)


# limb profiles (px). a/b: see tube()
THIGH_ST = [(0, 7.0, 7.0), (2.5, 7.4, 7.7), (7, 7.0, 7.9), (12, 6.3, 7.2), (16, 5.7, 6.2), (THIGH, 5.5, 5.5)]
SHIN_ST = [(0, 5.5, 5.5), (3, 5.7, 5.7), (7.5, 6.3, 5.3), (12.5, 5.1, 4.6), (17, 4.1, 4.2), (SHIN, 4.2, 4.2)]
UARM_ST = [(0, 6.7, 6.7), (4, 6.6, 6.2), (11, 5.5, 6.0), (18, 4.9, 5.3), (UPPER_ARM, 4.6, 4.6)]
FARM_ST = [(0, 4.8, 4.8), (4, 4.9, 5.2), (10, 4.5, 4.8), (18, 3.9, 4.0), (FOREARM, 3.5, 3.5)]


# ------------------------------------------------------------------------------------------------- bodies
TORSO_PTS = [
    (NECK_X[0] + 0.4, -52.0), (NECK_X[1] - 0.4, -52.0), (NECK_X[1] - 0.4, -46.5),
    (13.0, -43.4), (18.0, -40.8),                                  # front trapezius, shoulder front
    (21.4, -35.8), (22.4, -28.5), (21.7, -21.0),                   # chest
    (18.3, -13.0), (15.4, -6.5), (12.6, -1.5), (11.6, 1.0),        # abdomen
    (3.5, 1.9), (-8.0, 1.9),                                       # hem
    (-11.8, 0.6), (-12.8, -3.5), (-15.6, -11.0), (-19.2, -19.5),   # lower back
    (-21.8, -28.0), (-20.3, -35.5), (-16.0, -40.2),                # back, shoulder blade
    (-9.5, -43.0), (NECK_X[0] + 0.4, -46.5),
]

# The pelvis starts INSIDE the torso and its front/back lines continue the torso's abdomen contour (see TORSO_PTS: 12.6,-1.5 ->
# 11.6,1.0 at the front; -11.8,0.6 at the back) before flaring out to the hips, so the abdomen flows into the pelvis with no shelf.
WAIST_PTS = [(-11.5, -8.0), (15.4, -8.0), (14.0, -4.5), (12.6, -1.5), (11.7, 1.2), (12.3, 3.8), (13.5, 6.8), (13.3, 9.8), (7.0, 11.6), (-1.0, 11.6), (-8.2, 10.0), (-12.4, 5.0), (-12.3, 1.0), (-12.6, -3.5)]


def sil_torso(female=False, neck=True):
    pts = list(TORSO_PTS)
    m = A.smooth(A.poly(A.curve_pts(RP("torso", pts), 8, closed=True)), 0.5)
    if not neck:
        top = A.poly(RP("torso", [(-8, -60), (16, -60), (16, NECK_BASE_Y + 0.9), (-8, NECK_BASE_Y + 0.9)]))
        m = A.sub(m, A.inter(top, A.poly(RP("torso", [(NECK_X[0] - 1.5, -60), (NECK_X[1] + 1.5, -60), (NECK_X[1] + 1.5, NECK_BASE_Y + 0.9), (NECK_X[0] - 1.5, NECK_BASE_Y + 0.9)]))))
    return m


def sil_pelvis(slot="waist"):
    """The whole pelvis block, drawn on the canvas of `slot` (the BARE body draws it as the lower part of the merged torso picture)."""
    return A.smooth(A.poly(A.curve_pts(RP(slot, WAIST_PTS), 8, closed=True)), 0.6)


# the torso's hem line (rig px); trousers / garments on the pelvis start exactly here, so the shirt hem and the waistband meet
HEM_PTS = [(-14.0, 0.3), (-8.0, 1.7), (3.5, 1.7), (11.6, 0.7), (14.0, 0.3)]


def sil_waist():
    """Garment piece for the pelvis: the pelvis below the torso hem (above it the torso picture already is the body)."""
    below = A.poly(RP("waist", A.curve_pts(HEM_PTS, 6) + [(16, 16), (-16, 16)]))
    return A.smooth(A.inter(sil_pelvis(), below), 0.5)


def sil_thigh():
    return tube("thigh", "y", THIGH_ST, True, True, 0.5)


def sil_shin():
    return tube("shin", "y", SHIN_ST, True, True, 0.5)


def sil_upper_arm():
    return tube("upper_arm", "x", UARM_ST, True, True, 0.5)


def sil_forearm():
    return tube("forearm", "x", FARM_ST, True, True, 0.5)


FOOT_PTS = [(-4.4, -1.0), (-5.6, 3.0), (-5.9, 6.4), (-4.6, 9.0), (-2.0, 9.6), (11.0, 9.6), (14.2, 9.1), (16.6, 7.7), (17.4, 5.9), (16.2, 4.4),
            (12.0, 3.4), (8.0, 2.2), (4.8, 0.6), (4.2, -1.0)]


def sil_foot():
    body = A.smooth(A.poly(A.curve_pts(JP("foot", FOOT_PTS), 6, closed=True)), 0.4)
    ankle = A.ellipse(*J("foot", 0, 0), 4.2 * 2, 4.2 * 2)          # joint cap (radius of the shin end)
    return A.smooth(A.union(body, ankle), 0.4)


def sil_hand():
    return A.smooth(A.ellipse(*J("hand", 0.3, 0.0), 5.0 * 2, 4.7 * 2), 0.5)


SIL = {"torso": sil_torso, "waist": sil_waist, "thigh": sil_thigh, "shin": sil_shin, "foot": sil_foot,
       "upper_arm": sil_upper_arm, "forearm": sil_forearm, "hand": sil_hand}

# the child end of a joint has no outline inside the joint disc (it would draw a line across the parent limb)
JOINT_CAP = {"shin": 5.5, "forearm": 4.8, "foot": 4.2}


def joint_cut(slot):
    """mask of the joint disc where this piece's outline is left out (None = outline everywhere)"""
    if slot not in JOINT_CAP:
        return None
    r = JOINT_CAP[slot] + 1.4
    cx, cy = J(slot, 0, 0)
    return A.smooth(A.ellipse(cx, cy, r * 2, r * 2), 0.3)
