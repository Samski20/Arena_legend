#!/usr/bin/env python3
"""Regenerates only the human head skins (after changing make_skin). Run from the project root: python3 -I tools/gen_skins.py"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import artlib as A, headlib as HL
for sid in HL.SHAPE_IDS:
    A.save(HL.make_skin(HL.Head(sid)), "art/head/%s/skin.png" % sid)
    print(sid, flush=True)
