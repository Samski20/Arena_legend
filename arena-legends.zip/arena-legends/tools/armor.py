#!/usr/bin/env python3
"""Body armour drawn on the new torso silhouette, in rig px (x forward, y down, hips at 0, neck at about -44).

Armour is cut from the SAME outline as the bare torso (bodykit.sil_torso) so it reaches every edge of the body: no skin shows at the
back, and the jetpack's mount plate seats against it. The tint layers follow the other garments: m main, a lighter, b darker, c accent.
"""
import numpy as np
import artlib as A
import bodykit as BK
import outfitlib as O
from outfitlib import Piece

RP = lambda pts: BK.RP("torso", pts)


def m_poly(pts, sm=0.5):
    return A.smooth(A.poly(RP(pts)), sm)


def m_blob(pts, sm=0.5, n=6):
    return A.smooth(A.poly(A.curve_pts(RP(pts), n, closed=True)), sm)


def m_box(x0, y0, x1, y1, r=0.5):
    return m_poly([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], r)


def base_sil(bottom=-1.0, scoop=True):
    O.canvas("torso")
    s = BK.sil_torso(False, False)
    s = A.inter(s, m_box(-30, -60, 30, bottom, 0.1))
    if scoop:                                   # neckline scoop; the shoulder straps stay
        s = A.sub(s, A.ellipse(*BK.R("torso", 3.4, -46.6), 7.4 * 2, 4.2 * 2))
    return s


def line(p, pts, w, color, alpha=1.0, curve=False):
    p.d_line(RP(pts), w, color, curve=curve, alpha=alpha)


def rivet(p, x, y, r=0.55):
    p.d_paint(A.ellipse(*BK.R("torso", x, y), r * 2, r * 2), O.METAL, "metal", bevel=0.3, outline=0.2)


def vest():
    """plate carrier: shoulder straps, webbing grid, three magazine pouches, chest pouch, cummerbund"""
    sil = base_sil(-1.2)
    p = Piece("torso", sil=sil, bevel=5.0, ambient=0.5, spec=0.12, texture=O.fabric_weave(60, 0.6), pad=0.0)
    # front plate bag + back plate bag
    front = A.inter(m_poly([(2, -41), (21.4, -39), (22.4, -28), (20.0, -9), (3.6, -6.4), (1.4, -22)], 0.9), sil)
    p.panel(front, bevel=2.0, outline=0.6, texture=O.fabric_weave(61, 0.5))
    back = A.inter(m_poly([(-22, -38), (-5, -41), (-2.6, -22), (-5, -7), (-14.6, -6.4), (-20.4, -22)], 0.9), sil)
    p.panel(back, bevel=2.0, outline=0.6, texture=O.fabric_weave(66, 0.5))
    for y in np.arange(-38.0, -8.0, 2.8):
        line(p, [(2.6, y), (21.4, y)], 0.5, (24, 26, 30), 0.45)
        line(p, [(-20.6, y), (-3.4, y)], 0.5, (24, 26, 30), 0.35)
    # chest pouch + three magazine pouches
    adm = A.inter(m_poly([(5.4, -35.4), (18.4, -35.4), (18.4, -27.2), (5.4, -27.2)], 0.6), sil)
    p.panel(adm, bevel=1.6, outline=0.6, texture=O.fabric_weave(63, 0.5))
    p.d_paint(m_box(6.2, -35.4, 17.6, -32.4, 0.4), (32, 34, 38), "cloth", bevel=0.8, outline=0.4)
    pouches = []
    for x0 in (3.6, 9.4, 15.2):
        pc = A.inter(m_poly([(x0, -23.2), (x0 + 5.2, -23.2), (x0 + 5.2, -11.2), (x0, -11.2)], 0.5), sil)
        p.panel(pc, bevel=1.6, outline=0.55, texture=O.fabric_weave(62, 0.5))
        p.d_paint(m_box(x0 + 0.5, -23.2, x0 + 4.7, -20.6, 0.3), (36, 38, 42), "cloth", bevel=0.7, outline=0.4)
        p.d_paint(m_box(x0 + 1.9, -22.0, x0 + 3.3, -19.4, 0.2), O.METAL, "metal", bevel=0.4, outline=0.3)
        pouches.append(pc)
    # shoulder straps with velcro tabs
    straps = []
    for pts in ([(-18, -43), (-7, -44.6), (-6, -33), (-19, -34)], [(8, -45.4), (19, -42), (20.6, -33), (8.6, -35)]):
        st = A.inter(m_poly(pts, 0.5), sil)
        p.panel(st, bevel=1.4, outline=0.55, texture=O.fabric_weave(64, 0.5))
        p.d_paint(m_box(pts[0][0] + 3.6, pts[0][1] + 3.4, pts[0][0] + 8.0, pts[0][1] + 7.4, 0.3), (40, 42, 46), "matte", bevel=0.4, outline=0.3)
        straps.append(st)
    # cummerbund
    cb = A.inter(m_poly([(-14, -8.0), (12.5, -8.0), (14.0, -1.2), (-12.8, -1.2)], 0.5), A.grow(sil, 0.3))
    cb = A.inter(m_box(-26, -8.0, 26, -1.0, 0.4), sil)
    p.panel(cb, bevel=1.8, outline=0.6, texture=O.fabric_weave(65, 0.6))
    p.d_paint(m_box(3.0, -6.8, 10.2, -2.4, 0.4), (34, 36, 40), "matte", bevel=0.6, outline=0.4)
    p.d_paint(m_box(5.2, -5.8, 8.0, -3.4, 0.3), O.METAL, "metal", bevel=0.5, outline=0.35)
    p.fold(RP([(-8, -12), (-10, -20), (-8, -30)]), 1.0, 0.25)
    p.blotch("a", A.union(adm, *pouches))
    p.blotch("b", A.union(cb, *straps))
    p.save("armor", "vest")


def plated():
    """heavy plate armour: layered angular plates with rivets and brass trim; solid back plate for the jetpack"""
    sil = base_sil(0.8)
    p = Piece("torso", sil=sil, material="metal", bevel=4.6, ambient=0.5, spec=0.38, pad=0.0)
    chest = A.inter(m_poly([(2.2, -42), (22, -40), (23, -29), (18.6, -19), (4.2, -19), (0.6, -29)], 0.9), sil)
    mid = A.inter(m_poly([(1.8, -20), (19.0, -20), (18.4, -13), (2.4, -13)], 0.6), sil)
    low = A.inter(m_poly([(2.4, -14), (17.4, -14), (15.4, -7.2), (4, -7.2)], 0.6), sil)
    belt = A.inter(m_box(-26, -8.0, 26, 1.0, 0.5), sil)
    back = A.inter(m_poly([(-23, -40), (-4, -42.6), (-2.4, -22), (-4.8, -9), (-13, -8), (-20.6, -22)], 0.9), sil)
    for m in (back, chest, mid, low, belt):
        p.panel(m, bevel=2.6, outline=0.75, material="metal", spec=0.45)
    # back plate ribs + spine
    for y in (-34, -27, -20, -14):
        p.seam(RP([(-20, y), (-12, y + 1.2), (-4, y)]), 0.5, 0.4)
    p.seam(RP([(-12, -41), (-12, -9)]), 0.6, 0.4, curve=False)
    # central ridge and edge light on the chest plate
    p.seam(RP([(11, -40), (11, -20)]), 0.7, 0.45, curve=False)
    p.light(A.line(RP([(3, -40), (21, -38.4)]), 0.8), 0.3)
    p.light(A.line(RP([(2.6, -19.6), (18, -19.6)]), 0.7), 0.22)
    for (x, y) in ((5, -37), (19.6, -36), (5, -22), (17, -22), (4.6, -16), (16, -16), (5.6, -9.4), (14, -9.4), (-18, -36), (-6, -38), (-18, -12), (-6, -12)):
        rivet(p, x, y, 0.6)
    # brass trim round the chest plate
    p.d_line(A.curve_pts(RP([(2.2, -42), (22, -40), (23, -29), (18.6, -19), (4.2, -19), (0.6, -29), (2.2, -42)]), 8), 0.7, O.BRASS, curve=False, alpha=0.65)
    # emblem
    p.d_paint(m_poly([(11.4, -36.4), (16.6, -31), (11.4, -24.4), (6.2, -31)], 0.3), O.BRASS, "metal", bevel=0.9, outline=0.45)
    p.d_flat(m_poly([(11.4, -34.4), (14.6, -31), (11.4, -26.8), (8.2, -31)], 0.2), (30, 34, 44), 0.8)
    p.blotch("a", A.union(back, mid, belt))
    p.save("armor", "plated")


if __name__ == "__main__":
    vest()
    plated()
