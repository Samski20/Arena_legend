#!/usr/bin/env python3
"""Small painting library for Arena Legends art generators (numpy + OpenCV + Pillow).

Everything is drawn from MASKS (float arrays, 1 = covered) and then PAINTED with pseudo-3D shading:
a mask is blurred into a height map, the height map gives a surface normal, and light comes from the upper left.
That gives rounded, volumetric parts (hair that has volume, helmets with a curved shell, beards that follow the jaw)
instead of flat polygons with a gradient. Materials change how the light behaves (metal = tight specular band,
cloth = soft and matte, hair = strand streaks, skin = soft, chitin = glossy).

Design space is 108 x 100 (the old head canvas). K scales it to the output size, SS is internal supersampling.
"""
import numpy as np, cv2
from PIL import Image

OX, OY = 12, 32                        # canvas margin (design units) left of / above the old 108x100 head box: room for afros, crests, tails
W0, H0 = 108 + OX, 100 + OY
K = 2                                  # output pixels per design unit
W, H = W0 * K, H0 * K                  # output canvas: 216 x 200
SS = 3                                 # internal supersampling
IW, IH = W * SS, H * SS
F = K * SS                             # design unit -> internal pixel


def set_canvas(w0, h0, ox=0, oy=0, k=2, ss=3):
    """Switch the drawing canvas (design size w0 x h0 plus margins) - used for limbs, which have their own picture sizes."""
    global OX, OY, W0, H0, K, W, H, SS, IW, IH, F
    OX, OY, W0, H0, K, SS = ox, oy, w0, h0, k, ss
    W, H = W0 * K, H0 * K
    IW, IH = W * SS, H * SS
    F = K * SS


def head_canvas():
    set_canvas(108 + 24, 100 + 32, 12, 32, 2, 3)

OUTLINE = np.array([20, 26, 40], np.float32) / 255.0
LIGHT = np.array([-0.52, -0.66, 0.55], np.float32)
LIGHT /= np.linalg.norm(LIGHT)


# ----------------------------------------------------------------------------- masks
def empty():
    return np.zeros((IH, IW), np.float32)


def _p(pts):
    a = np.array(pts, np.float64) + np.array([OX, OY])
    return (a * F).round().astype(np.int32)


def poly(pts, m=None, val=1.0):
    m = empty() if m is None else m
    cv2.fillPoly(m, [_p(pts)], val, lineType=cv2.LINE_AA)
    return m


def ellipse(cx, cy, rx, ry, rot=0.0, m=None, val=1.0):
    m = empty() if m is None else m
    cv2.ellipse(m, (int((cx + OX) * F), int((cy + OY) * F)), (max(1, int(rx * F)), max(1, int(ry * F))), rot, 0, 360, val, -1, cv2.LINE_AA)
    return m


def line(pts, width, m=None, val=1.0, round_caps=True):
    m = empty() if m is None else m
    ip = _p(pts)
    cv2.polylines(m, [ip], False, val, max(1, int(width * F)), cv2.LINE_AA)
    if round_caps:
        for q in (ip[0], ip[-1]):
            cv2.circle(m, (int(q[0]), int(q[1])), max(1, int(width * F / 2)), val, -1, cv2.LINE_AA)
    return m


def blob(cx, cy, r, m=None):
    return ellipse(cx, cy, r, r, 0, m)


def union(*ms):
    out = ms[0].copy()
    for x in ms[1:]:
        out = np.maximum(out, x)
    return out


def inter(a, b):
    return np.minimum(a, b)


def sub(a, b):
    return np.clip(a - b, 0, 1)


def blur(m, r):
    """Gaussian blur, radius in design units."""
    s = max(0.3, r * F)
    return cv2.GaussianBlur(m, (0, 0), s)


def smooth(m, r=1.2, sharp=14.0):
    """Round off corners: blur then re-threshold with a soft edge."""
    b = blur(m, r)
    return np.clip((b - 0.5) * sharp + 0.5, 0, 1)


def grow(m, r):
    """Dilate (r > 0) or erode (r < 0) by r design units. Padded so shapes touching the canvas edge stay clean."""
    k = max(1, int(abs(r) * F))
    ker = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * k + 1, 2 * k + 1))
    pad = k + 2
    p = cv2.copyMakeBorder(m, pad, pad, pad, pad, cv2.BORDER_CONSTANT, value=0)
    p = cv2.dilate(p, ker) if r > 0 else cv2.erode(p, ker)
    return p[pad:-pad, pad:-pad]


def closing(m, r):
    """Fill concave notches smaller than r (design units) without growing convex shapes."""
    k = max(1, int(r * F))
    pad = k + 2
    ker = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * k + 1, 2 * k + 1))
    p = cv2.copyMakeBorder(m, pad, pad, pad, pad, cv2.BORDER_CONSTANT, value=0)
    p = cv2.erode(cv2.dilate(p, ker), ker)
    return p[pad:-pad, pad:-pad]


def shift(m, dx, dy):
    M = np.float32([[1, 0, dx * F], [0, 1, dy * F]])
    return cv2.warpAffine(m, M, (IW, IH), flags=cv2.INTER_LINEAR, borderValue=0)


def half_plane(pts_a, pts_b, below=True):
    """Mask of everything on one side of the line a->b (design units)."""
    m = empty()
    (x1, y1), (x2, y2) = pts_a, pts_b
    big = 400
    dx, dy = x2 - x1, y2 - y1
    L = max(1e-6, (dx * dx + dy * dy) ** 0.5)
    nx, ny = (-dy / L, dx / L) if below else (dy / L, -dx / L)
    poly([(x1 - dx * big, y1 - dy * big), (x2 + dx * big, y2 + dy * big),
          (x2 + dx * big + nx * big, y2 + dy * big + ny * big), (x1 - dx * big + nx * big, y1 - dy * big + ny * big)], m)
    return m


def curve_pts(ctrl, n=40, closed=False):
    """Catmull-Rom through control points -> dense polyline."""
    P = [np.array(c, np.float64) for c in ctrl]
    if closed:
        P = [P[-1]] + P + [P[0], P[1]]
    else:
        P = [P[0]] + P + [P[-1]]
    out = []
    for i in range(1, len(P) - 2):
        p0, p1, p2, p3 = P[i - 1], P[i], P[i + 1], P[i + 2]
        for t in np.linspace(0, 1, n, endpoint=False):
            t2, t3 = t * t, t * t * t
            out.append(0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3))
    if not closed:
        out.append(P[-2])
    return [tuple(p) for p in out]


def chaikin(pts, it=2):
    P = [np.array(p, np.float64) for p in pts]
    for _ in range(it):
        Q = []
        for i in range(len(P)):
            a, b = P[i], P[(i + 1) % len(P)]
            Q.append(0.75 * a + 0.25 * b)
            Q.append(0.25 * a + 0.75 * b)
        P = Q
    return [tuple(p) for p in P]


def bbox(m, thr=0.5):
    ys, xs = np.where(m > thr)
    if len(xs) == 0:
        return None
    return xs.min() / F - OX, ys.min() / F - OY, xs.max() / F - OX, ys.max() / F - OY


def row_extent(m, y, thr=0.5):
    """(min_x, max_x) of the mask on design row y."""
    r = m[int(np.clip((y + OY) * F, 0, IH - 1))]
    xs = np.where(r > thr)[0]
    return (xs.min() / F - OX, xs.max() / F - OX) if len(xs) else (None, None)


def col_extent(m, x, thr=0.5):
    c = m[:, int(np.clip((x + OX) * F, 0, IW - 1))]
    ys = np.where(c > thr)[0]
    return (ys.min() / F - OY, ys.max() / F - OY) if len(ys) else (None, None)


# ----------------------------------------------------------------------------- painting
def _norm(rgb):
    return np.array(rgb, np.float32) / 255.0


def heightmap(m, bevel):
    h = blur(m, bevel)
    h = np.clip(h * 1.0, 0, 1)
    return h * h * (3 - 2 * h)


def paint(m, color=(255, 255, 255), material="cloth", bevel=3.0, outline=1.0, ambient=None, spec=None,
          texture=None, alpha_scale=1.0, light=None, rim=0.18, ol_color=None, ol_cut=None):
    """Returns an RGBA float image (IH, IW, 4) of mask `m` lit like a rounded object.
    color: base colour (0..255). white (255,255,255) is used for tintable parts: the game multiplies by a colour.
    outline: dark edge thickness in design units (0 = none).
    texture: optional float array (IH, IW) in [-1, 1] added to the lighting (strands, weave ...)."""
    base = _norm(color)
    mats = {"cloth": (0.55, 0.0, 10), "metal": (0.38, 0.55, 40), "skin": (0.66, 0.06, 8), "hair": (0.5, 0.3, 14),
            "chitin": (0.42, 0.45, 26), "glass": (0.7, 0.4, 30), "leather": (0.5, 0.18, 12), "matte": (0.62, 0.0, 8)}
    amb, sp, sh = mats.get(material, mats["cloth"])
    amb = amb if ambient is None else ambient
    sp = sp if spec is None else spec
    L = LIGHT if light is None else light
    h = heightmap(m, bevel)
    gy, gx = np.gradient(h)
    k = 7.0 * bevel
    nx, ny = -gx * k * F * 0.35, -gy * k * F * 0.35
    nz = np.ones_like(nx)
    ln = np.sqrt(nx * nx + ny * ny + nz * nz)
    nx, ny, nz = nx / ln, ny / ln, nz / ln
    diff = np.clip(nx * L[0] + ny * L[1] + nz * L[2], 0, 1)
    shade = amb + (1 - amb) * diff
    # edges curve away from the viewer: slightly darker rim, brighter just inside the lit side
    edge = np.clip(h * 2.2, 0, 1)
    shade = shade * (0.78 + 0.22 * edge)
    if texture is not None:
        shade = shade + texture * 0.22
    rgb = base[None, None, :] * shade[..., None]
    if sp > 0:
        hv = L + np.array([0, 0, 1.0], np.float32)
        hv /= np.linalg.norm(hv)
        s = np.clip(nx * hv[0] + ny * hv[1] + nz * hv[2], 0, 1) ** sh
        rgb = rgb + sp * s[..., None] * (0.35 + 0.65 * (1 - base[None, None, :] * 0.4))
    if rim > 0:   # thin bright rim on the lit side
        rl = np.clip(h * (1 - h) * 4.0, 0, 1) * np.clip(-(nx * L[0] + ny * L[1]) * 2.2, 0, 1)
        rgb = rgb + rim * rl[..., None]
    rgb = np.clip(rgb, 0, 1)
    a = np.clip(m, 0, 1) * alpha_scale
    out = np.zeros((IH, IW, 4), np.float32)
    out[..., :3] = rgb
    out[..., 3] = a
    if outline > 0:
        oc = OUTLINE if ol_color is None else _norm(ol_color)
        ring = np.clip(grow(m, outline) - m, 0, 1)
        if ol_cut is not None:
            ring = ring * (1.0 - np.clip(ol_cut, 0, 1))      # no outline inside a joint disc: the limb flows into its parent
        under = np.dstack([np.broadcast_to(oc, (IH, IW, 3)), ring * alpha_scale])
        out = over(out, under)                  # the outline sits UNDER the fill
    return out


def over(top, bottom):
    """Premultiplied-free 'over' compositing of two RGBA float images."""
    ta, ba = top[..., 3:4], bottom[..., 3:4]
    oa = ta + ba * (1 - ta)
    rgb = (top[..., :3] * ta + bottom[..., :3] * ba * (1 - ta)) / np.maximum(oa, 1e-6)
    return np.concatenate([rgb, oa], -1)


def blank():
    return np.zeros((IH, IW, 4), np.float32)


def stamp(canvas, rgba):
    return over(rgba, canvas)


def tint_layer(m, rgb, alpha=1.0, within=None):
    """A flat colour layer from a mask (optionally clipped to `within`)."""
    mm = m if within is None else inter(m, within)
    out = np.zeros((IH, IW, 4), np.float32)
    out[..., :3] = _norm(rgb)
    out[..., 3] = np.clip(mm, 0, 1) * alpha
    return out


def shade_layer(m, strength=0.35, within=None, color=(10, 14, 30)):
    return tint_layer(m, color, strength, within)


def light_layer(m, strength=0.5, within=None):
    return tint_layer(m, (255, 255, 255), strength, within)


def noise(seed, scale=2.0):
    rng = np.random.default_rng(seed)
    n = rng.random((IH, IW)).astype(np.float32)
    n = cv2.GaussianBlur(n, (0, 0), scale * F * 0.25)
    n = (n - n.mean()) / (n.std() + 1e-6)
    return np.clip(n * 0.5, -1, 1)


def strand_texture(strands, width=0.5, seed=0):
    """strands: list of control-point lists. Returns texture in [-1,1]: alternating dark / light streaks."""
    rng = np.random.default_rng(seed)
    t = np.zeros((IH, IW), np.float32)
    for ctrl in strands:
        pts = curve_pts(ctrl, 14)
        v = 1.0 if rng.random() > 0.45 else -1.0
        cv2.polylines(t, [_p(pts)], False, v * (0.55 + 0.45 * rng.random()), max(1, int(width * F)), cv2.LINE_AA)
    return cv2.GaussianBlur(t, (0, 0), 0.35 * F)


def to_image(rgba):
    """Downsample the supersampled canvas to the output size (premultiplied-correct) -> PIL image."""
    pm = rgba.copy()
    pm[..., :3] *= pm[..., 3:4]
    small = cv2.resize(pm, (W, H), interpolation=cv2.INTER_AREA)
    a = small[..., 3:4]
    rgb = np.where(a > 1e-4, small[..., :3] / np.maximum(a, 1e-6), 0)
    out = np.concatenate([np.clip(rgb, 0, 1), np.clip(a, 0, 1)], -1)
    return Image.fromarray((out * 255 + 0.5).astype(np.uint8), "RGBA")


def save(rgba, path, size=None):
    im = to_image(rgba)
    if size:
        im = im.resize(size, Image.LANCZOS)
    im.save(path, optimize=True)
    return im
