#!/usr/bin/env python3
"""Jetpack art: nine genuinely different packs, mechanical wings and flame pictures (4x resolution).
Pack picture: 46x60 design units (= game pixels) at 4 px per unit = 184x240 px, pivot (26,14) -> the rig draws it with
scale 4 ("JT_ART").  The back of the character hides everything right of x~23, so the silhouette lives on the left.
Layers (drawn in this order, the game tints them):
  base  main finish colour   trim  accent colour   det  baked colours (nozzles, straps, gems)
  glow  glow colour          shine  untinted highlights
Run through tools/gen_jetpack_art.py."""
import numpy as np
import cv2
import artlib as A

K = 4
CW, CH = 46, 60
PIV = (26, 14)
LAYERS = ("base", "trim", "det", "glow", "shine")

METAL = (150, 158, 172)
METAL_D = (74, 80, 94)
METAL_DD = (36, 40, 50)
LEATHER = (104, 74, 48)
BRASS = (216, 178, 84)
BRASS_D = (140, 104, 48)
WEB = (70, 72, 58)
RUBY = (214, 40, 60)
HOT = (255, 150, 60)


def canvas(w=CW, h=CH):
    A.set_canvas(w, h, 0, 0, K, 3)


def rect(x0, y0, x1, y1):
    return A.poly([(x0, y0), (x1, y0), (x1, y1), (x0, y1)])


def rrect(x0, y0, x1, y1, r=1.0):
    return A.smooth(rect(x0, y0, x1, y1), r)


def cap(x0, y0, x1, y1, r):
    return A.line([(x0, y0), (x1, y1)], 2 * r)


def disc(cx, cy, r):
    return A.ellipse(cx, cy, r, r)


def ring(cx, cy, rx, ry, w, rot=0.0):
    return A.sub(A.ellipse(cx, cy, rx, ry, rot), A.ellipse(cx, cy, rx - w, ry - w, rot))


def bell(cx, y0, y1, w0, w1, r=0.5):
    return A.smooth(A.poly([(cx - w0 / 2, y0), (cx + w0 / 2, y0), (cx + w1 / 2, y1), (cx - w1 / 2, y1)]), r)


class Pack:
    def __init__(self, w=CW, h=CH):
        canvas(w, h)
        self.w, self.h = w, h
        self.L = {k: A.blank() for k in LAYERS}

    def add(self, layer, m, color=(255, 255, 255), mat="metal", bevel=2.0, outline=0.75, **kw):
        self.L[layer] = A.over(A.paint(m, color, mat, bevel=bevel, outline=outline, **kw), self.L[layer])
        return m

    def flat(self, layer, m, color, alpha=1.0):
        self.L[layer] = A.over(A.tint_layer(m, color, alpha), self.L[layer])

    def shade(self, layer, m, s=0.3, within=None, color=(10, 14, 30)):
        self.L[layer] = A.over(A.tint_layer(m, color, s, within), self.L[layer])

    def light(self, layer, m, s=0.3, within=None):
        self.L[layer] = A.over(A.tint_layer(m, (255, 255, 255), s, within), self.L[layer])

    def glow(self, m, halo=1.6, strength=0.6):
        g = np.zeros((A.IH, A.IW, 4), np.float32)
        g[..., :3] = 1.0
        g[..., 3] = np.clip(np.maximum(m, A.blur(m, halo) * strength), 0, 1)
        self.L["glow"] = A.over(g, self.L["glow"])

    def streak(self, pts, w=0.5, a=0.55, within=None):
        m = A.blur(A.line(A.curve_pts(pts, 14) if len(pts) > 2 else pts, w), 0.25)
        if within is not None:
            m = A.inter(m, within)
        self.L["shine"] = A.over(A.tint_layer(m, (255, 255, 255), a), self.L["shine"])

    def seam(self, layer, pts, w=0.45, s=0.5, within=None):
        m = A.line(A.curve_pts(pts, 12) if len(pts) > 2 else pts, w)
        self.shade(layer, m, s, within)
        self.light(layer, A.shift(m, 0.25, 0.5), 0.14, within)

    def rivets(self, layer, pts, r=0.45, color=METAL):
        for x, y in pts:
            self.add(layer, disc(x, y, r), color, "metal", bevel=0.5, outline=0.25)

    def mount(self):
        """A back-frame plate on the pack's front face: it bridges the gap between the pack and the character's back (the torso
        hides the part inside the body) and carries the two strap anchors, so the pack always looks bolted on."""
        canvas(self.w, self.h)
        a = np.maximum.reduce([self.L[k][..., 3] for k in ("base", "trim", "det")])
        bb = A.bbox(a, 0.3)
        if bb is None:
            return
        x1, y0, y1 = bb[2], bb[1], bb[3]
        top, bot = y0 + 4.5, min(y1 - 12.5, y0 + 31)
        plate = rrect(x1 - 4.0, top, x1 + 7.5, bot, 1.6)
        pl = A.paint(plate, METAL_D, "metal", bevel=1.6, outline=0.7, ambient=0.5, spec=0.3)
        # strap tabs at the top and bottom edge, with bolts
        for ty in (top + 2.2, bot - 2.2):
            tab = rrect(x1 + 1.0, ty - 1.9, x1 + 7.2, ty + 1.9, 0.7)
            pl = A.over(A.paint(tab, LEATHER, "leather", bevel=0.8, outline=0.45, spec=0.2), pl)
            pl = A.over(A.paint(disc(x1 + 5.6, ty, 0.7), METAL, "metal", bevel=0.4, outline=0.25), pl)
        for ty in (top + 6, (top + bot) / 2, bot - 6):
            pl = A.over(A.paint(disc(x1 - 0.8, ty, 0.55), METAL, "metal", bevel=0.4, outline=0.25), pl)
        self.L["det"] = A.over(self.L["det"], pl)          # the pack itself stays in front of its own plate

    def save(self, folder, w=None):
        import os
        os.makedirs(folder, exist_ok=True)
        canvas(self.w, self.h)
        if not getattr(self, "_mounted", False) and self.w == CW:
            self.mount()
            self._mounted = True
        for k, img in self.L.items():
            if img[..., 3].max() > 0.01:
                A.save(img, folder + "/%s.png" % k)


# ============================================================================================ standard
def standard():
    p = Pack()
    back = cap(10, 11, 10, 38, 5.0)
    front = cap(19, 9, 19, 40, 5.6)
    p.add("base", back, (205, 208, 214), bevel=3.2, spec=0.4)
    p.add("base", front, bevel=3.4, spec=0.45)
    for m in (back, front):
        inner = A.grow(m, -0.4)
        for y0 in (15, 31):
            p.add("trim", A.inter(rect(0, y0, 40, y0 + 2.6), inner), bevel=0.9, outline=0.4, mat="metal")
    p.seam("base", [(19, 21), (19, 29)], 0.3, 0.35, front)
    # manifold and valves
    p.add("det", rrect(5.5, 3.2, 25, 7.4, 1.1), METAL, bevel=1.2, outline=0.6)
    for x in (10, 19):
        p.add("det", disc(x, 5.3, 1.5), METAL_D, bevel=0.7, outline=0.4)
    p.add("det", rrect(23, 4.2, 28, 6.4, 0.8), BRASS_D, bevel=0.8, outline=0.4)
    # straps + buckle
    p.add("det", rect(3, 22.5, 26, 25.5), LEATHER, "leather", bevel=0.9, outline=0.5)
    p.add("det", rrect(16.8, 21.8, 20.4, 26.2, 0.5), BRASS, bevel=0.8, outline=0.4)
    p.add("det", rect(18, 23.1, 19.2, 24.9), (60, 44, 30), "matte", bevel=0.3, outline=0)
    # gauge
    p.add("det", disc(19, 14, 2.1), (232, 232, 222), "glass", bevel=0.8, outline=0.5)
    p.glow(A.line([(19, 14), (20.2, 12.9)], 0.4), 0.8, 0.5)
    # glow slit
    p.glow(rrect(17.8, 27.5, 20.2, 38.2, 0.6), 1.3, 0.55)
    p.glow(rrect(8.6, 27, 11.0, 36.5, 0.6), 1.1, 0.4)
    # nozzles
    for cx, y0, y1, w0, w1 in ((10, 40, 47.5, 6.4, 8.8), (19, 41, 50, 7.2, 10.2)):
        p.add("det", bell(cx, y0, y1, w0, w1), METAL_D, bevel=1.6, outline=0.7)
        p.add("det", bell(cx, y0 + 1.2, y0 + 2.6, w0 + 0.6, w0 + 1.4, 0.3), METAL, bevel=0.5, outline=0.4)
        p.flat("det", A.ellipse(cx, y1 - 0.1, w1 / 2 - 0.9, 0.9), METAL_DD, 0.95)
    p.streak([(6.5, 13), (6.2, 26), (6.6, 35)], 0.5, 0.5, back)
    p.streak([(15.2, 12), (14.8, 28), (15.3, 38)], 0.55, 0.55, front)
    return p, dict(nozzles=[(10, 49.4), (19, 49.4)], flame="fire", scale=[0.8, 0.9])


# ============================================================================================ military
def stripes(x0, y0, x1, y1, step=2.4, w=1.2):
    m = A.empty()
    n = int((x1 - x0 + y1 - y0) / step) + 2
    for i in range(n):
        o = i * step
        A.line([(x0 + o - (y1 - y0), y1), (x0 + o, y0)], w, m)
    return A.inter(m, rect(x0, y0, x1, y1))


def military():
    p = Pack()
    plate = rrect(3, 5.5, 25.5, 45, 2.4)
    p.add("base", plate, bevel=2.6, mat="matte", ambient=0.55, spec=0.05)
    p.seam("base", [(4.5, 10), (24, 10)], 0.35, 0.5, plate)
    p.seam("base", [(4.5, 40), (24, 40)], 0.35, 0.5, plate)
    # tubular roll frame
    frame = A.union(A.line([(3.2, 6), (3.2, 45)], 1.5), A.line([(3.2, 6), (25, 6)], 1.4), A.line([(3.2, 45), (25, 45)], 1.4))
    p.add("trim", frame, bevel=0.9, outline=0.5)
    # two fuel canisters, strapped
    for cx, y0, y1 in ((8.6, 11, 36), (15.6, 11, 36)):
        c = cap(cx, y0, cx, y1, 3.3)
        p.add("base", c, (232, 236, 228), bevel=2.4, mat="metal", spec=0.25, ambient=0.5)
        p.add("det", cap(cx, y0 - 2.6, cx, y0 - 2.6, 1.3), METAL, bevel=0.7, outline=0.45)   # screw cap
        p.add("det", rrect(cx - 3.4, y0 + 7, cx + 3.4, y0 + 9.4, 0.4), WEB, "cloth", bevel=0.6, outline=0.4)
        p.add("det", rrect(cx - 3.4, y1 - 9.2, cx + 3.4, y1 - 6.8, 0.4), WEB, "cloth", bevel=0.6, outline=0.4)
        p.add("det", rrect(cx - 0.7, y0 + 6.8, cx + 0.7, y0 + 9.6, 0.3), BRASS_D, "metal", bevel=0.4, outline=0.3)
        p.add("det", rrect(cx - 0.7, y1 - 9.4, cx + 0.7, y1 - 6.6, 0.3), BRASS_D, "metal", bevel=0.4, outline=0.3)
        p.streak([(cx - 1.9, y0 + 1), (cx - 1.9, y1 - 1)], 0.45, 0.4, c)
    # hazard band
    hz = rect(19.5, 11, 25, 15.2)
    p.add("det", A.smooth(hz, 0.3), (232, 190, 40), "matte", bevel=0.5, outline=0.5)
    p.flat("det", stripes(19.5, 11, 25, 15.2, 2.2, 1.0), (24, 24, 24), 0.95)
    # MOLLE webbing
    for k in range(5):
        y = 17.5 + k * 3.0
        p.add("det", rect(19.2, y, 25, y + 1.0), WEB, "cloth", bevel=0.3, outline=0.2)
        p.flat("det", A.line([(19.4, y + 0.5), (24.8, y + 0.5)], 0.18), (110, 112, 90), 0.7)
    # thruster block with two compact cones
    p.add("base", rrect(5.5, 36, 24, 44, 1.2), bevel=1.6, mat="metal", spec=0.2)
    for cx in (10, 19.5):
        p.add("det", bell(cx, 43, 51, 6.0, 9.0), METAL_D, bevel=1.4, outline=0.7)
        p.add("det", bell(cx, 43.5, 45, 7.0, 7.8, 0.3), METAL, bevel=0.5, outline=0.4)
        p.flat("det", A.ellipse(cx, 50.9, 3.5, 0.9), METAL_DD, 0.95)
    p.rivets("det", [(5, 7), (24, 7), (5, 43.5), (24, 43.5), (12.5, 7)], 0.5)
    p.glow(disc(22.6, 8.6, 0.9), 1.1, 0.7)
    return p, dict(nozzles=[(10, 50.5), (19.5, 50.5)], flame="fire", scale=[0.7, 0.7])


# ============================================================================================ heavy
def heavy():
    p = Pack()
    drum = A.union(rrect(2.5, 13, 24.5, 31.5, 2.2), cap(13.5, 13.5, 13.5, 31.5, 11.0))
    p.add("base", drum, bevel=4.2, spec=0.35)
    for y in (12, 19, 26, 33):
        p.add("trim", A.inter(rect(0, y, 30, y + 1.7), A.grow(drum, -0.3)), bevel=0.7, outline=0.35)
    p.seam("base", [(13.5, 8), (13.5, 38)], 0.3, 0.3, drum)
    # intake with fan
    p.add("det", A.ellipse(13.5, 7.2, 9.0, 3.3), METAL, bevel=1.6, outline=0.7)
    p.add("det", A.ellipse(13.5, 7.2, 7.2, 2.5), METAL_DD, "matte", bevel=0.8, outline=0.3)
    for i in range(9):
        a = i * np.pi / 4.5
        p.flat("det", A.line([(13.5, 7.2), (13.5 + 7.0 * np.cos(a), 7.2 + 2.4 * np.sin(a))], 0.55), (120, 128, 142), 0.9)
    p.add("det", disc(13.5, 7.2, 1.3), METAL, bevel=0.5, outline=0.3)
    # exhaust stacks with heat shields
    for cx, y1, r in ((8, 52, 3.4), (19, 50, 3.9)):
        p.add("det", cap(cx, 36, cx, y1 - 2, r), METAL_D, bevel=2.0, outline=0.7)
        p.add("det", bell(cx, y1 - 4, y1, r * 2 + 0.4, r * 2 + 2.6, 0.4), METAL, bevel=1.0, outline=0.6)
        p.flat("det", A.ellipse(cx, y1 - 0.1, r + 0.7, 1.0), METAL_DD, 0.95)
        p.add("det", rrect(cx - r - 0.4, 40, cx + r + 0.4, 46, 0.7), (150, 110, 70), "metal", bevel=0.9, outline=0.5)
        for k in range(3):
            p.flat("det", A.line([(cx - r, 41 + k * 2), (cx + r, 41 + k * 2)], 0.3), (84, 58, 36), 0.9)
    p.glow(rrect(5.5, 14.5, 10.5, 16.2, 0.4), 1.2, 0.5)
    p.glow(rrect(5.5, 21.5, 10.5, 23.2, 0.4), 1.2, 0.5)
    p.glow(rrect(5.5, 28.5, 10.5, 30.2, 0.4), 1.2, 0.5)
    p.rivets("det", [(5, 10), (22, 10), (5, 36), (22, 36)], 0.55)
    p.add("det", rrect(15, 21, 21, 26, 0.6), METAL_D, bevel=0.8, outline=0.5)   # plate
    p.flat("det", rrect(16, 22, 20, 23, 0.2), (190, 60, 50), 0.9)
    p.streak([(5.8, 12), (5.6, 28), (6.2, 36)], 0.7, 0.5, drum)
    return p, dict(nozzles=[(8, 51.4), (19, 49.4)], flame="heavy", scale=[1.0, 1.15])


# ============================================================================================ future
def future():
    p = Pack()
    body = A.smooth(A.poly([(6, 7), (14, 3.5), (22, 6), (25, 15), (24, 30), (20, 43), (13, 47.5), (8, 40), (4.5, 24), (4, 13)]), 2.4)
    p.add("base", body, bevel=4.6, spec=0.6, ambient=0.5, ol_color=(10, 14, 26))
    # dorsal fin
    fin = A.smooth(A.poly([(4.5, 21), (1.2, 33), (2.6, 38), (7, 34)]), 0.8)
    p.add("trim", fin, bevel=1.2, outline=0.6)
    p.add("trim", A.smooth(A.poly([(8, 7), (3.5, 10), (3, 15), (7.5, 13)]), 0.6), bevel=1.0, outline=0.5)
    # panel seams + accent bands
    s1 = [(6.5, 12), (8.4, 26), (12.5, 43)]
    s2 = [(21.5, 9), (23, 24), (19.5, 40)]
    p.add("trim", A.inter(A.line(A.curve_pts(s1, 14), 1.3), A.grow(body, -0.2)), bevel=0.4, outline=0.2)
    p.add("trim", A.inter(A.line(A.curve_pts(s2, 14), 1.1), A.grow(body, -0.2)), bevel=0.4, outline=0.2)
    p.seam("base", [(10, 8), (11, 28), (15, 44)], 0.3, 0.35, body)
    # dark canopy plate
    p.add("det", A.smooth(A.poly([(12, 11), (19, 12), (20.5, 27), (15, 31), (11.5, 20)]), 1.2), (22, 28, 44), "glass", bevel=1.8, outline=0.5, spec=0.6)
    # energy seams (glow)
    p.glow(A.inter(A.line(A.curve_pts([(8.1, 14), (9.6, 26), (13, 41.5)], 14), 0.55), body), 1.4, 0.7)
    p.glow(A.inter(A.line(A.curve_pts([(20.2, 10), (21.4, 24), (18.6, 38.5)], 14), 0.5), body), 1.3, 0.6)
    p.glow(A.line(A.curve_pts([(13, 15), (16, 18), (16.5, 25)], 10), 0.4), 1.0, 0.7)
    # emitter rings
    for cx, cy, rx in ((13, 47.8, 6.0), (19.5, 44.6, 4.6)):
        p.add("det", ring(cx, cy, rx, rx * 0.32, rx * 0.34), METAL_D, bevel=0.8, outline=0.5)
        p.glow(ring(cx, cy + 0.15, rx - 0.7, rx * 0.26, 0.55), 1.1, 0.8)
    p.streak([(7.4, 9), (6.6, 22), (9, 38)], 0.7, 0.6, body)
    p.streak([(14, 5), (20, 7.5)], 0.5, 0.5, body)
    return p, dict(nozzles=[(13, 48.5), (19.5, 45.2)], flame="plasma", scale=[1.0, 0.8])


# ============================================================================================ experimental
def experimental():
    p = Pack()
    cx, cy = 13.5, 27
    # frame: top bracket, bottom mount, struts
    p.add("base", rrect(9, 2.5, 18, 7, 1.1), bevel=1.4, spec=0.4)
    p.add("base", rrect(8, 46.5, 19, 51, 1.2), bevel=1.4, spec=0.4)
    p.add("trim", A.union(A.line([(13.5, 6), (13.5, 14)], 1.1), A.line([(13.5, 40), (13.5, 47.5)], 1.1)), bevel=0.6, outline=0.4)
    # brass coils on the struts
    for y in (8, 10.5, 13, 42, 44.3):
        p.flat("det", A.line([(12, y), (15, y + 0.6)], 0.55), BRASS, 1.0)
        p.flat("det", A.line([(12, y + 0.5), (15, y + 1.1)], 0.18), BRASS_D, 0.9)
    # gimbal rings
    p.add("base", ring(cx, cy, 13.0, 13.0, 1.9), bevel=0.9, spec=0.5, outline=0.55)
    p.add("trim", ring(cx, cy, 11.2, 4.6, 1.5, 62), bevel=0.8, outline=0.45)
    p.add("base", ring(cx, cy, 10.2, 4.0, 1.4, -48), bevel=0.8, spec=0.5, outline=0.45)
    # core
    p.add("det", disc(cx, cy, 5.3), (30, 36, 52), "glass", bevel=2.4, outline=0.6, spec=0.7)
    p.glow(disc(cx, cy, 3.2), 3.0, 0.8)
    p.flat("shine", A.ellipse(cx - 1.6, cy - 1.8, 1.3, 0.8, -35), (255, 255, 255), 0.7)
    # nodes where the rings meet
    for x, y in ((cx, cy - 13), (cx, cy + 13), (cx - 13, cy), (cx + 13, cy)):
        p.add("det", disc(x, y, 1.4), METAL, bevel=0.6, outline=0.4)
    # three emitter cones
    for x, y1 in ((8.5, 53), (13.5, 54.5), (18.5, 53)):
        p.add("det", bell(x, 51, y1, 3.0, 5.0, 0.3), METAL_D, bevel=1.0, outline=0.5)
        p.flat("det", A.ellipse(x, y1 - 0.1, 2.0, 0.6), METAL_DD, 0.95)
        p.glow(A.ellipse(x, y1 - 0.4, 1.3, 0.4), 0.8, 0.7)
    p.streak([(3.6, 22), (3.4, 30)], 0.5, 0.55)
    return p, dict(nozzles=[(8.5, 54), (13.5, 55.5), (18.5, 54)], flame="arc", scale=[0.55, 0.7, 0.55])


# ============================================================================================ gilded
def scroll(p, pts, w=0.35, col=BRASS_D, alpha=0.95, within=None):
    m = A.line(A.curve_pts(pts, 14), w)
    if within is not None:
        m = A.inter(m, within)
    p.flat("det", m, col, alpha)


def gilded():
    p = Pack()
    # swept feather fins at the back
    for i, (cx, cy, rx, ry, rot) in enumerate(((7.5, 16, 8.5, 2.6, -62), (6.0, 22, 9.5, 2.8, -70), (5.2, 29, 9.5, 2.7, -80), (5.6, 36, 8, 2.4, -92))):
        f = A.ellipse(cx, cy, rx, ry, rot)
        p.add("trim", f, bevel=1.1, outline=0.55, spec=0.5)
        p.seam("trim", [(cx - rx * 0.1, cy + ry * 0.4), (cx + 0.4, cy - rx * 0.7)], 0.25, 0.4, f)
    back = cap(11, 11, 11, 38, 4.7)
    front = cap(19.5, 8.5, 19.5, 40, 5.4)
    p.add("base", back, (214, 214, 214), bevel=3.0, spec=0.7, ambient=0.5)
    p.add("base", front, bevel=3.2, spec=0.75, ambient=0.5)
    for m, cx in ((back, 11), (front, 19.5)):
        inner = A.grow(m, -0.4)
        for y0 in (14, 30):
            band = A.inter(rect(0, y0, 40, y0 + 3.0), inner)
            p.add("trim", band, bevel=0.8, outline=0.4, spec=0.7)
            for k in range(-2, 3):
                p.add("det", disc(cx + k * 2.0, y0 + 1.5, 0.45), (255, 236, 170), "metal", bevel=0.3, outline=0.15)
        scroll(p, [(cx - 2.6, 20), (cx - 1.0, 23), (cx + 1.5, 21), (cx + 2.8, 24.5)], 0.32, within=inner)
        scroll(p, [(cx + 2.6, 26), (cx + 1.0, 28.5), (cx - 1.5, 26.8)], 0.3, within=inner)
        scroll(p, [(cx - 2.8, 34.5), (cx, 37), (cx + 2.8, 35)], 0.3, within=inner)
    # crown finial and gems
    p.add("det", A.smooth(A.poly([(16.2, 4), (17.4, 0.8), (18.8, 3), (19.5, 0.2), (20.2, 3), (21.6, 0.8), (22.8, 4)]), 0.2), BRASS, bevel=0.6, outline=0.4)
    p.add("det", rrect(15.6, 3.6, 23.4, 5.4, 0.5), BRASS, bevel=0.6, outline=0.4)
    for x, y, r in ((19.5, 22, 1.7), (11, 22.5, 1.4), (19.5, 11.2, 1.0)):
        p.add("det", disc(x, y, r), RUBY, "glass", bevel=0.9, outline=0.45, spec=0.8)
        p.glow(disc(x, y, r * 0.55), 1.4, 0.55)
    # flared nozzles
    for cx, y0, y1, w0, w1 in ((11, 40, 48, 5.6, 9.2), (19.5, 41.5, 51, 6.6, 10.8)):
        p.add("det", bell(cx, y0, y1, w0, w1, 0.5), BRASS, bevel=1.7, outline=0.65, spec=0.8)
        p.add("det", bell(cx, y0 + 1.6, y0 + 3.0, w0 + 0.6, w0 + 1.6, 0.3), BRASS_D, bevel=0.5, outline=0.35)
        p.flat("det", A.ellipse(cx, y1 - 0.1, w1 / 2 - 0.8, 0.9), (60, 40, 20), 0.95)
    p.streak([(7.4, 14), (7.2, 28), (7.5, 36)], 0.5, 0.6, back)
    p.streak([(15.4, 12), (15, 30), (15.6, 38)], 0.55, 0.65, front)
    return p, dict(nozzles=[(11, 49.4), (19.5, 49.8)], flame="gold", scale=[0.8, 0.95])


# ============================================================================================ compact boosters
def compact():
    p = Pack()
    spine = rrect(3.5, 13, 23, 41, 2.3)
    p.add("base", spine, (220, 224, 230), bevel=2.4, spec=0.3, mat="matte")
    for cx, y0, y1, r in ((8.5, 18, 38, 3.2), (16.5, 20, 40, 3.5)):
        b = cap(cx, y0, cx, y1, r)
        p.add("base", b, bevel=2.3, spec=0.55)
        p.add("trim", A.inter(cap(cx, y0 - 3.4, cx, y0 - 1.2, r), A.grow(b, -0.1)), bevel=0.8, outline=0.4)   # nose cap
        p.add("trim", A.inter(rect(0, y1 - 5.6, 30, y1 - 3.4), A.grow(b, -0.3)), bevel=0.6, outline=0.35)
        p.glow(A.inter(rect(0, y0 + 8, 30, y0 + 9.3), A.grow(b, -0.3)), 0.9, 0.6)
        p.streak([(cx - r * 0.55, y0), (cx - r * 0.55, y1)], 0.4, 0.5, b)
        p.add("det", bell(cx, y1 - 1.2, y1 + 4.4, r * 1.7, r * 2.5, 0.4), METAL_D, bevel=1.1, outline=0.55)
        p.flat("det", A.ellipse(cx, y1 + 4.3, r * 1.25 - 0.1, 0.7), METAL_DD, 0.95)
    # stabiliser fins
    p.add("trim", A.smooth(A.poly([(5.4, 30), (1.2, 40), (5.8, 38)]), 0.4), bevel=0.8, outline=0.45)
    p.add("trim", A.smooth(A.poly([(20, 35), (24.5, 44), (19.6, 42)]), 0.4), bevel=0.8, outline=0.45)
    p.add("det", rrect(10, 15, 19, 18, 0.5), METAL_D, bevel=0.7, outline=0.4)
    p.rivets("det", [(5, 15), (21.5, 15), (5, 39), (21.5, 39)], 0.45)
    return p, dict(nozzles=[(8.5, 42.2), (16.5, 44.2)], flame="blue", scale=[0.62, 0.7])


# ============================================================================================ alien
def alien():
    p = Pack()
    shell = A.smooth(A.union(A.ellipse(13.5, 26, 11, 17), A.poly([(7, 10), (13, 5), (20, 10), (18, 20), (9, 20)])), 2.0)
    p.add("base", shell, (232, 232, 232), "chitin", bevel=4.6, spec=0.55, ambient=0.5, ol_color=(10, 26, 24))
    # ridges
    for y in (14, 19.5, 25, 30.5, 36):
        w = 9.5 - abs(y - 25) * 0.28
        p.seam("base", [(13.5 - w, y + 1.4), (13.5, y - 0.5), (13.5 + w, y + 1.4)], 0.5, 0.5, shell)
    # side lobes (trim)
    for cx, cy, rot in ((4.4, 22, 18), (4.8, 32, 8)):
        p.add("trim", A.ellipse(cx, cy, 3.3, 6.2, rot), bevel=1.4, outline=0.55, mat="chitin", spec=0.5)
    # crystals (baked teal) with glow
    for pts in (((9, 9), (10.5, 0.8), (13, 8.5)), ((12.5, 8), (15.6, 0.2), (17.8, 8)), ((16.8, 9.5), (20.5, 2.5), (21.5, 11)), ((6.6, 13), (4.6, 5.6), (9.4, 11.2))):
        m = A.smooth(A.poly(list(pts)), 0.3)
        p.add("det", m, (92, 232, 196), "glass", bevel=1.2, outline=0.5, spec=0.8)
        p.glow(A.grow(m, -0.4), 1.4, 0.5)
    # glowing veins
    for pts in (((13.5, 14), (11, 22), (13.5, 30), (13.5, 40)), ((13.5, 17), (17.5, 23), (16, 31)), ((13.5, 20), (9.4, 27), (11, 35))):
        p.glow(A.inter(A.line(A.curve_pts(list(pts), 14), 0.5), shell), 1.3, 0.65)
    # eye-like core
    p.add("det", A.ellipse(13.5, 25, 3.6, 2.6), (14, 40, 40), "glass", bevel=1.2, outline=0.5)
    p.glow(A.ellipse(13.5, 25, 1.4, 2.2), 1.6, 0.8)
    # petal exhaust (iris)
    for dx, rot in ((-4.2, 12), (-1.4, 4), (1.4, -4), (4.2, -12)):
        p.add("trim", A.smooth(A.poly([(13.5 + dx * 0.6 - 1.4, 40), (13.5 + dx * 0.6 + 1.4, 40), (13.5 + dx * 1.3 + 1.0, 49), (13.5 + dx * 1.3 - 1.0, 49)]), 0.4), bevel=0.9, outline=0.45, mat="chitin")
    p.glow(A.ellipse(13.5, 47.5, 3.4, 0.9), 1.2, 0.7)
    p.add("det", A.smooth(A.poly([(16, 42), (20, 41), (24, 46), (21, 52), (19, 47)]), 0.8), (30, 70, 64), "chitin", bevel=1.0, outline=0.5)   # tendril
    p.streak([(6.4, 16), (5.8, 26), (7.2, 35)], 0.65, 0.5, shell)
    return p, dict(nozzles=[(13.5, 48.4), (21.5, 51.6)], flame="green", scale=[0.95, 0.55])


# ============================================================================================ mechanical wings
WCW, WCH = 64, 58
WPIV = (58, 50)


def _blade(p, ang, length, width, near=True):
    a = np.radians(ang)
    d = np.array([np.cos(a), -np.sin(a)])
    n = np.array([-d[1], d[0]])
    root = np.array(WPIV, float)
    pts = [root + n * width * 0.5, root + d * length * 0.55 + n * width * 0.62, root + d * length - n * 0.2, root + d * length * 0.55 - n * width * 0.5, root - n * width * 0.5]
    m = A.smooth(A.poly([tuple(q) for q in pts]), 0.5)
    p.add("base", m, bevel=1.6, outline=0.6, spec=0.5)
    # leading-edge strip (trim) and spar
    lead = [root + n * width * 0.5, root + d * length * 0.55 + n * width * 0.62, root + d * length - n * 0.2]
    edge = A.inter(A.line([tuple(q) for q in lead], 1.1), A.grow(m, -0.2))
    p.add("trim", edge, bevel=0.5, outline=0.25)
    spar = [tuple(root + d * 3), tuple(root + d * length * 0.9)]
    p.flat("det", A.inter(A.line(spar, 0.5), m), (40, 46, 60), 0.85)
    p.glow(A.inter(A.line([tuple(root + d * 6), tuple(root + d * length * 0.8)], 0.4), m), 1.0, 0.7)
    for f in (0.3, 0.5, 0.7):
        c = root + d * length * f
        p.flat("det", A.inter(A.line([tuple(c - n * width * 0.4), tuple(c + n * width * 0.4)], 0.3), m), (40, 46, 60), 0.7)


def wing_art():
    p = Pack(WCW, WCH)
    blades = [(176, 40, 5.2), (162, 47, 5.6), (148, 52, 6.0), (134, 55, 6.0), (120, 52, 5.8), (106, 46, 5.4), (94, 38, 5.0)]
    for ang, ln, w in blades:
        _blade(p, ang, ln * 0.86, w * 1.75)
    p.add("det", disc(WPIV[0], WPIV[1], 3.6), METAL_D, bevel=1.4, outline=0.6)
    p.add("det", disc(WPIV[0], WPIV[1], 1.7), METAL, bevel=0.6, outline=0.4)
    p.glow(disc(WPIV[0], WPIV[1], 0.9), 1.4, 0.8)
    return p


def wing_core():
    """small power core between the shoulder blades that carries the wings"""
    p = Pack()
    body = rrect(7, 10, 23, 34, 3.0)
    p.add("base", body, bevel=3.0, spec=0.5)
    p.add("trim", A.inter(rect(0, 17, 40, 19.4), A.grow(body, -0.3)), bevel=0.6, outline=0.3)
    p.add("det", disc(15, 25.5, 4.3), (28, 34, 50), "glass", bevel=1.8, outline=0.55, spec=0.6)
    p.glow(disc(15, 25.5, 2.4), 2.4, 0.8)
    p.add("det", rrect(10.5, 5.5, 19.5, 10.5, 1.0), METAL_D, bevel=1.0, outline=0.5)
    for cx in (10.5, 19.5):
        p.add("det", bell(cx, 33, 39.5, 4.0, 6.2, 0.4), METAL_D, bevel=1.1, outline=0.5)
        p.flat("det", A.ellipse(cx, 39.4, 2.5, 0.7), METAL_DD, 0.95)
    p.streak([(8.8, 12), (8.6, 30)], 0.5, 0.55, body)
    return p, dict(nozzles=[(10.5, 39.8), (19.5, 39.8)], flame="blue", scale=[0.5, 0.5])


DESIGNS = {"standard": standard, "military": military, "heavy": heavy, "future": future, "experimental": experimental,
           "gilded": gilded, "compact": compact, "alien": alien, "wings": wing_core}


# ============================================================================================ flames
FW, FH, FPIV = 32, 64, 16     # flame pictures are 2x: 32x64 px, nozzle point at (16, 3)


def _flame_img(w, length, stops, tip_sharp=1.0, jag=0.0, seed=0, halo=0.0):
    """Teardrop flame hanging down from the nozzle; colour ramps from the core stops along the length."""
    H, W = FH * 3, FW * 3
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    x = (xx - W / 2) / (W / 2)
    t = (yy - 8) / (length * 3)
    prof = np.where((t >= 0) & (t <= 1), w * np.power(np.clip(1 - t, 0, 1), 0.8 * tip_sharp) * np.sin(np.clip(t * 14, 0, np.pi / 2)) , 0)
    if jag:
        rng = np.random.default_rng(seed)
        prof = prof * (1 + jag * np.sin(t * 40 + rng.random() * 6) * (t > 0.2))
    d = np.abs(x) / np.maximum(prof, 1e-3)
    inside = np.clip(1 - d, 0, 1)
    a = np.clip(inside * 2.2, 0, 1) * (prof > 1e-3)
    # colour: across the width (core hot) and along length (cools towards the tip)
    cool = np.clip(t, 0, 1)
    core = np.clip(1 - d * 1.5, 0, 1)
    rgb = np.zeros((H, W, 3), np.float32)
    s = np.array(stops, np.float32) / 255.0      # [core, mid, edge, tip]
    k = np.clip(cool * 0.8 + (1 - core) * 0.9, 0, 1.0) * 3.0
    i0 = np.clip(k.astype(int), 0, 2)
    f = (k - i0)[..., None]
    rgb = s[i0] * (1 - f) + s[np.clip(i0 + 1, 0, 3)] * f
    alpha = a * np.clip(1.2 - cool * 0.9, 0, 1)
    if halo > 0:
        h = cv2.GaussianBlur((prof > 1e-3).astype(np.float32) * 1.0, (0, 0), 14) * halo
        alpha = np.maximum(alpha, np.clip(h, 0, 0.5))
    out = np.dstack([np.clip(rgb, 0, 1), np.clip(alpha, 0, 1)])
    out = cv2.resize(out, (FW, FH), interpolation=cv2.INTER_AREA)
    return out


FLAMES = {
    "fire":   dict(w=0.78, length=50, stops=[(255, 250, 220), (255, 214, 90), (255, 120, 30), (200, 40, 10)]),
    "heavy":  dict(w=1.0, length=44, stops=[(255, 244, 200), (255, 190, 60), (255, 96, 20), (120, 30, 10)], tip_sharp=1.3, jag=0.08),
    "plasma": dict(w=0.5, length=58, stops=[(255, 255, 255), (160, 240, 255), (60, 170, 255), (20, 60, 220)], tip_sharp=0.7),
    "arc":    dict(w=0.55, length=48, stops=[(255, 255, 255), (250, 190, 255), (190, 80, 255), (90, 30, 200)], jag=0.25),
    "gold":   dict(w=0.7, length=50, stops=[(255, 255, 240), (255, 238, 150), (255, 190, 60), (230, 120, 30)]),
    "blue":   dict(w=0.62, length=48, stops=[(255, 255, 255), (170, 225, 255), (70, 150, 255), (255, 150, 60)], tip_sharp=1.1),
    "green":  dict(w=0.7, length=48, stops=[(250, 255, 230), (190, 255, 120), (60, 230, 130), (20, 130, 110)], jag=0.16),
}


def flame(kind):
    c = FLAMES[kind]
    return _flame_img(c["w"], c["length"], c["stops"], c.get("tip_sharp", 1.0), c.get("jag", 0.0), 3, c.get("halo", 0.0))
