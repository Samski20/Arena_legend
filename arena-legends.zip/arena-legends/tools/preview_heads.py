#!/usr/bin/env python3
"""Contact-sheet preview of head parts (dev tool). usage: python3 tools/preview_heads.py <out.png> <shape> hair=a,b,c [facial=..] [eyes=..] [col=r,g,b]"""
import sys, numpy as np
from PIL import Image
import artlib as A, headlib as HL, hairlib as HR, eyelib as EL, gearlib as GL

def tint(img, rgb):
    a = np.array(img).astype(np.float32); a[..., :3] *= np.array(rgb, np.float32) / 255.0
    return Image.fromarray(a.clip(0, 255).astype(np.uint8), "RGBA")

def compose(h, hair=None, facial=None, eyes="round", brows="soft", skin=(232, 188, 156), hcol=(90, 62, 44), iris=(90, 170, 230), gear=None):
    cv = Image.new("RGBA", (A.W, A.H), (62, 72, 84, 255))
    hairp = HR.make_hair(h, hair) if hair else None
    if hairp and hairp["back"] is not None: cv.alpha_composite(tint(A.to_image(hairp["back"]), hcol))
    cv.alpha_composite(tint(A.to_image(HL.make_skin(h)), skin))
    for far in (False, True):
        pos = h.eye_far if far else h.eye_near
        b, i, t = EL.make_eye(eyes, far)
        ox, oy = int((pos[0] + A.OX - EL.EW / 2) * A.K), int((pos[1] + A.OY - EL.EH / 2) * A.K)
        for im, tc in ((b, None), (i, iris), (t, None)):
            im = tint(im, tc) if tc else im
            cv.alpha_composite(im, (ox, oy))
        bm = EL.make_brow(brows, far)
        if bm: cv.alpha_composite(tint(bm, hcol), (ox, oy - int(8 * A.K)))
    fp = HR.make_facial(h, facial) if facial else None
    if fp: cv.alpha_composite(tint(A.to_image(fp["front"]), hcol))
    gp = GL.make_gear(h, gear) if gear else None
    if hairp and not (gp and GL.GEAR[gear]["hair"] in ("front", "all")): cv.alpha_composite(tint(A.to_image(hairp["front"]), hcol))
    if gp:
        for k, c in (("base", (110, 120, 140)), ("trim", (200, 170, 70)), ("lens", (150, 220, 255)), ("shine", None)):
            if k in gp:
                im = A.to_image(gp[k]); cv.alpha_composite(tint(im, c) if c else im)
    return cv

if __name__ == "__main__":
    out, shape = sys.argv[1], sys.argv[2]
    kv = dict(a.split("=") for a in sys.argv[3:])
    h = HL.Head(shape)
    hairs = kv.get("hair", "").split(",") if kv.get("hair") else [None]
    facs = kv.get("facial", "").split(",") if kv.get("facial") else [None]
    gears = kv.get("gear", "").split(",") if kv.get("gear") else [None]
    ims = [compose(h, hr, fc, kv.get("eyes", "round"), gear=g) for hr in hairs for fc in facs for g in gears]
    cols = min(len(ims), 6)
    sheet = Image.new("RGBA", (A.W * cols, A.H * ((len(ims) + cols - 1) // cols)))
    for k, im in enumerate(ims): sheet.paste(im, ((k % cols) * A.W, (k // cols) * A.H))
    sheet.save(out)
