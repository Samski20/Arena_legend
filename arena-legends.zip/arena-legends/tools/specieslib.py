#!/usr/bin/env python3
"""Species-specific head parts (antennae, mandibles) and clothing overlays that fit a non-human body."""
import numpy as np
import artlib as A, hairlib as HR

# species head id -> {hair-slot items, facial-slot items}
SPECIES_HAIR = {"insect": {"antenna_straight": "Straight Antennae", "antenna_curled": "Curled Antennae", "antenna_feather": "Feathered Antennae"},
                "lumen": {"crest_frill": "Bio Frill", "crest_nodes": "Glow Nodes"}}
SPECIES_FACIAL = {"insect": {"mandible_short": "Short Mandibles", "mandible_long": "Long Mandibles"}, "lumen": {}}


def make_species_hair(h, sid, style):
    sp = h.species
    col = (255, 255, 255)
    glow = None
    if style.startswith("antenna"):
        out = A.empty(); back = A.empty()
        for i, (bx, dx) in enumerate(((h.back + 30, -1), (h.back + 46, 1))):
            by = h.top_y(bx) or h.top
            if style == "antenna_straight":
                pts = [(bx, by + 3), (bx + 4 * dx, by - 14), (bx + 12 * dx + 6, by - 28)]
            elif style == "antenna_curled":
                pts = [(bx, by + 3), (bx - 4, by - 14), (bx + 8, by - 26), (bx + 16, by - 20), (bx + 12, by - 14)]
            else:
                pts = [(bx, by + 3), (bx + 3 * dx, by - 12), (bx + 10 * dx + 4, by - 26)]
            m = HR.lock(pts, 3.0, 1.2)
            if style == "antenna_feather":
                for t in np.linspace(0.3, 0.95, 6):
                    k = int(t * (len(A.curve_pts(pts, 10)) - 1)); px, py = A.curve_pts(pts, 10)[k]
                    A.line([(px, py), (px + 7, py - 3)], 1.0, m); A.line([(px, py), (px - 5, py - 5)], 1.0, m)
            (back if i == 1 else out).__iadd__(0)  # (kept simple: both antennae in front layer)
            out = A.union(out, m)
            A.ellipse(pts[-1][0], pts[-1][1], 2.0, 2.0, 0, out)
        img = A.paint(A.smooth(out, 0.3), sp["skin"], "chitin", bevel=1.4, outline=0.9, ambient=0.5, spec=0.3)
        return {"front": img, "back": None, "glow": None, "baked": True}
    if style == "crest_frill":
        m = A.empty()
        for i in range(7):
            bx, by = HR.scalp_point(h, 0.12 + i * 0.1, 2)
            A.poly([(bx - 3, by + 2), (bx + 1 - i * 0.6, by - 13 - 4 * np.sin(np.pi * i / 6)), (bx + 3.5, by + 2)], m)
        img = A.paint(A.smooth(m, 0.3), tuple(int(c * 0.85) for c in sp["skin"]), "chitin", bevel=1.6, outline=0.95, ambient=0.5, spec=0.3)
        g = A.line([HR.scalp_point(h, 0.12 + i * 0.1, -5) for i in range(7)], 0.7)
        return {"front": img, "back": None, "glow": A.tint_layer(A.blur(g, 0.8), (255, 255, 255), 0.9), "baked": True}
    if style == "crest_nodes":
        m = A.empty(); g = A.empty()
        for fx in (0.3, 0.45, 0.6):
            bx, by = HR.scalp_point(h, fx, 1)
            A.ellipse(bx, by - 2, 3.2, 3.2, 0, m); A.ellipse(bx, by - 2, 1.6, 1.6, 0, g)
        img = A.paint(m, tuple(int(c * 0.8) for c in sp["skin"]), "chitin", bevel=1.2, outline=0.9, ambient=0.5, spec=0.4)
        return {"front": img, "back": None, "glow": A.over(A.tint_layer(g, (255, 255, 255), 1.0), A.tint_layer(A.blur(g, 1.6), (255, 255, 255), 0.6)), "baked": True}
    raise ValueError(style)


def make_species_facial(h, sid, style):
    sp = h.species
    if style.startswith("mandible"):
        # a pair of hooked pincers that grow out of a jaw plate and curve in towards the mouth (no free-floating sticks)
        L = 10.5 if style == "mandible_long" else 7.0
        wb = 4.6 if style == "mandible_long" else 4.2
        mx, my = h.mouth
        m = A.ellipse(mx - 1.5, my + 0.5, 4.2, 8.2, 0)                       # jaw plate the mandibles are rooted in
        for dy, d in ((-4.4, 1), (4.6, -1)):
            pts = [(mx - 1.5, my + dy), (mx + 2 + L * 0.55, my + dy - d * 2.6), (mx + 3 + L, my + dy * 0.22)]   # tip hooks in to the mouth line
            m = A.union(m, HR.lock(pts, wb, 0.9))
        m = A.smooth(m, 0.5)
        img = A.paint(m, tuple(int(c * 0.82) for c in sp["skin"]), "chitin", bevel=2.0, outline=0.95, ambient=0.5, spec=0.35)
        return {"front": img, "baked": True}
    raise ValueError(style)


# ----------------------------------------------------------------------------- clothing overlays for non-human bodies
import cv2, os
from PIL import Image

OVERLAY_SLOTS = {   # slot: (material, grow, outline)
    "torso": ("cloth", 0.9, 1.0), "waist": ("cloth", 0.8, 0.9), "thigh": ("cloth", 0.8, 0.95), "shin": ("cloth", 0.8, 0.95),
    "foot": ("leather", 1.0, 1.0), "upper_arm": ("cloth", 0.8, 0.95), "forearm": ("cloth", 0.8, 0.95), "hand": ("leather", 0.9, 0.9),
}


def make_overlays(folder, root="art/cosmetics/"):
    """Cloth / boot / glove pieces cut to the shape of a creature's own limbs, written as ov_<slot>.png (2x resolution,
    white, tinted in game by the clothing colour). They let a creature wear shirts, trousers, boots and gloves without
    changing its anatomy: the pieces follow ITS limbs instead of human ones."""
    for slot, (mat, gr, ol) in OVERLAY_SLOTS.items():
        src = "%s%s/%s.png" % (root, folder, slot)
        if not os.path.exists(src):
            continue
        im = Image.open(src).convert("RGBA")
        A.set_canvas(im.width, im.height, 0, 0, 2, 3)
        a = np.array(im)[..., 3].astype(np.float32) / 255.0
        m = cv2.resize(a, (A.IW, A.IH), interpolation=cv2.INTER_CUBIC).clip(0, 1)
        m = A.smooth(m, 0.5)
        cover = m
        if slot == "torso":     # keep the neck line and shoulders clear
            cover = A.inter(m, A.half_plane((0, im.height * 0.07), (im.width, im.height * 0.07), below=True))
        cover = A.grow(cover, -0.2) if slot != "hand" else cover
        tex = None
        if mat == "cloth":
            tex = np.zeros((A.IH, A.IW), np.float32)
            for i in range(0, int(im.width + im.height), 5):
                A.line([(i, 0), (i - im.height, im.height)], 0.35, tex)
            tex = (tex - 0.5 * tex.max()) * 0.25
        img = A.paint(A.grow(cover, 0.5), (255, 255, 255), mat, bevel=2.6, outline=ol, ambient=0.56, texture=tex, spec=0.1 if mat == "leather" else None)
        A.save(img, "%s%s/ov_%s.png" % (root, folder, slot))
    A.head_canvas()
