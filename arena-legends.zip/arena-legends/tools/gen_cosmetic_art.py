#!/usr/bin/env python3
"""Generates the full-anatomy cosmetic art sets into art/cosmetics/<id>/ (baked colour, NOT tinted).
Each set has its own torso, waist, thigh, shin, foot, upper arm, forearm, hand and head drawn for that character,
plus the extra pieces its flight presentation needs (wings, abdomen, antennae, cape, halo ...).
All limb pictures use the SAME canvas size and joint pivots as the human parts, so bones, weapons and
hit-boxes behave exactly as before. Programmer art: an artist can repaint any file of the same size/pivot.
Run from the project root:  python3 tools/gen_cosmetic_art.py   (needs Pillow)"""
import importlib.util, os
from PIL import Image, ImageDraw, ImageFilter, ImageChops
spec = importlib.util.spec_from_file_location("g", "tools/gen_character_art.py")
g = importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
S = g.S; P = g.P; E = g.E

def out(set_id):
    os.makedirs("art/cosmetics/%s/" % set_id, exist_ok=True); g.OUT = "art/cosmetics/%s/" % set_id

def make(name, w, h, shape, fill, det=None, outline=2.0, shade=0.3, hl=True):
    img = g.canvas(w, h); m = g.mask_of(w, h, shape)
    g.solid(img, m, fill=fill + (255,), outline=outline, shade=shade, hl=hl)
    if det: det(img, m)
    g.save(img, name, w, h); return m

def lines(fn, rgba, blur=0.5):
    def d(img, m): g.line_on(img, m, fn, rgba, blur)
    return d

def multi(*dets):
    def d(img, m):
        for x in dets: x(img, m)
    return d

def glow_dot(img, cx, cy, r, col):
    lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); dd = ImageDraw.Draw(lay)
    dd.ellipse(E((cx - r * 2, cy - r * 2, cx + r * 2, cy + r * 2)), fill=col[:3] + (70,))
    lay = lay.filter(ImageFilter.GaussianBlur(r * S * 0.8)); img.alpha_composite(lay)
    lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); ImageDraw.Draw(lay).ellipse(E((cx - r, cy - r, cx + r, cy + r)), fill=col[:3] + (255,))
    img.alpha_composite(lay)

# =========================================================================== INSECTOID
def insectoid():
    out("insectoid")
    C = (44, 122, 98); D = (22, 66, 58); A = (240, 172, 60); L = (226, 200, 120)
    # thorax: segmented shell with a pale belly plate on the front
    make("torso.png", 88, 92,
         lambda d: d.polygon(P([(10, 4), (42, 0), (78, 6), (87, 30), (82, 60), (68, 88), (42, 91), (22, 86), (8, 60), (2, 30)]), fill=255), C,
         multi(lines(lambda d, c: [d.arc(E((4, y - 22, 86, y + 22)), 200, 340, fill=c, width=int(2.2 * S)) for y in (30, 52, 74)], D + (200,)),
               lines(lambda d, c: d.polygon(P([(52, 8), (80, 12), (84, 40), (76, 70), (62, 84), (54, 50)]), fill=c), L + (150,), 0.8),
               lines(lambda d, c: [d.ellipse(E((14 + i * 9, 16 + (i % 2) * 5, 20 + i * 9, 22 + (i % 2) * 5)), fill=c) for i in range(5)], A + (230,), 0.3)))
    make("waist.png", 48, 24, lambda d: d.ellipse(E((4, 2, 44, 22)), fill=255), D,
         lines(lambda d, c: d.line(P([(8, 12), (40, 12)]), fill=c, width=S), A + (200,)))
    make("thigh.png", 36, 48, lambda d: (d.ellipse(E((6, 4, 32, 46)), fill=255), d.polygon(P([(8, 14), (-2, 24), (8, 30)]), fill=255)), C,
         lines(lambda d, c: [d.line(P([(10, 12 + i * 8), (28, 14 + i * 8)]), fill=c, width=S) for i in range(4)], D + (200,)))
    make("shin.png", 40, 40, lambda d: (d.polygon(P([(10, 2), (30, 2), (27, 38), (14, 38)]), fill=255), d.polygon(P([(10, 12), (0, 20), (11, 22)]), fill=255), d.polygon(P([(11, 26), (2, 33), (12, 34)]), fill=255)), D,
         lines(lambda d, c: d.line(P([(20, 4), (20, 36)]), fill=c, width=S), A + (180,)))
    make("foot.png", 56, 30, lambda d: (d.polygon(P([(4, 6), (30, 4), (54, 18), (48, 28), (20, 29), (4, 22)]), fill=255), d.polygon(P([(44, 16), (56, 22), (46, 26)]), fill=255)), D,
         lines(lambda d, c: [d.line(P([(34, 10), (54, 20 + i * 3)]), fill=c, width=S) for i in range(3)], A + (220,)))
    make("upper_arm.png", 58, 26, lambda d: (d.ellipse(E((2, 2, 54, 24)), fill=255), d.polygon(P([(22, 4), (30, -2), (36, 5)]), fill=255)), C,
         lines(lambda d, c: [d.line(P([(14 + i * 10, 4), (12 + i * 10, 22)]), fill=c, width=S) for i in range(4)], D + (190,)))
    make("forearm.png", 58, 24, lambda d: (d.polygon(P([(2, 5), (50, 7), (56, 12), (50, 17), (2, 20)]), fill=255), d.polygon(P([(20, 18), (34, 28), (38, 17)]), fill=255)), D,
         lines(lambda d, c: [d.line(P([(10 + i * 11, 6), (10 + i * 11, 19)]), fill=c, width=S) for i in range(4)], A + (200,)))
    make("hand.png", 28, 28, lambda d: (d.ellipse(E((4, 6, 20, 22)), fill=255), d.polygon(P([(16, 8), (28, 6), (20, 13)]), fill=255), d.polygon(P([(16, 18), (28, 22), (19, 14)]), fill=255)), D)
    # head: faceted compound eyes, brow plates, mandibles (eyes are painted in, no extra layer)
    def head_det(img, m):
        lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
        d.ellipse(E((44, 26, 98, 74)), fill=(150, 36, 40, 255)); d.ellipse(E((44, 26, 98, 74)), outline=(30, 10, 14, 255), width=S * 2)
        for gx in range(48, 96, 7):
            for gy in range(30, 72, 7): d.ellipse(E((gx, gy, gx + 4, gy + 4)), fill=(225, 80, 70, 255))
        d.ellipse(E((52, 32, 64, 42)), fill=(255, 255, 255, 220))
        img.alpha_composite(lay)
    make("head.png", 108, 100, lambda d: (d.ellipse(E((8, 4, 100, 80)), fill=255), d.polygon(P([(70, 70), (100, 82), (92, 99), (78, 90)]), fill=255), d.polygon(P([(50, 76), (60, 99), (68, 80)]), fill=255), d.polygon(P([(30, 6), (46, 0), (60, 8)]), fill=255)), C, head_det)
    # extras
    make("abdomen.png", 76, 64, lambda d: d.ellipse(E((2, 4, 74, 60)), fill=255), C,
         lines(lambda d, c: [d.arc(E((-6 + i * 12, 0, 40 + i * 12, 64)), 250, 110, fill=c, width=int(2.4 * S)) for i in range(5)], D + (210,)))
    make("antenna.png", 60, 40, lambda d: d.line(P([(2, 36), (24, 16), (56, 8)]), fill=255, width=int(3 * S)), D, outline=1.2, hl=False)
    make("mid_limb.png", 56, 26, lambda d: (d.polygon(P([(2, 10), (26, 6), (30, 12), (6, 16)]), fill=255), d.polygon(P([(26, 6), (54, 18), (50, 23), (22, 12)]), fill=255)), D, outline=1.4, hl=False)
    # wings: translucent membrane + veins, pivot at the left end
    def wing(name, w, h, poly, vein):
        img = g.canvas(w, h); m = g.mask_of(w, h, lambda d: d.polygon(P(poly), fill=255))
        mem = Image.new("RGBA", img.size, (170, 235, 220, 120)); img.paste(mem, (0, 0), m)
        edge = m.filter(ImageFilter.MaxFilter(5 * S // 2 | 1)); ring = ImageChops.subtract(edge, m)
        img.paste(Image.new("RGBA", img.size, (24, 70, 62, 230)), (0, 0), ring)
        g.line_on(img, m, vein, (30, 90, 80, 200), 0.4); g.save(img, name, w, h)
        gl = g.canvas(w, h); g.line_on(gl, m, vein, (120, 255, 220, 255), 1.2); g.save(gl, name.replace(".png", "_glow.png"), w, h)
    wing("wing_fore.png", 150, 60, [(4, 30), (30, 8), (100, 2), (148, 16), (120, 40), (60, 52), (10, 40)],
         lambda d, c: [d.line(P([(6, 30), (140 - i * 6, 8 + i * 9)]), fill=c, width=int(1.6 * S)) for i in range(5)])
    wing("wing_hind.png", 110, 44, [(4, 24), (30, 6), (84, 4), (108, 22), (80, 38), (24, 40)],
         lambda d, c: [d.line(P([(6, 24), (100 - i * 6, 8 + i * 7)]), fill=c, width=int(1.4 * S)) for i in range(4)])

# =========================================================================== LUMEN SEER (slender luminous alien)
def lumen():
    out("lumen")
    B = (168, 156, 232); D = (96, 88, 176); GL = (96, 240, 255)
    make("torso.png", 88, 92, lambda d: d.polygon(P([(26, 2), (62, 0), (68, 24), (62, 60), (54, 90), (36, 91), (28, 60), (22, 24)]), fill=255), B,
         lines(lambda d, c: ([d.arc(E((22, 10 + i * 14, 68, 36 + i * 14)), 200, 340, fill=c, width=int(2 * S)) for i in range(4)], d.line(P([(45, 6), (45, 86)]), fill=c, width=int(1.6 * S))), GL + (255,), 0.9))
    make("waist.png", 48, 24, lambda d: d.ellipse(E((12, 2, 36, 22)), fill=255), D, lines(lambda d, c: d.line(P([(16, 12), (32, 12)]), fill=c, width=S), GL + (255,), 0.8))
    make("thigh.png", 36, 48, lambda d: d.polygon(P([(12, 6), (24, 6), (28, 24), (24, 46), (14, 46), (10, 24)]), fill=255), B)
    make("shin.png", 40, 40, lambda d: d.polygon(P([(15, 2), (25, 2), (27, 22), (23, 38), (17, 38), (13, 22)]), fill=255), B,
         lines(lambda d, c: d.line(P([(20, 4), (20, 36)]), fill=c, width=S), GL + (255,), 0.9))
    make("foot.png", 56, 30, lambda d: d.polygon(P([(6, 8), (22, 6), (54, 20), (52, 26), (20, 28), (6, 22)]), fill=255), D, lines(lambda d, c: d.line(P([(30, 14), (52, 22)]), fill=c, width=S), GL + (255,), 0.8))
    make("upper_arm.png", 58, 26, lambda d: (d.polygon(P([(6, 8), (50, 10), (50, 16), (6, 19)]), fill=255), d.ellipse(E((2, 5, 20, 22)), fill=255)), B)
    make("forearm.png", 58, 24, lambda d: (d.polygon(P([(4, 7), (52, 9), (54, 13), (52, 16), (4, 18)]), fill=255), d.ellipse(E((2, 5, 16, 20)), fill=255)), B,
         lines(lambda d, c: d.line(P([(10, 12), (50, 12)]), fill=c, width=S), GL + (255,), 0.8))
    def hand_det(img, m):
        for cx, cy in ((26, 7), (27, 14), (25, 21)): glow_dot(img, cx, cy, 1.8, GL)
    make("hand.png", 28, 28, lambda d: (d.ellipse(E((3, 8, 14, 20)), fill=255), d.line(P([(10, 10), (26, 6)]), fill=255, width=3 * S), d.line(P([(10, 14), (27, 14)]), fill=255, width=3 * S), d.line(P([(10, 18), (25, 21)]), fill=255, width=3 * S)), B, hand_det, outline=1.4)
    def head_det(img, m):
        lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
        d.polygon(P([(48, 46), (92, 40), (98, 56), (66, 66), (52, 60)]), fill=(10, 14, 36, 255))
        img.alpha_composite(lay); glow_dot(img, 74, 52, 4.2, GL)
        g.line_on(img, m, lambda dd, c: [dd.arc(E((8 + i * 8, 2 + i * 3, 96 - i * 4, 70)), 205, 320, fill=c, width=int(1.6 * S)) for i in range(4)], GL + (200,), 0.8)
    make("head.png", 108, 100, lambda d: (d.ellipse(E((14, -2, 92, 76)), fill=255), d.polygon(P([(36, 54), (82, 54), (66, 98), (50, 94)]), fill=255)), B, head_det)
    # fx pieces
    ring = g.canvas(120, 40); dd = ImageDraw.Draw(ring)
    for i, a in enumerate((60, 110, 200)):
        dd.ellipse(E((4 + i * 8, 6 + i * 3, 116 - i * 8, 34 - i * 3)), outline=GL + (a,), width=int((3 - i * 0.6) * S))
    ring = ring.filter(ImageFilter.GaussianBlur(0.6 * S)); g.save(ring, "halo.png", 120, 40)
    orb = g.canvas(24, 24); glow_dot(orb, 12, 12, 3.2, GL); g.save(orb, "orb.png", 24, 24)

# =========================================================================== NIGHT GUARDIAN (superhero)
def guardian():
    out("guardian")
    N = (24, 30, 52); N2 = (40, 52, 86); SK = (222, 176, 146); AC = (210, 220, 236)
    make("torso.png", 88, 92, lambda d: d.polygon(P([(4, 6), (44, 0), (86, 8), (84, 36), (72, 66), (66, 90), (30, 91), (22, 66), (8, 38)]), fill=255), N,
         multi(lines(lambda d, c: ([d.arc(E((14, 8, 44, 36)), 20, 160, fill=c, width=int(1.8 * S)), d.arc(E((44, 8, 76, 36)), 20, 160, fill=c, width=int(1.8 * S))], [d.line(P([(30, y), (62, y)]), fill=c, width=int(1.4 * S)) for y in (46, 56, 66)]), N2 + (255,), 0.5),
               lines(lambda d, c: d.polygon(P([(44, 16), (62, 28), (44, 50), (26, 28)]), outline=c, width=int(3 * S)), AC + (240,), 0.4),
               lines(lambda d, c: d.polygon(P([(20, 74), (68, 74), (66, 88), (24, 88)]), fill=c), (200, 160, 50, 255), 0.4)))
    make("waist.png", 48, 24, lambda d: d.rounded_rectangle(P([(4, 2), (44, 22)]), radius=5 * S, fill=255), N2,
         lines(lambda d, c: [d.rectangle(E((8 + i * 14, 6, 16 + i * 14, 16)), fill=c) for i in range(3)], (200, 160, 50, 255), 0.3))
    make("thigh.png", 36, 48, lambda d: d.polygon(P([(6, 6), (32, 6), (34, 30), (28, 46), (10, 46), (4, 28)]), fill=255), N,
         lines(lambda d, c: d.line(P([(10, 12), (28, 40)]), fill=c, width=S), N2 + (255,)))
    make("shin.png", 40, 40, lambda d: (d.polygon(P([(10, 2), (30, 2), (28, 38), (13, 38)]), fill=255), d.polygon(P([(10, 8), (-2, 14), (10, 24)]), fill=255)), N2,
         lines(lambda d, c: d.line(P([(20, 6), (20, 34)]), fill=c, width=S), AC + (200,)))
    make("foot.png", 56, 30, lambda d: d.polygon(P([(4, 6), (30, 4), (55, 20), (50, 28), (6, 28)]), fill=255), N,
         lines(lambda d, c: d.line(P([(8, 24), (50, 24)]), fill=c, width=int(1.5 * S)), N2 + (255,)))
    make("upper_arm.png", 58, 26, lambda d: (d.rounded_rectangle(P([(4, 3), (54, 23)]), radius=9 * S, fill=255)), N,
         lines(lambda d, c: d.line(P([(6, 8), (50, 8)]), fill=c, width=S), N2 + (255,)))
    make("forearm.png", 58, 24, lambda d: (d.rounded_rectangle(P([(4, 4), (54, 20)]), radius=7 * S, fill=255), d.polygon(P([(18, 18), (26, 30), (34, 18)]), fill=255), d.polygon(P([(32, 18), (40, 28), (46, 18)]), fill=255)), N2,
         lines(lambda d, c: [d.line(P([(10 + i * 12, 5), (10 + i * 12, 19)]), fill=c, width=S) for i in range(4)], AC + (210,)))
    make("hand.png", 28, 28, lambda d: d.ellipse(E((4, 5, 24, 23)), fill=255), N, lines(lambda d, c: d.line(P([(8, 14), (22, 14)]), fill=c, width=S), N2 + (255,)))
    def head_det(img, m):
        lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
        for pts in ([(52, 48), (76, 44), (74, 58), (56, 60)], [(80, 44), (100, 48), (98, 60), (82, 58)]): d.polygon(P(pts), fill=(255, 255, 255, 255))
        img.alpha_composite(lay)
    cowl = lambda d: (d.ellipse(E((3, -2, 105, 82)), fill=255), d.polygon(P([(18, 18), (10, -12), (38, 8)]), fill=255), d.polygon(P([(58, 4), (66, -12), (84, 10)]), fill=255))
    img = g.canvas(108, 100); m = g.mask_of(108, 100, cowl)
    cut = g.mask_of(108, 100, lambda d: d.polygon(P([(0, 100), (0, 72), (46, 68), (76, 74), (108, 68), (108, 100)]), fill=255))
    jaw = g.mask_of(108, 100, lambda d: d.ellipse(E((14, 40, 100, 98)), fill=255))
    g.solid(img, ImageChops.multiply(jaw, cut.point(lambda v: 255 - v) if False else jaw), fill=SK + (255,), outline=2.0, shade=0.25)
    g.solid(img, ImageChops.subtract(m, cut), fill=N + (255,), outline=2.0, shade=0.3)
    head_det(img, m); g.save(img, "head.png", 108, 100)
    # cape: tall banner with scalloped hem; Polygon2D deforms it in flight
    cape = g.canvas(96, 150); cm = g.mask_of(96, 150, lambda d: d.polygon(P([(30, 0), (66, 0), (78, 40), (92, 100), (84, 136), (70, 146), (60, 134), (46, 148), (34, 134), (22, 146), (12, 130), (8, 90), (18, 40)]), fill=255))
    g.solid(cape, cm, fill=N + (255,), outline=2.0, shade=0.35, hl=False)
    g.line_on(cape, cm, lambda d, c: [d.line(P([(34 + i * 8, 6), (22 + i * 14, 140)]), fill=c, width=int(1.6 * S)) for i in range(5)], N2 + (210,), 0.9)
    g.line_on(cape, cm, lambda d, c: d.polygon(P([(30, 0), (66, 0), (62, 14), (34, 14)]), fill=c), (190, 40, 50, 255), 0.4)
    g.save(cape, "cape.png", 96, 150)

if __name__ == "__main__":
    insectoid(); lumen(); guardian()
