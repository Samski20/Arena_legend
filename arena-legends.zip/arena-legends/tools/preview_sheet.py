import sys, glob
from PIL import Image
def sheet(paths, out, tint=None, bg=(52,62,74), cols=5, scale=1.0, pad=8):
    ims=[]
    for p in paths:
        im=Image.open(p).convert('RGBA')
        if tint:
            r,g,b=tint
            px=im.load()
            from PIL import ImageChops
            t=Image.new('RGBA',im.size,(r,g,b,255)); im=ImageChops.multiply(im,t)
        if scale!=1.0: im=im.resize((int(im.width*scale),int(im.height*scale)),Image.LANCZOS)
        ims.append(im)
    rows=[];cur=[];
    for i,im in enumerate(ims):
        cur.append(im)
        if len(cur)==cols: rows.append(cur);cur=[]
    if cur: rows.append(cur)
    W=max(sum(i.width+pad for i in r) for r in rows)+pad
    H=sum(max(i.height for i in r)+pad for r in rows)+pad
    S=Image.new('RGBA',(W,H),bg+(255,))
    y=pad
    for r in rows:
        x=pad
        for im in r:
            S.alpha_composite(im,(x,y)); x+=im.width+pad
        y+=max(i.height for i in r)+pad
    S.save(out)
if __name__=='__main__':
    out=sys.argv[1]; tint=tuple(int(x) for x in sys.argv[2].split(',')) if sys.argv[2]!='-' else None
    sheet(sys.argv[3:], out, tint, cols=int(__import__('os').environ.get('COLS','5')), scale=float(__import__('os').environ.get('SC','1')))
