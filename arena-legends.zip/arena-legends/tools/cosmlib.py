#!/usr/bin/env python3
"""Full-body costume art for the cosmetic characters (2x, painted, baked colours; hue variants are made in game).
Every character has its OWN silhouettes and build, drawn on the same canvases / joints as every other body set:
  night_guardian  heavy armoured brawler      void_hunter    lean angular predator      solar_sentinel  tall radiant knight
  lumen_seer      slender floating mystic     insectoid      hunched chitin flyer       (comet vanguard: herolib.py)
Run through tools/gen_cosmetics_v2.py."""
import os
import numpy as np
import artlib as A
import outfitlib as O

COSM = "art/cosmetics/"


def P(pts, r=0.5):
    return A.smooth(A.poly(pts), r)


def L(pts, w, curve=True):
    return A.line(A.curve_pts(pts, 12) if curve and len(pts) > 2 else pts, w)


def polar(cx, cy, r, n, a0=-90.0, inner=None):
    pts = []
    for i in range(n * (2 if inner else 1)):
        a = np.radians(a0 + i * 360.0 / (n * (2 if inner else 1)))
        rr = r if (not inner or i % 2 == 0) else inner
        pts.append((cx + rr * np.cos(a), cy + rr * np.sin(a)))
    return pts


class CP(O.Piece):
    """A baked-colour body piece."""

    def __init__(self, slot, color, silfn=None, material="cloth", **kw):
        O.canvas(slot)
        sil = silfn() if silfn else None
        kw.setdefault("pad", 0)
        super().__init__(slot, sil=sil, material=material, **kw)
        self.img[..., :3] *= np.array(color, np.float32) / 255.0

    def tone(self, mask, color, alpha=1.0):
        """flat colour region inside the silhouette (keeps the shading underneath)"""
        lay = A.tint_layer(A.inter(mask, self.sil), color, alpha)
        # multiply-ish: keep the lighting by darkening the colour with the base luminance
        lum = np.clip(self.img[..., :3].mean(-1, keepdims=True) * 1.25, 0.25, 1.1)
        lay[..., :3] = np.clip(lay[..., :3] * lum, 0, 1)
        self.img = A.over(lay, self.img)

    def plate(self, pts_or_mask, color, bevel=2.2, outline=0.75, material="metal", r=0.5, **kw):
        m = pts_or_mask if isinstance(pts_or_mask, np.ndarray) else P(pts_or_mask, r)
        return self.panel(m, bevel=bevel, outline=outline, material=material, color=color, **kw)

    def finish(self, folder, glow=None):
        O.canvas(self.slot)
        out = A.over(self.detail, self.img)
        if self.glow is not None and glow is not None:
            g = self.glow.copy()
            g[..., :3] = np.array(glow, np.float32) / 255.0
            out = A.over(g, out)
        os.makedirs(COSM + folder, exist_ok=True)
        A.save(out, "%s%s/%s.png" % (COSM, folder, self.slot))


def S(poly_pts, r=1.4):
    return lambda: A.smooth(A.poly(poly_pts), r)


# =============================================================================================== NIGHT GUARDIAN
def night_guardian(folder="guardian"):
    N = (46, 56, 92); N2 = (80, 96, 142); N3 = (30, 36, 62); SIL = (196, 206, 226); AMB = (214, 166, 52); GL = (150, 205, 255)

    p = CP("torso", N, S([(2, 9), (44, 4), (87, 11), (87, 40), (79, 70), (72, 89), (24, 89), (14, 70), (4, 40)], 1.4), bevel=5.5)
    p.tone(A.poly([(0, 0), (88, 0), (88, 30), (0, 30)]), N2, 0.25)
    p.plate([(13, 11), (44, 6), (75, 11), (72, 40), (44, 52), (16, 40)], N2, bevel=3.2)
    # armoured collar yoke + shoulder caps
    p.plate([(5, 9), (22, 5), (34, 16), (14, 26), (4, 20)], N3, bevel=2.4)
    p.plate([(83, 11), (66, 6), (56, 17), (74, 28), (85, 22)], N3, bevel=2.4)
    # shield emblem
    p.plate([(44, 14), (58, 24), (44, 44), (30, 24)], N3, bevel=1.4, outline=0.6)
    p.plate(P([(44, 18), (53, 25), (44, 39), (35, 25)], 0.3), SIL, bevel=1.0, outline=0.4)
    p.d_flat(P([(44, 23), (49, 27), (44, 34), (39, 27)], 0.2), N3, 0.95)
    # abdominal plates
    for i, y in enumerate((53, 61, 69, 77)):
        w = 18 - i * 1.5
        p.plate(O.rrect(44 - w, y, 44 + w, y + 6.5, 1.0), N2 if i % 2 == 0 else (44, 54, 86), bevel=1.6, outline=0.6)
    p.seam([(14, 44), (20, 66), (24, 88)], 0.6, 0.55)
    p.seam([(74, 44), (68, 66), (64, 88)], 0.6, 0.55)
    p.stitch([(31, 14), (30, 40)], 0.3, 2.6)
    p.glow_lines([[(18, 40), (44, 51), (70, 40)], [(30, 24), (44, 14), (58, 24), (44, 44), (30, 24)]], 0.55)
    p.finish(folder, GL)

    p = CP("waist", (34, 40, 68), S([(3, 3), (45, 3), (44, 22), (4, 22)], 1.2), bevel=3.5)
    p.plate(O.rrect(3, 3, 45, 11, 1.2), AMB, bevel=1.8)
    for x in (9, 18, 30, 39):
        p.plate(O.rrect(x - 3.2, 10, x + 3.2, 21, 1.0), (38, 46, 74), bevel=1.5, outline=0.6)
        p.d_line([(x - 2, 13), (x + 2, 13)], 0.4, (22, 26, 42), curve=False)
    p.plate(O.rrect(20.5, 4, 27.5, 10, 0.8), SIL, bevel=1.2, outline=0.5)
    p.finish(folder)

    p = CP("thigh", N, S([(6, 4), (31, 4), (35, 28), (29, 46), (9, 46), (3, 28)], 1.8), bevel=4.5)
    p.plate([(8, 8), (30, 8), (31, 26), (26, 30), (11, 30), (8, 26)], N2, bevel=2.2)
    p.seam([(10, 33), (26, 33)], 0.5, 0.5)
    p.plate(O.rrect(6, 34, 31, 40, 0.8), N3, bevel=1.2, outline=0.5)
    p.finish(folder)

    p = CP("shin", N2, S([(9, 3), (31, 3), (30, 37), (13, 37)], 1.6), bevel=4.0)
    p.plate([(10, 4), (30, 4), (29, 17), (11, 17)], N3, bevel=2.0)                    # knee guard
    p.plate([(11, 19), (29, 19), (27, 36), (14, 36)], N, bevel=1.8)
    for y in (22, 27, 32):
        p.d_line([(13, y), (27, y)], 0.45, SIL, curve=False, alpha=0.9)
    p.finish(folder)

    p = CP("foot", N3, S([(4, 5), (27, 3), (36, 8), (50, 15), (54, 22), (51, 27), (6, 27)], 1.8), bevel=4.0, material="leather")
    p.plate([(34, 8), (50, 15), (53, 22), (44, 24), (34, 14)], (150, 160, 180), bevel=2.0)           # steel toe
    p.plate(O.rrect(4, 22, 52, 27, 1.0), (14, 16, 26), bevel=1.2)
    p.d_line([(8, 8), (26, 6)], 0.4, N2, curve=False)
    p.finish(folder)

    p = CP("upper_arm", N, S([(4, 4), (24, 3), (46, 6), (54, 13), (46, 21), (24, 23), (4, 22)], 2.4), bevel=4.0)
    p.plate(P([(2, 2), (24, 1), (28, 13), (22, 24), (2, 24)], 2.0), N2, bevel=2.8)                    # pauldron
    p.plate(O.rrect(30, 5, 36, 21, 0.8), N3, bevel=1.2, outline=0.5)
    p.plate(P([(44, 6), (54, 13), (44, 20)], 1.2), N2, bevel=1.6)
    p.finish(folder)

    p = CP("forearm", N2, S([(4, 5), (28, 5), (49, 8), (54, 12), (49, 16), (28, 19), (4, 19)], 1.6), bevel=3.5)
    O.canvas("forearm")
    for x in (16, 26, 36):                                                     # three gauntlet fins
        fin = P([(x, 17), (x + 5, 17), (x + 10, 23.5), (x + 2, 21)], 0.3)
        p.plate(fin, SIL, bevel=1.0, outline=0.55)
    p.plate([(10, 6), (46, 8), (47, 17), (10, 18)], N3, bevel=2.2)
    p.plate(O.rrect(12, 8, 22, 16, 1.0), N2, bevel=1.4, outline=0.5)
    p.d_line([(26, 9), (44, 10)], 0.35, SIL, curve=False)
    p.finish(folder)

    p = CP("hand", N3, S([(5, 6), (21, 5), (24, 14), (21, 22), (6, 22), (3, 14)], 1.5), bevel=3.0, material="leather")
    p.plate(O.rrect(6, 6, 20, 12, 1.0), N2, bevel=1.4, outline=0.5)
    for y in (13.5, 17):
        p.d_line([(13, y), (23, y)], 0.35, (14, 16, 26), curve=False)
    p.finish(folder)


def cape(folder, base, fold, hem, style="long"):
    """Cape / cloak picture (96x150). Deformed in game by CapeFx."""
    O.canvas("cape") if "cape" in O.SIZES else A.set_canvas(96, 150, 0, 0, 2, 3)
    A.set_canvas(96, 150, 0, 0, 2, 3)
    if style == "long":
        pts = [(30, 0), (66, 0), (78, 40), (92, 100), (86, 134), (74, 146), (62, 134), (48, 148), (36, 134), (22, 146), (12, 130), (8, 90), (18, 40)]
    else:   # ragged half cloak
        pts = [(30, 0), (66, 0), (76, 36), (88, 80), (82, 100), (74, 92), (68, 112), (58, 96), (50, 118), (40, 98), (30, 114), (22, 94), (12, 104), (8, 78), (18, 36)]
    sil = A.smooth(A.poly(pts), 1.2 if style == "long" else 0.5)
    tex = np.zeros((A.IH, A.IW), np.float32)
    for i in range(7):
        A.line(A.curve_pts([(34 + i * 6, 6), (24 + i * 11, 70), (20 + i * 12, 140)], 12), 1.4, tex)
    tex = (tex - 0.5) * 0.3
    img = A.paint(sil, base, "cloth", bevel=6.0, outline=1.1, ambient=0.46, texture=tex, spec=0.12)
    f = np.zeros((A.IH, A.IW), np.float32)
    for i in range(5):
        A.line(A.curve_pts([(38 + i * 7, 10), (30 + i * 12, 70), (26 + i * 13, 130)], 12), 1.0, f)
    img = A.over(A.tint_layer(A.inter(f, sil), fold, 0.5), img)
    hemm = A.inter(A.sub(sil, A.shift(sil, 0, -4.0)), A.half_plane((0, 100), (96, 100), below=True)) if style == "long" else A.inter(A.sub(sil, A.shift(sil, 0, -3.0)), A.half_plane((0, 80), (96, 80), below=True))
    img = A.over(A.tint_layer(hemm, hem, 0.95), img)
    collar = A.inter(A.poly([(30, 0), (66, 0), (64, 12), (32, 12)]), sil)
    img = A.over(A.paint(A.smooth(collar, 0.3), hem, "metal", bevel=1.4, outline=0.8, ambient=0.5, spec=0.5), img)
    os.makedirs(COSM + folder, exist_ok=True)
    A.save(img, "%s%s/cape.png" % (COSM, folder))


# =============================================================================================== VOID HUNTER
def void_hunter(folder="hunter"):
    B = (38, 40, 52); B2 = (68, 72, 90); B3 = (22, 24, 32); BONE = (206, 196, 172); OR = (255, 138, 77)

    p = CP("torso", B, S([(12, 6), (44, 2), (76, 7), (72, 30), (63, 58), (60, 87), (34, 87), (28, 58), (16, 32)], 1.0), bevel=5.5, material="matte")
    # swept spine/collar blades
    p.plate([(10, 6), (26, 1), (38, 14), (22, 22)], B2, bevel=2.2)
    p.plate([(78, 7), (60, 2), (50, 14), (66, 22)], B2, bevel=2.2)
    # sternum armour: angular, V shaped
    p.plate([(44, 8), (62, 22), (56, 46), (44, 58), (32, 46), (26, 22)], B2, bevel=3.0)
    p.plate([(44, 14), (55, 24), (50, 42), (44, 50), (38, 42), (33, 24)], B3, bevel=1.6, outline=0.55)
    # exposed ribs (bone)
    for i, y in enumerate((60, 66, 72, 78)):
        w = 12 - i * 1.4
        p.plate(O.rrect(44 - w, y, 44 + w, y + 3.6, 0.9), BONE, bevel=1.1, outline=0.55, material="matte")
    p.seam([(28, 30), (34, 60), (36, 86)], 0.5, 0.6)
    p.seam([(60, 30), (54, 60), (52, 86)], 0.5, 0.6)
    p.glow_lines([[(44, 16), (44, 52)], [(33, 26), (38, 42), (44, 50), (50, 42), (55, 26)], [(14, 14), (24, 22)], [(74, 14), (64, 22)]], 0.8)
    p.finish(folder, OR)

    p = CP("waist", B, S([(5, 3), (43, 3), (41, 21), (7, 21)], 1.4), bevel=3.5, material="matte")
    p.plate(P([(10, 4), (38, 4), (34, 18), (14, 18)], 0.8), B2, bevel=1.8)
    p.plate(P([(20, 5), (28, 5), (24, 21)], 0.4), BONE, bevel=1.0, outline=0.5, material="matte")
    p.glow_lines([[(11, 6), (13, 17)], [(37, 6), (35, 17)]], 0.6)
    p.finish(folder, OR)

    p = CP("thigh", B, S([(10, 4), (28, 4), (31, 26), (26, 46), (11, 46), (7, 26)], 1.8), bevel=4.5, material="matte")
    p.plate([(11, 6), (27, 6), (28, 24), (19, 32), (10, 24)], B2, bevel=2.0)
    p.plate(P([(5, 14), (12, 10), (11, 30)], 0.4), B3, bevel=1.2, outline=0.5)                 # side blade fin
    p.glow_lines([[(19, 10), (19, 28)]], 0.5)
    p.finish(folder, OR)

    # digitigrade-looking shin: a wedge with a knee spike and a heel spur
    p = CP("shin", B, S([(11, 2), (29, 2), (27, 20), (24, 37), (15, 37), (14, 20)], 1.4), bevel=3.5, material="matte")
    p.plate([(12, 3), (28, 3), (26, 16), (14, 16)], B2, bevel=1.8)
    p.plate(P([(28, 4), (38, 12), (29, 12)], 0.3), BONE, bevel=1.0, outline=0.5, material="matte")      # knee spike
    p.plate(P([(14, 24), (7, 36), (16, 33)], 0.3), B3, bevel=1.0, outline=0.5)                         # heel spur
    p.glow_lines([[(20, 19), (20, 34)]], 0.5)
    p.finish(folder, OR)

    # taloned foot
    p = CP("foot", B3, S([(6, 6), (24, 4), (40, 9), (52, 17), (55, 22), (49, 26), (30, 26), (22, 27), (7, 26)], 1.4), bevel=3.5, material="matte")
    for i, (x0, y0, x1, y1) in enumerate(((44, 14, 55, 19), (46, 19, 55, 24), (40, 23, 51, 27.5))):
        p.plate(P([(x0, y0 - 1.6), (x1, y1), (x0, y0 + 1.6)], 0.2), BONE, bevel=0.8, outline=0.45, material="matte")
    p.plate([(8, 7), (30, 5), (36, 12), (10, 15)], B2, bevel=1.8)
    p.glow_lines([[(10, 12), (30, 10)]], 0.5)
    p.finish(folder, OR)

    p = CP("upper_arm", B, S([(5, 7), (24, 5), (46, 8), (52, 13), (46, 18), (24, 21), (5, 20)], 2.0), bevel=3.5, material="matte")
    p.plate(P([(2, 12), (10, 2), (22, 3), (24, 14), (14, 24), (3, 22)], 1.2), B2, bevel=2.4)         # shoulder guard
    p.plate(P([(10, 3), (18, -2), (22, 6)], 0.3), BONE, bevel=1.0, outline=0.5, material="matte")      # shoulder spike
    p.plate(P([(40, 7), (52, 13), (40, 19)], 0.8), B3, bevel=1.4, outline=0.55)
    p.glow_lines([[(28, 9), (38, 9)]], 0.5)
    p.finish(folder, OR)

    p = CP("forearm", B, S([(5, 7), (28, 7), (48, 9), (54, 12), (48, 15), (28, 17), (5, 17)], 1.4), bevel=3.0, material="matte")
    p.plate([(8, 7), (30, 7), (46, 10), (30, 17), (8, 17)], B2, bevel=1.8)
    p.plate(P([(30, 14), (46, 20), (56, 23), (36, 17)], 0.2), BONE, bevel=0.9, outline=0.5, material="matte")      # wrist blade
    p.plate(P([(30, 8), (44, 3), (52, 1), (38, 10)], 0.2), BONE, bevel=0.9, outline=0.5, material="matte")
    p.glow_lines([[(12, 12), (40, 12)]], 0.5)
    p.finish(folder, OR)

    p = CP("hand", B3, S([(6, 8), (18, 7), (22, 13), (18, 20), (7, 20), (4, 14)], 1.2), bevel=2.5, material="matte")
    for i, (x, y) in enumerate(((23, 8), (26, 13), (23, 18))):
        p.plate(P([(17, y - 2), (x + 3, y), (17, y + 2)], 0.2), BONE, bevel=0.8, outline=0.45, material="matte")
    p.finish(folder, OR)


# =============================================================================================== SOLAR SENTINEL
def solar_sentinel(folder="sentinel"):
    W = (236, 240, 248); W2 = (196, 206, 226); G = (234, 186, 70); G2 = (176, 128, 40); DK = (40, 44, 64); SUN = (255, 224, 120)

    p = CP("torso", W, S([(2, 9), (30, 3), (44, 5), (58, 3), (86, 9), (86, 38), (76, 66), (68, 89), (28, 89), (20, 66), (4, 38)], 1.6), bevel=5.5, material="metal", spec=0.3)
    p.plate([(14, 8), (44, 5), (74, 8), (72, 38), (44, 50), (16, 38)], W2, bevel=3.0)
    # pauldron ridges and a high gold gorget
    p.plate(P([(3, 9), (22, 4), (28, 15), (6, 24)], 1.0), G, bevel=2.4, spec=0.6)
    p.plate(P([(85, 9), (66, 4), (60, 15), (82, 24)], 1.0), G, bevel=2.4, spec=0.6)
    p.plate(P([(28, 3), (44, 8), (60, 3), (56, 14), (44, 20), (32, 14)], 0.8), G, bevel=2.2, spec=0.6)
    # sun medallion
    cx, cy = 44, 34
    p.plate(P(polar(cx, cy, 17, 12, inner=11), 0.4), G2, bevel=1.4, outline=0.5)                  # rays
    p.plate(A.ellipse(cx, cy, 10, 10), G, bevel=2.6, spec=0.7)
    p.plate(A.ellipse(cx, cy, 6.2, 6.2), SUN, bevel=2.0, outline=0.4, spec=0.8)
    for i, y in enumerate((54, 62, 70, 78)):
        w = 19 - i * 1.4
        p.plate(O.rrect(44 - w, y, 44 + w, y + 6, 1.0), W2 if i % 2 == 0 else W, bevel=1.5, outline=0.6)
    p.seam([(20, 44), (26, 66), (28, 88)], 0.6, 0.45)
    p.seam([(68, 44), (62, 66), (60, 88)], 0.6, 0.45)
    p.glow_lines([[(18, 40), (44, 52), (70, 40)], [(30, 46), (44, 56), (58, 46)]], 0.6)
    p.finish(folder, SUN)

    p = CP("waist", G, S([(3, 3), (45, 3), (44, 22), (4, 22)], 1.2), bevel=3.5, material="metal", spec=0.6)
    p.plate(O.rrect(5, 4, 43, 10, 1.0), G2, bevel=1.4)
    p.plate(A.ellipse(24, 13, 7, 7), W, bevel=2.0, spec=0.6)
    p.plate(A.ellipse(24, 13, 3.6, 3.6), SUN, bevel=1.2, outline=0.4)
    for x in (9, 39):
        p.plate(O.rrect(x - 4, 11, x + 4, 21, 1.0), W2, bevel=1.4, outline=0.6)
    p.finish(folder)

    p = CP("thigh", W, S([(6, 4), (31, 4), (34, 28), (28, 46), (10, 46), (4, 28)], 1.8), bevel=4.5, material="metal", spec=0.3)
    p.plate([(8, 7), (30, 7), (30, 27), (24, 32), (12, 32), (8, 27)], W2, bevel=2.2)
    p.plate(O.rrect(5, 36, 32, 44, 1.2), G, bevel=1.8, spec=0.6)
    p.d_line([(10, 10), (10, 28)], 0.5, G, curve=False)
    p.finish(folder)

    p = CP("shin", G, S([(9, 3), (31, 3), (30, 37), (13, 37)], 1.6), bevel=4.0, material="metal", spec=0.6)
    p.plate([(10, 4), (30, 4), (29, 15), (11, 15)], G2, bevel=1.8)
    p.plate(P([(10, 12), (-1, 20), (11, 28)], 0.4), W, bevel=1.4, outline=0.6)          # little wing at the knee
    p.plate([(13, 19), (28, 19), (26, 36), (14, 36)], W, bevel=1.6, outline=0.6)
    p.finish(folder)

    p = CP("foot", W, S([(4, 5), (27, 3), (36, 8), (50, 15), (54, 22), (51, 27), (6, 27)], 1.8), bevel=4.0, material="metal", spec=0.3)
    p.plate([(32, 8), (50, 15), (53, 22), (42, 24), (32, 14)], G, bevel=2.0, spec=0.6)
    p.plate(O.rrect(4, 22, 52, 27, 1.0), G2, bevel=1.2)
    p.plate(P([(6, 6), (-1, 2), (4, 14)], 0.3), W2, bevel=1.0, outline=0.5)
    p.finish(folder)

    p = CP("upper_arm", W, S([(4, 4), (24, 3), (46, 6), (54, 13), (46, 21), (24, 23), (4, 22)], 2.4), bevel=4.0, material="metal", spec=0.3)
    p.plate(P([(2, 2), (26, 0), (30, 13), (24, 25), (2, 24)], 2.0), G, bevel=3.0, spec=0.6)
    p.plate(P(polar(14, 13, 6, 8, inner=3.2), 0.3), W, bevel=1.0, outline=0.4)
    p.plate(O.rrect(32, 4, 38, 22, 0.8), G2, bevel=1.2, outline=0.5)
    p.finish(folder)

    p = CP("forearm", G, S([(4, 4), (28, 4), (49, 7), (54, 12), (49, 17), (28, 20), (4, 20)], 1.6), bevel=3.5, material="metal", spec=0.6)
    p.plate([(10, 5), (46, 8), (47, 17), (10, 19)], W, bevel=2.0, outline=0.6)
    for x in (18, 30, 42):
        p.d_line([(x, 7), (x, 18)], 0.5, G2, curve=False)
    p.plate(P([(4, 4), (14, 12), (4, 20)], 0.3), G2, bevel=1.2, outline=0.5)
    p.finish(folder)

    p = CP("hand", W, S([(5, 6), (21, 5), (24, 14), (21, 22), (6, 22), (3, 14)], 1.5), bevel=3.0, material="metal", spec=0.3)
    p.plate(O.rrect(6, 5, 20, 11, 1.0), G, bevel=1.4, outline=0.5, spec=0.6)
    for y in (13, 16.5, 20):
        p.d_line([(11, y), (22, y)], 0.35, W2, curve=False)
    p.finish(folder)


# =============================================================================================== LUMEN SEER
def lumen_seer(folder="lumen"):
    B = (176, 164, 238); B2 = (130, 118, 214); B3 = (84, 76, 160); LT = (226, 220, 255); GL = (96, 240, 255)

    p = CP("torso", B, S([(26, 3), (44, 1), (62, 3), (68, 24), (62, 56), (54, 88), (34, 88), (26, 56), (20, 24)], 1.8), bevel=7.0, material="skin", ambient=0.58)
    p.tone(A.poly([(40, 0), (88, 0), (88, 92), (40, 92)]), LT, 0.22)
    # tapered crystal core / sternum
    p.plate(P([(44, 12), (52, 26), (44, 44), (36, 26)], 0.5), B3, bevel=1.6, outline=0.55, material="glass")
    p.plate(P([(44, 16), (49, 26), (44, 38), (39, 26)], 0.4), LT, bevel=1.0, outline=0.3, material="glass")
    for i in range(5):
        y = 48 + i * 8
        w = 10 - i * 1.1
        p.d_line([(44 - w, y + 2), (44, y - 1), (44 + w, y + 2)], 0.5, B3, alpha=0.9)
    p.seam([(26, 10), (28, 44), (36, 88)], 0.45, 0.35)
    p.glow_lines([[(44, 8), (44, 12)], [(36, 26), (44, 44), (52, 26)], [(44, 46), (44, 86)], [(24, 14), (30, 30), (36, 40)], [(64, 14), (58, 30), (52, 40)]], 0.55)
    p.finish(folder, GL)

    p = CP("waist", B2, S([(12, 3), (36, 3), (34, 21), (14, 21)], 1.6), bevel=4.0, material="skin")
    p.plate(P([(16, 5), (32, 5), (24, 19)], 0.5), B3, bevel=1.4, outline=0.5, material="glass")
    p.glow_lines([[(18, 8), (24, 16), (30, 8)]], 0.5)
    p.finish(folder, GL)

    p = CP("thigh", B, S([(12, 4), (25, 4), (28, 24), (24, 46), (14, 46), (10, 24)], 2.0), bevel=5.0, material="skin", ambient=0.58)
    p.tone(A.poly([(20, 0), (36, 0), (36, 48), (20, 48)]), LT, 0.2)
    p.plate(P([(14, 20), (23, 20), (24, 28), (13, 28)], 0.8), B3, bevel=1.2, outline=0.5, material="glass")
    p.glow_lines([[(18, 6), (18, 18)], [(18, 30), (18, 44)]], 0.45)
    p.finish(folder, GL)

    p = CP("shin", B, S([(14, 2), (26, 2), (28, 18), (24, 38), (16, 38), (12, 18)], 1.8), bevel=4.5, material="skin", ambient=0.58)
    p.plate(P([(15, 3), (25, 3), (26, 11), (14, 11)], 0.8), B2, bevel=1.4, outline=0.5)
    p.glow_lines([[(20, 14), (20, 34)]], 0.5)
    p.finish(folder, GL)

    # no heavy boot: a pointed, hovering slipper
    p = CP("foot", B2, S([(8, 9), (22, 7), (40, 13), (53, 21), (50, 24), (22, 27), (8, 24)], 1.8), bevel=4.0, material="skin")
    p.plate(P([(10, 10), (24, 8), (34, 14), (12, 18)], 0.6), B3, bevel=1.4, outline=0.5, material="glass")
    p.glow_lines([[(14, 20), (46, 22)]], 0.5)
    p.finish(folder, GL)

    p = CP("upper_arm", B, S([(6, 8), (26, 7), (46, 10), (52, 13), (46, 17), (26, 20), (6, 19)], 2.0), bevel=4.0, material="skin", ambient=0.58)
    p.plate(A.ellipse(9, 13.5, 6.4, 6.4), B3, bevel=2.2, outline=0.6, material="glass")
    p.plate(A.ellipse(9, 13.5, 3.2, 3.2), LT, bevel=1.0, outline=0.3, material="glass")
    p.glow_lines([[(14, 13), (46, 13)]], 0.4)
    p.finish(folder, GL)

    p = CP("forearm", B, S([(5, 8), (28, 8), (48, 10), (54, 12), (48, 14), (28, 17), (5, 17)], 1.6), bevel=3.5, material="skin", ambient=0.58)
    p.plate(A.ellipse(7, 12.5, 5.4, 5.4), B3, bevel=2.0, outline=0.55, material="glass")
    p.glow_lines([[(12, 12.5), (50, 12.5)]], 0.45)
    p.finish(folder, GL)

    p = CP("hand", B, S([(5, 10), (14, 9), (14, 18), (5, 18)], 1.4), bevel=2.5, material="skin")
    O.canvas("hand")
    for (y, x1) in ((10, 26), (14, 27), (18, 25)):                     # three long fingers with glowing tips
        p.panel(L([(12, y), (x1 - 1, y - 0.5 + (y - 14) * 0.15)], 2.2), bevel=0.8, outline=0.5, material="skin", color=(176, 164, 238))
        p.d_flat(A.ellipse(x1, y - 0.4 + (y - 14) * 0.15, 1.2, 1.2), GL)
    p.glow_lines([[(8, 14), (12, 14)]], 0.4)
    p.finish(folder, GL)


# =============================================================================================== INSECTOID
def insectoid(folder="insectoid"):
    C = (46, 128, 100); C2 = (30, 92, 78); D = (18, 56, 50); AM = (240, 172, 60); PALE = (222, 206, 134)

    p = CP("torso", C, S([(8, 6), (30, 1), (60, 1), (82, 8), (87, 32), (80, 62), (66, 88), (42, 91), (22, 86), (8, 60), (2, 30)], 2.2), bevel=6.0, material="chitin")
    p.tone(P([(50, 6), (80, 12), (85, 40), (76, 70), (60, 86), (52, 50)], 2.0), PALE, 0.55)           # pale belly plates
    for i, y in enumerate((20, 38, 56, 74)):
        p.seam([(8 + i * 2, y), (44, y + 6), (80 - i * 2, y)], 0.8, 0.6)
    p.plate(P([(10, 6), (30, 1), (46, 12), (22, 24), (6, 20)], 1.2), C2, bevel=2.8, material="chitin")      # hunched shoulder shell
    for i in range(5):
        p.d_flat(A.ellipse(16 + i * 8, 16 + (i % 2) * 5, 1.5, 1.5), AM)
    p.d_flat(A.ellipse(66, 44, 2.0, 5.0), AM, 0.9)
    p.finish(folder)

    p = CP("waist", D, S([(4, 3), (44, 3), (44, 21), (4, 21)], 2.0), bevel=3.5, material="chitin")
    p.seam([(8, 9), (40, 9)], 0.6, 0.6)
    p.seam([(8, 15), (40, 15)], 0.6, 0.6)
    p.d_line([(10, 12), (38, 12)], 0.5, AM, curve=False, alpha=0.9)
    p.finish(folder)

    p = CP("thigh", C, S([(7, 5), (30, 5), (33, 26), (28, 46), (10, 46), (4, 26)], 2.4), bevel=5.0, material="chitin")
    for y in (14, 24, 34):
        p.seam([(8, y), (20, y + 3), (31, y)], 0.7, 0.55)
    p.plate(P([(6, 12), (-1, 20), (7, 26)], 0.3), D, bevel=1.0, outline=0.5, material="chitin")            # side spine
    p.finish(folder)

    p = CP("shin", D, S([(11, 2), (29, 2), (26, 20), (24, 37), (15, 37), (13, 20)], 1.6), bevel=3.5, material="chitin")
    p.plate(P([(11, 8), (1, 15), (11, 22)], 0.3), C, bevel=1.0, outline=0.5, material="chitin")
    p.plate(P([(12, 24), (3, 31), (13, 33)], 0.3), C, bevel=1.0, outline=0.5, material="chitin")
    p.d_line([(20, 4), (20, 34)], 0.5, AM, curve=False, alpha=0.85)
    p.finish(folder)

    p = CP("foot", D, S([(6, 6), (24, 4), (40, 9), (52, 17), (55, 22), (49, 26), (22, 27), (7, 26)], 1.4), bevel=3.5, material="chitin")
    for (x0, y0) in ((44, 14), (46, 19), (40, 23)):
        p.plate(P([(x0, y0 - 1.5), (55, y0 + 2), (x0, y0 + 1.5)], 0.2), PALE, bevel=0.8, outline=0.45, material="chitin")
    p.d_line([(34, 10), (50, 19)], 0.5, AM, curve=False, alpha=0.9)
    p.finish(folder)

    p = CP("upper_arm", C, S([(4, 5), (26, 3), (46, 7), (54, 13), (46, 20), (26, 23), (4, 21)], 2.4), bevel=4.5, material="chitin")
    p.plate(P([(3, 3), (22, 1), (28, 13), (20, 24), (3, 22)], 2.0), C2, bevel=2.6, material="chitin")
    p.plate(P([(18, 3), (26, -3), (32, 5)], 0.3), D, bevel=1.0, outline=0.5, material="chitin")
    for x in (34, 40, 46):
        p.seam([(x, 6), (x - 1, 20)], 0.6, 0.5)
    p.finish(folder)

    p = CP("forearm", D, S([(4, 6), (28, 6), (48, 9), (54, 12), (48, 15), (28, 18), (4, 18)], 1.4), bevel=3.5, material="chitin")
    for x in (14, 23, 32, 41):                                           # serrated blade edge under the forearm
        p.plate(P([(x, 16), (x + 4, 16), (x + 7, 22.5)], 0.2), PALE, bevel=0.8, outline=0.45, material="chitin")
    for x in (10, 20, 30, 40):
        p.d_line([(x, 7), (x, 16)], 0.45, AM, curve=False, alpha=0.85)
    p.finish(folder)

    p = CP("hand", C2, S([(4, 8), (16, 6), (20, 13), (16, 21), (5, 20)], 1.2), bevel=2.5, material="chitin")
    for (x, y) in ((26, 7), (27, 14), (25, 21)):
        p.plate(P([(15, y - 2.2), (x, y), (15, y + 2.2)], 0.2), PALE, bevel=0.8, outline=0.45, material="chitin")
    p.finish(folder)


def _guardian_all():
    night_guardian()
    cape("guardian", (52, 64, 104), (30, 38, 70), (196, 206, 226))


def _hunter_all():
    void_hunter()
    cape("hunter", (44, 46, 58), (22, 24, 32), (255, 138, 77), "ragged")


CHARS = {"night_guardian": _guardian_all, "void_hunter": _hunter_all, "solar_sentinel": solar_sentinel,
         "lumen_seer": lumen_seer, "insectoid": insectoid}
