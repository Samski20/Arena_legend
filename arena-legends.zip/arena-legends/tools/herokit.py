#!/usr/bin/env python3
"""Small compositing helpers shared by tools/gen_heroes.py (layered, clipped, form-shaded suit painting on body-kit canvases)."""
import os
import numpy as np
import cv2
import artlib as A
import bodykit as BK

OUT = "art/cosmetics/"


def dk(c, f=0.34):
    return tuple(int(v * f) for v in c)


def mix(a, b, t):
    return tuple(int(x * (1 - t) + y * t) for x, y in zip(a, b))


class Sheet:
    """One slot picture. All coordinates are in game px of the slot's joint space (torso/waist: rig px)."""

    def __init__(self, slot, sil_fn=None):
        self.slot = slot
        BK.canvas(slot)
        self.rig = slot in ("torso", "waist")
        self.sil = sil_fn() if sil_fn else BK.SIL[slot]()
        self.img = A.blank()
        self.cut = BK.joint_cut(slot)

    # ---- geometry (px)
    def P(self, pts):
        return BK.RP(self.slot, pts) if self.rig else BK.JP(self.slot, pts)

    def pt(self, x, y):
        return BK.R(self.slot, x, y) if self.rig else BK.J(self.slot, x, y)

    def poly(self, pts, sm=0.3):
        return A.smooth(A.poly(self.P(pts)), sm) if sm else A.poly(self.P(pts))

    def blob(self, pts, sm=0.3, n=8):
        """closed Catmull-Rom shape through the points"""
        return A.smooth(A.poly(A.curve_pts(self.P(pts), n, closed=True)), sm) if sm else A.poly(A.curve_pts(self.P(pts), n, closed=True))

    def ell(self, x, y, rx, ry, rot=0.0):
        cx, cy = self.pt(x, y)
        return A.ellipse(cx, cy, rx * 2, ry * 2, rot)

    def stroke(self, pts, w=0.5, curve=True, n=10):
        p = self.P(pts)
        return A.line(A.curve_pts(p, n) if curve and len(p) > 2 else p, w * 2)

    def taper(self, pts, widths, n=12):
        """a stroke of varying width along a centre line (px)"""
        cp = A.curve_pts(self.P(pts), n) if len(pts) > 2 else self.P(pts)
        m = A.empty()
        N = len(cp)
        for i in range(N - 1):
            t = i / max(1, N - 2)
            w = np.interp(t, np.linspace(0, 1, len(widths)), widths) * 2
            A.line([cp[i], cp[i + 1]], w, m)
        return m

    # ---- painting
    def base(self, color, material="cloth", bevel=6.0, outline=1.05, **kw):
        self.img = A.over(A.paint(self.sil, color, material, bevel=bevel, outline=outline, ol_cut=self.cut, **kw), self.img)

    def part(self, mask, color, material="cloth", bevel=2.5, outline=0.5, clip=True, ol=None, ol_f=0.34, **kw):
        ol = ol if ol is not None else dk(color, ol_f)
        p = A.paint(mask, color, material, bevel=bevel, outline=outline, ol_color=ol, **kw)
        if clip:
            c = self.sil if clip is True else clip
            p[..., 3] *= np.clip(c, 0, 1)
        self.img = A.over(p, self.img)

    def soft(self, mask, color, a, blur=1.0, clip=True):
        m = A.blur(mask, blur) if blur > 0 else mask
        if clip:
            m = A.inter(m, self.sil if clip is True else clip)
        self.img = A.over(A.tint_layer(m, color, a), self.img)

    def line(self, pts, color, w=0.5, a=0.6, hi=0.0, blur=0.25, curve=True, clip=True):
        m = self.stroke(pts, w, curve)
        self.soft(m, color, a, blur, clip)
        if hi > 0:
            self.soft(A.shift(m, -0.35, -0.55), (255, 255, 255), hi, blur, clip)

    def save(self, folder, name=None):
        os.makedirs(OUT + folder, exist_ok=True)
        A.save(self.img, "%s%s/%s.png" % (OUT, folder, name or self.slot))
