#!/usr/bin/env python3
"""Head shape model for the modular character system.

A HEAD is a silhouette (mask) plus ANCHORS found on that silhouette (scalp top, hairline, brow, eyes, mouth, chin,
jaw line, ear ...). Hair, facial hair, headgear and eyes are all generated FROM the silhouette and its anchors, so
every piece is cut to fit its head instead of being one picture stretched over all of them.

Heads face right (ear on the left), like the old head art. Design space is 108 x 100 (see artlib).
"""
import numpy as np
import artlib as A

# --------------------------------------------------------------------------- shape definitions
# A head = a CRANIUM (super-ellipse: cx, cy, rx, ry, n; n > 2 is boxier) joined to a FACE PLATE polygon that carries the
# forehead, cheekbones, jaw and chin (points run clockwise from the forehead, facing right). `r` rounds the corners.
SHAPES = {
    "round": dict(name="Round", sk=(52, 37, 47, 32, 2.0), r=2.4,
        face=[(86, 26), (100, 42), (99, 60), (95, 74), (86, 85), (70, 90), (52, 88), (38, 80), (28, 64), (24, 40)]),
    "oval": dict(name="Oval", sk=(51, 38, 43, 34, 2.0), r=2.4,
        face=[(86, 26), (96, 42), (95, 62), (91, 78), (81, 91), (65, 96), (50, 93), (38, 84), (28, 64), (24, 40)]),
    "square": dict(name="Square", sk=(52, 37, 47, 31, 3.2), r=1.0,
        face=[(86, 26), (101, 38), (101, 64), (100, 80), (96, 90), (60, 92), (40, 88), (30, 76), (26, 50)]),
    "angular": dict(name="Angular", sk=(52, 37, 47, 32, 2.6), r=0.7,
        face=[(86, 26), (101, 38), (103, 56), (97, 72), (89, 86), (81, 95), (66, 89), (46, 82), (32, 70), (26, 46)]),
    "long": dict(name="Long", sk=(51, 37, 41, 35, 2.2), r=1.8,
        face=[(86, 26), (92, 36), (92, 62), (90, 80), (84, 94), (68, 98), (52, 94), (40, 84), (30, 64), (26, 36)]),
    "broad": dict(name="Broad", sk=(53, 40, 50, 30, 2.4), r=1.8,
        face=[(86, 26), (103, 45), (103, 62), (97, 75), (85, 84), (64, 87), (44, 83), (32, 70), (24, 48)]),
    "narrow": dict(name="Narrow", sk=(50, 36, 40, 32, 2.0), r=2.0,
        face=[(86, 26), (90, 40), (91, 62), (88, 78), (80, 90), (66, 95), (52, 91), (42, 80), (34, 62), (30, 40)]),
    "heavyjaw": dict(name="Strong Jaw", sk=(52, 37, 48, 31, 2.9), r=1.0,
        face=[(86, 26), (102, 40), (102, 60), (102, 78), (98, 91), (84, 95), (60, 94), (42, 89), (32, 74), (26, 48)]),
    "pointed": dict(name="Pointed Chin", sk=(51, 36, 47, 31, 2.1), r=1.2,
        face=[(86, 26), (99, 40), (98, 58), (93, 74), (87, 89), (81, 98), (68, 91), (48, 82), (35, 68), (27, 44)]),
    "cheekbone": dict(name="High Cheeks", sk=(52, 36, 47, 31, 2.1), r=1.0,
        face=[(86, 26), (101, 38), (105, 53), (100, 66), (92, 78), (85, 91), (69, 93), (49, 84), (35, 70), (27, 44)]),
}
SHAPE_IDS = list(SHAPES.keys())


def _superellipse(cx, cy, rx, ry, n, count=90):
    pts = []
    for i in range(count):
        t = 2 * np.pi * i / count
        c, s = np.cos(t), np.sin(t)
        pts.append((cx + rx * np.sign(c) * abs(c) ** (2.0 / n), cy + ry * np.sign(s) * abs(s) ** (2.0 / n)))
    return pts


def silhouette(sid):
    k = SHAPES[sid]
    sk = A.poly(_superellipse(*k["sk"]))
    face = A.poly(k["face"])
    m = A.union(sk, face)
    m = A.closing(m, 11)                   # closing: fills the notch where cranium meets face plate
    return A.smooth(m, k["r"])


def neck_mask(head_chin_y, sid=None):
    if sid == "lumen":                                  # slim neck: narrow under the skull, widening a little into the shoulders
        return A.smooth(A.poly([(49, head_chin_y - 16), (64.5, head_chin_y - 16), (64.5, 106), (49, 106)]), 0.5)
    return A.smooth(A.poly([(42, head_chin_y - 18), (70, head_chin_y - 18), (72, 99), (40, 99)]), 0.7)


# --------------------------------------------------------------------------- species heads (non-human anatomy)
def _lumen_sil():
    # tall, swept-back cranium over a small narrow face that tapers to a pointed chin
    sk = A.poly(_superellipse(46, 33, 38, 33, 2.0))
    occ = A.poly(_superellipse(30, 34, 28, 32, 2.0))                        # occipital bulge: the skull sweeps back
    face = A.poly([(64, 38), (80, 48), (78, 62), (70, 76), (62, 90), (54, 87), (46, 72), (40, 52)])
    m = A.union(A.union(sk, occ), face)
    return A.smooth(A.closing(m, 10), 2.4)


def _insect_sil():
    sk = A.poly(_superellipse(52, 40, 40, 35, 2.3))
    face = A.poly([(72, 42), (92, 52), (92, 70), (80, 84), (62, 88), (50, 74), (46, 54)])
    return A.smooth(A.closing(A.union(sk, face), 8), 1.4)


# name, silhouette builder, anchor overrides, skin colour, accepted slot items (None = everything)
SPECIES = {
    "lumen": dict(name="Lumen Skull", build=_lumen_sil, skin=(170, 158, 234), glow=(96, 240, 255),
                  anchors=dict(eye_near=(55, 56), eye_far=(79, 52), mouth=(62, 79), ear=(10, 60), nose=(94, 70)),
                  eyes_default="alien"),
    "insect": dict(name="Hive Skull", build=_insect_sil, skin=(54, 132, 104), glow=(255, 200, 80),
                   anchors=dict(eye_near=(62, 50), eye_far=(86, 52), mouth=(78, 80), ear=(18, 62), nose=(98, 70)),
                   eyes_default="compound"),
}
SPECIES_IDS = list(SPECIES.keys())


class Head:
    """Head silhouette + anchors, ready for part generators."""

    def __init__(self, sid):
        self.sid = sid
        self.k = SHAPES.get(sid, {})
        self.species = SPECIES.get(sid)
        self.skull = self.species["build"]() if self.species else silhouette(sid)
        self.ymax = A.bbox(self.skull)[3]
        # the face-only mask without the neck stub (everything above the neck line)
        x0, y0, x1, y1 = A.bbox(self.skull)
        self.bbox = (x0, y0, x1, y1)
        self.top = y0
        self.front = x1
        self.back = x0
        k = self.k
        # vertical landmarks
        self.chin_y = self.ymax
        h = self.ymax - self.top
        self.eye_y = self.top + h * 0.545
        self.brow_y = self.eye_y - h * 0.105
        self.nose_y = self.eye_y + h * 0.105
        self.mouth_y = self.eye_y + h * 0.255
        self.hairline_y = self.top + h * 0.30
        # horizontal landmarks follow the real silhouette so the face adapts to the shape
        fx_eye = A.row_extent(self.skull, self.eye_y)[1]
        self.eye_far = (fx_eye - 11.5, self.eye_y)
        self.eye_near = (fx_eye - 11.5 - 23.5, self.eye_y + 1.0)
        fm = A.row_extent(self.skull, self.mouth_y)[1]
        self.mouth = (fm - 17, self.mouth_y)
        self.mouth_front = fm - 6
        fb = A.row_extent(self.skull, self.brow_y)[1]
        self.brow_front = fb
        self.ear = (self.back + 17, self.eye_y + 5)
        # nose protrudes a little past the face edge
        self.nose = (fx_eye + 1.5, self.nose_y)
        if self.species:
            for k_, v_ in self.species["anchors"].items():
                setattr(self, k_, v_)
            self.mouth_front = self.mouth[0] + 11
            self.brow_y = self.eye_y - 9
        # a "face mask": the face plate (no neck, no back of head), used by fitters
        self.head_only = A.inter(self.skull, A.half_plane((0, self.chin_y - 9), (108, self.chin_y - 9), below=False))

    # -- the silhouette used for fitting parts (head + nose bump)
    def with_nose(self):
        m = A.union(self.skull, A.ellipse(self.nose[0] - 1.8, self.nose[1], 4.2, 3.4))
        return m

    def edge_x(self, y):
        return A.row_extent(self.skull, y)[1]

    def back_x(self, y):
        return A.row_extent(self.skull, y)[0]

    def top_y(self, x):
        return A.col_extent(self.skull, x)[0]

    def point(self, name):
        sx = {"crown": (self.back + self.front) * 0.5 - 1, "front_top": self.front - 14, "back_top": self.back + 14}
        if name == "crown":
            return (sx["crown"], self.top_y(sx["crown"]))
        if name == "front_top":
            return (sx["front_top"], self.top_y(sx["front_top"]))
        if name == "back_top":
            return (sx["back_top"], self.top_y(sx["back_top"]))
        raise KeyError(name)


def _debug_grid(path="/tmp/claude-0/shots/heads_silhouettes.png"):
    import cv2
    from PIL import Image
    ims = []
    for sid in SHAPE_IDS:
        h = Head(sid)
        rgba = A.paint(h.skull, (232, 188, 156), "skin", bevel=5.0)
        # anchors
        im = A.to_image(rgba)
        arr = np.array(im)
        for (x, y), col in ((h.eye_near, (0, 0, 255, 255)), (h.eye_far, (0, 0, 255, 255)), (h.mouth, (255, 0, 0, 255)),
                            (h.ear, (0, 200, 0, 255))):
            cv2.circle(arr, (int(x * A.K), int(y * A.K)), 3, col, -1)
        bg = Image.new("RGBA", im.size, (70, 80, 90, 255))
        bg.alpha_composite(Image.fromarray(arr))
        ims.append(bg)
    cols = 5
    sheet = Image.new("RGBA", (A.W * cols, A.H * ((len(ims) + cols - 1) // cols)))
    for i, im in enumerate(ims):
        sheet.paste(im, ((i % cols) * A.W, (i // cols) * A.H))
    sheet.save(path)


if __name__ == "__main__":
    _debug_grid()


# --------------------------------------------------------------------------- skin layer (tinted by skin colour in game)
def make_skin(h):
    """Neck + head + ear + nose + mouth, white-based so the game tints it with the skin tone."""
    neck = neck_mask(h.chin_y)
    img = A.paint(neck, (255, 255, 255), "skin", bevel=4.0, outline=0.95, ambient=0.5)
    # shadow the chin casts on the neck
    cast = A.inter(A.shift(h.skull, -1.5, 5.0), neck)
    img = A.over(A.tint_layer(A.blur(cast, 1.5), (60, 40, 50), 0.45, within=neck), img)
    # head
    img = A.over(A.paint(h.skull, (255, 255, 255), "skin", bevel=6.5, outline=1.0, ambient=0.62), img)
    # nose: a small rounded bump on the front edge
    nose = A.smooth(A.union(A.ellipse(h.nose[0] - 1.6, h.nose[1], 3.4, 2.8, -8), A.ellipse(h.nose[0] - 3.4, h.nose[1] - 2.6, 2.4, 3.4, 10)), 0.5)
    ring = A.sub(A.grow(nose, 0.95), nose)
    ring = A.sub(ring, A.grow(h.skull, -0.3) * 0)
    ring_out = A.sub(ring, A.grow(h.skull, -0.9))
    img = A.over(A.tint_layer(ring_out, (20, 26, 40), 1.0), img)
    img = A.over(A.paint(nose, (255, 255, 255), "skin", bevel=2.2, outline=0.0, ambient=0.66, rim=0.12), img)
    nostril = A.ellipse(h.nose[0] - 1.6, h.nose[1] + 2.0, 1.1, 0.7)
    img = A.over(A.tint_layer(nostril, (70, 40, 40), 0.7), img)
    # cheek warmth + cheekbone highlight / hollow
    cheek = A.ellipse(h.eye_near[0] + 12, h.nose_y + 4, 7, 4.5)
    img = A.over(A.tint_layer(A.blur(cheek, 2.2), (255, 120, 110), 0.22, within=h.skull), img)
    hollow = A.ellipse(h.ear[0] + 16, h.mouth_y + 2, 8, 5, 25)
    img = A.over(A.tint_layer(A.blur(hollow, 2.4), (90, 50, 60), 0.18, within=h.skull), img)
    # heavy brow shading (stronger on square / angular shapes)
    brow_sh = A.ellipse(h.eye_near[0] + 12, h.eye_y - 7.5, 26, 3.4, -3)
    img = A.over(A.tint_layer(A.blur(brow_sh, 1.8), (60, 40, 55), 0.2, within=h.skull), img)
    # jaw underside shade
    under = A.sub(h.skull, A.shift(h.skull, 0.8, -4.0))
    img = A.over(A.tint_layer(A.blur(under, 1.2), (70, 40, 55), 0.35, within=h.skull), img)
    # ear (on the left)
    ex, ey = h.ear
    ear = A.smooth(A.ellipse(ex, ey, 5.2, 7.6, -8), 0.4)
    img = A.over(A.paint(ear, (255, 255, 255), "skin", bevel=2.0, outline=0.9, ambient=0.55), img)
    inner = A.ellipse(ex + 0.6, ey + 0.4, 2.4, 4.4, -8)
    img = A.over(A.tint_layer(A.blur(inner, 0.5), (110, 60, 70), 0.45, within=ear), img)
    # mouth: soft lip line that turns up a touch at the front corner
    mx, my = h.mouth
    ml = A.line(A.curve_pts([(mx - 5.2, my + 0.4), (mx - 1, my + 1.0), (mx + 4, my + 0.5), (mx + 7.2, my - 0.7)], 10), 0.62)
    img = A.over(A.tint_layer(ml, (110, 50, 60), 0.9), img)
    lip = A.ellipse(mx + 1, my + 2.3, 4.4, 1.1, 2)
    img = A.over(A.tint_layer(A.blur(lip, 0.5), (200, 90, 100), 0.3, within=h.skull), img)
    return img


def make_species_skin(h):
    """Baked-colour head of a non-human species (no ear, no nose bump, no human mouth). Eyes come from the eye layer."""
    sp = h.species
    col = sp["skin"]
    neck = neck_mask(h.chin_y, h.sid)
    # no outline across the bottom of the neck: it runs on into the body picture instead of ending in a hard edge
    img = A.paint(neck, col, "chitin", bevel=4.0, outline=0.95, ambient=0.5, ol_cut=A.poly([(0, 97.5), (140, 97.5), (140, 150), (0, 150)]))
    if h.sid == "lumen":
        # the lower end of the neck dissolves into the body picture (same colour), so no hard edge or dark band shows there
        ramp = sum(A.poly([(0, y0), (140, y0), (140, 150), (0, 150)]) for y0 in np.linspace(97.0, 105.0, 9)) / 9.0
        img[..., 3] *= (1.0 - np.clip(ramp, 0, 1))
    cast = A.inter(A.shift(h.skull, -1.5, 5.0), neck)
    img = A.over(A.tint_layer(A.blur(cast, 1.5), (10, 10, 30), 0.4, within=neck), img)
    img = A.over(A.paint(h.skull, col, "chitin", bevel=7.0, outline=1.05, ambient=0.5, spec=0.35), img)
    # surface: faint ridges following the skull, a soft lit patch on the forehead
    tex = A.empty()
    for i in range(6):
        A.line(A.curve_pts([(14 + i * 9, 6 + i * 2), (30 + i * 9, 3 + i * 3), (72 + i * 4, 14 + i * 6)], 12), 0.7, tex)
    img = A.over(A.tint_layer(A.blur(tex, 0.5), tuple(int(c * 0.55) for c in col), 0.4, within=h.skull), img)
    lit = A.ellipse(h.front - 40, h.top + 14, 18, 8, -16)
    img = A.over(A.tint_layer(A.blur(lit, 3.0), (255, 255, 255), 0.35, within=h.skull), img)
    sh = A.sub(h.skull, A.shift(h.skull, 0.8, -4.0))
    img = A.over(A.tint_layer(A.blur(sh, 1.2), (10, 10, 40), 0.4, within=h.skull), img)
    mx, my = h.mouth
    if h.sid == "lumen":
        # bioluminescent veins running from a glowing forehead mark over the cranium and down the temple; a tiny slit mouth
        glowc = sp["glow"]
        veins = A.empty()
        for pts in ([(52, 8), (50, 20), (46, 34), (47, 46)], [(60, 6), (66, 18), (68, 30), (71, 41)], [(40, 12), (32, 24), (28, 38)], [(52, 8), (42, 8), (32, 14)]):
            A.line(A.curve_pts(pts, 12), 0.9, veins)
        gem = A.smooth(A.poly([(56, 16), (59, 21), (56, 26), (53, 21)]), 0.4)
        A.union(veins, gem) if False else None
        veins = A.union(veins, gem)
        halo = A.blur(veins, 2.4)
        img = A.over(A.tint_layer(halo, glowc, 0.55, within=h.skull), img)
        img = A.over(A.tint_layer(A.blur(veins, 0.45), (230, 255, 255), 0.95, within=h.skull), img)
        ml = A.line(A.curve_pts([(mx - 3, my), (mx, my + 0.4), (mx + 3, my)], 6), 0.5)
    else:
        ml = A.line(A.curve_pts([(mx - 4, my), (mx + 1, my + 0.8), (mx + 6, my + 0.2)], 8), 0.6)
    img = A.over(A.tint_layer(ml, tuple(int(c * 0.3) for c in col), 0.9), img)
    return img
