#!/usr/bin/env python3
"""Generates the NEW tintable character parts used by the customisation system (art/player/*.png).
Same look as the existing parts: white, soft shaded, dark outline, tinted in-game by PlayerRig colour groups.
Run from the project root:  python3 tools/gen_character_art.py   (needs Pillow)
These are programmer-made starting art: an artist can repaint any file with the same size and pivot."""
from PIL import Image, ImageDraw, ImageFilter, ImageChops
import math, os
OUT = "art/player/"
S = 4                                   # supersampling
OL = (22, 28, 42, 255)                  # outline colour (same family as the existing parts)
WHITE = (247, 248, 252, 255)

def canvas(w, h): return Image.new("RGBA", (w * S, h * S), (0, 0, 0, 0))
def mask_of(w, h, fn):
    m = Image.new("L", (w * S, h * S), 0); d = ImageDraw.Draw(m); fn(d); return m
def P(pts): return [(x * S, y * S) for x, y in pts]
def E(b): return [b[0] * S, b[1] * S, b[2] * S, b[3] * S]

def solid(img, mask, fill=WHITE, outline=2.0, shade=0.28, hl=True):
    """Fill `mask` with a soft-shaded colour and a dark outline, onto img."""
    w, h = img.size
    k = int(outline * S) | 1
    grown = mask.filter(ImageFilter.MaxFilter(k if k > 1 else 3))
    ol = Image.new("RGBA", img.size, OL); img.paste(ol, (0, 0), grown)
    body = Image.new("RGBA", img.size, fill)
    # vertical + side shading (lower-right darker, upper-left lighter), clipped to the mask
    sh = Image.new("L", img.size, 0); sd = ImageDraw.Draw(sh)
    for y in range(h):
        v = int(255 * shade * (y / h) ** 1.4); sd.line([(0, y), (w, y)], fill=v)
    sh = ImageChops.add(sh, Image.linear_gradient("L").rotate(90).resize(img.size).point(lambda v: int(v * shade * 0.35)))
    dark = Image.new("RGBA", img.size, (60, 70, 100, 255)); body = Image.composite(dark, body, sh)
    img.paste(body, (0, 0), mask)
    if hl:
        hm = mask.filter(ImageFilter.MinFilter(9 * S // 2 | 1)).filter(ImageFilter.GaussianBlur(3 * S))
        hm = ImageChops.subtract(mask, hm.point(lambda v: v)).filter(ImageFilter.GaussianBlur(S))
        top = Image.new("L", img.size, 0); ImageDraw.Draw(top).rectangle([0, 0, w, h // 2], fill=110)
        hm = ImageChops.multiply(hm, top)
        img.paste(Image.new("RGBA", img.size, (255, 255, 255, 255)), (0, 0), hm.point(lambda v: v // 3))
    return mask

def line_on(img, mask, fn, rgba=(20, 26, 40, 90), blur=0.6):
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(layer); fn(d, rgba)
    layer = layer.filter(ImageFilter.GaussianBlur(blur * S))
    a = ImageChops.multiply(layer.getchannel("A"), mask); layer.putalpha(a); img.alpha_composite(layer)

def save(img, name, w, h):
    img.resize((w, h), Image.LANCZOS).save(OUT + name); print("wrote", name)

def blank_like(name):
    t = Image.open(OUT + name); return t.size

# ---------------------------------------------------------------- bare body detail (shirtless)
def bare_detail(female):
    w, h = 88, 92
    base = Image.open(OUT + "torso_base.png").convert("RGBA").getchannel("A").resize((w * S, h * S), Image.LANCZOS)
    img = canvas(w, h)
    def f(d, c):
        if not female:
            d.arc(E((14, 26, 44, 50)), 20, 160, fill=c, width=int(1.6 * S))    # chest
            d.arc(E((44, 26, 74, 50)), 20, 160, fill=c, width=int(1.6 * S))
            d.line(P([(44, 24), (44, 80)]), fill=c, width=int(1.4 * S))        # centre line
            for y in (54, 62, 70): d.line(P([(30, y), (58, y)]), fill=c, width=int(1.3 * S))
        else:
            d.arc(E((16, 30, 44, 52)), 20, 160, fill=c, width=int(1.4 * S))
            d.line(P([(44, 56), (44, 80)]), fill=c, width=int(1.1 * S))
            d.arc(E((20, 44, 68, 96)), 200, 340, fill=c, width=int(1.1 * S))    # soft waist curve
    line_on(img, base, f, (30, 20, 20, 110))
    save(img, "bare_detail_f.png" if female else "bare_detail_m.png", w, h)

# ---------------------------------------------------------------- non-removable base coverage
def briefs():
    w, h = 48, 30
    img = canvas(w, h)
    m = mask_of(w, h, lambda d: d.polygon(P([(0, 0), (48, 0), (47, 14), (36, 28), (24, 21), (12, 28), (1, 14)]), fill=255))
    solid(img, m, outline=1.6); line_on(img, m, lambda d, c: d.line(P([(2, 5), (46, 5)]), fill=c, width=S), (20, 26, 40, 110))
    save(img, "under_waist.png", w, h)
    img = canvas(36, 16)
    m = mask_of(36, 16, lambda d: d.rounded_rectangle(P([(0, 0), (36, 16)]), radius=5 * S, fill=255))
    solid(img, m, outline=1.6); save(img, "under_cuff.png", 36, 16)

def sports_top():           # female base coverage over the chest (non-removable, plain sports top)
    w, h = 88, 92
    base = Image.open(OUT + "torso_base.png").convert("RGBA").getchannel("A").resize((w * S, h * S), Image.LANCZOS)
    img = canvas(w, h)
    band = mask_of(w, h, lambda d: d.rectangle(P([(0, 22), (88, 50)]), fill=255))
    m = ImageChops.multiply(base, band)
    solid(img, m, outline=1.4); save(img, "under_top.png", w, h)

# ---------------------------------------------------------------- hair (108x100, head faces right, ear on the left)
def hair(style):
    w, h = 108, 100
    img = canvas(w, h)
    cap = mask_of(w, h, lambda d: (d.ellipse(E((3, -4, 105, 66)), fill=255)))
    hl = mask_of(w, h, lambda d: d.polygon(P([(0, 0), (108, 0), (101, 26), (82, 36), (62, 34), (44, 50), (22, 62), (0, 74)]), fill=255))
    m = ImageChops.multiply(cap, hl)
    if style == "long":
        back = mask_of(w, h, lambda d: d.polygon(P([(4, 20), (40, 8), (46, 50), (36, 90), (12, 96), (0, 70)]), fill=255))
        m = ImageChops.lighter(m, back)
    if style == "pony":
        tail = mask_of(w, h, lambda d: (d.ellipse(E((0, 22, 24, 74)), fill=255), d.ellipse(E((6, 16, 20, 30)), fill=255)))
        m = ImageChops.lighter(m, tail)
    if style == "mohawk":
        m = mask_of(w, h, lambda d: d.polygon(P([(24, 14), (30, 0), (40, 12), (48, 0), (58, 11), (66, 0), (76, 14), (70, 24), (30, 26)]), fill=255))
    solid(img, m, outline=1.8)
    if style != "mohawk":
        line_on(img, m, lambda d, c: [d.arc(E((10 + i * 9, -2 + i * 2, 90 - i * 4, 62)), 200, 330, fill=c, width=S) for i in range(4)], (20, 26, 40, 70))
    save(img, f"hair_{style}.png", w, h)

# ---------------------------------------------------------------- goggles
def goggles():
    w, h = 108, 100
    img = canvas(w, h)
    m = mask_of(w, h, lambda d: d.polygon(P([(6, 40), (100, 38), (100, 49), (6, 52)]), fill=255))
    solid(img, m, outline=1.6, hl=False); save(img, "goggles_strap.png", w, h)
    img = canvas(w, h)
    m = mask_of(w, h, lambda d: d.rounded_rectangle(P([(56, 52), (103, 82)]), radius=12 * S, fill=255))
    solid(img, m, outline=2.2, shade=0.12)
    layer = Image.new("RGBA", img.size, (255, 255, 255, 0)); ImageDraw.Draw(layer).ellipse(E((62, 56, 76, 64)), fill=(255, 255, 255, 150))
    img.alpha_composite(layer); save(img, "goggles_lens.png", w, h)

# ---------------------------------------------------------------- full-head cosmetics
def eyes_layer(w, h, shapes, hi=True):
    img = canvas(w, h); d = ImageDraw.Draw(img)
    for pts in shapes:
        d.polygon(P(pts), fill=(8, 10, 16, 255))
        if hi:
            cx = sum(p[0] for p in pts) / len(pts) - 2; cy = sum(p[1] for p in pts) / len(pts) - 2
            d.ellipse(E((cx - 2, cy - 2, cx + 2, cy + 1)), fill=(255, 255, 255, 235))
    return img

def alien_head():
    w, h = 108, 100
    img = canvas(w, h)
    m = mask_of(w, h, lambda d: (d.ellipse(E((4, -2, 100, 74)), fill=255),
                               d.polygon(P([(48, 56), (96, 50), (84, 82), (62, 99), (46, 86)]), fill=255)))
    solid(img, m, outline=2.2, shade=0.32)
    line_on(img, m, lambda d, c: [d.arc(E((8 + i * 10, 2 + i * 2, 96 - i * 3, 62)), 200, 320, fill=c, width=int(1.3 * S)) for i in range(5)], (10, 30, 20, 90))
    save(img, "alien_head.png", w, h)
    save(eyes_layer(w, h, [[(52, 52), (94, 56), (98, 70), (76, 74), (58, 66)]]), "alien_eyes.png", w, h)

def insect_head():
    w, h = 108, 100
    img = canvas(w, h)
    m = mask_of(w, h, lambda d: (d.ellipse(E((8, 4, 100, 80)), fill=255),
                               d.polygon(P([(70, 70), (98, 78), (90, 98), (76, 88)]), fill=255),    # mandible
                               d.polygon(P([(52, 74), (60, 98), (68, 78)]), fill=255),
                               d.line(P([(40, 14), (22, 0)]), fill=255, width=3 * S), d.line(P([(60, 10), (50, 0)]), fill=255, width=3 * S)))
    solid(img, m, outline=2.2, shade=0.3)
    line_on(img, m, lambda d, c: [d.line(P([(14 + i * 14, 8), (22 + i * 14, 60)]), fill=c, width=S) for i in range(5)], (10, 30, 20, 80))
    save(img, "insect_head.png", w, h)
    e = canvas(w, h); d = ImageDraw.Draw(e)
    d.ellipse(E((46, 30, 92, 70)), fill=(70, 10, 20, 255))
    for gx in range(50, 90, 8):
        for gy in range(34, 68, 8): d.ellipse(E((gx, gy, gx + 5, gy + 5)), fill=(150, 30, 40, 255))
    d.ellipse(E((54, 36, 64, 44)), fill=(255, 255, 255, 200))
    save(e, "insect_eyes.png", w, h)

def hunter_head():
    w, h = 108, 100
    img = canvas(w, h)
    m = mask_of(w, h, lambda d: (d.polygon(P([(6, 40), (22, 6), (70, 0), (100, 28), (104, 60), (96, 84), (70, 96), (40, 92), (10, 76)]), fill=255),
                               d.rounded_rectangle(P([(78, 62), (106, 84)]), radius=7 * S, fill=255)))   # respirator snout
    solid(img, m, outline=2.2, shade=0.3)
    line_on(img, m, lambda d, c: (d.line(P([(22, 6), (70, 30), (104, 60)]), fill=c, width=int(1.4 * S)), d.line(P([(10, 76), (46, 58)]), fill=c, width=int(1.4 * S)),
                                  [d.line(P([(84, 66 + i * 5), (102, 66 + i * 5)]), fill=c, width=S) for i in range(3)]), (10, 14, 24, 130))
    save(img, "hunter_head.png", w, h)
    v = canvas(w, h); d = ImageDraw.Draw(v)
    d.polygon(P([(50, 44), (100, 40), (102, 52), (54, 58)]), fill=(255, 255, 255, 255)); d.rectangle(E((76, 52, 88, 62)), fill=(255, 255, 255, 255))
    save(v.filter(ImageFilter.GaussianBlur(0.4 * S)), "hunter_visor.png", w, h)

def cowl():
    w, h = 108, 100
    img = canvas(w, h)
    m = mask_of(w, h, lambda d: (d.ellipse(E((3, -2, 105, 82)), fill=255),
                               d.polygon(P([(18, 18), (12, -2), (36, 8)]), fill=255), d.polygon(P([(58, 4), (62, -2), (82, 10)]), fill=255)))
    cut = mask_of(w, h, lambda d: d.polygon(P([(0, 100), (0, 70), (46, 66), (74, 72), (108, 66), (108, 100)]), fill=255))
    m = ImageChops.subtract(m, cut)                                           # bare chin and jaw stay visible
    solid(img, m, outline=2.0, shade=0.3)
    line_on(img, m, lambda d, c: d.arc(E((12, 8, 96, 62)), 200, 330, fill=c, width=int(1.3 * S)), (10, 12, 24, 110))
    save(img, "cowl_head.png", w, h)
    l = canvas(w, h); d = ImageDraw.Draw(l)
    for pts in ([(56, 52), (74, 50), (72, 60), (58, 60)], [(80, 50), (98, 52), (96, 62), (82, 60)]):
        d.polygon(P(pts), fill=(255, 255, 255, 255))
    save(l.filter(ImageFilter.GaussianBlur(0.3 * S)), "cowl_lens.png", w, h)

# ---------------------------------------------------------------- torso overlays / back / jetpacks
def overlay_on_torso(name, fn, rgba):
    w, h = 88, 92
    base = Image.open(OUT + "torso_base.png").convert("RGBA").getchannel("A").resize((w * S, h * S), Image.LANCZOS)
    img = canvas(w, h); line_on(img, base, fn, rgba, 0.35); save(img, name, w, h)

def torso_overlays():
    overlay_on_torso("alien_chest.png", lambda d, c: ([d.arc(E((10, 16 + i * 14, 78, 46 + i * 14)), 200, 340, fill=c, width=int(2 * S)) for i in range(4)], d.line(P([(44, 14), (44, 86)]), fill=c, width=int(1.6 * S))), (6, 30, 20, 150))
    overlay_on_torso("hunter_chest.png", lambda d, c: (d.polygon(P([(18, 22), (70, 22), (62, 60), (44, 74), (26, 60)]), outline=c, width=int(2 * S)), d.line(P([(44, 22), (44, 74)]), fill=c, width=int(1.6 * S)),
                                                       d.line(P([(20, 66), (68, 66)]), fill=c, width=int(1.6 * S))), (8, 10, 18, 190))
    overlay_on_torso("hero_emblem.png", lambda d, c: (d.polygon(P([(44, 26), (60, 38), (44, 58), (28, 38)]), outline=c, width=int(3 * S)), d.line(P([(44, 26), (44, 58)]), fill=c, width=int(2 * S))), (255, 255, 255, 235))

def cape():
    w, h = 96, 120
    img = canvas(w, h)
    m = mask_of(w, h, lambda d: d.polygon(P([(70, 0), (96, 8), (60, 70), (36, 112), (8, 120), (16, 70), (30, 20)]), fill=255))
    solid(img, m, outline=2.0, shade=0.35)
    line_on(img, m, lambda d, c: [d.line(P([(66 - i * 12, 6 + i * 4), (60 - i * 16, 112)]), fill=c, width=S) for i in range(5)], (10, 12, 24, 90))
    save(img, "cape.png", w, h)

def jetpacks():
    # heavy: two wide tanks; slim: a single streamlined pack with fins. Same 80x104 canvas / pivot as jetpack_base.
    w, h = 80, 104
    img = canvas(w, h)
    m = mask_of(w, h, lambda d: (d.rounded_rectangle(P([(2, 6), (40, 98)]), radius=12 * S, fill=255), d.rounded_rectangle(P([(36, 14), (78, 92)]), radius=12 * S, fill=255)))
    solid(img, m, outline=2.2); line_on(img, m, lambda d, c: [d.line(P([(4, y), (76, y)]), fill=c, width=S) for y in (30, 60)], (10, 14, 24, 100))
    save(img, "jetpack_heavy.png", w, h)
    img = canvas(w, h)
    m = mask_of(w, h, lambda d: d.polygon(P([(20, 2), (62, 10), (74, 60), (58, 100), (24, 100), (8, 60)]), fill=255))
    solid(img, m, outline=2.2); line_on(img, m, lambda d, c: (d.line(P([(40, 6), (40, 98)]), fill=c, width=S), d.line(P([(14, 56), (68, 56)]), fill=c, width=S)), (10, 14, 24, 100))
    save(img, "jetpack_slim.png", w, h)

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    bare_detail(False); bare_detail(True); briefs(); sports_top()
    for s in ("short", "long", "pony", "mohawk"): hair(s)
    goggles(); alien_head(); insect_head(); hunter_head(); cowl(); torso_overlays(); cape(); jetpacks()
