#!/usr/bin/env python3
"""Footwear for the human character, drawn in joint space (px from the ankle / knee) on the shared body-kit slots.

A shoe is two pieces: the FOOT slot (sole, upper, toe, laces on the vamp) and the SHIN slot (sock / shaft / ankle cuff).
Tint layers: m main, a lighter, b darker, c outfit accent colour; d = fixed colours (soles, laces, eyelets).
"""
import numpy as np
import artlib as A
import bodykit as BK
import outfitlib as O
from outfitlib import Piece, rect

SOLE_Y = 9.8                       # underside of the sole (ankle joint space, px)
RUBBER = (34, 36, 42)
RUBBER_L = (58, 60, 68)
LACE = (232, 230, 222)
CREAM = (238, 234, 222)


def F(x, y):
    return BK.J("foot", x, y)


def S(x, y):
    return BK.J("shin", x, y)


def poly(slot, pts, n=6, soft=0.5):
    return A.smooth(A.poly(A.curve_pts(BK.JP(slot, pts), n, closed=True)), soft)


def hard(slot, pts, soft=0.25):
    return A.smooth(A.poly(BK.JP(slot, pts)), soft)


def box(slot, x0, y0, x1, y1, r=0.5):
    return A.smooth(A.poly(BK.JP(slot, [(x0, y0), (x1, y0), (x1, y1), (x0, y1)])), r)


def line(slot, pts, w):
    return A.line(BK.JP(slot, pts), w)


def laces(p, slot, pts, w=0.9, eyelets=True, col=LACE):
    """pts = [(x0,y0,x1,y1)...] each a lace crossing"""
    for (x0, y0, x1, y1) in pts:
        p.d_line(BK.JP(slot, [(x0, y0), (x1, y1)]), w, col, curve=False)
        if eyelets:
            p.d_paint(A.ellipse(*BK.J(slot, x0, y0), 0.8, 0.8), O.METAL, "metal", bevel=0.3, outline=0.2)
            p.d_paint(A.ellipse(*BK.J(slot, x1, y1), 0.8, 0.8), O.METAL, "metal", bevel=0.3, outline=0.2)


def sole_unit(p, slot_sil, y_top, tread=True, color=RUBBER, lug=2.2, y_cut=None, welt=None):
    """rubber sole band along the bottom of the foot, with lugs and a light welt line"""
    band = A.inter(box("foot", -12, y_top, 24, 14, 0.2), slot_sil)
    p.d_paint(A.smooth(band, 0.4), color, "matte", bevel=1.2, outline=0.0, ambient=0.6)
    if tread:
        x = -4.6
        while x < 16.5:
            p.d_flat(A.inter(box("foot", x, SOLE_Y - 1.5, x + 0.9, SOLE_Y + 0.2, 0.1), band), (16, 16, 20), 0.8)
            x += lug
    if welt is not None:
        p.d_flat(A.inter(box("foot", -12, y_top - 0.15, 24, y_top + 0.6, 0.1), slot_sil), welt, 0.9)
    p.d_flat(A.inter(box("foot", -12, SOLE_Y - 0.45, 24, SOLE_Y + 0.1, 0.1), slot_sil), (10, 10, 14), 0.5)


def ankle_cover():
    """the shin-slot cuff / shaft is the shin tube from y0 down over the ankle, a hair bigger than the leg"""
    return BK.sil_shin()


# ============================================================================================ combat boots
def combat():
    # shaft (shin slot) : leather up to just under the knee, lace-up front, padded cuff, pull tab
    BK.canvas("shin")
    leg = A.grow(BK.sil_shin(), 0.5)
    shaft = A.inter(leg, box("shin", -9, 8.8, 9, 25, 0.2))
    flare = hard("shin", [(-6.3, 8.6), (6.0, 8.6), (5.7, 11.5), (-6.0, 11.5)], 0.6)
    shaft = A.smooth(A.union(shaft, flare), 0.5)
    p = Piece("shin", sil=shaft, material="leather", bevel=3.6, spec=0.3, texture=O.fabric_weave(40, 0.2), pad=0, cut=False)
    cuff = A.inter(box("shin", -8, 8.5, 8, 11.6, 0.9), shaft)
    p.panel(cuff, bevel=1.5, outline=0.6, material="leather", spec=0.3)
    p.blotch("a", cuff)
    p.fold([(-4.5, 13.5), (0.5, 15.2), (4.8, 14.0)], 1.0, 0.28)
    p.fold([(-4.8, 17.6), (0.5, 19.0), (4.6, 18.2)], 0.9, 0.25)
    # tongue edge + lace channel on the front
    p.d_flat(A.inter(line("shin", [(3.0, 11.8), (3.7, 21.0)], 1.5), shaft), (24, 24, 28), 0.55)
    laces(p, "shin", [(2.6, 12.6, 5.2, 13.6), (2.6, 15.0, 5.0, 16.0), (2.6, 17.4, 4.9, 18.4), (2.6, 19.8, 4.8, 20.6)], 0.8)
    for y in (12.6, 15.0, 17.4, 19.8):
        p.d_line(BK.JP("shin", [(2.6, y), (5.0, y + 1.0)]), 0.8, LACE, curve=False)
    # pull tab at the back
    p.d_paint(box("shin", -6.6, 9.2, -5.2, 12.6, 0.4), (30, 30, 34), "leather", bevel=0.7, outline=0.4)
    # ankle strap
    strap = A.inter(box("shin", -7, 20.0, 7, 22.0, 0.4), shaft)
    p.d_paint(strap, (28, 28, 32), "leather", bevel=0.9, outline=0.4)
    p.d_paint(box("shin", 2.6, 19.9, 4.4, 22.1, 0.3), O.METAL, "metal", bevel=0.5, outline=0.3)
    p.save("boots", "boots")

    # foot slot
    BK.canvas("foot")
    sil = poly("foot", [(-5.6, -2.4), (-6.8, 3.0), (-6.9, 8.0), (-6.4, SOLE_Y), (-3.0, SOLE_Y + 0.15), (11.5, SOLE_Y + 0.15), (16.0, SOLE_Y - 0.1),
                        (18.4, 8.8), (19.0, 6.4), (18.0, 4.6), (14.5, 3.7), (10.0, 2.6), (6.0, 0.6), (5.4, -2.4)], 5, 0.4)
    p = Piece("foot", sil=sil, material="leather", bevel=3.8, spec=0.3, texture=O.fabric_weave(41, 0.2), pad=0, cut=True)
    # heel counter
    heel = A.inter(hard("foot", [(-9, -3), (-2.6, -3), (-1.6, 3.4), (-1.6, 9), (-9, 9)], 1.4), sil)
    p.panel(heel, bevel=1.3, outline=0.5, material="leather", spec=0.3)
    p.blotch("b", heel)
    # toe cap
    toe = A.inter(poly("foot", [(11.0, 2.6), (14.5, 3.4), (19.6, 5.4), (19.6, 11), (10.2, 11)], 4, 0.6), sil)
    p.panel(toe, bevel=1.5, outline=0.55, material="leather", spec=0.35)
    p.blotch("a", toe)
    p.stitch(BK.JP("foot", [(10.8, 3.4), (10.3, 7.6)]), gap=1.6)
    p.fold([(5.4, 2.2), (8.0, 3.4), (6.6, 5.6)], 0.9, 0.28)
    # lace run over the vamp
    laces(p, "foot", [(2.9, -1.2, 5.2, -0.1), (4.6, 0.1, 7.0, 1.2), (6.4, 1.1, 8.8, 2.2)], 0.8)
    sole_unit(p, sil, 7.7, True, RUBBER, 2.0, welt=(150, 118, 76))
    # heel block
    p.d_paint(A.inter(box("foot", -8, 7.4, -1.8, SOLE_Y + 0.3, 0.3), sil), RUBBER_L, "matte", bevel=0.9, outline=0.0)
    p.save("boots", "boots")


# ============================================================================================ sneakers
def _sneaker_foot(oid, chunky=False, high=False, mesh=False):
    SY = SOLE_Y
    sole_top = 7.0 if not chunky else 6.4
    BK.canvas("foot")
    # upper: padded collar around the ankle, tongue, rounded toe box
    sil = poly("foot", [(-5.6, -2.0), (-6.5, 2.0), (-6.8, 6.5), (-6.6, SY - 0.2), (-5.0, SY + 0.15), (12.5, SY + 0.15), (16.2, SY - 0.1),
                        (18.4, 8.6), (19.0, 6.2), (18.0, 4.2), (14.6, 3.2), (10.8, 2.2), (7.0, 0.2), (5.4, -2.6), (3.6, -3.1),
                        (1.2, -2.2), (-1.8, -0.9), (-4.0, -1.4)], 5, 0.45)
    p = Piece("foot", sil=sil, material="cloth", bevel=3.4, spec=0.18, texture=O.fabric_weave(42, 0.3), pad=0, cut=False)
    # toe bumper + toe cap
    toe = A.inter(poly("foot", [(11.4, 2.2), (14.6, 3.2), (19.8, 5.4), (19.8, 11.5), (10.4, 11.5)], 4, 0.6), sil)
    p.panel(toe, bevel=1.5, outline=0.55, material="leather", spec=0.28)
    p.blotch("b", toe)
    # side overlay (accent) sweeping from the heel up to the laces
    ov = A.inter(poly("foot", [(-7, 5.4), (-3.6, 0.2), (1.0, -0.2), (4.8, 1.2), (9.6, 4.2), (10.8, 6.6), (-7, 8.0)], 4, 0.7), sil)
    p.panel(ov, bevel=1.4, outline=0.5, material="leather", spec=0.22)
    p.blotch("a", ov)
    # heel clip + collar padding
    clip = A.inter(box("foot", -7.6, -0.8, -4.6, 6.2, 1.0), sil)
    p.panel(clip, bevel=1.0, outline=0.45, material="leather", spec=0.2)
    p.blotch("c", clip)
    collar = A.inter(A.sub(A.grow(sil, 0.0), A.grow(A.shift(sil, 0, 1.8), 0.0)), sil)
    p.light(A.blur(A.inter(collar, box("foot", -6, -4, 6, 0.4, 0.5)), 0.8), 0.25)
    p.fold([(7.4, 1.6), (10.6, 3.0), (9.4, 5.0)], 0.9, 0.24)
    if mesh:
        for i in range(6):
            x = 0.0 + i * 2.2
            p.d_flat(A.inter(line("foot", [(x, 5.2), (x + 2.0, 2.4)], 0.55), ov), (255, 255, 255), 0.0)
    # tongue + laces
    p.d_paint(hard("foot", [(2.4, -3.0), (5.6, -2.8), (7.4, 0.0), (4.4, 0.6)], 0.5), CREAM, "cloth", bevel=0.8, outline=0.4)
    laces(p, "foot", [(2.6, -1.0, 5.4, -1.6), (4.1, 0.2, 7.0, 0.6), (5.8, 1.2, 8.8, 2.0), (7.6, 2.2, 10.4, 3.4)], 0.9, eyelets=False)
    # midsole (cream, baked) + outsole
    mid = A.inter(box("foot", -12, sole_top, 24, SY - 0.9, 0.2), sil)
    p.d_paint(A.smooth(mid, 0.4), CREAM, "matte", bevel=1.4, outline=0.0, ambient=0.62)
    p.d_flat(A.inter(box("foot", -12, sole_top + 0.7, 24, sole_top + 1.1, 0.1), sil), (150, 160, 190), 0.55)
    out = A.inter(box("foot", -12, SY - 0.95, 24, SY + 0.3, 0.15), sil)
    p.d_paint(A.smooth(out, 0.3), RUBBER, "matte", bevel=0.6, outline=0.0)
    if chunky:
        x = -4.0
        while x < 16:
            p.d_flat(A.inter(box("foot", x, sole_top + 0.2, x + 0.7, SY - 1.0, 0.1), mid), (190, 188, 176), 0.7)
            x += 2.4
    p.save("boots", oid)


def _sock(oid, y0, high=False):
    """shin-slot companion: ribbed sock cuff (low) or padded high-top shaft"""
    BK.canvas("shin")
    leg = A.grow(BK.sil_shin(), 0.5)
    sh = A.inter(leg, box("shin", -9, y0, 9, 25, 0.2))
    if high:
        sh = A.smooth(A.union(sh, hard("shin", [(-6.0, y0 - 0.2), (5.8, y0 - 0.2), (5.5, y0 + 2.4), (-5.8, y0 + 2.4)], 0.6)), 0.5)
    p = Piece("shin", sil=sh, material="cloth", bevel=3.0 if high else 2.4, spec=0.1, texture=O.knit_texture(0.5) if not high else O.fabric_weave(42, 0.3),
              pad=0, cut=False)
    if not high:
        for x in (-3.6, -1.8, 0.0, 1.8, 3.6):
            p.shade(A.inter(line("shin", [(x, y0 + 0.4), (x, y0 + 8)], 0.45), sh), 0.18)
        band = A.inter(box("shin", -8, y0, 8, y0 + 1.5, 0.3), sh)
        p.panel(band, bevel=0.8, outline=0.35, material="cloth")
        p.blotch("c", band)
        p.blotch("a", A.inter(box("shin", -8, y0 + 2.2, 8, y0 + 3.0, 0.1), sh))
    else:
        cuff = A.inter(box("shin", -8, y0 - 0.4, 8, y0 + 2.6, 0.9), sh)
        p.panel(cuff, bevel=1.5, outline=0.55, material="cloth")
        p.blotch("a", cuff)
        patch = A.ellipse(*BK.J("shin", -0.2, y0 + 8.4), 3.4, 3.4)
        p.d_paint(patch, (240, 240, 244), "matte", bevel=0.8, outline=0.5)
        p.d_paint(A.ellipse(*BK.J("shin", -0.2, y0 + 8.4), 1.5, 1.5), (190, 40, 48), "matte", bevel=0.5, outline=0.0)
        laces(p, "shin", [(2.4, y0 + 3.2, 5.2, y0 + 3.9), (2.4, y0 + 5.4, 5.0, y0 + 6.1)], 0.9)
        p.d_flat(A.inter(line("shin", [(3.0, y0 + 2.8), (3.8, y0 + 10.5)], 1.4), sh), (210, 208, 198), 0.35)
    p.save("boots", oid)


def sneakers():
    _sneaker_foot("sneakers")
    _sock("sneakers", 14.6)


def hightops():
    _sneaker_foot("hightops", chunky=False)
    _sock("hightops", 10.0, True)


def runners():
    _sneaker_foot("runners", chunky=True, mesh=True)
    _sock("runners", 14.8)


# ============================================================================================ plated boots
def plated():
    BK.canvas("shin")
    leg = A.grow(BK.sil_shin(), 0.9)
    shaft = A.inter(leg, box("shin", -9, 7.6, 9, 25, 0.2))
    p = Piece("shin", sil=shaft, material="leather", bevel=3.2, spec=0.3, texture=O.fabric_weave(40, 0.2), pad=0, cut=False)
    # shin guard (accent plate), knee cup and ankle collar
    guard = A.inter(poly("shin", [(-3.8, 8.8), (4.6, 8.8), (5.6, 13), (4.2, 19.0), (-3.0, 19.0), (-4.4, 13)], 4, 0.8), shaft)
    p.panel(guard, bevel=2.2, outline=0.7, material="metal", spec=0.5)
    p.blotch("a", guard)
    p.d_line(BK.JP("shin", [(0.2, 9.6), (0.6, 18.2)]), 0.6, (30, 34, 42), alpha=0.5)
    for y in (10.0, 17.8):
        p.d_paint(A.ellipse(*BK.J("shin", -2.4, y), 0.7, 0.7), O.METAL, "metal", bevel=0.3, outline=0.2)
        p.d_paint(A.ellipse(*BK.J("shin", 3.4, y), 0.7, 0.7), O.METAL, "metal", bevel=0.3, outline=0.2)
    top = A.inter(box("shin", -8, 7.6, 8, 9.6, 0.7), shaft)
    p.panel(top, bevel=1.2, outline=0.5, material="leather")
    p.blotch("b", top)
    p.d_paint(A.inter(box("shin", -8, 19.2, 8, 21.4, 0.4), shaft), (28, 28, 32), "leather", bevel=0.9, outline=0.4)
    p.d_paint(box("shin", 2.4, 19.1, 4.4, 21.6, 0.3), O.BRASS, "metal", bevel=0.5, outline=0.3)
    p.save("boots", "plated")

    BK.canvas("foot")
    sil = poly("foot", [(-5.6, -2.4), (-7.0, 3.0), (-7.2, 8.0), (-6.6, SOLE_Y), (-3.0, SOLE_Y + 0.25), (12.0, SOLE_Y + 0.25), (16.6, SOLE_Y - 0.1),
                        (19.0, 8.8), (19.6, 6.2), (18.4, 4.2), (14.8, 3.2), (10.0, 2.4), (6.0, 0.4), (5.4, -2.4)], 5, 0.4)
    p = Piece("foot", sil=sil, material="leather", bevel=3.8, spec=0.3, texture=O.fabric_weave(41, 0.2), pad=0, cut=True)
    toe = A.inter(poly("foot", [(9.6, 2.4), (14.8, 3.2), (20.2, 5.2), (20.2, 11), (9.0, 11)], 4, 0.7), sil)
    p.panel(toe, bevel=2.2, outline=0.7, material="metal", spec=0.5)
    p.blotch("a", toe)
    p.d_line(BK.JP("foot", [(11.0, 3.8), (11.6, 7.2)]), 0.5, (30, 34, 42), alpha=0.5)
    heel = A.inter(hard("foot", [(-9, -3), (-2.4, -3), (-1.8, 3.4), (-1.8, 9), (-9, 9)], 1.6), sil)
    p.panel(heel, bevel=1.6, outline=0.55, material="metal", spec=0.45)
    p.blotch("b", heel)
    laces(p, "foot", [(3.0, -1.2, 5.2, -0.3), (4.6, 0.0, 7.0, 1.0), (6.4, 1.1, 8.6, 2.0)], 0.8)
    sole_unit(p, sil, 7.5, True, RUBBER, 1.8, welt=(120, 124, 136))
    p.d_paint(A.inter(box("foot", -8.5, 7.2, -1.4, SOLE_Y + 0.4, 0.3), sil), RUBBER_L, "matte", bevel=1.0, outline=0.0)
    p.save("boots", "plated")


ALL = {"boots": combat, "sneakers": sneakers, "hightops": hightops, "runners": runners, "plated": plated}

if __name__ == "__main__":
    import sys
    for k, fn in ALL.items():
        if len(sys.argv) < 2 or k in sys.argv[1:]:
            fn()
            print("footwear", k)
