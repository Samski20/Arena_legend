#!/usr/bin/env python3
"""Headgear generated to fit a given Head. Layers: base (tint 'helmet'), trim (tint 'accent'), lens (tint 'visor'),
shine (untinted), back (drawn behind the head, tint 'helmet'). Eyewear is placed on that head's eye anchors.

hair rule per item:  "keep"  = hair stays visible (goggles, headband, crown ...)
                     "front" = hair front layer hidden, hair that hangs behind (ponytail, long hair ...) still shows
                     "all"   = every hair layer hidden (hood)
hides: other slots the item covers ("facial" for a face mask)."""
import numpy as np
import artlib as A
import hairlib as HR

GEAR = {
    "none":    dict(name="None", hair="keep", hides=[]),
    "helmet":  dict(name="Combat Helmet", hair="front", hides=[]),
    "visor":   dict(name="Visor Helmet", hair="front", hides=[]),
    "beanie":  dict(name="Beanie", hair="front", hides=[]),
    "cap":     dict(name="Cap", hair="front", hides=[]),
    "headband": dict(name="Headband", hair="keep", hides=[]),
    "goggles": dict(name="Goggles", hair="keep", hides=[]),
    "shades":  dict(name="Sunglasses", hair="keep", hides=["eyes"]),
    "mask":    dict(name="Face Mask", hair="keep", hides=["facial"]),
    "hood":    dict(name="Hood", hair="all", hides=[]),
    "crown":   dict(name="Circlet", hair="keep", hides=[]),
    "cowl":    dict(name="Hero Cowl", hair="front", hides=[]),
    "hunter":  dict(name="Stalker Helm", hair="all", hides=["facial"]),
    "headset": dict(name="Comms Headset", hair="keep", hides=[]),
}
GEAR_IDS = list(GEAR.keys())


def shell(h, t, line_off, front_extra=0.0):
    """Skull grown by t, cut by a line from the nape over the ear up to the brow: the dome of a helmet / cap."""
    ex = h.ear[0]
    ctrl = [(h.back - 10, h.eye_y + 12 + line_off), (ex - 4, h.eye_y - 1 + line_off), (ex + 12, h.brow_y - 5 + line_off), (h.front - 8, h.brow_y - 5 + line_off), (h.front + 12, h.brow_y - 3 + line_off + front_extra)]
    pts = A.curve_pts(ctrl, 12)
    region = A.poly(pts + [(h.front + 30, -40), (h.back - 30, -40)])
    return A.inter(A.grow(h.skull, t), region), region


def _blank():
    return A.blank()


def make_gear(h, gid):
    if gid == "none":
        return None
    out = {}
    ex = h.ear[0]
    if gid in ("helmet", "visor"):
        m, region = shell(h, 4.6, 0.0)
        # ear guard flaps
        guard = A.smooth(A.ellipse(ex + 1, h.eye_y + 6, 9.5, 12.5), 0.6)
        m = A.smooth(A.union(m, A.inter(guard, A.grow(h.skull, 5.0))), 0.8)
        st = [[(h.front - 16, h.top + 4), (h.front - 30 - i * 4, h.top + 6), (h.back + 14 + i * 3, h.eye_y - 8)] for i in range(0, 1)]
        out["base"] = A.paint(m, (255, 255, 255), "metal", bevel=5.2, outline=1.1, ambient=0.5, spec=0.4)
        # rim band along the bottom edge + centre ridge + vents
        band = A.sub(m, A.shift(m, 0, -4.0))
        band = A.inter(band, A.grow(region, 0.4))
        ridge = A.inter(A.line(A.curve_pts([(h.front - 6, h.brow_y - 6), (h.front - 24, h.top + 1), (h.back + 18, h.top + 8), (h.back + 4, h.eye_y - 4)], 12), 2.6), m)
        trim = A.union(band, ridge)
        trim = A.union(trim, A.inter(A.ellipse(ex + 1, h.eye_y + 6, 4.8, 7.0), m))
        out["trim"] = A.paint(trim, (255, 255, 255), "metal", bevel=1.4, outline=0.0, ambient=0.55, spec=0.35, rim=0.0)
        sh = A.inter(A.ellipse(h.front - 38, h.top + 9, 18, 4.2, -14), m)
        out["shine"] = A.tint_layer(A.blur(sh, 1.0), (255, 255, 255), 0.55)
        if gid == "visor":
            vis = A.smooth(A.union(A.ellipse(h.eye_near[0] + 12, h.eye_y + 1.5, 29, 13.5), A.ellipse(h.eye_far[0] + 4, h.eye_y + 1, 12, 12)), 1.2)
            vis = A.inter(vis, A.grow(h.skull, 3.5))
            lens = A.paint(vis, (255, 255, 255), "glass", bevel=3.0, outline=1.0, ambient=0.75, spec=0.5, alpha_scale=0.5)
            out["lens"] = lens
            glint = A.inter(A.poly([(h.eye_near[0] - 6, h.eye_y - 11), (h.eye_near[0] + 4, h.eye_y - 11), (h.eye_near[0] - 6, h.eye_y + 10), (h.eye_near[0] - 14, h.eye_y + 10)]), vis)
            out["shine"] = A.over(A.tint_layer(glint, (255, 255, 255), 0.35), out["shine"])
    elif gid == "beanie":
        m, region = shell(h, 5.4, -4.0)
        top_bump = A.smooth(A.ellipse((h.back + h.front) / 2 - 2, h.top - 1, 28, 7), 1.0)
        m = A.smooth(A.union(m, A.inter(top_bump, A.grow(region, 6))), 1.0)
        tex = np.zeros((A.IH, A.IW), np.float32)
        for i in range(-10, 40):     # knit ribs
            x = h.back + i * 3.0
            tex += A.line([(x, h.top - 8), (x + (h.front - x) * 0.35, h.eye_y + 20)], 0.55) * (0.5 if i % 2 else -0.5)
        out["base"] = A.paint(m, (255, 255, 255), "cloth", bevel=5.0, outline=1.0, ambient=0.56, texture=tex * 0.55)
        cuff = A.inter(A.sub(m, A.shift(m, 0, -6.2)), A.grow(region, 0.4))
        ctex = np.zeros((A.IH, A.IW), np.float32)
        for i in range(0, 60):
            x = h.back - 10 + i * 2.2
            ctex += A.line([(x, h.eye_y - 20), (x, h.eye_y + 20)], 0.5) * (0.6 if i % 2 else -0.6)
        out["trim"] = A.paint(cuff, (255, 255, 255), "cloth", bevel=2.0, outline=0.0, ambient=0.6, texture=ctex * 0.5, rim=0.0)
        out["shine"] = A.tint_layer(A.blur(A.inter(A.ellipse(h.front - 40, h.top + 8, 16, 4, -12), m), 1.2), (255, 255, 255), 0.25)
    elif gid == "cap":
        m, region = shell(h, 4.2, -3.5)
        dome = A.smooth(m, 1.0)
        out["base"] = A.paint(dome, (255, 255, 255), "cloth", bevel=5.0, outline=1.0, ambient=0.54)
        brim = A.smooth(A.poly([(h.front - 14, h.brow_y - 8), (h.front + 4, h.brow_y - 11), (h.front + 20, h.brow_y - 3), (h.front + 22, h.brow_y + 3), (h.front + 6, h.brow_y + 1), (h.front - 14, h.brow_y - 2)]), 0.8)
        brimimg = A.paint(brim, (255, 255, 255), "cloth", bevel=2.2, outline=1.0, ambient=0.5, spec=0.15)
        btn = A.blob((h.back + h.front) / 2 - 2, h.top - 3, 2.2)
        seam = A.line(A.curve_pts([(h.front - 12, h.top + 3), ((h.back + h.front) / 2, h.top - 4), (h.back + 10, h.eye_y - 14)], 10), 0.5)
        trim = A.union(brim, A.union(btn, A.inter(seam, dome)))
        out["trim"] = A.over(A.paint(A.union(brim, btn), (255, 255, 255), "cloth", bevel=2.2, outline=1.0, ambient=0.5), A.tint_layer(A.inter(seam, dome), (20, 24, 40), 0.5))
        out["shine"] = A.tint_layer(A.blur(A.inter(A.ellipse(h.front - 40, h.top + 8, 15, 3.6, -12), dome), 1.2), (255, 255, 255), 0.28)
    elif gid == "headband":
        ctrl = [(h.back - 4, h.eye_y - 2), (h.back + 20, h.brow_y - 8), (h.front - 30, h.brow_y - 12), (h.front - 6, h.brow_y - 9), (h.front + 2, h.brow_y - 7)]
        band = A.line(A.curve_pts(ctrl, 14), 5.2)
        band = A.inter(A.smooth(band, 0.4), A.grow(h.skull, 3.0))
        out["base"] = A.paint(band, (255, 255, 255), "cloth", bevel=1.6, outline=0.95, ambient=0.6)
        knot = A.union(A.ellipse(h.back + 1, h.eye_y - 4, 4, 3.2), A.poly([(h.back + 1, h.eye_y - 4), (h.back - 12, h.eye_y + 4), (h.back - 9, h.eye_y + 9)]), A.poly([(h.back + 1, h.eye_y - 4), (h.back - 14, h.eye_y - 3), (h.back - 12, h.eye_y + 1)]))
        out["back"] = A.paint(A.smooth(knot, 0.4), (255, 255, 255), "cloth", bevel=1.4, outline=0.95, ambient=0.56)
        stripe = A.inter(A.line(A.curve_pts([(a, b + 0.4) for a, b in ctrl], 14), 1.0), band)
        out["trim"] = A.paint(stripe, (255, 255, 255), "cloth", bevel=0.5, outline=0.0, ambient=0.7, rim=0.0)
    elif gid in ("goggles", "shades"):
        sc = 1.0
        lens_c = [h.eye_near, h.eye_far]
        strap = A.line(A.curve_pts([(h.back - 4, h.eye_y - 4), (h.back + 22, h.eye_y - 8), (h.eye_near[0] - 14, h.eye_y - 4)], 12), 3.2)
        strap = A.inter(strap, A.grow(h.skull, 3.0))
        frame = A.empty(); lens = A.empty()
        for i, (cx, cy) in enumerate(lens_c):
            rx = 11.8 if i == 0 else 9.8
            ry = 9.6 if gid == "goggles" else 7.2
            A.ellipse(cx, cy, rx + 2.0, ry + 2.0, 0, frame)
            A.ellipse(cx, cy, rx, ry, 0, lens)
        bridge = A.line([(h.eye_near[0] + 11, h.eye_y - 1), (h.eye_far[0] - 9, h.eye_y - 1)], 2.2)
        frame = A.smooth(A.union(frame, bridge), 0.4)
        if gid == "goggles":
            out["base"] = A.over(A.paint(frame, (255, 255, 255), "metal", bevel=2.2, outline=1.0, ambient=0.5, spec=0.3), A.paint(strap, (255, 255, 255), "cloth", bevel=1.2, outline=0.9, ambient=0.5))
            out["lens"] = A.paint(lens, (255, 255, 255), "glass", bevel=2.5, outline=0.0, ambient=0.78, spec=0.5, alpha_scale=0.62, rim=0.0)
            sh = A.inter(A.poly([(h.eye_near[0] - 6, h.eye_y - 10), (h.eye_near[0] + 1, h.eye_y - 10), (h.eye_near[0] - 7, h.eye_y + 6), (h.eye_near[0] - 12, h.eye_y + 6)]), lens)
            out["shine"] = A.tint_layer(sh, (255, 255, 255), 0.45)
        else:
            out["base"] = A.over(A.paint(frame, (255, 255, 255), "metal", bevel=1.8, outline=1.0, ambient=0.5, spec=0.35), A.paint(strap, (255, 255, 255), "cloth", bevel=1.0, outline=0.9, ambient=0.5))
            out["lens"] = A.paint(lens, (34, 38, 52), "glass", bevel=2.5, outline=0.0, ambient=0.9, spec=0.6, alpha_scale=0.97, rim=0.0)
            sh = A.inter(A.poly([(h.eye_near[0] - 7, h.eye_y - 6), (h.eye_near[0] + 1, h.eye_y - 6), (h.eye_near[0] - 6, h.eye_y + 5), (h.eye_near[0] - 11, h.eye_y + 5)]), lens)
            out["shine"] = A.tint_layer(sh, (255, 255, 255), 0.5)
    elif gid == "mask":
        ctrl = [(ex - 2, h.eye_y + 9), (ex + 14, h.nose_y - 1), (h.front - 26, h.nose_y - 3), (h.front + 3, h.nose_y - 4), (h.front + 10, h.nose_y + 2)]
        upper = A.curve_pts(ctrl, 12)
        zone = A.poly(upper + [(h.front + 30, 140), (ex - 12, 140)])
        m = A.inter(A.grow(h.skull, 2.6), zone)
        nose = A.inter(A.ellipse(h.nose[0] - 1.6, h.nose[1], 4.4, 3.8), A.empty() + 1)
        m = A.smooth(A.union(m, nose * 0.0 + A.inter(A.grow(A.ellipse(h.nose[0] - 1.6, h.nose[1], 3.4, 2.8), 1.4), zone)), 0.9)
        out["base"] = A.paint(m, (255, 255, 255), "cloth", bevel=4.0, outline=1.0, ambient=0.55)
        folds = np.zeros((A.IH, A.IW), np.float32)
        for i in range(4):
            folds += A.line([(h.mouth[0] - 14 + i * 5, h.nose_y + 3), (h.mouth[0] - 14 + i * 5 + 3, h.chin_y - 2)], 0.5) * (0.6 if i % 2 else -0.6)
        strap = A.line(A.curve_pts([(ex + 6, h.eye_y + 7), (ex - 8, h.eye_y + 4), (h.back + 3, h.eye_y + 4)], 8), 2.0)
        out["trim"] = A.paint(A.inter(A.union(strap, A.inter(A.line([(h.mouth[0] - 6, h.nose_y + 7), (h.mouth[0] + 8, h.nose_y + 7)], 1.0), m)), A.grow(h.skull, 3)), (255, 255, 255), "cloth", bevel=0.8, outline=0.0, ambient=0.6, rim=0.0)
        out["shine"] = A.tint_layer(A.blur(A.inter(A.ellipse(h.mouth[0] - 6, h.nose_y + 8, 8, 3, -10), m), 1.0), (255, 255, 255), 0.22)
    elif gid == "hood":
        outer = A.grow(h.skull, 5.4)
        open_ = A.smooth(A.union(A.ellipse(h.front - 30, h.eye_y + 6, 38, 33), A.poly([(h.front - 40, h.brow_y - 9), (h.front + 12, h.brow_y - 9), (h.front + 12, h.chin_y + 6), (h.front - 44, h.chin_y + 6)])), 1.6)
        m = A.sub(outer, open_)
        m = A.inter(m, A.poly([(h.back - 20, h.top - 20), (h.front + 20, h.top - 20), (h.front + 20, h.brow_y - 3), (h.front - 20, h.eye_y + 10), (h.front - 30, h.chin_y + 4), (h.back - 20, h.chin_y + 4)]))
        peak = A.smooth(A.poly([(h.back + 4, h.top + 4), (h.back - 12, h.eye_y + 30), (h.back + 30, h.chin_y + 6)]), 1.0)
        m = A.smooth(A.union(m, A.inter(peak, A.grow(h.skull, 14))), 1.2)
        fold = np.zeros((A.IH, A.IW), np.float32)
        for i in range(5):
            fold += A.line(A.curve_pts([(h.back + 6 + i * 7, h.top + 4), (h.back + 2 + i * 6, h.eye_y), (h.back + 4 + i * 5, h.chin_y)], 10), 0.8) * (0.6 if i % 2 else -0.6)
        out["base"] = A.paint(m, (255, 255, 255), "cloth", bevel=6.0, outline=1.05, ambient=0.5, texture=fold * 0.5)
        drape = A.smooth(A.poly([(h.back - 4, h.eye_y + 6), (h.back + 36, h.chin_y - 4), (h.back + 40, 99), (h.back - 6, 99)]), 1.5)
        out["back"] = A.paint(drape, (255, 255, 255), "cloth", bevel=4.0, outline=1.0, ambient=0.44)
        out["shine"] = A.tint_layer(A.blur(A.inter(A.ellipse(h.front - 40, h.top + 8, 16, 4, -14), m), 1.2), (255, 255, 255), 0.22)
    elif gid == "crown":
        ctrl = [(h.back + 6, h.eye_y - 12), (h.back + 28, h.brow_y - 12), (h.front - 30, h.brow_y - 15), (h.front - 8, h.brow_y - 12), (h.front, h.brow_y - 10)]
        pts = A.curve_pts(ctrl, 14)
        band = A.line(pts, 3.2)
        pts_up = []
        for i in range(2, len(pts) - 2, 9):
            x, y = pts[i]
            ph = 4.5 + (i % 3) * 1.6
            pts_up.append(A.poly([(x - 2.6, y), (x, y - ph - 3), (x + 2.6, y)]))
        gem_pts = [pts[int(len(pts) * f)] for f in (0.35, 0.55, 0.78)]
        crown = A.inter(A.smooth(A.union(band, *pts_up) if pts_up else band, 0.3), A.grow(h.skull, 8.0))
        out["base"] = A.paint(crown, (255, 255, 255), "metal", bevel=1.8, outline=1.0, ambient=0.5, spec=0.55)
        gems = A.empty()
        for (x, y) in gem_pts:
            A.ellipse(x, y, 1.5, 1.7, 0, gems)
        out["lens"] = A.paint(gems, (255, 255, 255), "glass", bevel=0.8, outline=0.7, ambient=0.8, spec=0.6)
        out["shine"] = A.tint_layer(A.inter(A.line(pts, 0.7) * 0 + A.shift(A.line(pts, 0.8), 0.2, -1.1), crown), (255, 255, 255), 0.5)
    elif gid == "headset":
        cup = A.smooth(A.ellipse(ex + 1, h.eye_y + 4, 6.2, 8.4), 0.6)
        arc = A.line(A.curve_pts([(ex - 1, h.eye_y - 3), (ex + 2, h.brow_y - 14), ((h.back + h.front) / 2 - 8, h.top - 4), (h.front - 36, h.top + 3), (h.front - 24, h.hairline_y - 2)], 12), 2.0)
        arc = A.inter(arc, A.grow(h.skull, 6.0))
        mic = A.line(A.curve_pts([(ex + 3, h.eye_y + 9), (ex + 14, h.mouth_y + 6), (h.mouth[0] - 10, h.mouth_y + 3), (h.mouth[0] - 2, h.mouth_y - 0.5)], 12), 1.1)
        tipm = A.ellipse(h.mouth[0] - 1, h.mouth_y - 0.8, 2.4, 1.8)
        body = A.union(arc, cup)
        out["base"] = A.paint(A.smooth(body, 0.3), (255, 255, 255), "metal", bevel=2.2, outline=1.0, ambient=0.5, spec=0.4)
        out["trim"] = A.over(A.paint(A.union(mic, tipm), (255, 255, 255), "metal", bevel=1.0, outline=0.9, ambient=0.5), A.paint(A.ellipse(ex + 1, h.eye_y + 4, 3.2, 5.0), (255, 255, 255), "metal", bevel=1.4, outline=0.0, ambient=0.6, rim=0.0))
        out["shine"] = A.tint_layer(A.blur(A.inter(A.ellipse(ex - 1, h.eye_y + 1, 2.2, 3.2), cup), 0.6), (255, 255, 255), 0.5)
    elif gid == "cowl":
        # a full-head hero mask: covers the skull down to the cheeks, leaves the mouth and chin free, eye holes cut out
        m, region = shell(h, 3.6, 6.0, front_extra=4.0)
        cheeks = A.inter(A.grow(h.skull, 2.6), A.poly([(h.back - 10, h.eye_y), (h.front + 12, h.nose_y - 1), (h.front + 12, h.nose_y - 7), (h.back - 10, h.eye_y - 4)]))
        m = A.union(m, A.inter(A.grow(h.skull, 2.6), A.poly([(h.back - 10, 0), (h.front + 14, 0), (h.front + 14, h.nose_y - 2), (h.mouth[0] - 18, h.nose_y + 1), (ex + 2, h.mouth_y + 2), (h.back - 10, h.eye_y + 22)])))
        m = A.smooth(m, 0.9)
        holes = A.union(A.ellipse(h.eye_near[0] + 1, h.eye_y + 0.5, 12.6, 7.0, 6), A.ellipse(h.eye_far[0] + 1, h.eye_y, 9.4, 6.4, -4))
        holes = A.smooth(A.union(holes, A.line([(h.eye_near[0] + 10, h.eye_y), (h.eye_far[0] - 8, h.eye_y)], 5.0)), 0.9)
        shell_m = A.sub(m, holes)
        out["base"] = A.paint(shell_m, (255, 255, 255), "cloth", bevel=4.4, outline=1.0, ambient=0.5, spec=0.12)
        brow = A.inter(A.sub(A.grow(holes, 1.8), holes), shell_m)
        out["trim"] = A.paint(brow, (255, 255, 255), "cloth", bevel=1.2, outline=0.0, ambient=0.62, rim=0.0)
        fin = A.empty()
        for i in range(3):
            A.poly([(h.back + 12 + i * 3, h.eye_y - 4 + i * 5), (h.back - 6 + i * 2, h.eye_y + 6 + i * 5), (h.back + 14 + i * 3, h.eye_y + 6 + i * 5)], fin)
        out["back"] = A.paint(A.smooth(A.inter(fin, A.empty() + 1), 0.4), (255, 255, 255), "cloth", bevel=1.2, outline=0.9, ambient=0.5)
        out["shine"] = A.tint_layer(A.blur(A.inter(A.ellipse(h.front - 40, h.top + 9, 17, 4, -14), shell_m), 1.0), (255, 255, 255), 0.4)
    elif gid == "hunter":
        # angular stalker helm with a glowing slit and a respirator snout
        pts = [(h.back - 2, h.eye_y + 16), (h.back - 1, h.eye_y - 14), (h.back + 12, h.top - 1), (h.front - 36, h.top - 3), (h.front - 6, h.top + 10), (h.front + 3, h.brow_y - 2), (h.front + 5, h.nose_y + 2), (h.front + 3, h.mouth_y + 11), (h.front - 8, h.chin_y + 1), (h.mouth[0] - 6, h.chin_y + 4), (h.ear[0] + 2, h.chin_y - 14)]
        m = A.smooth(A.poly(pts), 0.6)
        out["base"] = A.paint(m, (255, 255, 255), "metal", bevel=4.6, outline=1.1, ambient=0.46, spec=0.5)
        facets = A.empty()
        for a, b in (((h.back + 12, h.top), (h.front - 6, h.top + 14)), ((h.front - 6, h.top + 14), (h.front + 6, h.nose_y + 2)), ((h.back + 6, h.eye_y + 10), (h.mouth[0] - 6, h.nose_y + 12))):
            A.line([a, b], 0.9, facets)
        snout = A.inter(A.poly([(h.mouth[0] - 6, h.nose_y + 3), (h.front + 8, h.nose_y + 4), (h.front + 6, h.mouth_y + 12), (h.mouth[0] - 8, h.mouth_y + 10)]), m)
        vents = A.empty()
        for i in range(3):
            A.line([(h.mouth[0] + 1, h.mouth_y + 3 + i * 3.2), (h.front + 3, h.mouth_y + 3 + i * 3.2)], 0.9, vents)
        trim = A.union(A.smooth(A.sub(snout, A.shift(snout, 0, -2)), 0.3), A.inter(facets, m))
        out["trim"] = A.over(A.paint(A.inter(vents, m), (255, 255, 255), "metal", bevel=0.6, outline=0.0, ambient=0.2, rim=0.0), A.paint(trim, (255, 255, 255), "metal", bevel=0.8, outline=0.0, ambient=0.34, rim=0.0))
        slit = A.smooth(A.poly([(h.eye_near[0] - 12, h.eye_y - 2.5), (h.front + 4, h.eye_y - 4.5), (h.front + 4, h.eye_y + 3.5), (h.eye_near[0] - 10, h.eye_y + 5.5)]), 0.7)
        out["lens"] = A.over(A.tint_layer(A.blur(slit, 1.4), (255, 255, 255), 0.5), A.paint(slit, (255, 255, 255), "glass", bevel=1.2, outline=0.9, ambient=0.9, spec=0.0, rim=0.0))
        out["shine"] = A.tint_layer(A.blur(A.inter(A.ellipse(h.front - 40, h.top + 6, 14, 3.4, -12), m), 1.0), (255, 255, 255), 0.4)
    else:
        raise ValueError(gid)
    return out
