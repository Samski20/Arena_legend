#!/usr/bin/env python3
"""Eye and eyebrow sprites for the modular head system.

Eyes are separate little sprites (a NEAR eye and a smaller FAR eye, as the head is seen in three-quarter view). The
rig places them on the anchors of whichever head shape is worn, so eyes never get stretched. Each eye has 3 layers:
  base : eye white, lid line, shadow  (not tinted)
  iris : the coloured iris + pupil     (tinted by the eye colour)
  top  : highlights and lashes         (not tinted)
Brows are one tintable picture per brow (near / far).
"""
import numpy as np
import cv2
import artlib as A

# crop box (design units) around an eye / brow centre
EW, EH = 34, 26
OUT_W, OUT_H = EW * A.K, EH * A.K

# name -> parameters.  w,hu,hd: half-width, upper and lower lid height; tilt: outer-corner rise (+ = outer corner up);
# peak: where the upper lid peaks (0 outer .. 1 inner); iris: iris radius / eye half-height; lidw: lid line weight;
# open: how open the lid is (heavy-lidded < 1); kind: how it is painted
EYES = {
    "round":    dict(name="Round",         w=7.4, hu=6.4, hd=5.6, tilt=0.0, peak=0.5,  iris=0.80, lidw=1.2, open=1.0, kind="human", lash=0.0),
    "narrow":   dict(name="Narrow",        w=8.4, hu=3.2, hd=2.6, tilt=0.4, peak=0.45, iris=0.95, lidw=1.3, open=1.0, kind="human", lash=0.0),
    "almond":   dict(name="Almond",        w=8.2, hu=4.8, hd=3.8, tilt=1.4, peak=0.55, iris=0.86, lidw=1.3, open=1.0, kind="human", lash=0.6),
    "angular":  dict(name="Angular",       w=8.4, hu=4.4, hd=3.0, tilt=2.2, peak=0.62, iris=0.84, lidw=1.7, open=1.0, kind="angular", lash=0.0),
    "heavy":    dict(name="Heavy-lidded",  w=8.0, hu=4.6, hd=4.0, tilt=-0.4, peak=0.5, iris=0.95, lidw=1.9, open=0.62, kind="human", lash=0.0),
    "large":    dict(name="Large",         w=8.6, hu=8.0, hd=6.6, tilt=0.0, peak=0.5,  iris=0.86, lidw=1.3, open=1.0, kind="human", lash=0.5),
    "small":    dict(name="Small",         w=5.4, hu=3.6, hd=3.2, tilt=0.0, peak=0.5,  iris=0.78, lidw=1.1, open=1.0, kind="human", lash=0.0),
    "sleepy":   dict(name="Sleepy",        w=7.8, hu=4.2, hd=4.4, tilt=-1.2, peak=0.4, iris=0.88, lidw=1.6, open=0.72, kind="human", lash=0.0),
    "cat":      dict(name="Cat",           w=8.4, hu=5.0, hd=4.2, tilt=1.8, peak=0.55, iris=1.05, lidw=1.4, open=1.0, kind="cat", lash=0.0),
    "visor":    dict(name="Futuristic",    w=9.2, hu=2.8, hd=2.6, tilt=0.0, peak=0.5,  iris=1.0, lidw=1.2, open=1.0, kind="visor", lash=0.0),
    "glow":     dict(name="Glowing",       w=8.0, hu=4.6, hd=4.0, tilt=1.0, peak=0.5,  iris=1.0, lidw=1.3, open=1.0, kind="glow", lash=0.0),
    "compound": dict(name="Compound",      w=10.5, hu=10.0, hd=9.0, tilt=0.0, peak=0.5, iris=1.0, lidw=0.0, open=1.0, kind="compound", lash=0.0),
    "alien":    dict(name="Alien",         w=13.2, hu=8.4, hd=8.0, tilt=7.0, peak=0.35, iris=1.0, lidw=0.0, open=1.0, kind="alien", lash=0.0),
}
EYE_IDS = list(EYES.keys())

BROWS = {
    "none":     None,
    "soft":     dict(name="Soft",     w=10.0, th=1.8, arch=1.2, tilt=0.0),
    "arched":   dict(name="Arched",   w=10.5, th=1.7, arch=2.6, tilt=0.6),
    "straight": dict(name="Straight", w=10.5, th=2.0, arch=0.0, tilt=0.0),
    "thick":    dict(name="Thick",    w=11.0, th=3.2, arch=0.8, tilt=0.4),
    "thin":     dict(name="Thin",     w=10.0, th=1.0, arch=1.6, tilt=0.4),
    "angry":    dict(name="Fierce",   w=10.5, th=2.4, arch=0.6, tilt=-2.6),
}
BROW_IDS = list(BROWS.keys())


def _crop(rgba, cx, cy):
    x0 = int(round((cx + A.OX - EW / 2) * A.F))
    y0 = int(round((cy + A.OY - EH / 2) * A.F))
    return rgba[y0:y0 + EH * A.F, x0:x0 + EW * A.F]


def _finish(rgba_crop):
    pm = rgba_crop.copy()
    pm[..., :3] *= pm[..., 3:4]
    small = cv2.resize(pm, (OUT_W, OUT_H), interpolation=cv2.INTER_AREA)
    a = small[..., 3:4]
    rgb = np.where(a > 1e-4, small[..., :3] / np.maximum(a, 1e-6), 0)
    from PIL import Image
    arr = (np.concatenate([np.clip(rgb, 0, 1), np.clip(a, 0, 1)], -1) * 255 + 0.5).astype(np.uint8)
    return Image.fromarray(arr, "RGBA")


def eye_outline(p, scale=1.0, flip=False, cx=54, cy=50):
    w, hu, hd = p["w"] * scale, p["hu"] * scale * p["open"], p["hd"] * scale
    t = p["tilt"] * scale
    pk = (p["peak"] - 0.5) * w * 0.9
    sgn = -1 if flip else 1
    # the near eye (left) has its outer corner on the LEFT: the tilt raises that corner
    L = (cx - w, cy - t * 0.5)
    R = (cx + w, cy + t * 0.5)
    up = [(cx - w * 0.55, cy - hu * 0.78 - t * 0.2), (cx + pk, cy - hu), (cx + w * 0.55, cy - hu * 0.72 + t * 0.2)]
    dn = [(cx + w * 0.5, cy + hd * 0.85), (cx, cy + hd), (cx - w * 0.5, cy + hd * 0.82)]
    ctrl = [L] + up + [R] + dn
    return A.curve_pts(ctrl, 18, closed=True), L, R, up, dn


def make_eye(style, far=False):
    """Returns (base, iris, top) PIL images for one eye."""
    p = EYES[style]
    sc = 0.84 if far else 1.0
    cx, cy = 54.0, 50.0
    pts, L, R, up, dn = eye_outline(p, sc, cx=cx, cy=cy)
    opening = A.smooth(A.poly(pts), 0.35)
    kind = p["kind"]
    base = A.blank(); iris = A.blank(); top = A.blank()
    ir = p["iris"] * min(p["hu"] * p["open"] + p["hd"], p["w"]) * sc * (0.62 if kind not in ("cat",) else 0.7)
    look = 0.30 * p["w"] * sc                       # the eyes look toward the front (right)
    icx, icy = cx + look, cy + (p["hd"] - p["hu"] * p["open"]) * sc * 0.18
    if kind == "alien":
        shp = A.smooth(opening, 0.5)
        base = A.over(A.paint(shp, (28, 30, 40), "glass", bevel=2.6, outline=0.95, spec=0.5, rim=0.0), base)
        # glossy highlight arc and a faint inner glow (iris layer = coloured gleam)
        gl = A.inter(A.ellipse(cx - w_ if (w_ := p["w"] * sc * 0.18) else cx, cy - 2.2 * sc, p["w"] * sc * 0.38, 1.4 * sc, -18), shp)
        top = A.over(A.tint_layer(gl, (255, 255, 255), 0.85), top)
        top = A.over(A.tint_layer(A.inter(A.blob(cx + p["w"] * sc * 0.28, cy + 1.6 * sc, 0.8 * sc), shp), (255, 255, 255), 0.7), top)
        glow = A.inter(A.ellipse(cx + 1.0, cy + 0.8 * sc, p["w"] * sc * 0.5, p["hu"] * sc * 0.45, 12), shp)
        iris = A.over(A.tint_layer(A.blur(glow, 1.2), (255, 255, 255), 0.55, within=shp), iris)
        return _finish(_crop(base, cx, cy)), _finish(_crop(iris, cx, cy)), _finish(_crop(top, cx, cy))
    if kind == "compound":
        rx, ry = p["w"] * sc, (p["hu"] + p["hd"]) * 0.5 * sc
        dome = A.smooth(A.ellipse(cx, cy, rx, ry, -12), 0.4)
        base = A.over(A.paint(dome, (70, 28, 34), "chitin", bevel=3.4, outline=1.0, ambient=0.5, spec=0.4), base)
        facets = A.empty()
        for gx in np.arange(-rx, rx, 3.1):
            for gy in np.arange(-ry, ry, 3.1):
                if (gx / rx) ** 2 + (gy / ry) ** 2 < 0.82:
                    A.ellipse(cx + gx + (1.5 if int(gy / 3.1) % 2 else 0), cy + gy, 1.25, 1.25, 0, facets)
        iris = A.over(A.paint(A.inter(facets, dome), (255, 255, 255), "glass", bevel=0.7, outline=0.0, ambient=0.8, spec=0.0, rim=0.0), iris)
        top = A.over(A.tint_layer(A.inter(A.ellipse(cx - rx * 0.3, cy - ry * 0.4, rx * 0.34, ry * 0.2, -35), dome), (255, 255, 255), 0.85), top)
        return _finish(_crop(base, cx, cy)), _finish(_crop(iris, cx, cy)), _finish(_crop(top, cx, cy))
    if kind == "visor":
        slit = A.smooth(A.poly([(cx - p["w"] * sc, cy - 1.2 * sc), (cx + p["w"] * sc, cy - 2.2 * sc), (cx + p["w"] * sc, cy + 1.6 * sc), (cx - p["w"] * sc, cy + 2.4 * sc)]), 0.5)
        base = A.over(A.paint(slit, (18, 22, 34), "glass", bevel=1.6, outline=0.9, spec=0.35, rim=0.0), base)
        core = A.inter(A.poly([(cx - p["w"] * sc * 0.82, cy - 0.5 * sc), (cx + p["w"] * sc * 0.82, cy - 1.4 * sc), (cx + p["w"] * sc * 0.82, cy + 0.5 * sc), (cx - p["w"] * sc * 0.82, cy + 1.2 * sc)]), slit)
        iris = A.over(A.tint_layer(A.blur(core, 0.35), (255, 255, 255), 1.0), iris)
        halo = A.blur(core, 1.6)
        iris = A.over(A.tint_layer(halo, (255, 255, 255), 0.5), iris)
        top = A.over(A.tint_layer(A.inter(A.ellipse(cx - 3, cy - 1.0 * sc, 2.6 * sc, 0.45 * sc, -6), core), (255, 255, 255), 0.95), top)
        return _finish(_crop(base, cx, cy)), _finish(_crop(iris, cx, cy)), _finish(_crop(top, cx, cy))

    # ---- human-like family (round, narrow, almond, angular, heavy, large, small, sleepy, cat, glow)
    sclera_col = (250, 250, 252) if kind != "glow" else (255, 252, 240)
    base = A.over(A.paint(opening, sclera_col, "matte", bevel=1.8, outline=0.0, ambient=0.8, rim=0.0), base)
    # soft shadow under the upper lid
    lid_shadow = A.inter(opening, A.shift(opening, 0, 2.4 * sc))
    lid_shadow = A.sub(opening, lid_shadow)
    base = A.over(A.tint_layer(A.blur(lid_shadow, 0.6), (90, 96, 130), 0.55, within=opening), base)
    # lid line (thick on top, thin below)
    up_curve = A.curve_pts([L] + up + [R], 16)
    dn_curve = A.curve_pts([R] + dn + [L], 16)
    lid = A.line(up_curve, p["lidw"] * sc * 0.9)
    lid = A.union(lid, A.line(dn_curve, 0.55 * sc))
    base = A.over(A.tint_layer(lid, (20, 24, 38), 1.0), base)
    # iris
    ir_r = ir
    iris_m = A.inter(A.ellipse(icx, icy, ir_r * (0.92 if kind != "cat" else 0.78), ir_r, 0), opening)
    if kind == "cat":
        iris_m = A.inter(A.ellipse(icx, icy, ir_r * 0.86, ir_r * 1.15, 0), opening)
    dark_rim = A.sub(iris_m, A.shrink(iris_m, 0.7) if hasattr(A, "shrink") else A.grow(iris_m, -0.7))
    iris_img = A.paint(iris_m, (255, 255, 255), "glass", bevel=1.5, outline=0.0, ambient=0.72, spec=0.0, rim=0.0)
    iris = A.over(iris_img, iris)
    iris = A.over(A.tint_layer(dark_rim, (40, 40, 60), 0.55), iris)
    # radial streaks in the iris
    for a in np.linspace(0, 2 * np.pi, 9, endpoint=False):
        s = A.line([(icx + np.cos(a) * ir_r * 0.35, icy + np.sin(a) * ir_r * 0.35), (icx + np.cos(a) * ir_r * 0.85, icy + np.sin(a) * ir_r * 0.85)], 0.28)
        iris = A.over(A.tint_layer(s, (30, 30, 50), 0.22, within=iris_m), iris)
    # pupil
    if kind == "cat":
        pup = A.ellipse(icx, icy, ir_r * 0.16, ir_r * 0.92, 0)
    else:
        pup = A.ellipse(icx, icy, ir_r * 0.42, ir_r * 0.42, 0)
    iris = A.over(A.tint_layer(A.inter(pup, opening), (6, 8, 14), 1.0), iris)
    # upper-lid shadow over the iris (lid casts a shadow on it)
    shade = A.sub(iris_m, A.shift(iris_m, 0, 1.5 * sc))
    iris = A.over(A.tint_layer(shade, (10, 12, 30), 0.5), iris)
    if kind == "glow":
        glow = A.blur(iris_m, 2.4)
        iris = A.over(A.tint_layer(glow, (255, 255, 255), 0.55), iris)
        base = A.over(A.tint_layer(A.blur(opening, 1.4), (255, 255, 255), 0.35), base)
    # highlights + lashes in the top layer
    hl = A.blob(icx - ir_r * 0.34, icy - ir_r * 0.38, max(0.7, ir_r * 0.24))
    hl2 = A.blob(icx + ir_r * 0.30, icy + ir_r * 0.34, max(0.4, ir_r * 0.11))
    top = A.over(A.tint_layer(A.inter(A.union(hl, hl2), opening), (255, 255, 255), 0.95), top)
    # re-draw the thick upper lid on top so the iris never covers it
    top = A.over(A.tint_layer(A.inter(A.line(up_curve, p["lidw"] * sc * 0.9), A.grow(opening, 0.6)), (20, 24, 38), 1.0), top)
    if p["lash"] > 0:
        fl = A.line([L, (L[0] - 2.4 * p["lash"] * sc, L[1] - 2.0 * p["lash"] * sc)], 0.9 * sc)
        fl = A.union(fl, A.line([(L[0] + 2.0, L[1] - p["hu"] * sc * 0.4), (L[0] - 1.0, L[1] - p["hu"] * sc * 0.8 - p["lash"] * 1.2)], 0.7 * sc))
        top = A.over(A.tint_layer(fl, (20, 24, 38), 1.0), top)
    if kind == "angular":
        wing = A.poly([(R[0] - 1, R[1] - 0.6), (R[0] + 3.2, R[1] - 2.6), (R[0] - 0.6, R[1] + 0.8)])
        top = A.over(A.tint_layer(wing, (20, 24, 38), 1.0), top)
    return _finish(_crop(base, cx, cy)), _finish(_crop(iris, cx, cy)), _finish(_crop(top, cx, cy))


def make_brow(style, far=False):
    p = BROWS[style]
    if p is None:
        return None
    sc = 0.84 if far else 1.0
    cx, cy = 54.0, 50.0
    w, th = p["w"] * sc, p["th"] * sc
    t = p["tilt"] * sc
    arch = p["arch"] * sc
    # near brow: outer end on the left. tilt > 0 raises the outer end
    pts = A.curve_pts([(cx - w / 2, cy + t * 0.5), (cx - w * 0.15, cy - arch * 0.8), (cx + w * 0.22, cy - arch), (cx + w / 2, cy - t * 0.5 + 0.4)], 16)
    m = A.line(pts, th)
    # taper the inner end
    taper = A.half_plane((cx + w * 0.3, cy - 20), (cx + w * 0.3, cy + 20), below=False)
    m = A.union(A.inter(m, taper), A.smooth(A.inter(m, A.sub(A.half_plane((0, 0), (1, 0)) * 0 + 1, taper)), 0.3) * 0.85)
    m = A.smooth(m, 0.35)
    img = A.paint(m, (255, 255, 255), "hair", bevel=0.9, outline=0.0, ambient=0.62, rim=0.0)
    return _finish(_crop(img, cx, cy))


if __name__ == "__main__":
    from PIL import Image
    import sys
    cols = 6
    ims = []
    for sid in EYE_IDS:
        b, i, t = make_eye(sid)
        bg = Image.new("RGBA", b.size, (232, 188, 156, 255))
        tint = Image.new("RGBA", i.size, (90, 170, 230, 255))
        ii = Image.fromarray((np.array(i).astype(np.float32) * np.array(tint).astype(np.float32) / 255).astype(np.uint8))
        bg.alpha_composite(b); bg.alpha_composite(ii); bg.alpha_composite(t)
        ims.append(bg.resize((b.width * 2, b.height * 2), Image.LANCZOS))
    w, h = ims[0].size
    sheet = Image.new("RGBA", (w * cols, h * ((len(ims) + cols - 1) // cols)))
    for k, im in enumerate(ims):
        sheet.paste(im, ((k % cols) * w, (k // cols) * h))
    sheet.save("/tmp/claude-0/shots/eyes_sheet.png")
    bi = []
    for sid in BROW_IDS[1:]:
        m = make_brow(sid)
        bg = Image.new("RGBA", m.size, (232, 188, 156, 255))
        mm = Image.fromarray((np.array(m).astype(np.float32) * np.array([58, 42, 34, 255]) / 255).astype(np.uint8))
        bg.alpha_composite(mm); bi.append(bg.resize((m.width * 2, m.height * 2)))
    s2 = Image.new("RGBA", (bi[0].width * len(bi), bi[0].height))
    for k, im in enumerate(bi): s2.paste(im, (k * im.width, 0))
    s2.save("/tmp/claude-0/shots/brows_sheet.png")
