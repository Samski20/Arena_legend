#!/usr/bin/env python3
"""Mouth expressions for the human heads. One small picture per style (26x18 design units, 4 px per unit); the game puts it
on the head's mouth anchor, so the same mouth fits every head shape. Colours are baked (lips, teeth, tongue).
Run: python3 -I tools/gen_mouths.py   (project root)"""
import numpy as np
import artlib as A

BW, BH, K = 26, 18, 4
CX, CY = 13.0, 8.0
DARK = (70, 22, 32)
LIP = (206, 104, 112)
LIP_L = (232, 140, 142)
LINE = (112, 46, 58)
TEETH = (246, 244, 238)
TEETH_S = (200, 198, 196)
TONGUE = (226, 96, 112)

# style: name, xl/xr half extents, corner heights (+ = down), mid height of the upper lip, opening (mouth height),
#        teeth rows (upper, lower thickness), tongue 0/1/2 (inside / out), extras
STYLES = {
    "smile":   dict(name="Soft Smile",  xl=6.3, xr=6.3, cl=-0.1, cr=-0.9, um=0.9, open=0.0),
    "neutral": dict(name="Neutral",     xl=5.6, xr=5.6, cl=0.0, cr=0.0, um=0.1, open=0.0),
    "smirk":   dict(name="Smirk",       xl=5.8, xr=6.6, cl=0.5, cr=-2.2, um=0.5, open=0.0),
    "frown":   dict(name="Frown",       xl=5.8, xr=5.6, cl=1.0, cr=0.6, um=-0.9, open=0.0),
    "pout":    dict(name="Pout",        xl=3.8, xr=3.8, cl=0.2, cr=0.0, um=0.1, open=0.0, pout=True),
    "grin":    dict(name="Grin",        xl=6.8, xr=6.8, cl=-0.6, cr=-1.6, um=1.2, open=2.6, teeth=(1.7, 1.0)),
    "toothy":  dict(name="Wide Grin",   xl=7.6, xr=7.4, cl=-1.4, cr=-2.4, um=1.0, open=4.2, teeth=(2.3, 1.7), tongue=1),
    "gnash":   dict(name="Gnash",       xl=7.2, xr=7.0, cl=1.0, cr=0.6, um=-1.0, open=3.6, teeth=(2.1, 1.7), angular=True, grit=True),
    "grit":    dict(name="Clenched",    xl=6.4, xr=6.2, cl=0.3, cr=0.1, um=-0.1, open=2.0, teeth=(1.1, 0.9), grit=True),
    "snarl":   dict(name="Snarl",       xl=6.4, xr=7.0, cl=0.7, cr=-1.8, um=0.3, open=2.2, teeth=(1.5, 0.8), curl=True),
    "shout":   dict(name="Shout",       xl=6.2, xr=5.8, cl=0.5, cr=0.2, um=-0.2, open=6.6, teeth=(1.5, 0.0), tongue=1),
    "laugh":   dict(name="Laugh",       xl=7.4, xr=7.2, cl=-1.8, cr=-2.8, um=0.2, open=5.6, teeth=(1.8, 0.0), tongue=1),
    "shock":   dict(name="Shocked",     xl=2.6, xr=2.6, cl=0.0, cr=0.0, um=0.0, open=5.2, round=True),
    "fangs":   dict(name="Fangs",       xl=6.4, xr=6.4, cl=-0.2, cr=-1.1, um=0.9, open=0.0, fangs=True),
    "tongue":  dict(name="Tongue Out",  xl=6.2, xr=6.4, cl=-0.6, cr=-1.4, um=1.4, open=0.9, tongue=2),
}
IDS = list(STYLES)


def _curve(pts):
    return A.curve_pts(pts, 24)


def _strip(top, bot):
    return A.poly(list(top) + list(reversed(bot)))


def make(style):
    s = STYLES[style]
    A.set_canvas(BW, BH, 0, 0, K, 3)
    xl, xr = CX - s["xl"], CX + s["xr"]
    xm = (xl + xr) / 2 + 0.6
    up = _curve([(xl, CY + s["cl"]), (xm, CY + s["um"]), (xr, CY + s["cr"])])
    if s.get("angular"):
        up = [(xl, CY + s["cl"]), (xl + 3, CY + s["um"] + 0.4), (xm, CY + s["um"] - 0.5), (xm + 3.5, CY + s["um"] + 0.2), (xr, CY + s["cr"])]
    if s.get("curl"):
        up = _curve([(xl, CY + s["cl"]), (xm - 1, CY + s["um"] + 0.3), (xr - 3.5, CY - 0.4), (xr, CY + s["cr"])])
    op = s["open"]
    img = A.blank()
    if s.get("round"):
        inner = A.ellipse(CX + 0.6, CY + 1.0, s["xl"], op / 2 + 0.4)
        img = A.over(A.paint(A.grow(inner, 0.9), LIP, "skin", bevel=1.0, outline=0.0, ambient=0.6), img)
        img = A.over(A.tint_layer(A.ellipse(CX + 0.6, CY + 1.0, s["xl"] - 0.2, op / 2 + 0.4 - 0.2), DARK), img)
        img = A.over(A.tint_layer(A.ellipse(CX + 0.6, CY + 2.4, s["xl"] - 1.0, 1.4), TONGUE, 0.9, within=inner), img)
        img = A.over(A.tint_layer(A.sub(A.grow(inner, 1.0), A.grow(inner, 0.7)), LINE), img)
        return img
    if op > 0:
        n_ = len(up)
        low = [(x, y + op * np.sin(np.clip((x - xl) / (xr - xl), 0, 1) * np.pi) ** 0.6) for x, y in up]
        if not s.get('angular'):
            low = _curve([low[0], low[n_ // 4], low[n_ // 2], low[3 * n_ // 4], low[-1]])
        interior = A.smooth(_strip(up, low), 0.25)
        img = A.over(A.tint_layer(interior, DARK), img)
        # tongue
        if s.get("tongue") == 1:
            tg = A.ellipse(xm + 0.2, CY + op * 0.78 + 0.6, (xr - xl) * 0.3, op * 0.34 + 0.6)
            img = A.over(A.paint(A.inter(tg, interior), TONGUE, "skin", bevel=0.9, outline=0.0, ambient=0.6), img)
        # teeth
        tu, tl = s.get("teeth", (0, 0))
        if tu > 0:
            upper = A.inter(_strip(up, [(x, y + tu) for x, y in up]), interior)
            if s.get("grit") and not s.get("angular"):
                upper = A.inter(upper, A.grow(interior, -0.1))
            img = A.over(A.paint(upper, TEETH, "matte", bevel=0.7, outline=0.0, ambient=0.78, rim=0.0), img)
        if tl > 0:
            lower = A.inter(_strip([(x, y - tl) for x, y in low], low), interior)
            img = A.over(A.paint(lower, TEETH_S if not s.get("grit") else TEETH, "matte", bevel=0.7, outline=0.0, ambient=0.72, rim=0.0), img)
        if s.get("grit"):
            # the clenched row: a gap between upper and lower teeth and thin gaps between single teeth
            mid = [((a[0] + b[0]) / 2, (a[1] + b[1]) / 2 + (tu - tl) * 0.15) for a, b in zip(up, low)]
            img = A.over(A.tint_layer(A.inter(A.line(mid, 0.3), interior), (150, 140, 140), 0.9), img)
            for x in np.arange(xl + 1.8, xr - 1.2, 1.7):
                img = A.over(A.tint_layer(A.inter(A.line([(x, CY - 2), (x - 0.1, CY + op + 3)], 0.16), interior), (170, 160, 160), 0.8), img)
        elif tu > 0:
            for x in np.arange(xl + 2.0, xr - 1.0, 1.9):
                img = A.over(A.tint_layer(A.inter(A.line([(x, CY - 2), (x, CY + tu + 1)], 0.14), A.inter(interior, A.grow(interior, 0))), (190, 184, 184), 0.55), img)
        if s.get("curl"):
            fang = A.smooth(A.poly([(xr - 4.6, CY - 0.3), (xr - 3.4, CY - 0.4), (xr - 4.0, CY + 2.1)]), 0.1)
            img = A.over(A.paint(fang, TEETH, "matte", bevel=0.4, outline=0.0, ambient=0.8), img)
        # soft shade under the upper lip
        img = A.over(A.tint_layer(A.blur(A.shift(_strip(up, [(x, y - 1.4) for x, y in up]), 0, 0.5), 0.3), (30, 8, 14), 0.5, within=interior), img)
        lowlip = A.inter(_strip(low, [(x, y + 1.3) for x, y in low]), A.sub(A.grow(interior, 1.4), interior))
        lowlip = _strip(low, [(x, y + 1.3) for x, y in low])
        img = A.over(A.paint(A.smooth(lowlip, 0.3), LIP, "skin", bevel=0.8, outline=0.0, ambient=0.6, rim=0.1), img)
        img = A.over(A.tint_layer(A.line(low, 0.55), LINE, 0.9), img)
        img = A.over(A.tint_layer(A.line(up, 0.65), LINE, 1.0), img)
        if len(low) > 10:
            img = A.over(A.tint_layer(A.shift(A.line([(x, y + 1.0) for x, y in low][3:-3], 0.4), 0, 0.9), LIP_L, 0.5), img)
    else:
        # closed mouth: dark line, the lower lip as a soft rose shape under it
        low_off = 1.9 if s.get("pout") else 1.3
        lowlip = A.ellipse(xm - 0.2, CY + (s["um"] + s["cl"] + s["cr"]) / 3 + low_off, (xr - xl) * 0.38, 1.1 + (0.7 if s.get("pout") else 0.0))
        img = A.over(A.tint_layer(A.blur(lowlip, 0.5), LIP, 0.55), img)
        img = A.over(A.tint_layer(A.line(up, 0.7), LINE, 1.0), img)
        if s.get("pout"):
            img = A.over(A.tint_layer(A.blur(A.ellipse(xm, CY - 1.1, 2.6, 0.8), 0.4), LIP, 0.5), img)
    if s.get("fangs"):
        for fx in (xm - 2.4, xm + 2.6):
            fang = A.smooth(A.poly([(fx - 0.8, CY + 0.7 + (s["cr"] * (fx - xl) / (xr - xl))), (fx + 0.8, CY + 0.6 + (s["cr"] * (fx - xl) / (xr - xl))), (fx, CY + 3.0)]), 0.1)
            img = A.over(A.paint(fang, TEETH, "matte", bevel=0.4, outline=0.2, ambient=0.8, ol_color=LINE), img)
        img = A.over(A.tint_layer(A.line(up, 0.7), LINE, 1.0), img)
    if s.get("tongue") == 2:
        tg = A.ellipse(xm + 1.6, CY + 3.6, 1.9, 3.3, 8)
        img = A.over(A.paint(tg, TONGUE, "skin", bevel=1.1, outline=0.45, ambient=0.6, ol_color=LINE), img)
        img = A.over(A.tint_layer(A.line([(xm + 2.0, CY + 1.8), (xm + 2.2, CY + 4.4)], 0.2), (170, 60, 80), 0.8), img)
        img = A.over(A.tint_layer(A.line(up, 0.7), LINE, 1.0), img)
    return img
