#!/usr/bin/env python3
"""Headgear generated to fit a given Head (v2: richer shapes and baked details).
Layers (all white-based, tinted in game unless noted):
  base  main colour ('helmet')      trim  secondary colour ('accent')     lens  lens colour ('visor')
  shine untinted highlights         back  drawn behind the head           det   details that keep their own colours
hair rule per item:  "keep" = hair stays visible, "front" = front hair hidden (hanging hair still shows), "all" = hidden
hides: other slots the item covers ("facial" for a face mask, "eyes" for opaque eyewear)."""
import numpy as np
import cv2
import artlib as A

GEAR = {
    "none":     dict(name="None", hair="keep", hides=[]),
    "helmet":   dict(name="Combat Helmet", hair="front", hides=[]),
    "visor":    dict(name="Visor Helmet", hair="front", hides=[]),
    "beanie":   dict(name="Beanie", hair="front", hides=[]),
    "cap":      dict(name="Cap", hair="front", hides=[]),
    "beret":    dict(name="Beret", hair="front", hides=[]),
    "boonie":   dict(name="Bush Hat", hair="front", hides=[]),
    "headband": dict(name="Headband", hair="keep", hides=[]),
    "goggles":  dict(name="Goggles", hair="keep", hides=[]),
    "shades":   dict(name="Sunglasses", hair="keep", hides=["eyes"]),
    "mask":     dict(name="Respirator", hair="keep", hides=["facial"]),
    "hood":     dict(name="Hood", hair="all", hides=[]),
    "crown":    dict(name="Circlet", hair="keep", hides=[]),
    "cowl":     dict(name="Hero Cowl", hair="front", hides=[]),
    "hunter":   dict(name="Stalker Helm", hair="all", hides=["facial"]),
    "headset":  dict(name="Comms Headset", hair="keep", hides=[]),
}
GEAR_IDS = list(GEAR.keys())

METAL = (172, 180, 192)
METAL_D = (88, 96, 110)
BRASS = (216, 178, 84)
STRAP = (44, 40, 38)
RUBBER = (36, 38, 44)
OLIVE_D = (60, 66, 50)


def shell(h, t, line_off, front_extra=0.0):
    """Skull grown by t, cut by a line from the nape over the ear up to the brow: the dome of a helmet / cap."""
    ex = h.ear[0]
    ctrl = [(h.back - 10, h.eye_y + 12 + line_off), (ex - 4, h.eye_y - 1 + line_off), (ex + 12, h.brow_y - 5 + line_off), (h.front - 8, h.brow_y - 5 + line_off), (h.front + 12, h.brow_y - 3 + line_off + front_extra)]
    pts = A.curve_pts(ctrl, 12)
    region = A.poly(pts + [(h.front + 30, -40), (h.back - 30, -40)])
    return A.inter(A.grow(h.skull, t), region), region


def P(m, color=(255, 255, 255), mat="metal", bevel=3.0, outline=1.0, ambient=None, spec=None, texture=None, rim=0.18, alpha=1.0):
    return A.paint(m, color, mat, bevel=bevel, outline=outline, ambient=ambient, spec=spec, texture=texture, rim=rim, alpha_scale=alpha)


def stripes(h, pts_fn, n, width=0.5, alt=True, amp=0.5):
    t = np.zeros((A.IH, A.IW), np.float32)
    for i in range(n):
        t += A.line(pts_fn(i), width) * (amp if (i % 2 or not alt) else -amp)
    return t


def glint(m, cx, cy, rx, ry, rot=-14, s=0.5, blur=1.0):
    return A.tint_layer(A.blur(A.inter(A.ellipse(cx, cy, rx, ry, rot), m), blur), (255, 255, 255), s)


def make_gear(h, gid):
    if gid == "none":
        return None
    out = {}
    D = A.blank()                      # baked-colour details
    ex, ey = h.ear
    mid = (h.back + h.front) / 2

    def det(m, color, mat="metal", bevel=1.0, outline=0.6, **kw):
        nonlocal D
        D = A.over(P(m, color, mat, bevel, outline, **kw), D)

    def det_line(pts, w, color, alpha=1.0, curve=True):
        nonlocal D
        pp = A.curve_pts(pts, 12) if curve and len(pts) > 2 else pts
        D = A.over(A.tint_layer(A.line(pp, w), color, alpha), D)

    if gid in ("helmet", "visor"):
        m, region = shell(h, 4.8, -1.0)
        earcut = A.smooth(A.ellipse(ex + 1, ey + 2, 10.5, 12.8), 0.7)
        m = A.sub(m, earcut)                                 # high-cut around the ear
        lip = A.smooth(A.poly([(h.front - 22, h.brow_y - 11), (h.front + 8, h.brow_y - 9), (h.front + 10, h.brow_y - 5), (h.front - 18, h.brow_y - 3)]), 0.5)
        m = A.smooth(A.union(m, A.inter(lip, A.grow(A.union(h.skull, A.ellipse(h.front - 8, h.brow_y - 5, 24, 8)), 6))), 0.8)
        sheen = P(m, mat="metal", bevel=5.8, outline=1.15, ambient=0.5, spec=0.42)
        out["base"] = sheen
        # woven cover band + centre ridge as the secondary colour
        band = A.inter(A.sub(m, A.shift(m, 0, -4.2)), A.grow(region, 0.5))
        ridge = A.inter(A.line(A.curve_pts([(h.front - 4, h.brow_y - 8), (h.front - 24, h.top + 1), (h.back + 20, h.top + 7), (h.back + 5, h.eye_y - 4)], 12), 2.8), m)
        out["trim"] = P(A.union(band, ridge), mat="cloth", bevel=1.6, outline=0.0, ambient=0.55, rim=0.0, texture=stripes(h, lambda i: [(h.back + 8 + i * 3.4, h.top - 6), (h.back + 8 + i * 3.4, h.eye_y + 14)], 28, 0.5, amp=0.6))
        # ear cup of the headset under the cut + bolts + rails
        det(A.smooth(A.ellipse(ex + 1, ey + 2, 6.4, 8.4), 0.5), (52, 56, 64), "metal", 1.6, 0.7)
        det(A.smooth(A.ellipse(ex + 1, ey + 2, 3.2, 4.6), 0.4), (28, 30, 36), "matte", 1.0, 0.0)
        det(A.smooth(A.poly([(ex + 12, ey - 17), (ex + 30, ey - 19), (ex + 31, ey - 14), (ex + 13, ey - 12)]), 0.4), METAL_D, "metal", 1.0, 0.6)   # side rail
        for dx in (15, 21, 27):
            det(A.ellipse(ex + dx, ey - 15.6, 0.9, 0.9), METAL, "metal", 0.3, 0.2)
        det(A.smooth(A.poly([(h.front - 14, h.brow_y - 16), (h.front + 2, h.brow_y - 14.5), (h.front + 2, h.brow_y - 8), (h.front - 14, h.brow_y - 9)]), 0.5), METAL_D, "metal", 1.2, 0.65)   # NVG shroud
        det(A.ellipse(h.front - 6, h.brow_y - 11.5, 1.8, 1.8), (30, 32, 38), "matte", 0.5, 0.3)
        # chin strap
        det_line([(ex + 5, ey + 12), (ex + 2, ey + 22), (mid + 6, h.chin_y - 1)], 1.4, STRAP)
        det(A.smooth(A.poly([(mid + 2, h.chin_y - 4), (mid + 10, h.chin_y - 4), (mid + 10, h.chin_y + 1), (mid + 2, h.chin_y + 1)]), 0.4), METAL, "metal", 0.6, 0.4)
        out["shine"] = glint(m, h.front - 40, h.top + 9, 18, 4.2, -14, 0.55)
        if gid == "visor":
            vis = A.smooth(A.union(A.ellipse(h.eye_near[0] + 10, h.eye_y + 1.5, 26, 13.4), A.ellipse(h.eye_far[0] + 4, h.eye_y + 1, 12.5, 12.4)), 1.2)
            vis = A.inter(vis, A.grow(h.skull, 1.6))
            out["lens"] = P(vis, mat="glass", bevel=3.2, outline=1.0, ambient=0.75, spec=0.5, alpha=0.62)
            frame = A.sub(A.grow(vis, 1.5), vis)
            det(A.smooth(frame, 0.3), (40, 44, 54), "metal", 1.0, 0.0)
            det(A.smooth(A.poly([(h.front - 6, h.eye_y - 14), (h.front + 8, h.eye_y - 12), (h.front + 8, h.eye_y + 14), (h.front - 6, h.eye_y + 14)]), 0.3) * 0, (0, 0, 0))
            g1 = A.inter(A.poly([(h.eye_near[0] - 6, h.eye_y - 12), (h.eye_near[0] + 4, h.eye_y - 12), (h.eye_near[0] - 6, h.eye_y + 11), (h.eye_near[0] - 15, h.eye_y + 11)]), vis)
            out["shine"] = A.over(A.tint_layer(g1, (255, 255, 255), 0.4), out["shine"])
            # antenna stub
            det(A.smooth(A.poly([(h.back + 20, h.top + 1), (h.back + 22, h.top - 13), (h.back + 24, h.top - 13), (h.back + 24, h.top + 2)]), 0.3), (60, 66, 76), "metal", 0.6, 0.5)
    elif gid == "beanie":
        m, region = shell(h, 5.6, -4.5)
        bump = A.smooth(A.ellipse(mid - 2, h.top - 1.5, 28, 8), 1.0)
        m = A.smooth(A.union(m, A.inter(bump, A.grow(region, 7))), 1.0)
        ribs = stripes(h, lambda i: [(h.back + i * 3.0, h.top - 10), (h.back + i * 3.0 + (h.front - h.back - i * 3.0) * 0.38, h.eye_y + 20)], 46, 0.55, amp=0.55)
        out["base"] = P(m, mat="cloth", bevel=5.4, outline=1.05, ambient=0.54, texture=ribs * 0.65)
        cuff = A.inter(A.sub(m, A.shift(m, 0, -7.4)), A.grow(region, 0.5))
        ctex = stripes(h, lambda i: [(h.back - 12 + i * 2.2, h.eye_y - 22), (h.back - 12 + i * 2.2, h.eye_y + 22)], 62, 0.5, amp=0.7)
        out["trim"] = P(cuff, mat="cloth", bevel=2.2, outline=0.0, ambient=0.58, texture=ctex * 0.55, rim=0.0)
        stripe = A.inter(A.sub(cuff, A.shift(cuff, 0, -2.4)), cuff)
        out["trim"] = A.over(A.tint_layer(A.shift(stripe, 0, 1.6), (0, 0, 0), 0.0), out["trim"])
        det(A.smooth(A.poly([(h.front - 14, h.brow_y - 5), (h.front - 4, h.brow_y - 5), (h.front - 4, h.brow_y + 1), (h.front - 14, h.brow_y + 1)]), 0.4), (210, 214, 220), "cloth", 0.5, 0.45)   # woven tag
        det_line([(h.front - 12, h.brow_y - 2), (h.front - 6, h.brow_y - 2)], 0.7, (60, 66, 80))
        out["shine"] = glint(m, h.front - 40, h.top + 8, 16, 4, -12, 0.25, 1.2)
    elif gid == "cap":
        m, region = shell(h, 4.4, -3.5)
        dome = A.smooth(m, 1.0)
        panels = np.zeros((A.IH, A.IW), np.float32)
        for k in range(4):
            panels += A.line(A.curve_pts([(h.back + 12 + k * 3, h.eye_y - 14), (mid - 6 + k * 8, h.top - 2), (h.front - 22 + k * 5, h.brow_y - 6)], 10), 0.5) * (0.6 if k % 2 else -0.6)
        out["base"] = P(dome, mat="cloth", bevel=5.4, outline=1.05, ambient=0.54, texture=panels * 0.5)
        brim = A.smooth(A.poly([(h.front - 14, h.brow_y - 9), (h.front + 4, h.brow_y - 12), (h.front + 22, h.brow_y - 4), (h.front + 26, h.brow_y + 3), (h.front + 8, h.brow_y + 2), (h.front - 14, h.brow_y - 1)]), 1.0)
        btn = A.blob(mid - 2, h.top - 3.2, 2.4)
        under = A.inter(A.sub(brim, A.shift(brim, 0, -3.2)), brim)
        brimimg = P(brim, mat="cloth", bevel=2.4, outline=1.05, ambient=0.52, spec=0.18)
        out["trim"] = A.over(P(btn, mat="cloth", bevel=1.4, outline=0.9, ambient=0.5), brimimg)
        out["trim"] = A.over(A.tint_layer(under, (10, 12, 24), 0.35), out["trim"])
        det(A.smooth(A.poly([(h.front - 30, h.brow_y - 24), (h.front - 14, h.brow_y - 23), (h.front - 14, h.brow_y - 12), (h.front - 30, h.brow_y - 13)]), 1.4), (236, 238, 242), "cloth", 1.0, 0.7)    # logo patch
        det(A.smooth(A.poly([(h.front - 25, h.brow_y - 21), (h.front - 19, h.brow_y - 21), (h.front - 22, h.brow_y - 15)]), 0.3), (210, 70, 60), "matte", 0.3, 0.0)
        for k in range(3):
            det(A.ellipse(mid - 12 + k * 7, h.top + 4.5 - abs(k - 1) * 0.5, 0.9, 0.9), (20, 22, 30), "matte", 0.3, 0.0)    # eyelets
        det(A.smooth(A.poly([(h.back - 4, h.eye_y - 8), (h.back + 7, h.eye_y - 9), (h.back + 8, h.eye_y - 2), (h.back - 3, h.eye_y - 1)]), 0.3), (50, 54, 62), "cloth", 0.5, 0.4)   # size strap
        out["shine"] = glint(dome, h.front - 40, h.top + 8, 15, 3.6, -12, 0.28, 1.2)
    elif gid == "beret":
        m, region = shell(h, 4.6, -5.5)
        puff = A.smooth(A.ellipse(mid - 6, h.top + 2, 38, 13), 1.4)
        puff = A.inter(puff, A.poly([(-50, -80), (200, -80), (200, h.brow_y - 4), (-50, h.eye_y - 6)]))
        m = A.smooth(A.union(m, puff), 1.2)
        tex = stripes(h, lambda i: [(mid - 22 + i * 4, h.top - 8), (mid - 16 + i * 4, h.eye_y - 4)], 12, 0.7, amp=0.4)
        out["base"] = P(m, mat="cloth", bevel=6.0, outline=1.05, ambient=0.54, texture=tex * 0.4)
        band = A.inter(A.sub(m, A.shift(m, 0, -3.0)), A.grow(region, 0.5))
        out["trim"] = P(band, mat="leather", bevel=1.4, outline=0.0, ambient=0.5, rim=0.0)
        det(A.smooth(A.ellipse(h.front - 20, h.brow_y - 8, 4.6, 5.0), 0.5), BRASS, "metal", 1.6, 0.7)
        det(A.smooth(A.poly([(h.front - 20, h.brow_y - 12), (h.front - 17, h.brow_y - 6), (h.front - 20, h.brow_y - 4), (h.front - 23, h.brow_y - 6)]), 0.3), (150, 40, 40), "matte", 0.5, 0.0)
        det(A.ellipse(mid - 6, h.top - 1, 1.6, 1.6), (30, 32, 38), "matte", 0.4, 0.3)
        out["shine"] = glint(m, h.front - 42, h.top + 6, 14, 3.4, -10, 0.2, 1.2)
    elif gid == "boonie":
        m, region = shell(h, 5.0, -6.5)
        crown_top = A.smooth(A.ellipse(mid - 2, h.top - 1.5, 27, 8), 1.0)
        m = A.smooth(A.union(m, A.inter(crown_top, A.grow(region, 8))), 1.0)
        brim_y = h.brow_y - 6
        brim = A.smooth(A.poly(A.curve_pts([(h.back - 12, h.eye_y - 4), (h.back + 10, brim_y + 5), (mid, brim_y + 3), (h.front + 6, brim_y + 4), (h.front + 20, brim_y + 9),
                                             (h.front + 4, brim_y + 12), (mid, brim_y + 10), (h.back + 6, brim_y + 12)], 8, closed=True)), 1.0)
        panels = stripes(h, lambda i: [(h.back + 6 + i * 5, h.top - 6), (h.back + 4 + i * 5, brim_y)], 16, 0.4, amp=0.4)
        out["base"] = P(m, mat="cloth", bevel=5.0, outline=1.05, ambient=0.54, texture=panels * 0.5)
        out["trim"] = P(brim, mat="cloth", bevel=2.2, outline=1.05, ambient=0.5, spec=0.1, texture=None)
        # brim stitching + eyelets + a cord around the crown
        det_line([(h.back - 6, brim_y + 8), (mid, brim_y + 7), (h.front + 12, brim_y + 8)], 0.4, (30, 34, 28), alpha=0.7)
        det_line([(h.back - 2, brim_y - 1), (mid, brim_y - 4), (h.front - 10, brim_y - 4)], 1.1, (92, 82, 60))
        for k in range(4):
            det(A.ellipse(h.back + 14 + k * 5, brim_y - 7 + abs(k - 1.5) * 0.4, 0.9, 0.9), (20, 22, 24), "matte", 0.3, 0.0)
        out["shine"] = glint(m, h.front - 42, h.top + 7, 13, 3.2, -10, 0.2, 1.2)
    elif gid == "headband":
        ctrl = [(h.back - 4, h.eye_y - 2), (h.back + 20, h.brow_y - 8), (h.front - 30, h.brow_y - 12), (h.front - 6, h.brow_y - 9), (h.front + 2, h.brow_y - 7)]
        band = A.line(A.curve_pts(ctrl, 14), 5.6)
        band = A.inter(A.smooth(band, 0.4), A.grow(h.skull, 3.0))
        out["base"] = P(band, mat="cloth", bevel=1.8, outline=1.0, ambient=0.58, texture=stripes(h, lambda i: [(h.back + i * 3, h.brow_y - 16), (h.back + i * 3, h.brow_y + 4)], 40, 0.4, amp=0.4) * 0.5)
        knot = A.union(A.ellipse(h.back + 1, h.eye_y - 4, 4.4, 3.4),
                       A.poly(A.curve_pts([(h.back + 1, h.eye_y - 4), (h.back - 7, h.eye_y + 2), (h.back - 13, h.eye_y + 12), (h.back - 8, h.eye_y + 12), (h.back - 3, h.eye_y + 4)], 6)),
                       A.poly(A.curve_pts([(h.back + 1, h.eye_y - 4), (h.back - 9, h.eye_y - 5), (h.back - 15, h.eye_y - 1), (h.back - 9, h.eye_y + 2)], 6)))
        out["back"] = P(A.smooth(knot, 0.5), mat="cloth", bevel=1.4, outline=0.95, ambient=0.56)
        stripe = A.inter(A.line(A.curve_pts([(a, b + 0.4) for a, b in ctrl], 14), 1.2), band)
        out["trim"] = P(stripe, mat="cloth", bevel=0.5, outline=0.0, ambient=0.7, rim=0.0)
        plate = A.smooth(A.poly([(h.front - 40, h.brow_y - 16), (h.front - 14, h.brow_y - 15), (h.front - 14, h.brow_y - 6), (h.front - 40, h.brow_y - 7)]), 1.0)
        plate = A.inter(plate, A.grow(h.skull, 5))
        det(plate, (176, 184, 196), "metal", 1.6, 0.7)
        det(A.smooth(A.poly([(h.front - 30, h.brow_y - 13.5), (h.front - 24, h.brow_y - 14), (h.front - 24, h.brow_y - 8.4), (h.front - 30, h.brow_y - 8.8)]), 0.3), (44, 52, 70), "matte", 0.4, 0.0)
    elif gid in ("goggles", "shades"):
        lens_c = [h.eye_near, h.eye_far]
        strap_pts = A.curve_pts([(h.back - 4, h.eye_y - 4), (h.back + 22, h.eye_y - 8), (h.eye_near[0] - 14, h.eye_y - 4)], 12)
        strap = A.inter(A.line(strap_pts, 3.6 if gid == "goggles" else 2.2), A.grow(h.skull, 3.0))
        if gid == "goggles":
            frame = A.empty(); lens = A.empty()
            for i, (cx, cy) in enumerate(lens_c):
                rx = 12.4 if i == 0 else 10.2
                ry = 10.2
                A.ellipse(cx, cy, rx + 2.6, ry + 2.6, 0, frame)
                A.ellipse(cx, cy, rx, ry, 0, lens)
            bridge = A.line([(h.eye_near[0] + 11, h.eye_y - 1), (h.eye_far[0] - 9, h.eye_y - 1)], 2.6)
            frame = A.smooth(A.union(frame, bridge), 0.5)
            rubber = A.paint(frame, (255, 255, 255), "matte", bevel=2.4, outline=1.05, ambient=0.5, spec=0.12)
            out["base"] = A.over(rubber, P(strap, mat="cloth", bevel=1.2, outline=0.95, ambient=0.5))
            out["lens"] = P(lens, mat="glass", bevel=2.8, outline=0.0, ambient=0.78, spec=0.55, alpha=0.66, rim=0.0)
            out["trim"] = P(A.sub(A.grow(lens, 0.6), lens), mat="metal", bevel=0.8, outline=0.0, ambient=0.55, spec=0.4, rim=0.0)
            for (cx, cy) in lens_c:
                for a in (-1.0, 1.0):
                    det(A.ellipse(cx + a * 5, cy - 11.6, 0.8, 0.8), (22, 24, 28), "matte", 0.2, 0.0)       # vents
            det(A.smooth(A.poly([(h.back + 14, h.eye_y - 9), (h.back + 20, h.eye_y - 10), (h.back + 20, h.eye_y - 5), (h.back + 14, h.eye_y - 4)]), 0.3), METAL, "metal", 0.6, 0.45)   # strap buckle
            sh = A.inter(A.poly([(h.eye_near[0] - 6, h.eye_y - 10), (h.eye_near[0] + 1, h.eye_y - 10), (h.eye_near[0] - 7, h.eye_y + 6), (h.eye_near[0] - 12, h.eye_y + 6)]), lens)
            out["shine"] = A.tint_layer(sh, (255, 255, 255), 0.5)
        else:
            # one wraparound lens
            lens = A.smooth(A.union(A.ellipse(h.eye_near[0] + 1, h.eye_y + 0.5, 13.4, 8.4, 4), A.ellipse(h.eye_far[0], h.eye_y, 10.6, 8.0, -4),
                                    A.line([(h.eye_near[0] + 10, h.eye_y - 3), (h.eye_far[0] - 8, h.eye_y - 3)], 6.0)), 1.1)
            frame = A.smooth(A.union(A.grow(lens, 1.5), A.line([(h.eye_near[0] - 12, h.eye_y - 3), (h.back + 24, h.eye_y - 5)], 2.4)), 0.4)
            out["base"] = A.over(P(frame, mat="metal", bevel=1.8, outline=1.05, ambient=0.5, spec=0.38), P(strap, mat="cloth", bevel=1.0, outline=0.9, ambient=0.5))
            out["lens"] = P(lens, (28, 32, 46), "glass", bevel=2.8, outline=0.0, ambient=0.9, spec=0.6, alpha=0.97, rim=0.0)
            det(A.smooth(A.poly([(h.eye_near[0] - 10, h.eye_y - 6.5), (h.eye_near[0] - 2, h.eye_y - 7), (h.eye_near[0] - 9, h.eye_y + 5), (h.eye_near[0] - 14, h.eye_y + 4)]) * 0 + A.inter(A.poly([(h.eye_near[0] - 8, h.eye_y - 7), (h.eye_near[0], h.eye_y - 7), (h.eye_near[0] - 7, h.eye_y + 5), (h.eye_near[0] - 13, h.eye_y + 5)]), lens), 0.3), (96, 140, 180), "glass", 0.4, 0.0, alpha=0.55)
            out["shine"] = A.tint_layer(A.inter(A.poly([(h.eye_near[0] - 7, h.eye_y - 6), (h.eye_near[0] + 1, h.eye_y - 6), (h.eye_near[0] - 6, h.eye_y + 5), (h.eye_near[0] - 11, h.eye_y + 5)]), lens), (255, 255, 255), 0.5)
    elif gid == "mask":
        # half-face respirator: moulded shell over nose and mouth, two filter canisters, head straps
        ctrl = [(ex - 2, h.eye_y + 9), (ex + 14, h.nose_y - 1), (h.front - 26, h.nose_y - 3), (h.front + 3, h.nose_y - 4), (h.front + 10, h.nose_y + 2)]
        upper = A.curve_pts(ctrl, 12)
        zone = A.poly(upper + [(h.front + 30, 140), (ex - 12, 140)])
        m = A.inter(A.grow(h.skull, 2.8), zone)
        snout = A.inter(A.grow(A.ellipse(h.nose[0] - 1.6, h.nose[1], 3.4, 2.8), 1.6), zone)
        m = A.smooth(A.union(m, snout), 1.0)
        m = A.inter(m, A.poly([(h.back - 20, h.nose_y - 8), (h.front + 30, h.nose_y - 8), (h.front + 30, h.chin_y + 6), (h.back - 20, h.chin_y + 6)]))
        out["base"] = P(m, mat="matte", bevel=4.6, outline=1.05, ambient=0.52, spec=0.2)
        rim = A.inter(A.sub(m, A.grow(m, -1.8)), m)
        out["trim"] = P(rim, mat="cloth", bevel=0.6, outline=0.0, ambient=0.5, rim=0.0)
        # canisters
        for (cx, cy, rr) in ((h.mouth[0] - 8, h.mouth_y + 1, 6.4), (h.mouth[0] + 6, h.mouth_y + 4, 5.6)):
            det(A.smooth(A.ellipse(cx, cy, rr, rr), 0.4), (58, 62, 70), "metal", 2.2, 0.75, spec=0.35)
            det(A.smooth(A.ellipse(cx, cy, rr * 0.6, rr * 0.6), 0.3), (24, 26, 32), "matte", 1.2, 0.0)
            for a in range(6):
                det(A.ellipse(cx + np.cos(a * 1.047) * rr * 0.32, cy + np.sin(a * 1.047) * rr * 0.32, 0.55, 0.55), (110, 116, 126), "metal", 0.2, 0.0)
        det(A.smooth(A.ellipse(h.nose[0] - 6, h.nose_y + 8, 3.0, 2.2), 0.3), (24, 26, 32), "matte", 0.8, 0.5)     # speaking port
        det_line([(ex + 6, h.eye_y + 7), (ex - 8, h.eye_y + 4), (h.back + 3, h.eye_y + 5)], 1.8, STRAP)
        det_line([(ex + 10, h.nose_y + 4), (ex - 6, h.eye_y + 14), (h.back + 6, h.eye_y + 18)], 1.6, STRAP)
        out["shine"] = glint(m, h.mouth[0] - 6, h.nose_y + 6, 7, 2.6, -10, 0.25, 1.0)
    elif gid == "hood":
        # shell grown from the skull; the face opening is cut with a soft peaked brim over the brow
        outer = A.grow(h.skull, 6.4)
        open_ = A.smooth(A.union(A.ellipse(h.front - 29, h.eye_y + 7, 37, 32), A.poly([(h.front - 40, h.brow_y - 6), (h.front + 12, h.brow_y - 6), (h.front + 12, h.chin_y + 5), (h.front - 44, h.chin_y + 5)])), 1.8)
        m = A.sub(outer, open_)
        m = A.inter(m, A.poly([(h.back - 20, h.top - 20), (h.front + 20, h.top - 20), (h.front + 20, h.brow_y - 2), (h.front - 20, h.eye_y + 10), (h.front - 30, h.chin_y + 5), (h.back - 20, h.chin_y + 5)]))
        # the fabric gathers into a rounded point at the back of the neck
        peak = A.smooth(A.poly([(h.back + 6, h.top + 6), (h.back - 12, h.eye_y + 26), (h.back - 6, h.chin_y + 4), (h.back + 30, h.chin_y + 6)]), 1.6)
        m = A.smooth(A.union(m, A.inter(peak, A.grow(h.skull, 13))), 1.6)
        # curved folds that fan from the crown towards the back of the neck
        def fold_pts(i):
            return A.curve_pts([(h.back + 14 + i * 6.5, h.top + 3), (h.back + 4 + i * 5.2, h.eye_y - 4), (h.back + 2 + i * 4.4, h.chin_y + 2)], 10)
        fold = stripes(h, fold_pts, 6, 1.3, amp=0.8)
        out["base"] = P(m, mat="cloth", bevel=6.8, outline=1.1, ambient=0.5, texture=fold * 0.7)
        # stitched rim round the opening
        rimm = A.inter(A.sub(A.grow(open_, 2.6), open_), m)
        out["trim"] = P(rimm, mat="cloth", bevel=1.8, outline=0.0, ambient=0.52, rim=0.0, texture=A.noise(5, 1.4) * 0.4)
        # the inside of the hood falls into shadow just behind the rim: depth round the face
        shade = A.inter(A.sub(A.grow(open_, 7.5), A.grow(open_, 2.0)), m)
        det_shadow = A.tint_layer(A.blur(shade, 2.2), (8, 10, 20), 0.34)
        D = A.over(det_shadow, D)
        # cowl: drapes over the nape and shoulders and ends in a rounded hem (behind the head, in front of the torso's back)
        cowl_ctrl = [(h.back - 2, h.eye_y + 8), (h.back - 9, h.chin_y - 6), (h.back - 4, h.chin_y + 14), (h.back + 16, h.chin_y + 22), (h.back + 38, h.chin_y + 17), (h.back + 47, h.chin_y + 3), (h.back + 40, h.eye_y + 18)]
        drape = A.smooth(A.poly(A.curve_pts(cowl_ctrl, 10)), 1.8)
        fold2 = stripes(h, lambda i: A.curve_pts([(h.back + 6 + i * 9, h.chin_y - 8), (h.back + 4 + i * 9, h.chin_y + 6), (h.back + 7 + i * 8, h.chin_y + 19)], 8), 4, 1.2, amp=0.7)
        out["back"] = P(drape, mat="cloth", bevel=5.2, outline=1.05, ambient=0.44, texture=fold2 * 0.6)
        # drawstrings with metal tips hang from the opening
        for k, dx in enumerate((-33, -25)):
            x0 = h.front + dx
            det_line([(x0, h.chin_y + 3), (x0 + 1.5, h.chin_y + 11 + k * 3), (x0 + 0.5, h.chin_y + 19 + k * 3)], 1.0, (214, 218, 226))
            det(A.smooth(A.ellipse(x0 + 0.5, h.chin_y + 20.5 + k * 3, 1.3, 2.0), 0.3), BRASS, "metal", 0.6, 0.4)
        out["shine"] = glint(m, h.front - 40, h.top + 8, 16, 4, -14, 0.22, 1.2)
    elif gid == "crown":
        ctrl = [(h.back + 6, h.eye_y - 12), (h.back + 28, h.brow_y - 12), (h.front - 30, h.brow_y - 15), (h.front - 8, h.brow_y - 12), (h.front, h.brow_y - 10)]
        pts = A.curve_pts(ctrl, 14)
        band = A.line(pts, 3.6)
        spikes = []
        n = len(pts)
        for k, f in enumerate((0.12, 0.28, 0.44, 0.60, 0.76, 0.9)):
            x, y = pts[int(n * f)]
            ph = (11.0 if k == 2 else 7.0 if k in (1, 3) else 4.4)
            spikes.append(A.poly([(x - 2.8, y + 1), (x - 0.6, y - ph * 0.55), (x, y - ph), (x + 0.6, y - ph * 0.55), (x + 2.8, y + 1)]))
        crown = A.inter(A.smooth(A.union(band, *spikes), 0.35), A.grow(h.skull, 14.0))
        out["base"] = P(crown, mat="metal", bevel=1.9, outline=1.0, ambient=0.5, spec=0.6)
        scroll = np.zeros((A.IH, A.IW), np.float32)
        for k in range(len(pts) // 5):
            x, y = pts[k * 5]
            A.line(A.curve_pts([(x - 1.8, y + 0.4), (x, y - 1.4), (x + 1.8, y + 0.4)], 6), 0.45, scroll)
        out["trim"] = A.over(A.tint_layer(A.inter(scroll, band), (0, 0, 0), 0.0), A.blank())
        gx, gy = pts[int(n * 0.44)]
        gems = A.empty()
        A.ellipse(gx, gy + 0.4, 2.4, 3.0, 0, gems)
        for f in (0.2, 0.68):
            gxx, gyy = pts[int(n * f)]
            A.ellipse(gxx, gyy, 1.3, 1.5, 0, gems)
        out["lens"] = P(gems, mat="glass", bevel=1.0, outline=0.75, ambient=0.8, spec=0.7)
        sx, sy = pts[int(n * 0.28)]
        det_line([(pts[int(n * 0.05)][0], pts[int(n * 0.05)][1] + 0.2)] + [pts[int(n * 0.95)]], 0.35, (150, 110, 40), alpha=0.7, curve=False) if False else None
        out["shine"] = A.tint_layer(A.inter(A.shift(A.line(pts, 0.9), 0.2, -1.3), crown), (255, 255, 255), 0.55)
    elif gid == "headset":
        cup = A.smooth(A.ellipse(ex + 1, ey - 1, 7.0, 9.4), 0.6)
        arc = A.line(A.curve_pts([(ex - 1, ey - 8), (ex + 2, h.brow_y - 14), (mid - 8, h.top - 5), (h.front - 36, h.top + 2), (h.front - 24, h.hairline_y - 3)], 12), 2.4)
        arc = A.inter(arc, A.grow(h.skull, 7.0))
        out["base"] = P(A.smooth(A.union(arc, cup), 0.3), mat="metal", bevel=2.4, outline=1.05, ambient=0.5, spec=0.4)
        mic = A.line(A.curve_pts([(ex + 3, ey + 6), (ex + 14, h.mouth_y + 6), (h.mouth[0] - 10, h.mouth_y + 3), (h.mouth[0] - 2, h.mouth_y - 0.5)], 12), 1.3)
        out["trim"] = A.over(P(A.union(mic, A.ellipse(h.mouth[0] - 1, h.mouth_y - 0.8, 2.8, 2.0)), mat="metal", bevel=1.0, outline=0.9, ambient=0.5), P(A.ellipse(ex + 1, ey - 1, 4.0, 6.0), mat="metal", bevel=1.6, outline=0.0, ambient=0.6, rim=0.0))
        det(A.smooth(A.ellipse(ex + 1, ey - 1, 2.0, 3.0), 0.3), (30, 32, 38), "matte", 0.8, 0.0)
        det(A.ellipse(ex + 5.6, ey - 7, 0.9, 0.9), (80, 240, 140), "glass", 0.3, 0.0)                      # status light
        det_line([(ex + 1, ey + 8), (ex - 2, ey + 20), (ex - 12, ey + 34)], 0.9, (28, 30, 36), alpha=0.9)   # cable
        det(A.smooth(A.ellipse(mid - 12, h.top - 5, 2.4, 1.6), 0.3), (60, 66, 76), "metal", 0.6, 0.4)
        out["shine"] = glint(cup, ex - 1, ey - 4, 2.4, 3.4, 0, 0.5, 0.6)
    elif gid == "cowl":
        m, region = shell(h, 3.6, 6.0, front_extra=4.0)
        m = A.union(m, A.inter(A.grow(h.skull, 2.6), A.poly([(h.back - 10, 0), (h.front + 14, 0), (h.front + 14, h.nose_y - 2), (h.mouth[0] - 18, h.nose_y + 1), (ex + 2, h.mouth_y + 2), (h.back - 10, h.eye_y + 22)])))
        m = A.smooth(m, 0.9)
        holes = A.union(A.ellipse(h.eye_near[0] + 1, h.eye_y + 0.5, 12.6, 7.0, 6), A.ellipse(h.eye_far[0] + 1, h.eye_y, 9.4, 6.4, -4))
        holes = A.smooth(A.union(holes, A.line([(h.eye_near[0] + 10, h.eye_y), (h.eye_far[0] - 8, h.eye_y)], 5.0)), 0.9)
        shell_m = A.sub(m, holes)
        out["base"] = P(shell_m, mat="cloth", bevel=4.8, outline=1.05, ambient=0.5, spec=0.14, texture=A.noise(9, 1.0) * 0.25)
        brow = A.inter(A.sub(A.grow(holes, 1.8), holes), shell_m)
        out["trim"] = P(brow, mat="cloth", bevel=1.2, outline=0.0, ambient=0.62, rim=0.0)
        fin = A.empty()
        for i in range(3):
            A.poly([(h.back + 12 + i * 3, h.eye_y - 4 + i * 5), (h.back - 6 + i * 2, h.eye_y + 6 + i * 5), (h.back + 14 + i * 3, h.eye_y + 6 + i * 5)], fin)
        out["back"] = P(A.smooth(fin, 0.4), mat="cloth", bevel=1.2, outline=0.9, ambient=0.5)
        det_line(A.curve_pts([(h.front - 28, h.top + 8), (mid, h.top + 1), (h.back + 22, h.top + 8)], 8), 0.45, (0, 0, 0), alpha=0.25)
        out["shine"] = glint(shell_m, h.front - 40, h.top + 9, 17, 4, -14, 0.4, 1.0)
    elif gid == "hunter":
        pts = [(h.back - 2, h.eye_y + 16), (h.back - 1, h.eye_y - 14), (h.back + 12, h.top - 1), (h.front - 36, h.top - 3), (h.front - 6, h.top + 10), (h.front + 3, h.brow_y - 2), (h.front + 5, h.nose_y + 2), (h.front + 3, h.mouth_y + 11), (h.front - 8, h.chin_y + 1), (h.mouth[0] - 6, h.chin_y + 4), (ex + 2, h.chin_y - 14)]
        m = A.smooth(A.poly(pts), 0.6)
        out["base"] = P(m, mat="metal", bevel=4.8, outline=1.15, ambient=0.46, spec=0.5)
        facets = A.empty()
        for a, b in (((h.back + 12, h.top), (h.front - 6, h.top + 14)), ((h.front - 6, h.top + 14), (h.front + 6, h.nose_y + 2)), ((h.back + 6, h.eye_y + 10), (h.mouth[0] - 6, h.nose_y + 12)), ((h.back + 14, h.top + 2), (h.back + 4, h.eye_y + 6))):
            A.line([a, b], 0.9, facets)
        snout = A.inter(A.poly([(h.mouth[0] - 6, h.nose_y + 3), (h.front + 8, h.nose_y + 4), (h.front + 6, h.mouth_y + 12), (h.mouth[0] - 8, h.mouth_y + 10)]), m)
        vents = A.empty()
        for i in range(4):
            A.line([(h.mouth[0] + 1, h.mouth_y + 2 + i * 2.8), (h.front + 3, h.mouth_y + 2 + i * 2.8)], 0.9, vents)
        trim = A.union(A.smooth(A.sub(snout, A.shift(snout, 0, -2)), 0.3), A.inter(facets, m))
        out["trim"] = A.over(P(A.inter(vents, m), mat="metal", bevel=0.6, outline=0.0, ambient=0.2, rim=0.0), P(trim, mat="metal", bevel=0.8, outline=0.0, ambient=0.34, rim=0.0))
        slit = A.smooth(A.poly([(h.eye_near[0] - 12, h.eye_y - 2.5), (h.front + 4, h.eye_y - 4.5), (h.front + 4, h.eye_y + 3.5), (h.eye_near[0] - 10, h.eye_y + 5.5)]), 0.7)
        out["lens"] = A.over(A.tint_layer(A.blur(slit, 1.4), (255, 255, 255), 0.5), P(slit, mat="glass", bevel=1.2, outline=0.9, ambient=0.9, spec=0.0, rim=0.0))
        det(A.smooth(A.poly([(h.back + 18, h.top), (h.back + 22, h.top - 16), (h.back + 25, h.top - 16), (h.back + 25, h.top + 1)]), 0.3), (50, 54, 62), "metal", 0.8, 0.6)       # antenna
        det(A.ellipse(h.back + 23.5, h.top - 16, 1.4, 1.4), (255, 120, 60), "glass", 0.3, 0.0)
        det(A.smooth(A.poly([(ex - 6, ey - 6), (ex + 10, ey - 8), (ex + 10, ey + 8), (ex - 6, ey + 10)]), 0.8), (40, 44, 52), "metal", 1.6, 0.7)           # side module
        det(A.ellipse(ex + 2, ey + 1, 2.0, 2.0), (255, 120, 60), "glass", 0.4, 0.0)
        out["shine"] = glint(m, h.front - 40, h.top + 6, 14, 3.4, -12, 0.4, 1.0)
    else:
        raise ValueError(gid)
    out["det"] = D
    return out
