#!/usr/bin/env python3
"""Saurian Vanguard: the armoured lizard-alien cosmetic, designed from the reference picture supplied by the player
(blue-grey spotted reptilian skin, bald ridged skull, amber eyes, small tusk, angular purple/black tactical armour with
green and magenta light strips, high maroon collar, shoulder spikes, fingerless gauntlets, long spotted tail, clawed
three-toed talons). Programmer art in the game's outline-and-soft-shade style; an artist can repaint any file.
Writes art/cosmetics/saurian/*.png.  Run from the project root: python3 tools/gen_saurian_art.py"""
import importlib.util, math, random
from PIL import Image, ImageDraw, ImageFilter, ImageChops
spec = importlib.util.spec_from_file_location("c", "tools/gen_cosmetic_art.py")
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
g = c.g; S = g.S; P = g.P; E = g.E
random.seed(11)
SKIN = (118, 152, 166); SKIN_D = (78, 108, 124); BELLY = (190, 206, 200); SPOT = (70, 96, 112)
PUR = (104, 66, 150); PUR_D = (56, 36, 88); BLK = (30, 28, 38); GRN = (96, 214, 84); MAG = (214, 80, 232); MAR = (126, 44, 74); TAN = (200, 164, 96); CLAW = (236, 224, 196)

def spots(img, m, n, cols=(SPOT,), rmin=1.2, rmax=3.2, box=None):
    lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    w, h = img.size[0] // S, img.size[1] // S
    x0, y0, x1, y1 = box or (0, 0, w, h)
    for _ in range(n):
        x, y, r = random.uniform(x0, x1), random.uniform(y0, y1), random.uniform(rmin, rmax)
        d.ellipse(E((x - r, y - r, x + r, y + r)), fill=random.choice(cols) + (200,))
    lay.putalpha(ImageChops.multiply(lay.getchannel("A"), m)); img.alpha_composite(lay)

def streak(img, m, x0, y0, x1, y1, w=3, a=110):
    lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.line(P([(x0, y0), (x1, y1)]), fill=(255, 255, 255, a), width=int(w * S))
    lay = lay.filter(ImageFilter.GaussianBlur(0.8 * S)); lay.putalpha(ImageChops.multiply(lay.getchannel("A"), m)); img.alpha_composite(lay)

def glowline(img, pts, col=GRN, w=1.8):
    lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.line(P(pts), fill=col + (110,), width=int((w + 2.4) * S)); d.line(P(pts), fill=col + (255,), width=int(w * S))
    lay2 = lay.filter(ImageFilter.GaussianBlur(0.6 * S)); img.alpha_composite(lay2)

def plate(img, poly, fill, w, h, outline=1.7, glow=None):
    """A metal armour plate: darker edge, soft specular streak, optional light strip."""
    m = g.mask_of(w, h, lambda d: d.polygon(P(poly), fill=255))
    g.solid(img, m, fill=fill + (255,), outline=outline, shade=0.38)
    xs = [p[0] for p in poly]; ys = [p[1] for p in poly]
    streak(img, m, min(xs) + 3, min(ys) + 3, min(xs) + (max(xs) - min(xs)) * 0.55, min(ys) + (max(ys) - min(ys)) * 0.4, 2.4, 120)
    if glow: glowline(img, glow[0], glow[1] if len(glow) > 1 else GRN)
    return m

def out(): c.out("saurian")

def torso(scaled=False):
    out(); w, h = 88, 92
    img = g.canvas(w, h)
    base = g.mask_of(w, h, lambda d: d.polygon(P([(8, 8), (44, 2), (80, 8), (86, 36), (76, 64), (68, 90), (30, 91), (20, 64), (6, 36)]), fill=255))
    if scaled:
        g.solid(img, base, fill=SKIN + (255,), outline=2.0, shade=0.32)
        belly = g.mask_of(w, h, lambda d: d.polygon(P([(46, 8), (80, 12), (82, 40), (72, 66), (62, 86), (50, 70)]), fill=255))
        lay = Image.new("RGBA", img.size, BELLY + (255,)); lay.putalpha(ImageChops.multiply(belly, base)); img.alpha_composite(lay)
        g.line_on(img, base, lambda d, col: [d.arc(E((44, 10 + i * 12, 86, 34 + i * 12)), 190, 350, fill=col, width=int(1.3 * S)) for i in range(5)], SKIN_D + (200,), 0.4)
        spots(img, base, 26, box=(6, 6, 50, 88))
        # short black chest band so the bare look is never fully bare
        band = g.mask_of(w, h, lambda d: d.polygon(P([(6, 66), (70, 66), (68, 90), (30, 91), (20, 76)]), fill=255))
        g.solid(img, band, fill=BLK + (255,), outline=1.6, shade=0.3)
    else:
        g.solid(img, base, fill=BLK + (255,), outline=2.0, shade=0.28)
        g.line_on(img, base, lambda d, col: [d.line(P([(10, 40 + i * 12), (78, 40 + i * 12)]), fill=col, width=S) for i in range(4)], (70, 66, 90, 150), 0.4)
        plate(img, [(10, 14), (44, 10), (44, 52), (26, 58), (12, 36)], PUR, w, h)                      # left chest plate (far side)
        plate(img, [(46, 10), (80, 14), (78, 38), (62, 58), (46, 52)], PUR, w, h, glow=([(50, 20), (72, 24)], GRN))
        plate(img, [(34, 18), (54, 18), (52, 40), (44, 46), (36, 40)], PUR_D, w, h, glow=([(40, 24), (48, 24), (48, 36), (40, 36), (40, 24)], GRN))
        glowline(img, [(30, 60), (36, 86)], GRN, 1.6); glowline(img, [(60, 60), (54, 86)], GRN, 1.6)
        for cx, cy in ((22, 24), (68, 24)):
            lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); ImageDraw.Draw(lay).ellipse(E((cx - 2.5, cy - 2.5, cx + 2.5, cy + 2.5)), fill=MAG + (255,)); img.alpha_composite(lay)
        collar = g.mask_of(w, h, lambda d: d.polygon(P([(10, 12), (46, 0), (80, 8), (74, 20), (46, 14), (14, 24)]), fill=255))
        g.solid(img, collar, fill=MAR + (255,), outline=1.8, shade=0.3)
    g.save(img, "torso_scaled.png" if scaled else "torso.png", w, h)

def waist():
    out(); w, h = 48, 24; img = g.canvas(w, h)
    m = g.mask_of(w, h, lambda d: d.rounded_rectangle(P([(2, 2), (46, 22)]), radius=4 * S, fill=255))
    g.solid(img, m, fill=BLK + (255,), outline=1.8, shade=0.3)
    for x in (6, 30):
        pm = g.mask_of(w, h, lambda d, x=x: d.rounded_rectangle(P([(x, 5), (x + 11, 19)]), radius=2 * S, fill=255)); g.solid(img, pm, fill=(58, 54, 72, 255), outline=1.2, shade=0.3, hl=False)
    glowline(img, [(21, 8), (21, 17)], MAG, 1.6)
    g.save(img, "waist.png", w, h)

def thigh(scaled=False):
    out(); w, h = 36, 48; img = g.canvas(w, h)
    m = g.mask_of(w, h, lambda d: d.polygon(P([(7, 6), (31, 6), (34, 28), (28, 46), (10, 46), (4, 28)]), fill=255))
    g.solid(img, m, fill=(BLK if not scaled else SKIN) + (255,), outline=1.9, shade=0.3)
    if scaled:
        spots(img, m, 12, box=(4, 20, 32, 46)); g.line_on(img, m, lambda d, col: [d.arc(E((4, 16 + i * 9, 34, 36 + i * 9)), 190, 350, fill=col, width=S) for i in range(3)], SKIN_D + (200,), 0.4)
        tr = g.mask_of(w, h, lambda d: d.polygon(P([(5, 4), (33, 4), (35, 18), (3, 18)]), fill=255)); g.solid(img, tr, fill=BLK + (255,), outline=1.5, shade=0.3)   # trunks: base coverage
    else:
        plate(img, [(16, 8), (32, 10), (32, 34), (24, 42), (16, 36)], PUR, w, h, glow=([(26, 14), (26, 34)], GRN))
    g.save(img, "thigh_scaled.png" if scaled else "thigh.png", w, h)

def shin(scaled=False):
    out(); w, h = 40, 40; img = g.canvas(w, h)
    m = g.mask_of(w, h, lambda d: d.polygon(P([(10, 2), (30, 2), (28, 38), (13, 38)]), fill=255))
    g.solid(img, m, fill=(PUR if not scaled else SKIN) + (255,), outline=1.9, shade=0.36)
    if scaled:
        spots(img, m, 8, box=(10, 4, 30, 36)); g.line_on(img, m, lambda d, col: [d.arc(E((8, 6 + i * 9, 32, 22 + i * 9)), 190, 350, fill=col, width=S) for i in range(3)], SKIN_D + (200,), 0.4)
    else:
        streak(img, m, 14, 4, 18, 30, 3, 110); glowline(img, [(24, 6), (21, 32)], GRN, 1.8)
    g.save(img, "shin_scaled.png" if scaled else "shin.png", w, h)

def foot():
    out(); w, h = 56, 30; img = g.canvas(w, h)
    m = g.mask_of(w, h, lambda d: (d.polygon(P([(4, 4), (28, 4), (44, 14), (50, 24), (14, 28), (4, 20)]), fill=255), d.polygon(P([(2, 18), (-1, 26), (12, 27)]), fill=255)))
    g.solid(img, m, fill=TAN + (255,), outline=1.9, shade=0.34)
    g.line_on(img, m, lambda d, col: [d.arc(E((8 + i * 7, 6, 26 + i * 7, 26)), 200, 340, fill=col, width=S) for i in range(4)], (120, 90, 50, 170), 0.4)
    cap = g.mask_of(w, h, lambda d: d.polygon(P([(4, 2), (30, 2), (26, 11), (6, 12)]), fill=255)); g.solid(img, cap, fill=PUR + (255,), outline=1.6, shade=0.32)
    for (x, y, tx, ty) in ((44, 14, 55, 17), (46, 20, 56, 25), (36, 26, 44, 29)):                       # three forward claws
        cm = g.mask_of(w, h, lambda d, x=x, y=y, tx=tx, ty=ty: d.polygon(P([(x, y - 2), (tx, ty), (x + 1, y + 3)]), fill=255)); g.solid(img, cm, fill=CLAW + (255,), outline=1.2, shade=0.2, hl=False)
    g.save(img, "foot.png", w, h)

def upper_arm():
    out(); w, h = 58, 26; img = g.canvas(w, h)
    sl = g.mask_of(w, h, lambda d: d.rounded_rectangle(P([(10, 5), (54, 21)]), radius=6 * S, fill=255)); g.solid(img, sl, fill=BLK + (255,), outline=1.8, shade=0.3)
    plate(img, [(2, 6), (10, 1), (26, 3), (30, 13), (24, 23), (6, 22)], PUR, w, h, glow=([(8, 14), (24, 14)], GRN))   # pauldron
    sp = g.mask_of(w, h, lambda d: d.polygon(P([(10, 4), (14, -6), (22, 4)]), fill=255)); g.solid(img, sp, fill=PUR + (255,), outline=1.6, shade=0.3)   # shoulder spike
    glowline(img, [(34, 13), (52, 13)], GRN, 1.4)
    g.save(img, "upper_arm.png", w, h)

def forearm():
    out(); w, h = 58, 24; img = g.canvas(w, h)
    m = g.mask_of(w, h, lambda d: d.rounded_rectangle(P([(3, 4), (54, 20)]), radius=6 * S, fill=255)); g.solid(img, m, fill=BLK + (255,), outline=1.8, shade=0.3)
    plate(img, [(8, 3), (46, 5), (52, 12), (46, 19), (8, 21)], PUR, w, h, glow=([(16, 12), (44, 12)], GRN))
    for x in (14, 24, 34):
        lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); ImageDraw.Draw(lay).rectangle(E((x, 8, x + 4, 11)), fill=GRN + (255,)); img.alpha_composite(lay)
    g.save(img, "forearm.png", w, h)

def hand():
    out(); w, h = 28, 28; img = g.canvas(w, h)
    m = g.mask_of(w, h, lambda d: d.ellipse(E((3, 6, 20, 22)), fill=255)); g.solid(img, m, fill=BLK + (255,), outline=1.6, shade=0.3)
    for (x, y, tx, ty) in ((18, 8, 27, 6), (19, 13, 28, 14), (18, 18, 26, 22)):
        fm = g.mask_of(w, h, lambda d, x=x, y=y, tx=tx, ty=ty: (d.line(P([(x, y), (tx - 3, ty)]), fill=255, width=int(3.4 * S)), d.polygon(P([(tx - 4, ty - 2), (tx, ty), (tx - 4, ty + 2)]), fill=255)))
        g.solid(img, fm, fill=TAN + (255,), outline=1.3, shade=0.25, hl=False)
    g.save(img, "hand.png", w, h)

def head(crest=False):
    out(); w, h = 108, 100; img = g.canvas(w, h)
    skull = lambda d: (d.ellipse(E((10, 0, 98, 82)), fill=255), d.ellipse(E((56, 38, 106, 86)), fill=255), d.polygon(P([(50, 70), (84, 74), (72, 99), (52, 94)]), fill=255), d.rounded_rectangle(P([(40, 90), (68, 104)]), radius=4 * S, fill=255))
    m = g.mask_of(w, h, skull)
    if crest:
        fin = g.mask_of(w, h, lambda d: [d.polygon(P([(30 - i * 7, 8 + i * 9), (14 - i * 8, -2 + i * 12), (24 - i * 7, 20 + i * 10)]), fill=255) for i in range(3)])
        fm = ImageChops.lighter(fin, fin); g.solid(img, fm, fill=PUR + (255,), outline=1.7, shade=0.3)
    g.solid(img, m, fill=SKIN + (255,), outline=2.2, shade=0.32)
    spots(img, m, 34, box=(16, 4, 66, 70)); g.line_on(img, m, lambda d, col: [d.arc(E((14 + i * 6, 2 + i * 5, 96 - i * 4, 70)), 205, 300, fill=col, width=S) for i in range(3)], SKIN_D + (190,), 0.5)
    ridge = Image.new("RGBA", img.size, (0, 0, 0, 0)); rd = ImageDraw.Draw(ridge)
    rd.arc(E((44, 34, 102, 66)), 200, 300, fill=SKIN_D + (255,), width=int(4 * S)); rd.ellipse(E((50, 28, 66, 40)), fill=SKIN_D + (150,)); img.alpha_composite(ridge)   # brow ridge
    for (x, y) in ((96, 66), (99, 71)):
        ImageDraw.Draw(img).ellipse(E((x - 1, y - 1, x + 1, y + 1)), fill=(30, 40, 50, 255))                    # nostril slits
    lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); ImageDraw.Draw(lay).polygon(P([(84, 86), (88, 98), (92, 86)]), fill=CLAW + (255,))                    # tusk
    img.alpha_composite(lay)
    ImageDraw.Draw(img).line(P([(70, 84), (100, 80)]), fill=(30, 40, 50, 255), width=int(1.3 * S))                  # mouth line
    g.save(img, "head_crest.png" if crest else "head_smooth.png", w, h)

def eyes_set():
    out(); w, h = 108, 100
    def eye(kind):
        img = g.canvas(w, h)
        for (cx, cy, k) in ((78, 52, 1.0), (97, 52, 0.7)):
            ew, eh = 18 * k, 12 * k
            if kind == "black_oval":
                m = g.mask_of(w, h, lambda d: d.ellipse(E((cx - ew / 2, cy - eh / 2 - 1, cx + ew / 2, cy + eh / 2 + 3)), fill=255)); g.solid(img, m, fill=(14, 18, 28, 255), outline=1.4, shade=0.1, hl=False)
                lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); ImageDraw.Draw(lay).ellipse(E((cx - 4 * k, cy - 4 * k, cx - 0.5 * k, cy - 0.5 * k)), fill=(255, 255, 255, 220)); img.alpha_composite(lay)
            else:
                col = (255, 168, 44) if kind == "amber_slit" else (120, 255, 150)
                m = g.mask_of(w, h, lambda d: d.polygon(P([(cx - ew / 2, cy + 1), (cx - ew * 0.15, cy - eh / 2), (cx + ew / 2, cy - 1), (cx + ew * 0.2, cy + eh / 2)]), fill=255))
                g.solid(img, m, fill=col + (255,), outline=1.4, shade=0.2, hl=False)
                lay = Image.new("RGBA", img.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
                ld.ellipse(E((cx - 1.3 * k, cy - eh * 0.45, cx + 1.3 * k, cy + eh * 0.45)), fill=(20, 14, 10, 255)); ld.ellipse(E((cx - 5 * k, cy - 3 * k, cx - 2.5 * k, cy - 0.5 * k)), fill=(255, 255, 255, 230))
                lay.putalpha(ImageChops.multiply(lay.getchannel("A"), m)); img.alpha_composite(lay)
                if kind == "glow_green":
                    glow = Image.new("RGBA", img.size, (0, 0, 0, 0)); ImageDraw.Draw(glow).ellipse(E((cx - ew, cy - eh, cx + ew, cy + eh)), fill=(120, 255, 150, 90)); img.alpha_composite(glow.filter(ImageFilter.GaussianBlur(3 * S)))
        g.save(img, "eyes_%s.png" % kind, w, h)
    for k in ("amber_slit", "black_oval", "glow_green"): eye(k)

def tail():
    out()
    for name, (w, h, a, b) in {"tail_a.png": (64, 32, 26, 20), "tail_b.png": (60, 26, 20, 14), "tail_c.png": (56, 20, 14, 5)}.items():
        img = g.canvas(w, h)
        m = g.mask_of(w, h, lambda d: d.polygon(P([(0, h / 2 - a / 2), (w - 4, h / 2 - b / 2), (w, h / 2), (w - 4, h / 2 + b / 2), (0, h / 2 + a / 2)]), fill=255))
        g.solid(img, m, fill=SKIN + (255,), outline=1.9, shade=0.34)
        belly = g.mask_of(w, h, lambda d: d.polygon(P([(0, h / 2 + a * 0.3), (w - 6, h / 2 + b * 0.3), (w - 4, h / 2 + b / 2), (0, h / 2 + a / 2)]), fill=255))
        lay = Image.new("RGBA", img.size, BELLY + (255,)); lay.putalpha(ImageChops.multiply(belly, m)); img.alpha_composite(lay)
        spots(img, m, 12, box=(2, 2, w - 6, h * 0.55))
        for i in range(4):                                                                                  # dorsal ridge spines
            x = 8 + i * (w - 16) / 4; ts = a * (1 - i / 5)
            sp = g.mask_of(w, h, lambda d, x=x, ts=ts: d.polygon(P([(x - 3, h / 2 - ts / 2 + 1), (x + 1, h / 2 - ts / 2 - 5), (x + 5, h / 2 - ts / 2 + 1)]), fill=255)); g.solid(img, sp, fill=PUR_D + (255,), outline=1.1, shade=0.2, hl=False)
        g.save(img, name, w, h)

def pack():
    out(); w, h = 80, 104; img = g.canvas(w, h)
    m = g.mask_of(w, h, lambda d: (d.rounded_rectangle(P([(6, 8), (62, 86)]), radius=10 * S, fill=255), d.rounded_rectangle(P([(40, 14), (78, 80)]), radius=10 * S, fill=255)))
    g.solid(img, m, fill=PUR_D + (255,), outline=2.1, shade=0.36)
    plate(img, [(10, 12), (56, 12), (58, 40), (12, 44)], PUR, w, h, glow=([(16, 28), (52, 28)], GRN))
    for x in (16, 44):
        nz = g.mask_of(w, h, lambda d, x=x: d.polygon(P([(x, 84), (x + 18, 84), (x + 14, 100), (x + 4, 100)]), fill=255)); g.solid(img, nz, fill=(44, 40, 56, 255), outline=1.7, shade=0.3, hl=False)
        glowline(img, [(x + 9, 62), (x + 9, 82)], MAG, 1.6)
    g.save(img, "jetpack.png", w, h)

if __name__ == "__main__":
    for sc in (False, True): torso(sc); thigh(sc); shin(sc)
    waist(); foot(); upper_arm(); forearm(); hand(); head(False); head(True); eyes_set(); tail(); pack()
