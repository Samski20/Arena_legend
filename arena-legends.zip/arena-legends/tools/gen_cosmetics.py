#!/usr/bin/env python3
"""The four full-anatomy cosmetics, drawn on the shared body-kit slot canvases (tools/bodykit.py).

  comet_vanguard / night_guardian : costumed humanoids (own suits, gauntlets, boots, capes)
  insectoid_drone                 : chitin hive flyer (segmented thorax, wasp waist, spined legs, pincers, abdomen, wings)
  lumen_seer                      : reed-slender luminous alien (tall narrow torso, long fine limbs, three-fingered hands)

Run from the project root:  python3 tools/gen_cosmetics.py [vanguard|guardian|insectoid|lumen]
Colours are baked in; the hue variants are produced in game by a shader.
"""
import os
import sys
import numpy as np
import cv2
import artlib as A
import bodykit as BK
from herokit import Sheet as _Sheet, dk, mix


class Sheet(_Sheet):
    def blob(self, pts, n=6, sm=0.3):
        return super().blob(pts, sm, n)

TAU = np.pi * 2


# ------------------------------------------------------------------------------------------------ shared shapes
def blobsil(slot, pts, n=6, sm=0.4):
    rig = slot in ("torso", "waist")
    P = BK.RP(slot, pts) if rig else BK.JP(slot, pts)
    return A.smooth(A.poly(A.curve_pts(P, n, closed=True)), sm)


def polysil(slot, pts, sm=0.25):
    rig = slot in ("torso", "waist")
    P = BK.RP(slot, pts) if rig else BK.JP(slot, pts)
    return A.smooth(A.poly(P), sm)


def torso_sil(sx=1.0, wx=1.0, front=1.0, back=1.0, neck=False, dy=0.0, extra=None):
    """The standard torso outline reshaped: shoulder width sx, waist width wx, chest depth front/back."""
    pts = []
    for x, y in BK.TORSO_PTS:
        if y <= -46.0:
            pts.append((x, y))
            continue
        t = float(np.clip((y + 44.0) / 45.0, 0, 1))
        f = sx * (1 - t) + wx * t
        pts.append((x * f * (front if x > 0 else back), y + dy * (1 - t)))
    m = A.smooth(A.poly(A.curve_pts(BK.RP("torso", pts), 8, closed=True)), 0.5)
    if extra is not None:
        m = A.union(m, extra())
    if not neck:
        lo = BK.NECK_BASE_Y + 0.9
        col = A.poly(BK.RP("torso", [(BK.NECK_X[0] - 1.5, -60), (BK.NECK_X[1] + 1.5, -60), (BK.NECK_X[1] + 1.5, lo), (BK.NECK_X[0] - 1.5, lo)]))
        m = A.sub(m, col)
    return m


# Creature bodies (insectoid, lumen) have no separate pelvis picture: their torso picture runs on down over the hips and the legs hang
# straight from it. The torso canvas is 12 px taller for that (same top-left corner, so the pivot is unchanged).
MERGED = ("insectoid", "lumen")
TORSO_STD = ((50, 58), (25, 33))
TORSO_TALL = ((50, 70), (25, 33))
HEM_Y = 1.7                                            # trousers / garments on the pelvis start at the torso hem
PELVIS = {}                                            # folder -> fn(slot) giving the pelvis outline on that slot's canvas


def below_hem(slot):
    return A.poly(BK.RP(slot, [(-30, HEM_Y), (30, HEM_Y), (30, 30), (-30, 30)]))


def foot_pts(heel=6.9, toe=19.0, top=-2.4):
    return [(-5.6, top), (-heel, 3.0), (-heel, 8.0), (-6.4, 9.8), (-3.0, 9.95), (11.5, 9.95), (16.0, 9.7), (toe - 0.6, 8.8), (toe, 6.4),
            (toe - 1.0, 4.6), (14.5, 3.7), (10.0, 2.6), (6.0, 0.6), (5.4, top)]


def box(S, x0, y0, x1, y1, sm=0.2):
    return S.poly([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], sm)


def rim_light(S, sm=0.5):
    """a soft light edge along the top-left and a darker lower rim: the same lighting on every piece"""
    top = A.sub(S.sil, A.shift(S.sil, 0.5, 0.9))
    S.soft(top, (255, 255, 255), 0.22, 0.4)
    low = A.sub(S.sil, A.shift(S.sil, -0.4, -0.9))
    S.soft(low, (0, 0, 0), 0.22, 0.5)


def hero_cape(folder, main, hem, lining, fold):
    os.makedirs("art/cosmetics/%s" % folder, exist_ok=True)
    A.set_canvas(96, 150, 0, 0, 2, 3)
    sil = A.smooth(A.poly([(30, 0), (66, 0), (78, 40), (92, 100), (86, 134), (74, 146), (62, 134), (48, 148), (36, 134), (22, 146), (12, 130), (8, 90), (18, 40)]), 1.2)
    tex = np.zeros((A.IH, A.IW), np.float32)
    for i in range(8):
        A.line(A.curve_pts([(32 + i * 5.2, 6), (22 + i * 10.5, 70), (16 + i * 11.5, 140)], 12), 1.5, tex)
    tex = (tex - 0.5) * 0.34
    img = A.paint(sil, main, "cloth", bevel=7.0, outline=1.1, ambient=0.46, texture=tex, spec=0.12)
    # inner lining peeks along the leading edge, deeper fold shadows, a lighter highlight sweep
    edge = A.sub(sil, A.shift(sil, 4.5, 0))
    img = A.over(A.tint_layer(A.blur(A.inter(edge, A.half_plane((0, 10), (96, 10), below=True)), 0.6), lining, 0.55, within=sil), img)
    shadow = A.empty()
    A.line(A.curve_pts([(36, 8), (34, 70), (30, 138)], 12), 3.5, shadow)
    img = A.over(A.tint_layer(A.blur(shadow, 2.0), (0, 0, 0), 0.28, within=sil), img)
    hl = A.empty()
    A.line(A.curve_pts([(58, 8), (66, 60), (74, 128)], 12), 2.6, hl)
    img = A.over(A.tint_layer(A.blur(hl, 2.2), (255, 255, 255), 0.18, within=sil), img)
    hemm = A.inter(A.sub(sil, A.shift(sil, 0, -4.4)), A.half_plane((0, 118), (96, 118), below=True))
    img = A.over(A.tint_layer(hemm, hem, 0.95), img)
    col = A.inter(A.poly([(30, 0), (66, 0), (64, 11), (32, 11)]), sil)
    img = A.over(A.paint(A.smooth(col, 0.3), hem, "metal", bevel=1.6, outline=0.9, ambient=0.5, spec=0.5), img)
    A.save(img, "art/cosmetics/%s/cape.png" % folder)


# =============================================================================================== COMET VANGUARD
def vanguard(folder="vanguard"):
    SUIT = (24, 118, 138); SUIT2 = (16, 84, 104); GOLD = (236, 190, 66); WHITE = (238, 244, 250); VIO = (118, 54, 150); DK = (10, 34, 46)
    GOLD_D = (150, 110, 30)

    def gold(S, mask, bevel=1.6, ol=0.5):
        S.part(mask, GOLD, "metal", bevel=bevel, outline=ol, ol=dk(GOLD, 0.3), ambient=0.5, spec=0.6)

    # ---- torso
    S = Sheet("torso", lambda: torso_sil(1.07, 0.97))
    S.base(SUIT, "cloth", bevel=6.5, ambient=0.5, spec=0.18)
    S.soft(S.poly([(-26, -52), (-13, -52), (-15, 4), (-26, 4)]), DK, 0.42, 3.5)                 # turned-away back side
    S.soft(S.poly([(-4, -2), (22, -2), (22, 4), (-4, 4)]), DK, 0.3, 1.5)
    S.soft(S.poly([(10, -40), (24, -40), (24, -12), (12, -12)]), (255, 255, 255), 0.14, 3.0)     # light on the chest front
    # chest: pectoral line, sternum, abdominal blocks
    S.line([(2, -30.5), (9, -28.2), (20, -30.0)], DK, 0.42, 0.5, hi=0.18)
    S.line([(4, -41), (3.4, -30.5)], DK, 0.34, 0.32, hi=0.1)
    for y, x1 in ((-23.0, 17.5), (-17.0, 16.4), (-11.0, 15.0)):
        S.line([(5, y), (11, y + 1.0), (x1, y)], DK, 0.34, 0.34, hi=0.12)
    S.line([(11, -26), (11, -5)], DK, 0.3, 0.3, hi=0.1)
    # white flank panel (back side) and collar yoke
    side = A.inter(S.poly([(-24, -42), (-16.0, -41.5), (-14.6, -22), (-12.4, -4), (-20, -4)], 0.5), S.sil)
    S.part(A.smooth(side, 0.5), WHITE, "cloth", bevel=2.0, outline=0.0, ambient=0.6, rim=0.0, alpha_scale=0.9)
    yoke = A.inter(S.blob([(-17, -43), (-4, -44.8), (12, -44.4), (19.4, -40.4), (14, -38.6), (3, -40.6), (-8, -40.2)]), S.sil)
    gold(S, yoke, 1.4, 0.45)
    # comet emblem: faceted star head with a swept tail
    cx, cy = 10.0, -29.0
    star = S.poly([(cx + (7.4 if i % 2 == 0 else 3.3) * np.cos(a), cy + (7.4 if i % 2 == 0 else 3.3) * np.sin(a))
                   for i, a in enumerate(np.linspace(-np.pi / 2, 3 * np.pi / 2, 11)[:-1])], 0.2)
    tail = S.poly([(cx - 2, cy - 1), (cx - 15, cy - 8), (cx - 11, cy - 3), (cx - 17, cy - 1), (cx - 10, cy + 1), (cx - 13, cy + 5), (cx - 2, cy + 2)], 0.25)
    gold(S, A.smooth(A.union(star, tail), 0.2), 1.1, 0.4)
    S.soft(S.ell(cx - 0.6, cy - 0.6, 1.4, 1.4), WHITE, 0.9, 0.4)
    belt = A.inter(box(S, -16, -5.6, 20, 2.2, 0.5), S.sil)
    gold(S, belt, 1.6, 0.5)
    for x in (-9, -1, 14):
        S.part(A.inter(box(S, x - 1.7, -4.2, x + 1.7, 0.6, 0.4), S.sil), DK, "matte", bevel=0.6, outline=0.0, clip=True)
    S.part(A.inter(S.ell(6.2, -1.7, 3.0, 2.6), S.sil), GOLD, "metal", bevel=1.0, outline=0.4, ol=dk(GOLD, 0.3), spec=0.6)
    S.soft(S.ell(6.2, -1.7, 1.2, 1.0), DK, 0.8, 0.3)
    rim_light(S)
    S.save(folder)

    # ---- waist: deep-teal pelvis under the belt
    S = Sheet("waist")
    S.base(SUIT2, "cloth", bevel=4.0, ambient=0.5, spec=0.15)
    S.soft(box(S, -14, 4, 19, 12, 0.5), DK, 0.25, 2.0)
    rim_light(S)
    S.save(folder)

    # ---- thigh
    S = Sheet("thigh")
    S.base(SUIT, "cloth", bevel=5.5, ambient=0.5, spec=0.15)
    S.soft(box(S, -9, -2, -3.6, 22, 0.4), DK, 0.38, 2.4)
    S.soft(box(S, 3.2, 2, 8.6, 14, 0.4), (255, 255, 255), 0.12, 2.0)
    S.line([(-0.4, 3), (0.4, 18)], DK, 0.32, 0.34, hi=0.1)
    S.line([(-5.3, 1.5), (-5.0, 17.4)], GOLD, 0.34, 0.9)
    rim_light(S)
    S.save(folder)

    # ---- shin: suit above, boot shaft with a gold cuff below
    S = Sheet("shin")
    S.base(SUIT, "cloth", bevel=5.0, ambient=0.5, spec=0.15)
    S.soft(box(S, -9, -2, -3.4, 24, 0.4), DK, 0.35, 2.0)
    boot = A.inter(box(S, -9, 8.4, 9, 26, 0.2), S.sil)
    S.part(boot, SUIT2, "leather", bevel=3.4, outline=0.6, spec=0.3)
    cuff = A.inter(box(S, -9, 7.8, 9, 10.6, 0.6), A.grow(S.sil, 0.5))
    gold(S, cuff, 1.4, 0.5)
    S.line([(3.4, 12), (3.4, 21)], GOLD, 0.3, 0.8)
    S.soft(box(S, 3, 11, 6, 22, 0.4), (255, 255, 255), 0.12, 1.0)
    S.soft(box(S, -9, 11, -3.4, 24, 0.4), DK, 0.3, 1.5)
    rim_light(S)
    S.save(folder)

    # ---- foot: teal boot with a gold sole line and toe highlight
    S = Sheet("foot", lambda: blobsil("foot", foot_pts(), 5, 0.4))
    S.base(SUIT2, "leather", bevel=4.0, ambient=0.5, spec=0.3)
    toe = A.inter(S.blob([(10.4, 2.4), (14.8, 3.4), (19.8, 5.4), (19.8, 11), (9.6, 11)]), S.sil)
    S.part(toe, SUIT, "leather", bevel=1.8, outline=0.45, spec=0.35)
    sole = A.inter(box(S, -9, 7.5, 22, 11, 0.2), S.sil)
    S.part(sole, DK, "matte", bevel=1.1, outline=0.0, clip=True)
    S.part(A.inter(box(S, -9, 7.2, 22, 8.0, 0.1), S.sil), GOLD, "metal", bevel=0.6, outline=0.0, spec=0.6)
    heel = A.inter(S.poly([(-9, -3), (-3.0, -3), (-2.2, 3.4), (-2.2, 9), (-9, 9)], 1.2), S.sil)
    S.part(heel, SUIT, "leather", bevel=1.2, outline=0.4)
    S.line([(4.2, -1.4), (7.4, 0.6)], GOLD, 0.34, 0.9)
    rim_light(S)
    S.save(folder)

    # ---- upper arm: sleeve with a gold shoulder cap
    S = Sheet("upper_arm")
    S.base(SUIT, "cloth", bevel=5.0, ambient=0.5, spec=0.15)
    S.soft(box(S, -8, 2.0, 28, 8, 0.4), DK, 0.3, 1.8)
    S.line([(8, -4.2), (22, -3.6)], WHITE, 0.4, 0.7)
    cap = A.inter(S.ell(0.8, -0.6, 7.0, 6.4), A.grow(S.sil, 0.6))
    gold(S, cap, 2.6, 0.55)
    S.soft(S.ell(-1.2, -3.0, 2.8, 1.6), WHITE, 0.45, 1.0)
    rim_light(S)
    S.save(folder)

    # ---- forearm: sleeve to the elbow, then a flared gold gauntlet
    S = Sheet("forearm")
    S.base(SUIT, "cloth", bevel=4.5, ambient=0.5, spec=0.15)
    gaunt = A.inter(S.blob([(6.5, -5.4), (15, -5.0), (23.4, -4.8), (24.6, 0), (23.4, 4.8), (15, 5.0), (6.5, 5.4), (5.4, 0)], 6), A.grow(S.sil, 0.5))
    gold(S, gaunt, 2.6, 0.55)
    for x in (11.5, 17.0, 21.8):
        S.line([(x, -4.6), (x, 4.6)], GOLD_D, 0.34, 0.7, hi=0.2, curve=False)
    S.soft(S.ell(12, -2.4, 6.4, 1.1), WHITE, 0.4, 0.6)
    rim_light(S)
    S.save(folder)

    # ---- hand: gold glove
    S = Sheet("hand")
    S.base(GOLD, "metal", bevel=3.2, outline=0.95, ambient=0.5, spec=0.55)
    S.line([(1.4, -3.2), (1.4, 3.2)], GOLD_D, 0.3, 0.8, hi=0.25, curve=False)
    S.line([(3.2, -3.0), (3.2, 3.0)], GOLD_D, 0.3, 0.7, hi=0.2, curve=False)
    S.soft(S.ell(-0.6, -2.6, 2.4, 1.0), WHITE, 0.5, 0.5)
    S.save(folder)
    hero_cape(folder, VIO, GOLD, (200, 150, 240), None)


# =============================================================================================== NIGHT GUARDIAN
def guardian(folder="guardian"):
    N = (26, 32, 56); N2 = (42, 54, 90); SL = (74, 88, 124); SIL = (214, 224, 240); AMB = (214, 164, 54); RED = (150, 28, 44); DK = (6, 8, 18)

    def plate(S, mask, color=SL, bevel=2.0, ol=0.5):
        S.part(mask, color, "metal", bevel=bevel, outline=ol, ol=dk(color, 0.3), ambient=0.46, spec=0.5)

    # ---- torso: broad V of the shoulders, armoured chest, narrow waist
    S = Sheet("torso", lambda: torso_sil(1.16, 0.88, front=1.04))
    S.base(N, "cloth", bevel=6.0, ambient=0.48, spec=0.16)
    S.soft(S.poly([(-26, -52), (-12, -52), (-15, 4), (-26, 4)]), DK, 0.5, 3.0)
    S.soft(S.poly([(10, -40), (26, -40), (26, -10), (12, -10)]), (255, 255, 255), 0.1, 3.0)
    chest = A.inter(S.blob([(-6, -42), (14, -43), (24, -37), (24, -26), (16, -17), (4, -17), (-6, -24)], 6), S.sil)
    plate(S, A.smooth(chest, 0.5), SL, 3.2, 0.6)
    S.line([(2, -41), (3, -19)], DK, 0.34, 0.5, hi=0.15)
    for y in (-14.0, -9.0, -4.0):
        plate(S, A.inter(S.blob([(-10, y - 1.8), (8, y - 2.4), (17, y - 1.8), (16, y + 1.8), (8, y + 2.2), (-10, y + 1.8)], 5, ), S.sil), N2, 1.2, 0.4)
    # angular sigil: a silver chevron with a blade drop
    sg = S.poly([(6, -37), (16, -36.5), (11, -26), (14, -20), (9.2, -24), (4.4, -20), (7, -26)], 0.15)
    S.part(sg, SIL, "metal", bevel=0.9, outline=0.35, ol=dk(SIL, 0.35), spec=0.6)
    # trapezius spikes
    for x0 in (-16.0, -9.0):
        S.part(S.poly([(x0, -41), (x0 + 3.2, -48.5), (x0 + 6.4, -41.4)], 0.15), SL, "metal", bevel=0.9, outline=0.4, ol=dk(SL, 0.3), clip=False)
    belt = A.inter(box(S, -16, -5.6, 20, 2.2, 0.5), S.sil)
    S.part(belt, AMB, "metal", bevel=1.6, outline=0.5, ol=dk(AMB, 0.3), spec=0.5)
    for x in (-9, -1, 14):
        S.part(A.inter(box(S, x - 1.7, -4.2, x + 1.7, 0.6, 0.4), S.sil), DK, "matte", bevel=0.6, outline=0.0)
    S.part(A.inter(S.poly([(4.4, -5.6), (8.6, -5.6), (8.6, 2.0), (4.4, 2.0)], 0.3), S.sil), SIL, "metal", bevel=0.9, outline=0.3, ol=dk(SIL, 0.3), spec=0.6)
    rim_light(S)
    S.save(folder)

    S = Sheet("waist")
    S.base(N2, "cloth", bevel=4.0, ambient=0.48, spec=0.14)
    S.soft(box(S, -14, 4, 19, 12, 0.5), DK, 0.3, 2.0)
    rim_light(S)
    S.save(folder)

    S = Sheet("thigh")
    S.base(N, "cloth", bevel=5.5, ambient=0.48, spec=0.14)
    S.soft(box(S, -9, -2, -3.6, 22, 0.4), DK, 0.45, 2.4)
    plate(S, A.inter(S.blob([(-5.4, 4.2), (5.6, 3.6), (6.4, 9.6), (-5.2, 10.6)], 5), S.sil), N2, 1.8, 0.5)
    S.line([(-0.2, 11.6), (0.4, 18)], DK, 0.3, 0.4, hi=0.1)
    S.line([(-5.2, 13.0), (5.8, 12.6)], SL, 0.34, 0.8)
    rim_light(S)
    S.save(folder)

    S = Sheet("shin")
    S.base(N, "cloth", bevel=5.0, ambient=0.48, spec=0.14)
    S.soft(box(S, -9, -2, -3.4, 24, 0.4), DK, 0.42, 2.0)
    shaft = A.inter(box(S, -9, 6.4, 9, 26, 0.2), S.sil)
    S.part(shaft, N2, "leather", bevel=3.4, outline=0.6, spec=0.3)
    guard = A.inter(S.blob([(-3.2, 8.0), (4.6, 7.8), (5.4, 14), (3.4, 19.6), (-2.6, 19.4), (-4.2, 14)], 5), S.sil)
    plate(S, guard, SL, 2.0, 0.5)
    S.line([(0.4, 8.8), (0.6, 19)], DK, 0.28, 0.5, hi=0.2)
    plate(S, A.inter(box(S, -9, 6.0, 9, 8.2, 0.6), A.grow(S.sil, 0.5)), SIL, 1.2, 0.45)
    rim_light(S)
    S.save(folder)

    S = Sheet("foot", lambda: blobsil("foot", foot_pts(7.1, 19.2), 5, 0.4))
    S.base(N2, "leather", bevel=4.0, ambient=0.48, spec=0.3)
    toe = A.inter(S.blob([(10.0, 2.4), (14.8, 3.2), (20.2, 5.2), (20.2, 11), (9.2, 11)]), S.sil)
    plate(S, toe, SL, 2.0, 0.5)
    S.part(A.inter(box(S, -9, 7.5, 22, 11, 0.2), S.sil), DK, "matte", bevel=1.1, outline=0.0)
    S.part(A.inter(box(S, -9, 7.2, 22, 7.9, 0.1), S.sil), SIL, "metal", bevel=0.5, outline=0.0, spec=0.6)
    plate(S, A.inter(S.poly([(-9, -3), (-2.6, -3), (-2.0, 3.4), (-2.0, 9), (-9, 9)], 1.2), S.sil), SL, 1.4, 0.45)
    S.line([(3.6, -1.6), (7.0, 0.6)], SIL, 0.3, 0.8)
    rim_light(S)
    S.save(folder)

    S = Sheet("upper_arm")
    S.base(N, "cloth", bevel=5.0, ambient=0.48, spec=0.14)
    S.soft(box(S, -8, 2.0, 28, 8, 0.4), DK, 0.38, 1.8)
    cap = A.inter(S.blob([(-6.0, -3.0), (0.0, -7.2), (7.6, -5.4), (9.6, 0.4), (4.4, 5.8), (-4.8, 5.0)], 6), A.grow(S.sil, 0.7))
    plate(S, cap, SL, 2.8, 0.55)
    S.line([(-3.4, -3.6), (4.6, -1.0)], DK, 0.3, 0.45, hi=0.2)
    S.line([(11.4, -4.6), (11.0, 4.6)], SL, 0.3, 0.6)
    rim_light(S)
    S.save(folder)

    S = Sheet("forearm")
    S.base(N2, "cloth", bevel=4.5, ambient=0.48, spec=0.14)
    gaunt = A.inter(S.blob([(5.2, -5.2), (14, -5.0), (23.6, -4.4), (24.6, 0), (23.6, 4.4), (14, 5.0), (5.2, 5.2), (4.4, 0)], 6), A.grow(S.sil, 0.5))
    plate(S, gaunt, SL, 2.6, 0.55)
    for x in (9.4, 14.6, 19.8):                      # swept fins along the underside of the gauntlet
        fin = S.poly([(x, 4.2), (x + 3.4, 6.0), (x + 1.2, 3.8)], 0.1)
        S.part(fin, SIL, "metal", bevel=0.5, outline=0.3, ol=dk(SIL, 0.3), clip=False, spec=0.6)
    S.line([(6.6, 0), (23, 0)], DK, 0.3, 0.45, hi=0.2)
    rim_light(S)
    S.save(folder)

    S = Sheet("hand")
    S.base(N, "leather", bevel=3.0, outline=0.95, ambient=0.48, spec=0.25)
    S.part(A.inter(S.ell(0.2, -0.2, 3.6, 3.4), S.sil), N2, "leather", bevel=1.2, outline=0.35)
    S.line([(2.4, -3), (2.4, 3)], DK, 0.28, 0.5, hi=0.15, curve=False)
    S.save(folder)
    hero_cape(folder, (30, 38, 70), RED, (150, 28, 44), None)


# =============================================================================================== INSECTOID DRONE
SHELL = (44, 122, 98); SHELL_D = (22, 66, 58); AMBER = (240, 172, 60); BELLY = (226, 200, 120)


def insectoid(folder="insectoid"):
    # shell with a wasp waist: broad armoured chest, a dorsal hump for the wings, a neck collar
    hump = lambda: blobsil("torso", [(-22, -34), (-18, -46), (-8, -49), (-4, -42), (-8, -34)], 5, 0.4)
    # the wasp-waist pelvis is part of the torso picture (no separate piece): the legs hang straight from it
    PEL = [(-10, -5.0), (13.4, -5.0), (15.4, 0), (14.0, 6.4), (9.6, 10.6), (3, 11.4), (-4, 10.0), (-9.4, 6), (-10.6, 0)]
    PELVIS["insectoid"] = lambda slot: blobsil(slot, PEL, 6, 0.5)
    BK.SLOTS["torso"] = TORSO_TALL
    S = Sheet("torso", lambda: A.smooth(A.union(torso_sil(1.0, 0.8, front=1.02, back=1.0, neck=True, extra=hump), PELVIS["insectoid"]("torso")), 0.9))
    S.base(SHELL, "chitin", bevel=6.0, ambient=0.46, spec=0.4)
    S.soft(S.poly([(-26, -52), (-12, -52), (-15, 4), (-26, 4)]), SHELL_D, 0.5, 3.0)
    # segmented plates across the chest (arcs follow the barrel of the shell)
    for i, y in enumerate((-36.5, -28.5, -20.5, -12.5, -5.0)):
        w = 15.5 - 0.7 * i
        S.line([(-w - 2, y - 2.4), (0, y + 1.4), (w + 3, y - 2.4)], SHELL_D, 0.5, 0.75, hi=0.35)
    # pale belly plates down the front
    belly = A.inter(S.blob([(7, -41), (18, -38), (21, -28), (19, -16), (14, -6), (9, -2), (7, -16), (6, -30)], 6), S.sil)
    S.part(A.smooth(belly, 0.5), BELLY, "chitin", bevel=2.4, outline=0.5, ol=dk(BELLY, 0.3), ambient=0.5, spec=0.35)
    for y in (-35, -29, -23, -17, -11, -5.4):
        S.line([(8, y), (14, y + 1.0), (19.4 - (y + 36) * 0.18, y - 0.2)], dk(BELLY, 0.45), 0.34, 0.6, hi=0.3)
    # amber stud line along the shoulders + spine ridge
    for i in range(6):
        S.part(S.ell(-16 + i * 4.4, -42.5 + (i % 2) * 0.8 - abs(i - 2.5) * 0.18, 1.15, 1.15), AMBER, "metal", bevel=0.6, outline=0.25, ol=dk(AMBER, 0.3), spec=0.6, clip=False)
    S.soft(S.ell(-8, -44, 6, 1.4), (255, 255, 255), 0.35, 1.0)
    # neck collar ring (the head sits in it)
    S.part(A.inter(S.blob([(-4.4, -47), (11, -47), (11, -43.2), (-4.4, -43.2)], 5), S.sil), SHELL_D, "chitin", bevel=1.4, outline=0.5, ol=dk(SHELL_D, 0.4), clip=False)
    # dark wasp-waist pelvis block below the torso hem, drawn into the same picture
    pel = A.smooth(A.inter(A.inter(PELVIS["insectoid"]("torso"), below_hem("torso")), S.sil), 0.4)
    S.part(pel, SHELL_D, "chitin", bevel=3.2, outline=0.55, ol=dk(SHELL_D, 0.4), ambient=0.46, spec=0.4)
    for y in (2.4, 5.0, 7.6, 10.0):
        S.line([(-9, y), (2, y + 1.0), (13, y)], dk(SHELL_D, 0.4), 0.4, 0.8, hi=0.3)
    S.part(S.ell(2, 5.0, 2.2, 1.8), AMBER, "metal", bevel=0.8, outline=0.3, ol=dk(AMBER, 0.3), spec=0.6, clip=False)
    rim_light(S)
    S.save(folder)
    BK.SLOTS["torso"] = TORSO_STD

    S = Sheet("waist")                                     # no separate pelvis picture
    S.save(folder)

    # femur: swelling spindle with spines on the back
    THIGH_I = [(0, 6.0, 6.0), (4, 6.6, 6.8), (9.5, 6.2, 6.6), (14.5, 4.6, 5.0), (BK.THIGH, 3.9, 3.9)]
    spines = lambda: A.union(*[polysil("thigh", [(-5.0, y), (-8.0, y + 1.6), (-5.0, y + 3.4)], 0.1) for y in (3.6, 8.6, 13.4)])
    S = Sheet("thigh", lambda: A.union(BK.tube("thigh", "y", THIGH_I, True, True, 0.5), spines()))
    S.base(SHELL, "chitin", bevel=5.0, ambient=0.46, spec=0.4)
    S.soft(box(S, -9, -2, -2.6, 22, 0.4), SHELL_D, 0.5, 2.4)
    for y in (4.0, 8.4, 12.8):
        S.line([(-5.8, y), (0, y + 1.6), (6.2, y)], SHELL_D, 0.4, 0.7, hi=0.3)
    S.part(S.ell(0, 1, 3.6, 3.4), SHELL_D, "chitin", bevel=1.2, outline=0.4, ol=dk(SHELL_D, 0.4), clip=False)       # hip socket
    rim_light(S)
    S.save(folder)

    # tibia: slender, with spurs
    SHIN_I = [(0, 4.2, 4.2), (4, 4.4, 4.0), (10, 3.8, 3.4), (16, 3.2, 3.0), (BK.SHIN, 3.0, 3.0)]
    sp = lambda: A.union(polysil("shin", [(-3.4, 6), (-6.6, 9.4), (-3.2, 10.6)], 0.1), polysil("shin", [(-3.0, 12), (-6.0, 15.4), (-2.8, 16.4)], 0.1),
                         polysil("shin", [(3.2, 9), (5.6, 12.4), (2.8, 13)], 0.1))
    S = Sheet("shin", lambda: A.union(BK.tube("shin", "y", SHIN_I, True, True, 0.5), sp()))
    S.base(SHELL_D, "chitin", bevel=4.0, ambient=0.46, spec=0.42)
    S.line([(0, 4), (0.2, 17)], AMBER, 0.34, 0.85)
    S.soft(box(S, -9, -2, -1.8, 24, 0.4), (0, 0, 0), 0.25, 1.4)
    S.part(S.ell(0, 0, 3.4, 3.2), SHELL, "chitin", bevel=1.0, outline=0.4, ol=dk(SHELL, 0.4), clip=False)           # knee cap
    rim_light(S)
    S.save(folder)

    # tarsus + talons
    pts = [(-4.0, -1.6), (-4.8, 4), (-4.6, 8.0), (-2.6, 9.8), (6, 9.8), (12.6, 9.8), (16.0, 9.2), (19.6, 8.4), (18.0, 7.0), (14.6, 6.4), (18.4, 4.8), (16.0, 3.8),
           (11.4, 4.2), (8.6, 2.6), (5.4, 0.2), (3.6, -1.6)]
    S = Sheet("foot", lambda: A.smooth(A.union(A.smooth(A.poly(BK.JP("foot", pts)), 0.3), A.ellipse(*BK.J("foot", 0, 0), 3.0 * 2, 3.0 * 2)), 0.3))
    S.base(SHELL_D, "chitin", bevel=3.4, ambient=0.46, spec=0.42)
    for x in (-1.0, 3.0, 7.0):
        S.line([(x, 3.4), (x + 0.6, 9.4)], AMBER, 0.3, 0.8)
    S.soft(box(S, -9, 7.8, 22, 11, 0.2), (0, 0, 0), 0.3, 0.6)
    S.soft(S.ell(12, 5.8, 3.4, 0.9), (255, 255, 255), 0.35, 0.5)
    rim_light(S)
    S.save(folder)

    # upper arm: bulbous shoulder joint, ridged
    UA = [(0, 6.4, 6.4), (5, 6.2, 5.6), (12, 5.0, 4.6), (19, 4.0, 4.0), (BK.UPPER_ARM, 3.4, 3.4)]
    S = Sheet("upper_arm", lambda: A.union(BK.tube("upper_arm", "x", UA, True, True, 0.5), polysil("upper_arm", [(9, -4.2), (13, -6.6), (16, -4.2)], 0.1)))
    S.base(SHELL, "chitin", bevel=5.0, ambient=0.46, spec=0.4)
    S.soft(box(S, -8, 1.4, 28, 8, 0.4), SHELL_D, 0.45, 1.6)
    for x in (4.0, 9.0, 14.0, 19.0):
        S.line([(x, -6.0), (x + 1.0, 0), (x, 6.0)], SHELL_D, 0.4, 0.7, hi=0.3)
    S.part(S.ell(0.4, 0, 5.4, 5.0), SHELL_D, "chitin", bevel=2.0, outline=0.5, ol=dk(SHELL_D, 0.4), clip=False)       # shoulder socket
    S.part(S.ell(0.2, -0.4, 2.0, 2.0), AMBER, "metal", bevel=0.6, outline=0.25, ol=dk(AMBER, 0.3), spec=0.6)
    rim_light(S)
    S.save(folder)

    # forearm: dark blade-edged limb
    FA = [(0, 4.0, 4.0), (6, 4.4, 4.0), (14, 3.8, 3.4), (BK.FOREARM, 2.8, 2.8)]
    blade = lambda: A.union(*[polysil("forearm", [(x, 3.0), (x + 4.2, 5.8), (x + 5.4, 3.0)], 0.1) for x in (8.4, 13.8, 19.2)])
    S = Sheet("forearm", lambda: A.union(BK.tube("forearm", "x", FA, True, True, 0.5), blade()))
    S.base(SHELL_D, "chitin", bevel=4.0, ambient=0.46, spec=0.42)
    S.line([(2, -1.4), (22, -0.6)], AMBER, 0.34, 0.85)
    for x in (6.0, 12.0, 18.0):
        S.line([(x, -3.6), (x + 0.8, 0), (x, 3.4)], (0, 0, 0), 0.34, 0.5, hi=0.25)
    S.part(S.ell(0, 0, 3.6, 3.4), SHELL, "chitin", bevel=1.0, outline=0.4, ol=dk(SHELL, 0.4), clip=False)             # elbow
    rim_light(S)
    S.save(folder)

    # pincer hand
    top = [(-2.6, -2.4), (2.4, -4.4), (6.4, -2.6), (3.6, -1.4), (6.2, 0.4), (-2.4, 2.6)]
    low = [(-2.6, 2.4), (2.4, 4.4), (6.4, 2.8), (3.6, 1.6), (6.2, -0.2)]
    S = Sheet("hand", lambda: A.smooth(A.union(A.smooth(A.poly(BK.JP("hand", top)), 0.2), A.smooth(A.poly(BK.JP("hand", low)), 0.2), A.ellipse(*BK.J("hand", -0.6, 0.0), 3.6 * 2, 3.4 * 2)), 0.3))
    S.base(SHELL_D, "chitin", bevel=2.4, outline=0.9, ambient=0.46, spec=0.42)
    S.line([(2.4, -3.0), (5.6, -1.8)], AMBER, 0.26, 0.9)
    S.line([(2.4, 3.0), (5.6, 1.8)], AMBER, 0.26, 0.9)
    S.save(folder)
    insect_extras(folder)
    make_overlays(folder)


def insect_extras(folder):
    """abdomen, antennae, mid-limb and four membrane wings (+ glowing veins), on the picture sizes WingsFx expects"""
    P = "art/cosmetics/%s/" % folder
    # abdomen: ribbed shell sac
    A.set_canvas(76, 64, 0, 0, 2, 3)
    m = A.smooth(A.poly(A.curve_pts([(3, 34), (10, 12), (30, 4), (54, 8), (72, 24), (72, 42), (54, 58), (28, 60), (8, 52)], 8, closed=True)), 0.8)
    img = A.paint(m, SHELL, "chitin", bevel=7.0, outline=1.1, ambient=0.44, spec=0.42)
    for i in range(6):
        x = 12 + i * 10
        seg = A.empty()
        A.line(A.curve_pts([(x + 6, 8), (x - 2, 32), (x + 6, 56)], 10), 1.2, seg)
        img = A.over(A.tint_layer(A.blur(seg, 0.4), SHELL_D, 0.8, within=m), img)
        img = A.over(A.tint_layer(A.shift(A.blur(seg, 0.4), 1.3, 0), (255, 255, 255), 0.2, within=m), img)
    belly = A.empty()
    A.line(A.curve_pts([(8, 48), (36, 56), (66, 44)], 10), 3.0, belly)
    img = A.over(A.tint_layer(A.blur(belly, 0.8), BELLY, 0.6, within=m), img)
    for x, y in ((30, 16), (44, 18), (58, 24)):
        img = A.over(A.paint(A.ellipse(x, y, 2.2, 2.2), AMBER, "metal", bevel=0.8, outline=0.35, spec=0.6), img)
    A.save(img, P + "abdomen.png")
    # antenna: a jointed whip (pivot at its base)
    A.set_canvas(60, 40, 0, 0, 2, 3)
    ant = A.line(A.curve_pts([(2, 36), (18, 22), (40, 14), (56, 8)], 14), 2.0)
    A.line([(56, 8), (58, 6)], 3.6, ant)
    img = A.paint(A.smooth(ant, 0.3), SHELL_D, "chitin", bevel=1.1, outline=0.8, ambient=0.5, spec=0.4)
    A.save(img, P + "antenna.png")
    # mid limb (two segments)
    A.set_canvas(56, 26, 0, 0, 2, 3)
    ml = A.union(A.line([(4, 12), (26, 8)], 4.4), A.line([(26, 8), (52, 20)], 3.2))
    A.line([(52, 20), (55, 24)], 1.8, ml)
    img = A.paint(A.smooth(ml, 0.3), SHELL_D, "chitin", bevel=1.4, outline=0.9, ambient=0.5, spec=0.4)
    img = A.over(A.paint(A.ellipse(26, 8, 3.0, 3.0), SHELL, "chitin", bevel=1.0, outline=0.5, spec=0.4), img)
    A.save(img, P + "mid_limb.png")

    def wing(name, w, h, poly, veins, root):
        A.set_canvas(w, h, 0, 0, 2, 3)
        m = A.smooth(A.poly(A.curve_pts(poly, 8, closed=True)), 0.8)
        mem = np.zeros((A.IH, A.IW, 4), np.float32)
        yy = np.linspace(0, 1, A.IH)[:, None]
        mem[..., 0] = 0.58 + 0.2 * yy
        mem[..., 1] = 0.92
        mem[..., 2] = 0.86
        mem[..., 3] = m * (0.34 + 0.12 * yy)
        ring = A.sub(m, A.grow(m, -1.2))
        img = A.over(A.tint_layer(ring, (24, 70, 62), 0.92), mem)
        vm = A.empty()
        for pts, wd in veins:
            A.line(A.curve_pts(pts, 12) if len(pts) > 2 else pts, wd, vm)
        vm = A.inter(vm, A.grow(m, -0.2))
        img = A.over(A.tint_layer(vm, (24, 80, 70), 0.85), img)
        A.save(img, P + name)
        gl = np.zeros((A.IH, A.IW, 4), np.float32)
        gl[..., :3] = 1.0
        gl[..., 3] = np.clip(np.maximum(vm, A.blur(vm, 1.4) * 0.6), 0, 1)
        A.save(gl, P + name.replace(".png", "_glow.png"))

    wing("wing_fore.png", 150, 60, [(4, 30), (30, 8), (100, 2), (148, 16), (120, 40), (60, 52), (10, 40)],
         [([(6, 30), (60, 12), (140, 16)], 1.2), ([(6, 31), (70, 30), (126, 28)], 1.0), ([(6, 32), (60, 46), (112, 38)], 0.9), ([(40, 14), (46, 44)], 0.6), ([(80, 8), (84, 40)], 0.6)], 0)
    wing("wing_hind.png", 110, 44, [(4, 24), (30, 6), (84, 4), (108, 22), (80, 38), (24, 40)],
         [([(6, 24), (50, 10), (100, 20)], 1.1), ([(6, 25), (60, 28), (92, 30)], 0.9), ([(34, 9), (38, 36)], 0.6)], 0)


# =============================================================================================== LUMEN SEER
LB = (168, 156, 232); LD = (96, 88, 176); LDD = (60, 54, 130); GLOW = (96, 240, 255)


def lumen(folder="lumen"):
    def glowline(S, pts, w=0.32, a=0.95):
        m = S.stroke(pts, w)
        halo = A.blur(m, 0.9)
        S.img = A.over(A.tint_layer(A.inter(halo, S.sil), GLOW, 0.4), S.img)
        S.img = A.over(A.tint_layer(A.inter(m, S.sil), (200, 255, 255), a), S.img)

    # one long, slender body: a slim neck column (the same width as the head's own neck stub) widening into narrow shoulders, a
    # small waist and gently flaring hips; the legs hang straight from it
    LUM = [(0.6, -54), (0.6, -49.6), (-3.6, -46.2), (-8.6, -42.6), (-9.6, -35), (-8.0, -24), (-5.4, -14), (-4.2, -6), (-5.8, 1.5), (-7.2, 7),
           (-3.8, 11.6), (3.8, 12.4), (10.0, 11.4), (12.6, 7.0), (11.4, 1.0), (8.0, -5.0), (7.4, -13), (10.0, -23), (12.8, -32), (14.0, -39.5),
           (9.0, -45.6), (7.0, -49.6), (7.0, -54)]
    PELVIS["lumen"] = lambda slot: blobsil(slot, [(-6.4, 0.4), (11.8, 0.4), (12.4, 7.0), (9.8, 11.4), (3.8, 12.4), (-3.6, 11.6), (-6.8, 7.5)], 6, 0.5)
    BK.SLOTS["torso"] = TORSO_TALL
    S = Sheet("torso", lambda: blobsil("torso", LUM, 8, 0.7))
    S.base(LB, "skin", bevel=6.0, ambient=0.6, spec=0.14)
    S.soft(S.poly([(-26, -52), (-1.5, -52), (-1.5, 14), (-26, 14)]), LDD, 0.4, 2.4)
    S.soft(S.poly([(6, -44), (14, -44), (11, -4), (5, -4)]), (255, 255, 255), 0.18, 2.4)
    S.soft(S.poly([(-10, 3.0), (16, 3.0), (16, 14), (-10, 14)]), LD, 0.45, 2.0)             # hips a shade deeper
    # luminous sternum + rib lines
    glowline(S, [(4.2, -44.0), (4.4, -26), (3.6, -2)], 0.34)
    for i, y in enumerate((-40, -34, -28, -22, -16, -10)):
        w = 7.0 - abs(i - 1.8) * 0.6
        glowline(S, [(4.2, y), (4.2 + w * 0.6, y + 1.0), (4.2 + w, y - 0.2)], 0.26, 0.8)
        S.line([(4.2, y + 0.9), (4.2 - w * 0.6, y + 1.8), (4.2 - w, y + 0.6)], LDD, 0.3, 0.55, hi=0.2)
    glowline(S, [(-5.2, 5.2), (2.4, 7.4), (11.0, 5.0)], 0.3)                               # glowing line across the hips
    S.part(S.ell(4.2, -30, 2.0, 2.0), (200, 255, 255), "glass", bevel=0.8, outline=0.3, ol=dk(GLOW, 0.4), spec=0.7, clip=False)
    S.soft(S.ell(4.2, -30, 4.0, 4.0), GLOW, 0.35, 1.4)
    rim_light(S)
    S.save(folder)
    BK.SLOTS["torso"] = TORSO_STD

    S = Sheet("waist")                                     # no separate pelvis picture (it is part of the torso picture)
    S.save(folder)

    THIGH_L = [(0, 3.6, 3.6), (5, 3.6, 3.8), (12, 3.0, 3.2), (16, 2.6, 2.8), (BK.THIGH, 2.4, 2.4)]
    S = Sheet("thigh", lambda: BK.tube("thigh", "y", THIGH_L, True, True, 0.5))
    S.base(LB, "skin", bevel=3.4, ambient=0.6, spec=0.14)
    S.soft(box(S, -9, -2, -0.6, 22, 0.4), LDD, 0.4, 1.2)
    glowline(S, [(0.6, 3), (0.8, 16)], 0.26, 0.7)
    rim_light(S)
    S.save(folder)

    SHIN_L = [(0, 2.4, 2.4), (5, 2.4, 2.6), (12, 2.0, 2.2), (BK.SHIN, 1.8, 1.8)]
    S = Sheet("shin", lambda: BK.tube("shin", "y", SHIN_L, True, True, 0.5))
    S.base(LB, "skin", bevel=3.0, ambient=0.6, spec=0.14)
    S.soft(box(S, -9, -2, -0.4, 24, 0.4), LDD, 0.4, 1.0)
    S.part(S.ell(0, 0, 2.8, 2.8), LD, "skin", bevel=1.0, outline=0.4, ol=dk(LD, 0.4), clip=False)
    glowline(S, [(0.3, 5), (0.4, 17)], 0.24, 0.7)
    rim_light(S)
    S.save(folder)

    pts = [(-2.6, -1.0), (-3.2, 3.0), (-3.0, 7.6), (-1.8, 9.8), (5, 9.9), (13, 9.9), (18.2, 9.6), (19.2, 8.6), (16.6, 7.4), (10, 5.4), (6, 2.4), (3.6, -1.0)]
    S = Sheet("foot", lambda: A.smooth(A.union(A.smooth(A.poly(A.curve_pts(BK.JP("foot", pts), 5, closed=True)), 0.4), A.ellipse(*BK.J("foot", 0, 0), 2.4 * 2, 2.4 * 2)), 0.3))
    S.base(LD, "skin", bevel=3.2, ambient=0.58, spec=0.16)
    glowline(S, [(2, 6), (10, 8.6), (17, 9)], 0.24, 0.8)
    S.soft(box(S, -9, 8.0, 22, 11, 0.2), LDD, 0.35, 0.5)
    rim_light(S)
    S.save(folder)

    UA = [(0, 3.4, 3.4), (6, 3.2, 3.4), (14, 2.6, 2.8), (BK.UPPER_ARM, 2.2, 2.2)]
    S = Sheet("upper_arm", lambda: BK.tube("upper_arm", "x", UA, True, True, 0.5))
    S.base(LB, "skin", bevel=3.4, ambient=0.6, spec=0.14)
    S.soft(box(S, -8, 0.8, 28, 8, 0.4), LDD, 0.4, 1.0)
    S.part(S.ell(0.2, 0, 3.8, 3.6), LD, "skin", bevel=1.2, outline=0.4, ol=dk(LD, 0.4), clip=False)
    glowline(S, [(5, 0), (22, 0.2)], 0.24, 0.7)
    rim_light(S)
    S.save(folder)

    FA = [(0, 2.4, 2.4), (8, 2.2, 2.4), (BK.FOREARM, 1.6, 1.6)]
    S = Sheet("forearm", lambda: BK.tube("forearm", "x", FA, True, True, 0.5))
    S.base(LB, "skin", bevel=3.0, ambient=0.6, spec=0.14)
    S.soft(box(S, -8, 0.5, 28, 7, 0.4), LDD, 0.4, 1.0)
    glowline(S, [(3, 0), (22, 0.1)], 0.24, 0.8)
    rim_light(S)
    S.save(folder)

    # three long fingers with glowing tips
    fing = lambda: A.smooth(A.union(A.ellipse(*BK.J("hand", -1.4, 0.0), 2.4 * 2, 2.6 * 2), *[A.line(BK.JP("hand", [(0.4, 0.2 * k), (3.2, 2.0 * k), (6.2, 3.0 * k)]), 1.6) for k in (-1, 0, 1)]), 0.25)
    S = Sheet("hand", fing)
    S.base(LB, "skin", bevel=2.0, outline=0.85, ambient=0.6, spec=0.14)
    for k in (-1, 0, 1):
        S.soft(S.ell(6.2, 3.0 * k, 0.9, 0.9), GLOW, 0.9, 0.5, clip=False)
        S.soft(S.ell(6.2, 3.0 * k, 0.45, 0.45), (230, 255, 255), 1.0, 0.1, clip=False)
    S.save(folder)
    make_overlays(folder)


# =============================================================================================== clothing overlays for creatures
OVERLAY = {"torso": ("cloth", 0.5), "waist": ("cloth", 0.4), "thigh": ("cloth", 0.4), "shin": ("cloth", 0.4), "foot": ("leather", 0.6),
           "upper_arm": ("cloth", 0.4), "forearm": ("cloth", 0.4), "hand": ("leather", 0.5)}


def make_overlays(folder):
    """ov_<slot>.png: clothing cut from the creature's own limbs (white, tinted in game), so shirts and boots follow ITS body"""
    for slot, (mat, gr) in OVERLAY.items():
        src = "art/cosmetics/%s/%s.png" % (folder, slot)
        if not os.path.exists(src):
            continue
        if folder in MERGED:
            BK.SLOTS["torso"] = TORSO_TALL
        BK.canvas(slot)
        from PIL import Image
        im = np.array(Image.open(src).convert("RGBA"))[..., 3].astype(np.float32) / 255.0
        m = cv2.resize(im, (A.IW, A.IH), interpolation=cv2.INTER_CUBIC).clip(0, 1)
        m = A.smooth(m, 0.4)
        if folder in MERGED and slot == "torso":
            m = A.sub(m, below_hem("torso"))        # a shirt ends at the hem; the pelvis has its own (trousers) overlay
        if folder in MERGED and slot == "waist":
            m = A.inter(PELVIS[folder]("waist"), below_hem("waist"))
        if slot == "torso":                       # the neck column and shoulders stay uncovered
            m = A.sub(m, A.poly(BK.RP("torso", [(-8, -60), (16, -60), (16, BK.NECK_BASE_Y + 1.4), (-8, BK.NECK_BASE_Y + 1.4)])))
        cover = A.grow(m, gr)
        img = A.paint(cover, (255, 255, 255), mat, bevel=3.0, outline=0.9, ambient=0.56, spec=0.1)
        A.save(img, "art/cosmetics/%s/ov_%s.png" % (folder, slot))
        BK.SLOTS["torso"] = TORSO_STD


JOBS = {"vanguard": vanguard, "guardian": guardian, "insectoid": insectoid, "lumen": lumen}

if __name__ == "__main__":
    want = sys.argv[1:] or list(JOBS)
    for k in want:
        JOBS[k]()
        print("cosmetic", k)
    A.head_canvas()
