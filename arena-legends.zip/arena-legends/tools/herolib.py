#!/usr/bin/env python3
"""Costume art for the superhero cosmetics (same picture sizes / joints as every other body set, drawn at 2x).
Run via tools/gen_cosmetic_art_v2.py. Colours are baked in (the hue variants are made in game by a shader)."""
import numpy as np
import artlib as A

SIZES = {"torso": (88, 92), "waist": (48, 24), "thigh": (36, 48), "shin": (40, 40), "foot": (56, 30),
         "upper_arm": (58, 26), "forearm": (58, 24), "hand": (28, 28), "cape": (96, 150)}


def _canvas(slot):
    w, h = SIZES[slot]
    A.set_canvas(w, h, 0, 0, 2, 3)


def _fin(img, folder, slot):
    A.save(img, "art/cosmetics/%s/%s.png" % (folder, slot))


def comet_vanguard(folder="vanguard"):
    import os
    os.makedirs("art/cosmetics/%s" % folder, exist_ok=True)
    SUIT = (24, 118, 138); SUIT2 = (16, 84, 104); GOLD = (236, 190, 66); WHITE = (238, 244, 250); VIO = (118, 54, 150); DARK = (12, 40, 52)

    def gold(m, bevel=1.4):
        return A.paint(m, GOLD, "metal", bevel=bevel, outline=0.9, ambient=0.5, spec=0.6)

    # ---- torso: V-taper, sculpted chest, comet emblem
    _canvas("torso")
    sil = A.smooth(A.poly([(3, 6), (44, 0), (86, 8), (85, 36), (74, 66), (68, 90), (30, 91), (22, 66), (9, 38)]), 1.2)
    img = A.paint(sil, SUIT, "cloth", bevel=6.0, outline=1.1, ambient=0.5, spec=0.18)
    # pectoral / abdomen seams
    seams = A.empty()
    A.line(A.curve_pts([(14, 20), (30, 34), (44, 30), (58, 34), (74, 20)], 10), 0.9, seams)
    A.line([(44, 32), (44, 86)], 0.8, seams)
    for y in (50, 60, 70):
        A.line(A.curve_pts([(31, y), (44, y + 2), (59, y)], 8), 0.7, seams)
    img = A.over(A.tint_layer(seams, DARK, 0.55, within=sil), img)
    # white side panels
    side = A.inter(A.poly([(4, 8), (20, 8), (24, 66), (24, 90), (14, 60)]), sil)
    img = A.over(A.paint(A.smooth(side, 0.6), WHITE, "cloth", bevel=2.0, outline=0.0, ambient=0.6, rim=0.0, alpha_scale=0.9), img)
    # collar
    col = A.inter(A.poly([(26, 0), (62, -2), (60, 12), (44, 18), (28, 12)]), sil)
    img = A.over(gold(A.smooth(A.sub(col, A.shift(col, 0, 4.4)), 0.4)), img)
    # comet emblem: star head + swept tail
    cx, cy = 46, 36
    star = A.poly([(cx + 10 * np.cos(a), cy + 10 * np.sin(a)) if i % 2 == 0 else (cx + 4.4 * np.cos(a), cy + 4.4 * np.sin(a))
                   for i, a in enumerate(np.linspace(-np.pi / 2, 3 * np.pi / 2, 11)[:-1])])
    tail = A.poly([(cx - 4, cy - 2), (cx - 26, cy - 14), (cx - 20, cy - 6), (cx - 30, cy - 4), (cx - 18, cy + 1), (cx - 24, cy + 8), (cx - 4, cy + 3)])
    emblem = A.smooth(A.union(star, tail), 0.3, 18)
    img = A.over(gold(A.inter(emblem, sil), 1.2), img)
    img = A.over(A.tint_layer(A.blur(A.inter(A.blob(cx - 1, cy - 1, 2.0), sil), 0.6), WHITE, 0.9), img)
    # belt hint at the bottom
    belt = A.inter(A.poly([(22, 80), (70, 80), (68, 92), (24, 92)]), sil)
    img = A.over(gold(A.smooth(belt, 0.4)), img)
    img = A.over(A.tint_layer(A.inter(A.rect if False else A.poly([(38, 82), (52, 82), (52, 90), (38, 90)]), sil), DARK, 0.9), img)
    _fin(img, folder, "torso")

    _canvas("waist")
    sil = A.smooth(A.poly([(3, 2), (45, 2), (44, 22), (4, 22)]), 1.4)
    img = A.paint(sil, GOLD, "metal", bevel=3.0, outline=1.0, ambient=0.5, spec=0.6)
    for x in (12, 24, 36):
        img = A.over(A.tint_layer(A.inter(A.poly([(x - 2.5, 7), (x + 2.5, 7), (x + 2.5, 16), (x - 2.5, 16)]), sil), DARK, 0.8), img)
    _fin(img, folder, "waist")

    _canvas("thigh")
    sil = A.smooth(A.poly([(7, 5), (31, 5), (34, 28), (28, 47), (10, 47), (4, 28)]), 1.6)
    img = A.paint(sil, SUIT, "cloth", bevel=5.0, outline=1.05, ambient=0.5, spec=0.18)
    img = A.over(A.tint_layer(A.inter(A.line([(12, 8), (14, 44)], 1.0), sil), DARK, 0.5), img)
    img = A.over(A.tint_layer(A.inter(A.poly([(23, 6), (32, 6), (34, 28), (28, 46), (24, 46)]), sil), SUIT2, 0.5), img)
    _fin(img, folder, "thigh")

    _canvas("shin")
    sil = A.smooth(A.poly([(10, 2), (30, 2), (29, 38), (13, 38)]), 1.2)
    sil = A.union(sil, A.smooth(A.poly([(11, 8), (1, 16), (11, 26)]), 0.6))        # knee fin
    img = A.paint(sil, SUIT, "cloth", bevel=4.0, outline=1.0, ambient=0.5, spec=0.15)
    cuff = A.inter(A.poly([(8, 2), (31, 2), (31, 10), (8, 10)]), sil)
    img = A.over(gold(A.smooth(cuff, 0.4)), img)
    img = A.over(A.tint_layer(A.inter(A.line([(20, 12), (20, 36)], 0.8), sil), DARK, 0.5), img)
    _fin(img, folder, "shin")

    _canvas("foot")
    sil = A.smooth(A.poly([(4, 4), (28, 2), (50, 14), (55, 21), (52, 28), (6, 28)]), 1.4)
    img = A.paint(sil, SUIT2, "leather", bevel=4.0, outline=1.05, ambient=0.5, spec=0.3)
    img = A.over(gold(A.smooth(A.inter(A.poly([(4, 2), (30, 2), (30, 9), (4, 9)]), sil), 0.3)), img)
    img = A.over(A.tint_layer(A.inter(A.poly([(4, 24), (54, 24), (54, 30), (4, 30)]), sil), DARK, 0.8), img)
    _fin(img, folder, "foot")

    _canvas("upper_arm")
    sil = A.smooth(A.poly([(4, 4), (50, 6), (55, 13), (50, 21), (4, 23)]), 2.0)
    img = A.paint(sil, SUIT, "cloth", bevel=4.5, outline=1.0, ambient=0.5, spec=0.15)
    pauldron = A.smooth(A.ellipse(11, 13, 11, 11), 0.5)
    img = A.over(gold(pauldron, 2.0), img)
    img = A.over(A.tint_layer(A.inter(A.line([(24, 6), (24, 22)], 1.0), sil), DARK, 0.5), img)
    _fin(img, folder, "upper_arm")

    _canvas("forearm")
    sil = A.smooth(A.poly([(4, 5), (50, 7), (55, 12), (50, 17), (4, 19)]), 1.6)
    fin = A.poly([(18, 17), (26, 27), (36, 17)])
    img = A.paint(A.union(sil, A.smooth(fin, 0.4)), GOLD, "metal", bevel=3.0, outline=1.0, ambient=0.5, spec=0.6)
    img = A.over(A.tint_layer(A.inter(A.poly([(4, 8), (14, 8), (14, 16), (4, 16)]), sil), SUIT, 1.0), img)
    for x in (24, 32, 40):
        img = A.over(A.tint_layer(A.inter(A.line([(x, 6), (x, 18)], 0.7), sil), DARK, 0.6), img)
    _fin(img, folder, "forearm")

    _canvas("hand")
    sil = A.smooth(A.ellipse(14, 14, 9.6, 9.0), 0.5)
    img = A.paint(sil, GOLD, "metal", bevel=3.0, outline=0.95, ambient=0.5, spec=0.55)
    _fin(img, folder, "hand")

    # ---- cape: tall banner, violet outside with a gold hem and a lighter fold
    _canvas("cape")
    sil = A.smooth(A.poly([(30, 0), (66, 0), (78, 40), (92, 100), (86, 134), (74, 146), (62, 134), (48, 148), (36, 134), (22, 146), (12, 130), (8, 90), (18, 40)]), 1.2)
    tex = np.zeros((A.IH, A.IW), np.float32)
    for i in range(7):
        A.line(A.curve_pts([(34 + i * 6, 6), (24 + i * 11, 70), (20 + i * 12, 140)], 12), 1.4, tex)
    tex = (tex - 0.5) * 0.3
    img = A.paint(sil, VIO, "cloth", bevel=6.0, outline=1.1, ambient=0.46, texture=tex, spec=0.12)
    hem = A.inter(A.sub(sil, A.shift(sil, 0, -5.0)), A.half_plane((0, 120), (96, 120), below=True))
    img = A.over(A.tint_layer(hem, GOLD, 0.95), img)
    collar = A.inter(A.poly([(30, 0), (66, 0), (64, 12), (32, 12)]), sil)
    img = A.over(gold(A.smooth(collar, 0.3)), img)
    _fin(img, folder, "cape")
    A.head_canvas()


if __name__ == "__main__":
    comet_vanguard()
