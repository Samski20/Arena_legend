#!/usr/bin/env python3
"""Generates art/body/*.png (bare body) and art/outfits/<kind>_<id>/<slot>_<layer>.png. Run from the project root.
   python3 tools/gen_outfit_art.py [body|tops|bottoms|boots|gloves|armor|all] [id ...]"""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import artlib as A
import outfitlib as O
from outfitlib import Piece, rect, rrect, camo

SKIN = (255, 255, 255)


# =============================================================================================== bare body
SK_SHADE = (92, 52, 56)          # form shadows on skin (multiplied into the white base, so they follow any skin tone)


def _soft(img, mask, inside, color, a, blur):
    return A.over(A.tint_layer(A.blur(A.inter(mask, inside), blur), color, a), img)


def body():
    import bodykit as BK
    os.makedirs(O.BODY, exist_ok=True)

    def save(img, name):
        A.save(img, O.BODY + name + ".png")

    # ---- torso (male / female): ribcage tapering to the waist, trapezius rising into the neck, soft chest and core forms
    # The bare body is ONE piece: ribcage, abdomen AND pelvis in a single picture (the legs hang straight from it, like the
    # reference game). Its canvas is 12 px taller than the garments' torso canvas so the pelvis fits; the top-left corner
    # (and so the pivot) is unchanged, so every garment drawn on the old canvas still lines up.
    BK.SLOTS["torso"] = ((50, 70), (25, 33))
    for fem in (False, True):
        O.canvas("torso")
        sil = A.smooth(A.union(BK.sil_torso(fem, neck=True), BK.sil_pelvis("torso")), 1.6)
        R = lambda x, y: BK.R("torso", x, y)
        img = A.paint(sil, SKIN, "skin", bevel=8.0, outline=1.05, ambient=0.62, spec=0.05)
        inside = A.grow(sil, -1.0)
        # light rolls over the chest and shoulders; the lower back and the side under the arm fall into shade
        img = _soft(img, A.ellipse(*R(10, -28), 17, 13, -10), inside, (255, 255, 255), 0.20, 3.0)
        img = _soft(img, A.poly(BK.RP("torso", [(-22, -34), (-9, -34), (-11, 2), (-15, 2)])), inside, SK_SHADE, 0.22, 4.0)
        # pectoral mass with a soft underside shadow (no hard outline: it is skin, not armour)
        pe = A.union(A.ellipse(*R(5, -27), 19, 12, -8), A.ellipse(*R(16.5, -27.5), 13, 11, 12))
        if fem:
            pe = A.union(A.ellipse(*R(4, -26), 16, 11, -6), A.ellipse(*R(15, -26.5), 12, 10, 10))
        img = A.over(A.paint(A.inter(pe, inside), SKIN, "skin", bevel=4.0, outline=0.0, ambient=0.68, spec=0.04, rim=0.2), img)
        under = A.sub(A.shift(pe, 0.6, 3.2), pe)
        img = _soft(img, under, inside, SK_SHADE, 0.34, 1.0)
        if not fem:
            for y, x0, x1 in ((-17.5, 1.5, 12.5), (-11.8, 2.5, 12.0), (-6.2, 3.5, 11.5)):          # core: soft blocks, not ruled lines
                seg = A.line(BK.RP("torso", [(x0, y), (x1, y + 0.3)]), 0.9)
                img = _soft(img, seg, inside, SK_SHADE, 0.28, 0.5)
            img = _soft(img, A.line(A.curve_pts(BK.RP("torso", [(8.0, -23), (8.4, -14), (8.6, -4)]), 10), 0.7), inside, SK_SHADE, 0.26, 0.5)
        else:
            img = _soft(img, A.line(A.curve_pts(BK.RP("torso", [(9.5, -22), (9.8, -12), (10, -3)]), 10), 0.6), inside, SK_SHADE, 0.16, 0.6)
        # collarbone and the slope of the trapezius into the neck
        img = _soft(img, A.line(A.curve_pts(BK.RP("torso", [(2, -41.5), (9, -39.6), (17, -38.2)]), 8), 0.7), inside, SK_SHADE, 0.26, 0.4)
        img = _soft(img, A.poly(BK.RP("torso", [(-12, -46), (-3, -46), (-3, -40), (-12, -37)])), inside, SK_SHADE, 0.12, 2.0)
        # underside of the hips falls into soft shade
        img = _soft(img, A.poly(BK.RP("torso", [(-14, 6), (18, 6), (18, 14), (-14, 14)])), inside, SK_SHADE, 0.2, 2.0)
        save(img, "torso_f" if fem else "torso")

    BK.SLOTS["torso"] = ((50, 58), (25, 33))          # back to the standard torso canvas
    # ---- neck patch: drawn over the junction of head and torso so the neck flows into the trapezius without a seam
    O.canvas("torso")
    nm = A.smooth(A.poly(BK.RP("torso", [(BK.NECK_X[0] + 0.1, -49.5), (BK.NECK_X[1] - 0.1, -49.5), (BK.NECK_X[1] + 0.9, -41.0), (BK.NECK_X[0] - 0.9, -41.0)])), 0.5)
    cut = A.poly(BK.RP("torso", [(-20, -52), (30, -52), (30, -48.4), (-20, -48.4)]))
    cut = A.union(cut, A.poly(BK.RP("torso", [(-20, -43.2), (30, -43.2), (30, -38), (-20, -38)])))
    img = A.paint(nm, SKIN, "skin", bevel=3.0, outline=1.0, ambient=0.64, spec=0.04, ol_cut=cut)
    img[..., 3] *= 1.0 - 0.0
    fade = np.clip((A.blur(A.poly(BK.RP("torso", [(-20, -52), (30, -52), (30, -47.6), (-20, -47.6)])), 1.2)), 0, 1)
    img[..., 3] *= (1.0 - fade)                       # fades out upward into the head's own neck
    save(img, "neck")

    # ---- pelvis: part of the torso picture now, so the bare pelvis slot is an empty (transparent) picture; only trousers use it
    O.canvas("waist")
    save(A.blank(), "waist")

    # ---- thigh: quad on the front, hamstring behind
    O.canvas("thigh")
    sil = BK.sil_thigh()
    img = A.paint(sil, SKIN, "skin", bevel=6.0, outline=1.0, ambient=0.62, spec=0.04)
    inside = A.grow(sil, -1.0)
    img = _soft(img, A.ellipse(*BK.J("thigh", 2.4, 8.5), 6.5, 17, 4), inside, (255, 255, 255), 0.16, 2.0)
    img = _soft(img, A.poly(BK.JP("thigh", [(-8, 1), (-3.6, 1), (-3.2, 17), (-8, 19)])), inside, SK_SHADE, 0.2, 2.0)
    save(img, "thigh")

    # ---- shin: calf behind, shin bone in front
    O.canvas("shin")
    sil = BK.sil_shin()
    img = A.paint(sil, SKIN, "skin", bevel=5.0, outline=1.0, ambient=0.62, spec=0.04)
    inside = A.grow(sil, -1.0)
    img = _soft(img, A.ellipse(*BK.J("shin", -1.6, 7.5), 6, 12, 8), inside, (255, 255, 255), 0.12, 1.6)
    img = _soft(img, A.poly(BK.JP("shin", [(2.2, 2), (6, 2), (5, 19), (3, 19)])), inside, SK_SHADE, 0.18, 1.8)
    save(img, "shin")

    # ---- bare foot: ankle, arch, toes
    O.canvas("foot")
    sil = BK.sil_foot()
    img = A.paint(sil, SKIN, "skin", bevel=4.0, outline=1.0, ambient=0.62, spec=0.04)
    inside = A.grow(sil, -1.0)
    toes = A.empty()
    for i, x in enumerate((10.4, 12.6, 14.6, 16.2)):
        A.line(BK.JP("foot", [(x, 5.4 + i * 0.45), (x + 0.5, 8.6)]), 0.4, toes)
    img = _soft(img, toes, inside, SK_SHADE, 0.4, 0.3)
    img = _soft(img, A.ellipse(*BK.J("foot", 4.5, 6.8), 9, 3, 0), inside, SK_SHADE, 0.14, 1.4)
    save(img, "foot")

    # ---- arms
    O.canvas("upper_arm")
    sil = BK.sil_upper_arm()
    img = A.paint(sil, SKIN, "skin", bevel=6.0, outline=1.0, ambient=0.62, spec=0.04)
    inside = A.grow(sil, -1.0)
    img = _soft(img, A.ellipse(*BK.J("upper_arm", 4.5, -2.2), 14, 5.5, 0), inside, (255, 255, 255), 0.18, 1.6)       # deltoid / triceps catch the light
    img = _soft(img, A.ellipse(*BK.J("upper_arm", 11.5, 4.0), 18, 4, 0), inside, SK_SHADE, 0.2, 1.4)               # biceps underside
    save(img, "upper_arm")
    O.canvas("forearm")
    sil = BK.sil_forearm()
    img = A.paint(sil, SKIN, "skin", bevel=5.0, outline=1.0, ambient=0.62, spec=0.04)
    inside = A.grow(sil, -1.0)
    img = _soft(img, A.ellipse(*BK.J("forearm", 8, -1.6), 18, 4, 0), inside, (255, 255, 255), 0.14, 1.4)
    img = _soft(img, A.ellipse(*BK.J("forearm", 12, 3.4), 22, 3.2, 0), inside, SK_SHADE, 0.18, 1.2)
    save(img, "forearm")

    # ---- hand: fist wrapped around the grip, thumb on top
    O.canvas("hand")
    palm = BK.sil_hand()
    thumb = A.smooth(A.ellipse(*BK.J("hand", 2.2, -4.3), 5.4, 3.2, -25), 0.4)
    full = A.union(palm, thumb)
    img = A.paint(full, SKIN, "skin", bevel=3.0, outline=0.95, ambient=0.64, spec=0.04)
    inside = A.grow(full, -1.0)
    f = A.empty()
    for y in (-2.0, 0.4, 2.8):
        A.line(BK.JP("hand", [(1.4, y), (4.4, y + 0.2)]), 0.4, f)
    img = _soft(img, f, inside, SK_SHADE, 0.42, 0.3)
    save(img, "hand")


def harness():
    """The jetpack harness on the torso (torso canvas): shoulder strap over the trapezius and down the chest to the belt,
    a chest link with buckle and a hip tab. h = tinted webbing, h_d = baked buckles."""
    import bodykit as BK
    O.canvas("torso")
    RPt = lambda pts: BK.RP("torso", pts)
    web = A.empty()
    A.line(A.curve_pts(RPt([(-21.5, -33.5), (-19.0, -40.0), (-12.0, -43.4), (-3.0, -43.3), (5.5, -41.6), (10.5, -35.5), (13.4, -26.0), (14.6, -16.0), (13.8, -6.0), (12.0, 0.8)]), 12), 3.3 * 2 / 2 * 1.0, web)
    A.line(RPt([(14.3, -24.8), (21.2, -25.4)]), 2.6, web)
    A.line(A.curve_pts(RPt([(-21.5, -14.0), (-16.5, -9.0), (-12.0, -3.5)]), 8), 2.8, web)
    web = A.smooth(web, 0.4)
    tex = O.fabric_weave(70, 0.5)
    img = A.paint(web, (255, 255, 255), "cloth", bevel=1.3, outline=0.7, ambient=0.55, texture=tex)
    A.save(img, O.BODY + "harness.png")
    det = A.blank()
    buckle = A.smooth(A.poly(RPt([(15.4, -27.4), (19.2, -27.4), (19.2, -23.0), (15.4, -23.0)])), 0.5)
    det = A.over(A.paint(buckle, O.METAL, "metal", bevel=1.0, outline=0.55, spec=0.5), det)
    det = A.over(A.paint(A.smooth(A.poly(RPt([(16.4, -26.2), (18.2, -26.2), (18.2, -24.2), (16.4, -24.2)])), 0.3), (40, 44, 52), "matte", bevel=0.3, outline=0.0), det)
    adj = A.smooth(A.poly(RPt([(12.2, -17.5), (15.8, -17.5), (15.8, -15.0), (12.2, -15.0)])), 0.4)       # strap slider
    det = A.over(A.paint(adj, O.METAL, "metal", bevel=0.7, outline=0.4, spec=0.45), det)
    for (x, y) in ((-19.8, -34.0), (-19.8, -13.2)):
        det = A.over(A.paint(A.ellipse(*BK.R("torso", x, y), 1.4, 1.4), O.METAL, "metal", bevel=0.4, outline=0.3), det)
    A.save(det, O.BODY + "harness_d.png")


# =============================================================================================== helpers shared by tops
def collar(oid, kind, **kw):
    """The neckline piece (drawn over the neck, on the torso canvas)."""
    O.canvas("torso")
    p = Piece("torso", sil=collar_mask(kind), bevel=3.0, outline=1.0, ambient=0.5, texture=O.knit_texture(0.5) if kind in ("crew", "scoop", "mock") else None)
    if kind == "crew":
        p.shade(A.poly([(38, 8), (64, 8), (60, 12), (42, 12)]), 0.2, within=True)
        p.seam([(37, 10), (50, 15), (66, 10)], 0.5, 0.45)
    elif kind == "spread":                       # open shirt collar: two points
        p.seam([(52, 6), (50, 20)], 0.7, 0.55, curve=False)
        p.light(A.poly([(36, 4), (50, 4), (49, 12)]), 0.18)
        p.stitch([(37, 8), (49, 18)], gap=2.6)
        p.stitch([(66, 8), (53, 18)], gap=2.6)
    elif kind == "mock":
        p.seam([(38, 11), (50, 14), (66, 11)], 0.6, 0.5)
    elif kind == "zip":
        p.d_paint(A.poly([(50.5, 3), (53, 3), (53, 21), (50.5, 21)]), O.METAL, "metal", bevel=0.8, outline=0.4)
    p.save("top", oid, "collar")
    return p


def collar_mask(kind):
    O.canvas("torso")
    if kind == "crew":
        return A.smooth(A.poly([(34, 4), (46, 7), (56, 7), (68, 4), (69, 10), (61, 17), (50, 19), (40, 17), (33, 11)]), 1.0)
    if kind == "scoop":
        return A.smooth(A.poly([(34, 4), (44, 6), (58, 6), (69, 4), (68, 8), (60, 13), (50, 14), (41, 12), (34, 8)]), 1.0)
    if kind == "mock":                           # high rolled neck
        return A.smooth(A.poly([(34, 3), (66, 3), (68, 16), (50, 22), (34, 17)]), 1.2)
    if kind == "spread":
        return A.smooth(A.poly([(33, 3), (68, 3), (70, 12), (58, 23), (52, 17), (46, 24), (33, 14)]), 1.0)
    if kind == "zip":
        return A.smooth(A.poly([(31, 2), (70, 2), (72, 12), (62, 24), (52, 20), (42, 24), (31, 14)]), 1.2)
    return A.smooth(A.poly([(34, 3), (66, 3), (66, 14), (34, 14)]), 1.0)


def sleeve_mask(slot, x_end, taper=0.0):
    O.canvas(slot)
    return A.inter(O.SIL[slot](), A.poly([(0, -10), (x_end, -10), (x_end, 90), (0, 90)]))


# =============================================================================================== tops
def top_bra():
    O.canvas("torso")
    p = Piece("torso", sil=A.inter(O.sil_torso(True), A.poly([(0, 18), (100, 18), (100, 52), (0, 52)])), material="cloth", bevel=3.0, ambient=0.5, texture=O.knit_texture(0.4))
    p.seam([(20, 36), (50, 46), (80, 38)], 0.6, 0.4)
    p.save("top", "bra")


def top_tshirt():
    O.canvas("torso")
    p = Piece("torso", bevel=6.0, texture=O.fabric_weave(1, 0.45))
    for pts in ([(8, 62), (22, 70), (34, 72)], [(66, 74), (78, 66)], [(28, 40), (36, 48), (30, 58)], [(44, 54), (56, 58), (70, 54)]):
        p.fold(pts, 1.2, 0.26)
    p.seam([(78, 12), (82, 36)], 0.7, 0.45)                       # armhole seam, front
    p.seam([(8, 14), (11, 38)], 0.7, 0.45)
    p.stitch([(10, 84), (30, 85), (60, 85), (70, 84)], gap=2.6)    # hem stitching
    p.shade(A.poly([(4, 82), (90, 82), (90, 100), (4, 100)]), 0.18)
    # small chest pocket patch tint 'a'
    pocket = A.smooth(A.poly([(60, 34), (76, 33), (76, 48), (60, 49)]), 0.7)
    p.panel(pocket, bevel=1.2, outline=0.6, texture=O.fabric_weave(1, 0.4))
    p.blotch("a", A.inter(pocket, A.empty() + 1.0))
    p.save("top", "tshirt")
    # sleeve: short, with a rib hem in the secondary colour
    O.canvas("upper_arm")
    m = sleeve_mask("upper_arm", 36)
    p = Piece("upper_arm", sil=m, bevel=4.5, texture=O.fabric_weave(2, 0.45))
    p.fold([(16, 8), (22, 14), (14, 19)], 1.0, 0.24)
    hem = A.inter(rect(31, -5, 40, 40), m)
    p.panel(hem, bevel=1.4, outline=0.6)
    p.blotch("a", hem)
    p.save("top", "tshirt")
    collar("tshirt", "crew")


def top_tank():
    O.canvas("torso")
    sil = A.sub(O.sil_torso(), A.union(A.poly([(0, 0), (22, 0), (14, 30), (0, 36)]), A.poly([(100, 0), (74, 0), (80, 22), (100, 26)])))
    sil = A.smooth(sil, 1.6)
    p = Piece("torso", sil=sil, bevel=5.5, texture=O.knit_texture(0.5))
    p.fold([(12, 60), (24, 66), (36, 66)], 1.2, 0.26)
    p.fold([(48, 52), (58, 58), (72, 54)], 1.2, 0.22)
    p.shade(A.poly([(4, 80), (90, 80), (90, 100), (4, 100)]), 0.2)
    p.stitch([(14, 84), (40, 85), (70, 84)], gap=2.6)
    p.seam([(22, 14), (13, 34)], 0.6, 0.35)
    p.seam([(74, 22), (80, 12)], 0.6, 0.35)
    p.save("top", "tank")
    collar("tank", "scoop")


def top_tactical():
    """Long-sleeve combat shirt: zip collar, shoulder panels, chest pockets, elbow panels, velcro patch."""
    O.canvas("torso")
    p = Piece("torso", bevel=6.0, texture=O.fabric_weave(4, 0.5))
    # shoulder yokes and the torso panel line
    yoke = A.inter(A.poly([(0, 0), (100, 0), (100, 20), (60, 26), (30, 26), (0, 20)]), p.sil)
    p.panel(yoke, bevel=2.0, outline=0.55, texture=O.fabric_weave(4, 0.5))
    p.blotch("a", A.sub(yoke, A.grow(yoke, -0.1) * 0))
    # chest pockets with flaps (zipped)
    for x0, x1 in ((34, 52), (62, 80)):
        pk = A.smooth(A.poly([(x0, 36), (x1, 35), (x1 + 1, 54), (x0 - 1, 55)]), 0.8)
        p.panel(pk, bevel=1.4, outline=0.6, texture=O.fabric_weave(4, 0.4))
        p.stitch([(x0 + 1, 42), (x1 - 1, 42)], gap=2.2)
        p.d_paint(A.poly([(x0 + 3, 41.2), (x1 - 3, 41.0), (x1 - 3, 42.6), (x0 + 3, 42.8)]), O.METAL_D, "metal", bevel=0.6, outline=0.35)
    p.seam([(57, 24), (58, 80)], 0.8, 0.55, curve=False)          # front zip line
    p.d_paint(A.poly([(56.4, 22), (58.8, 22), (58.8, 80), (56.4, 80)]), (60, 64, 72), "metal", bevel=0.7, outline=0.4)
    p.fold([(8, 64), (22, 72), (36, 74)], 1.2, 0.25)
    p.fold([(66, 72), (80, 64)], 1.1, 0.22)
    p.shade(A.poly([(4, 80), (90, 80), (90, 100), (4, 100)]), 0.2)
    # name tape + flag patch (baked)
    p.d_paint(rrect(62, 58, 80, 63, 0.4), (30, 34, 40), "matte", bevel=0.5, outline=0.4)
    p.d_flat(rrect(63, 59, 79, 62, 0.3), (190, 196, 204), 0.55)
    p.d_paint(rrect(37, 15, 46, 22, 0.5), (70, 112, 82), "matte", bevel=0.5, outline=0.4)
    p.d_flat(rect(37, 17.4, 46, 19.6), (210, 220, 215), 0.7)
    p.blotch("a", yoke)
    p.save("top", "tactical")
    # sleeves with elbow panels and shoulder patch
    O.canvas("upper_arm")
    p = Piece("upper_arm", bevel=4.5, texture=O.fabric_weave(5, 0.5))
    p.fold([(14, 7), (22, 14), (12, 20)], 1.0, 0.25)
    sh = A.inter(rect(0, -5, 20, 40), p.sil)
    p.panel(sh, bevel=1.4, outline=0.5)
    p.blotch("a", sh)
    p.d_paint(rrect(26, 8, 36, 17, 0.5), (70, 112, 82), "matte", bevel=0.4, outline=0.35)
    p.save("top", "tactical")
    O.canvas("forearm")
    p = Piece("forearm", bevel=4.0, texture=O.fabric_weave(6, 0.5))
    el = A.inter(rect(0, 0, 18, 30), p.sil)
    p.panel(el, bevel=1.4, outline=0.5)
    p.blotch("a", el)
    cuff = A.inter(rect(44, 0, 60, 30), p.sil)
    p.panel(cuff, bevel=1.2, outline=0.5)
    p.d_paint(rrect(44, 6, 50, 13, 0.4), O.METAL_D, "metal", bevel=0.5, outline=0.35)
    p.save("top", "tactical")
    collar("tactical", "zip")


def top_uniform():
    """Military camouflage field jacket (BDU style): spread collar, button placket, bellows pockets, epaulettes."""
    O.canvas("torso")
    p = Piece("torso", bevel=6.0, texture=O.fabric_weave(7, 0.55))
    ma, mb, mc = camo(31, 7.0)
    p.fold([(8, 62), (22, 70), (36, 72)], 1.3, 0.27)
    p.fold([(66, 74), (80, 66)], 1.2, 0.24)
    p.fold([(40, 52), (50, 58), (62, 56)], 1.1, 0.2)
    p.seam([(8, 16), (10, 38)], 0.7, 0.45)
    p.seam([(80, 14), (84, 36)], 0.7, 0.45)
    # button placket
    plk = A.poly([(57, 20), (64, 20), (64, 86), (57, 86)])
    p.panel(A.smooth(plk, 0.4), bevel=1.0, outline=0.5)
    # four bellows pockets with button flaps
    for (x0, x1, y0, y1) in ((30, 50, 34, 52), (68, 84, 34, 52), (26, 48, 62, 82), (68, 84, 62, 80)):
        pk = A.smooth(A.poly([(x0, y0), (x1, y0 - 1), (x1 + 1, y1), (x0 - 1, y1 + 1)]), 0.8)
        p.panel(pk, bevel=1.5, outline=0.6, texture=O.fabric_weave(8, 0.5))
        flap = A.smooth(A.poly([(x0, y0), (x1, y0 - 1), (x1, y0 + 6), ((x0 + x1) / 2, y0 + 8), (x0, y0 + 6)]), 0.5)
        p.panel(flap, bevel=1.2, outline=0.55)
        p.d_paint(A.ellipse((x0 + x1) / 2, y0 + 5, 1.5, 1.5), (96, 90, 64), "metal", bevel=0.6, outline=0.35)
    # epaulettes
    for pts in ([(14, 10), (32, 6), (34, 14), (14, 18)], [(64, 8), (82, 12), (80, 20), (62, 16)]):
        e = A.smooth(A.poly(pts), 0.6)
        p.panel(e, bevel=1.2, outline=0.55)
    for y in (24, 36, 48, 60, 72, 82):                    # buttons
        p.d_paint(A.ellipse(60.5, y, 1.5, 1.5), (92, 86, 60), "metal", bevel=0.6, outline=0.35)
    # name tape and unit patch
    p.d_paint(rrect(66, 24, 82, 29, 0.4), (36, 40, 30), "matte", bevel=0.5, outline=0.4)
    p.d_flat(rrect(67, 25, 81, 28, 0.3), (200, 205, 188), 0.6)
    p.d_paint(rrect(34, 22, 46, 32, 0.8), (60, 70, 50), "matte", bevel=0.5, outline=0.4)
    p.d_flat(A.poly([(40, 24), (44, 29), (36, 29)]), (210, 200, 130), 0.85)
    p.blotch("a", ma)
    p.blotch("b", mb)
    p.blotch("c", mc)
    p.save("top", "uniform")
    O.canvas("upper_arm")
    p = Piece("upper_arm", bevel=4.5, texture=O.fabric_weave(9, 0.55))
    ma, mb, mc = camo(32, 6.0)
    p.fold([(14, 7), (22, 14), (12, 20)], 1.0, 0.25)
    pk = A.smooth(A.poly([(26, 6), (40, 6), (40, 20), (26, 20)]), 0.6)
    p.panel(pk, bevel=1.3, outline=0.55)
    p.d_paint(rrect(29, 9, 37, 14, 0.4), (60, 70, 50), "matte", bevel=0.4, outline=0.35)
    p.blotch("a", ma); p.blotch("b", mb); p.blotch("c", mc)
    p.save("top", "uniform")
    O.canvas("forearm")
    p = Piece("forearm", bevel=4.0, texture=O.fabric_weave(10, 0.55))
    ma, mb, mc = camo(33, 6.0)
    el = A.smooth(A.poly([(2, 4), (18, 5), (18, 18), (2, 19)]), 0.8)
    p.panel(el, bevel=1.2, outline=0.5)
    cuff = A.inter(rect(44, 0, 60, 30), p.sil)
    p.panel(cuff, bevel=1.2, outline=0.5)
    p.d_paint(A.ellipse(48, 12, 1.4, 1.4), (92, 86, 60), "metal", bevel=0.5, outline=0.3)
    p.blotch("a", ma); p.blotch("b", mb); p.blotch("c", mc)
    p.save("top", "uniform")
    collar("uniform", "spread")


def top_jacket():
    """Leather field jacket: big lined collar, zip, angled pockets, ribbed hem and cuffs."""
    O.canvas("torso")
    p = Piece("torso", material="leather", bevel=6.5, ambient=0.5, spec=0.28, texture=O.fabric_weave(12, 0.28))
    hem = A.inter(rect(0, 78, 100, 100), p.sil)
    p.fold([(8, 58), (22, 66), (38, 70)], 1.4, 0.3)
    p.fold([(66, 70), (80, 60)], 1.3, 0.26)
    p.fold([(30, 38), (40, 46), (34, 56)], 1.2, 0.22)
    p.seam([(8, 14), (10, 40)], 0.8, 0.5)
    p.seam([(80, 12), (84, 38)], 0.8, 0.5)
    p.stitch([(10, 18), (11, 40)], gap=2.6)
    p.stitch([(79, 16), (83, 38)], gap=2.6)
    # yoke
    p.seam([(8, 24), (36, 30), (58, 28), (84, 24)], 0.8, 0.5)
    # angled slash pockets with zips
    for (x0, y0, x1, y1) in ((64, 58, 82, 68), (26, 60, 46, 70)):
        pk = A.smooth(A.poly([(x0, y0), (x1, y0 + 4), (x1, y1 + 4), (x0, y1)]), 0.7)
        p.panel(pk, bevel=1.4, outline=0.6, material="leather", spec=0.25)
        p.d_line([(x0 + 2, y0 + 1.5), (x1 - 2, y0 + 5)], 0.9, O.METAL, curve=False)
    # chest flap pocket on the front
    fl = A.smooth(A.poly([(66, 34), (82, 36), (82, 46), (66, 44)]), 0.7)
    p.panel(fl, bevel=1.4, outline=0.55, material="leather", spec=0.25)
    p.d_paint(A.ellipse(74, 43, 1.3, 1.3), O.BRASS, "metal", bevel=0.5, outline=0.3)
    # zipper
    p.seam([(57, 20), (58, 80)], 0.9, 0.6, curve=False)
    p.d_paint(A.poly([(56.3, 18), (58.7, 18), (58.7, 80), (56.3, 80)]), (150, 156, 166), "metal", bevel=0.6, outline=0.4)
    for y in range(24, 80, 5):
        p.d_flat(rect(55.6, y, 59.4, y + 0.9), (60, 64, 72), 0.8)
    p.d_paint(rrect(55, 76, 60, 82, 0.5), O.METAL, "metal", bevel=0.5, outline=0.4)
    # ribbed hem band (secondary colour)
    band = A.inter(rect(0, 79, 100, 100), p.sil)
    p.panel(band, bevel=1.6, outline=0.6, texture=O.knit_texture(0.9))
    p.blotch("a", band)
    # shoulder epaulette + patch
    p.d_paint(rrect(38, 14, 48, 22, 0.6), (140, 40, 40), "matte", bevel=0.4, outline=0.35)
    p.d_flat(A.poly([(43, 15.5), (46, 20), (40, 20)]), (240, 220, 160), 0.85)
    p.save("top", "jacket")
    O.canvas("upper_arm")
    p = Piece("upper_arm", material="leather", bevel=4.5, spec=0.26, texture=O.fabric_weave(13, 0.28))
    p.fold([(12, 6), (20, 14), (10, 20)], 1.2, 0.28)
    p.seam([(10, 4), (14, 22)], 0.7, 0.45)
    p.seam([(34, 4), (36, 22)], 0.7, 0.4)
    p.stitch([(11, 5), (15, 21)], gap=2.4)
    p.save("top", "jacket")
    O.canvas("forearm")
    p = Piece("forearm", material="leather", bevel=4.0, spec=0.26, texture=O.fabric_weave(14, 0.28))
    p.fold([(18, 8), (26, 13), (16, 17)], 1.0, 0.26)
    cuff = A.inter(rect(44, 0, 60, 30), p.sil)
    p.panel(cuff, bevel=1.4, outline=0.55, texture=O.knit_texture(0.9))
    p.blotch("a", cuff)
    p.save("top", "jacket")
    # lined collar: leather outside, lining (secondary colour) inside
    O.canvas("torso")
    cm = A.smooth(A.poly([(30, 2), (71, 2), (73, 13), (63, 25), (52, 20), (41, 25), (30, 14)]), 1.3)
    p = Piece("torso", sil=cm, material="leather", bevel=3.4, outline=1.0, spec=0.25)
    inner = A.smooth(A.poly([(40, 4), (62, 4), (60, 14), (52, 17), (44, 14)]), 0.8)
    p.panel(inner, bevel=1.8, outline=0.5, texture=O.knit_texture(0.7))
    p.blotch("a", inner)
    p.seam([(52, 17), (52, 24)], 0.7, 0.5, curve=False)
    p.stitch([(31, 12), (42, 23)], gap=2.4)
    p.stitch([(72, 12), (63, 23)], gap=2.4)
    p.save("top", "jacket", "collar")


def top_suit():
    """Futuristic combat suit: segmented bodysuit with hard plates and glowing seams."""
    O.canvas("torso")
    p = Piece("torso", material="matte", bevel=6.0, ambient=0.52, spec=0.2, texture=O.fabric_weave(15, 0.2))
    # hard plates in the secondary colour
    plate_main = A.smooth(A.poly([(44, 26), (74, 26), (78, 46), (66, 60), (52, 60), (40, 46)]), 1.0)
    side_l = A.smooth(A.poly([(8, 28), (26, 30), (30, 66), (20, 74), (12, 50)]), 1.0)
    side_r = A.smooth(A.poly([(76, 54), (84, 40), (84, 60), (74, 76), (68, 70)]), 1.0)
    abdom = A.smooth(A.poly([(38, 64), (68, 64), (66, 84), (40, 84)]), 1.0)
    collar_guard = A.smooth(A.poly([(14, 8), (36, 6), (42, 20), (24, 26), (10, 20)]), 1.0)
    platesA = A.union(plate_main, side_l, side_r, abdom, collar_guard)
    for m in (plate_main, side_l, side_r, abdom, collar_guard):
        p.panel(m, bevel=2.4, outline=0.75, material="metal", ambient=0.5, spec=0.35)
    p.blotch("a", platesA)
    p.seam([(8, 62), (22, 70)], 0.7, 0.4)
    p.fold([(66, 72), (80, 64)], 1.0, 0.2)
    p.shade(A.poly([(4, 82), (90, 82), (90, 100), (4, 100)]), 0.18)
    # power cell on the chest
    p.d_paint(A.smooth(A.poly([(50, 34), (62, 34), (66, 42), (62, 50), (50, 50), (46, 42)]), 0.6), (24, 30, 40), "glass", bevel=1.4, outline=0.6)
    p.glow_lines([[(44, 26), (46, 42), (52, 60)], [(74, 26), (66, 42), (60, 60)], [(52, 38), (62, 38)], [(52, 42), (62, 42)], [(52, 46), (62, 46)],
                  [(30, 30), (30, 66)], [(76, 54), (72, 74)], [(40, 70), (66, 70)], [(14, 14), (36, 12)]], 0.8)
    p.save("top", "suit")
    O.canvas("upper_arm")
    p = Piece("upper_arm", material="matte", bevel=4.5, spec=0.2, texture=O.fabric_weave(16, 0.2))
    seg = [A.smooth(A.poly([(4, 4), (18, 3), (18, 23), (4, 23)]), 0.8), A.smooth(A.poly([(24, 5), (40, 6), (40, 21), (24, 22)]), 0.8)]
    for m in seg:
        p.panel(m, bevel=2.0, outline=0.65, material="metal", spec=0.3)
    p.blotch("a", A.union(*seg))
    p.glow_lines([[(21, 4), (21, 22)], [(42, 6), (42, 21)]], 0.7)
    p.save("top", "suit")
    O.canvas("forearm")
    p = Piece("forearm", material="matte", bevel=4.0, spec=0.2, texture=O.fabric_weave(17, 0.2))
    br = A.smooth(A.poly([(22, 5), (46, 7), (46, 17), (22, 18)]), 0.8)
    p.panel(br, bevel=2.0, outline=0.65, material="metal", spec=0.3)
    p.blotch("a", br)
    p.glow_lines([[(24, 11.5), (44, 12)]], 0.7)
    p.save("top", "suit")
    collar("suit", "mock")


# =============================================================================================== bottoms
def belt(p, buckle=True, color=O.LEATHER, loops=True, webbing=False):
    """belt across a waist piece (painted in the baked detail layer)"""
    if loops:
        for x in (10, 20, 34, 41):
            p.d_paint(rrect(x, 3, x + 2.4, 11, 0.3), (50, 52, 58), "matte", bevel=0.4, outline=0.3)
    p.d_paint(rrect(2, 8, 46, 14.5, 0.5), color, "leather", bevel=1.2, outline=0.6, spec=0.2)
    if buckle:
        p.d_paint(rrect(34, 7.2, 41, 15.5, 0.8), O.METAL, "metal", bevel=0.9, outline=0.5)
        p.d_flat(rrect(35.6, 9.4, 39.4, 13.3, 0.4), color, 1.0)
    for x in (12, 18, 24):
        p.d_flat(A.ellipse(x, 11.2, 0.5, 0.5), (30, 30, 34), 0.7)


def bottom_pants():
    O.canvas("waist")
    p = Piece("waist", bevel=4.0, texture=O.fabric_weave(20, 0.5))
    p.seam([(4, 20), (44, 20)], 0.5, 0.3, curve=False)
    belt(p)
    p.save("bottom", "pants")
    O.canvas("thigh")
    p = Piece("thigh", bevel=6.0, texture=O.fabric_weave(21, 0.5))
    p.seam([(26, 6), (28, 42)], 0.7, 0.5, curve=False)                # side seam
    p.stitch([(24.5, 6), (26.5, 42)], gap=2.4)
    p.fold([(10, 30), (20, 34), (30, 32)], 1.2, 0.26)                 # knee crease
    p.fold([(8, 14), (16, 22), (10, 28)], 1.1, 0.2)
    pk = A.smooth(A.poly([(8, 6), (22, 6), (22, 14), (8, 17)]), 0.6)        # front pocket edge
    p.seam([(9, 7), (21, 14)], 0.6, 0.4)
    p.save("bottom", "pants")
    O.canvas("shin")
    p = Piece("shin", bevel=5.0, texture=O.fabric_weave(22, 0.5))
    p.fold([(12, 12), (20, 17), (28, 14)], 1.1, 0.24)
    hemm = A.inter(rect(0, 32, 50, 50), p.sil)
    p.seam([(12, 32), (28, 32)], 0.6, 0.4, curve=False)
    p.shade(hemm, 0.12)
    p.seam([(26, 3), (26, 35)], 0.6, 0.4, curve=False)
    p.save("bottom", "pants")


def _cargo(oid, camo_pat=False, tactical=False, armored=False):
    o = oid
    O.canvas("waist")
    p = Piece("waist", bevel=4.0, texture=O.fabric_weave(23, 0.55))
    if camo_pat:
        ma, mb, mc = camo(41, 5.5)
        p.blotch("a", ma); p.blotch("b", mb); p.blotch("c", mc)
    p.seam([(4, 20), (44, 20)], 0.5, 0.3, curve=False)
    belt(p, color=(54, 56, 60) if tactical else O.LEATHER_D)
    if tactical:       # webbing + small pouch on the belt
        p.d_paint(rrect(6, 14.5, 18, 21, 0.6), (44, 46, 52), "cloth", bevel=1.0, outline=0.5)
        p.d_flat(rect(11, 14.5, 12.4, 21), (30, 32, 36), 0.9)
    p.save("bottom", o)
    O.canvas("thigh")
    p = Piece("thigh", bevel=6.0, texture=O.fabric_weave(24, 0.55))
    if camo_pat:
        ma, mb, mc = camo(42, 5.5)
        p.blotch("a", ma); p.blotch("b", mb); p.blotch("c", mc)
    p.fold([(8, 30), (20, 34), (30, 32)], 1.3, 0.27)
    p.seam([(28, 6), (30, 42)], 0.7, 0.5, curve=False)
    # cargo pocket with flap and button
    pk = A.smooth(A.poly([(7, 16), (24, 16), (25, 33), (6, 33)]), 0.9)
    p.panel(pk, bevel=1.8, outline=0.65, texture=O.fabric_weave(25, 0.5))
    fl = A.smooth(A.poly([(7, 16), (24, 16), (24, 23), (15.5, 25.5), (7, 23)]), 0.6)
    p.panel(fl, bevel=1.5, outline=0.6)
    p.stitch([(8.5, 31), (22.5, 31)], gap=2.2)
    p.d_paint(A.ellipse(15.5, 21.5, 1.4, 1.4), (88, 84, 60) if camo_pat else (70, 74, 82), "metal", bevel=0.5, outline=0.3)
    if tactical:
        p.d_paint(rrect(5, 24, 31, 28, 0.5), (34, 36, 42), "cloth", bevel=0.8, outline=0.45)      # drop-leg strap
        p.d_paint(rrect(26, 22, 31, 30, 0.5), O.METAL_D, "metal", bevel=0.6, outline=0.4)
    p.save("bottom", o)
    O.canvas("shin")
    p = Piece("shin", bevel=5.0, texture=O.fabric_weave(26, 0.55))
    if camo_pat:
        ma, mb, mc = camo(43, 5.5)
        p.blotch("a", ma); p.blotch("b", mb); p.blotch("c", mc)
    p.fold([(12, 14), (20, 19), (28, 16)], 1.2, 0.26)
    p.seam([(26, 3), (26, 35)], 0.6, 0.4, curve=False)
    if tactical:       # reinforced knee panel and shin strap
        kn = A.smooth(A.poly([(11, 3), (29, 3), (28, 15), (12, 15)]), 0.8)
        p.panel(kn, bevel=1.8, outline=0.6, texture=O.fabric_weave(27, 0.6))
        p.blotch("a", kn)
        p.d_paint(rrect(10, 22, 30, 25.5, 0.5), (34, 36, 42), "cloth", bevel=0.8, outline=0.45)
        p.d_paint(rrect(17, 21.5, 22, 26, 0.4), O.METAL_D, "metal", bevel=0.5, outline=0.35)
    elif camo_pat:     # bloused trouser leg gathered over the boot top with a tie
        p.fold([(12, 30), (20, 34), (28, 31)], 1.1, 0.3)
        p.d_line([(11, 33), (29, 33)], 1.0, (40, 40, 30), curve=False, alpha=0.8)
    else:
        p.d_paint(rrect(11, 31, 29, 34, 0.5), (46, 48, 54), "cloth", bevel=0.7, outline=0.4)
    p.save("bottom", o)


def bottom_combat():
    _cargo("combat")


def bottom_military():
    _cargo("military", camo_pat=True)


def bottom_tactical():
    _cargo("tactical", tactical=True)


def bottom_armored():
    O.canvas("waist")
    p = Piece("waist", material="matte", bevel=4.0, texture=O.fabric_weave(28, 0.4))
    belt(p, color=(40, 42, 48), loops=False)
    for x0 in (2, 30):
        pl = A.smooth(A.poly([(x0, 12), (x0 + 15, 12), (x0 + 14, 22), (x0 + 1, 22)]), 0.7)
        p.panel(pl, bevel=2.0, outline=0.7, material="metal", spec=0.38)
    p.blotch("a", A.smooth(A.poly([(2, 12), (17, 12), (16, 22), (3, 22)]), 0.7) + A.smooth(A.poly([(30, 12), (45, 12), (44, 22), (31, 22)]), 0.7))
    p.save("bottom", "armored")
    O.canvas("thigh")
    p = Piece("thigh", material="matte", bevel=6.0, texture=O.fabric_weave(29, 0.4))
    plates = []
    for (y0, y1) in ((6, 19), (21, 32)):
        pl = A.smooth(A.poly([(8, y0), (28, y0 - 1), (31, y1), (7, y1 + 1)]), 1.0)
        p.panel(pl, bevel=2.4, outline=0.8, material="metal", spec=0.4)
        plates.append(pl)
        p.d_paint(A.ellipse(11, (y0 + y1) / 2, 1.0, 1.0), O.METAL, "metal", bevel=0.4, outline=0.25)
        p.d_paint(A.ellipse(26, (y0 + y1) / 2, 1.0, 1.0), O.METAL, "metal", bevel=0.4, outline=0.25)
    p.blotch("a", A.union(*plates))
    p.fold([(10, 38), (20, 41), (30, 38)], 1.0, 0.25)
    p.save("bottom", "armored")
    O.canvas("shin")
    p = Piece("shin", material="matte", bevel=5.0, texture=O.fabric_weave(30, 0.4))
    kc = A.smooth(A.poly([(10, 2), (30, 2), (29, 13), (20, 16), (11, 13)]), 1.0)
    gd = A.smooth(A.poly([(12, 16), (28, 15), (27, 32), (14, 33)]), 1.0)
    for m in (kc, gd):
        p.panel(m, bevel=2.4, outline=0.8, material="metal", spec=0.4)
    p.blotch("a", A.union(kc, gd))
    p.d_line([(20, 17), (20, 31)], 0.7, O.METAL_D, curve=False)
    p.save("bottom", "armored")


def bottom_shorts():
    O.canvas("waist")
    p = Piece("waist", bevel=4.0, texture=O.fabric_weave(31, 0.5))
    p.seam([(4, 20), (44, 20)], 0.5, 0.3, curve=False)
    belt(p)
    p.save("bottom", "shorts")
    O.canvas("thigh")
    m = A.inter(O.sil_thigh(), A.poly([(0, 0), (60, 0), (60, 30), (0, 30)]))
    p = Piece("thigh", sil=m, bevel=5.5, texture=O.fabric_weave(32, 0.5))
    pk = A.smooth(A.poly([(7, 8), (23, 8), (24, 22), (6, 22)]), 0.9)
    p.panel(pk, bevel=1.6, outline=0.6)
    p.stitch([(8, 19), (22, 19)], gap=2.2)
    p.d_paint(A.ellipse(15, 13, 1.3, 1.3), (70, 74, 82), "metal", bevel=0.5, outline=0.3)
    hem = A.inter(rect(0, 24, 50, 40), m)
    p.panel(hem, bevel=1.4, outline=0.55)
    p.blotch("a", hem)
    p.save("bottom", "shorts")


def bottom_briefs():
    O.canvas("waist")
    m = A.inter(O.sil_waist(), A.poly([(0, 8), (60, 8), (60, 30), (0, 30)]))
    p = Piece("waist", sil=m, bevel=3.5, texture=O.knit_texture(0.4))
    p.seam([(4, 12), (44, 12)], 0.5, 0.35, curve=False)
    p.save("bottom", "briefs")
    O.canvas("thigh")
    m = A.inter(O.sil_thigh(), A.poly([(0, 0), (60, 0), (60, 14), (0, 14)]))
    p = Piece("thigh", sil=m, bevel=3.5, texture=O.knit_texture(0.4))
    p.save("bottom", "briefs")


# =============================================================================================== boots
def boots_boots():
    """Tall lace-up combat boots: leather shaft, toe cap, rubber sole with tread."""
    O.canvas("shin")
    shaft = A.smooth(A.poly([(10, 14), (30, 13), (29.5, 36), (13.5, 36)]), 1.2)
    p = Piece("shin", sil=shaft, material="leather", bevel=4.5, spec=0.3, texture=O.fabric_weave(40, 0.2))
    p.fold([(12, 24), (20, 28), (28, 25)], 1.3, 0.3)
    cuff = A.inter(rect(0, 12, 50, 19), shaft)
    p.panel(cuff, bevel=1.8, outline=0.6, material="leather", spec=0.3)
    p.blotch("a", cuff)
    # laces up the front
    for i, y in enumerate(range(18, 34, 3)):
        p.d_line([(24, y), (28.5, y + 1)], 0.6, (210, 200, 180), curve=False)
        p.d_paint(A.ellipse(24, y, 0.7, 0.7), O.METAL, "metal", bevel=0.3, outline=0.2)
    p.d_line([(26, 17), (26, 34)], 0.5, (30, 30, 34), curve=False, alpha=0.6)
    p.d_paint(rrect(11, 31, 29, 35.5, 0.6), (30, 30, 34), "leather", bevel=0.8, outline=0.45)   # ankle strap
    p.save("boots", "boots")
    O.canvas("foot")
    p = Piece("foot", material="leather", bevel=5.0, spec=0.3, texture=O.fabric_weave(41, 0.2))
    toe = A.smooth(A.poly([(36, 7), (49, 14), (54, 21), (50, 27), (36, 27)]), 1.0)
    p.panel(toe, bevel=2.0, outline=0.6, material="leather", spec=0.35)
    p.blotch("a", toe)
    p.fold([(26, 10), (32, 14), (28, 18)], 1.0, 0.3)
    p.stitch([(36, 8), (37, 26)], gap=2.2)
    p.d_line([(16, 4), (26, 10), (33, 14)], 0.6, (210, 200, 180), alpha=0.85)
    # sole with tread, heel block
    sole = A.inter(A.poly([(0, 21.5), (60, 21.5), (60, 40), (0, 40)]), p.sil)
    p.d_paint(A.smooth(sole, 0.5), (36, 36, 40), "matte", bevel=1.0, outline=0.0)
    for x in range(10, 52, 4):
        p.d_flat(rect(x, 24, x + 2, 26.5), (20, 20, 24), 0.8)
    p.d_flat(rect(5, 21.2, 53, 22.2), (110, 110, 118), 0.6)
    p.d_paint(A.smooth(A.poly([(5, 19), (16, 19), (16, 26), (5, 26)]), 0.4), (30, 30, 34), "matte", bevel=0.8, outline=0.0)
    p.save("boots", "boots")


def boots_sneakers():
    O.canvas("foot")
    low = A.sub(O.sil_foot(), A.poly([(0, 0), (30, 0), (30, 3.5), (0, 6)]))
    p = Piece("foot", sil=low, material="cloth", bevel=5.5, spec=0.15, texture=O.fabric_weave(42, 0.3))
    toe = A.smooth(A.poly([(38, 10), (49, 15), (54, 21), (50, 26), (38, 26)]), 1.0)
    p.panel(toe, bevel=2.0, outline=0.55, material="leather", spec=0.25)
    # side stripe (accent colour)
    stripe = A.smooth(A.poly([(10, 18), (22, 11), (34, 15), (24, 22), (10, 22)]), 0.8)
    p.panel(stripe, bevel=1.4, outline=0.5)
    p.blotch("a", stripe)
    p.blotch("b", toe)
    p.fold([(30, 8), (36, 12), (32, 16)], 0.9, 0.22)
    for i, x in enumerate((21, 25, 29, 33)):
        p.d_line([(x, 5 + i * 1.6), (x + 3.5, 8 + i * 1.6)], 0.7, (236, 238, 242), curve=False)
    p.d_paint(A.smooth(A.poly([(3, 23), (55, 23), (53, 28), (4, 28)]), 0.5), (238, 236, 228), "matte", bevel=1.0, outline=0.0)
    p.d_flat(rect(4, 25.6, 54, 26.2), (190, 150, 90), 0.8)
    p.save("boots", "sneakers")


# =============================================================================================== gloves
def gloves_gloves():
    """Tactical gloves: knuckle guard, finger seams, wrist strap."""
    O.canvas("hand")
    thumb = A.smooth(A.ellipse(19, 6.5, 4.4, 3.2, -30), 0.4)
    m = A.union(O.sil_hand(), thumb)
    p = Piece("hand", sil=m, material="leather", bevel=3.2, spec=0.3, outline=0.95, texture=O.fabric_weave(50, 0.2))
    kn = A.smooth(A.poly([(16, 10), (24, 10), (25, 19), (16, 19)]), 0.6)
    p.panel(kn, bevel=1.4, outline=0.45, material="matte")
    p.blotch("a", kn)
    for y in (12.5, 15, 17.5):
        p.seam([(17, y), (25, y)], 0.35, 0.5, curve=False)
    p.d_line([(4, 12), (4, 20)], 0.9, (28, 30, 36), curve=False)
    p.save("gloves", "gloves")
    O.canvas("forearm")
    cuff = A.inter(O.sil_forearm(), A.poly([(36, 0), (60, 0), (60, 40), (36, 40)]))
    p = Piece("forearm", sil=cuff, material="leather", bevel=3.0, spec=0.3, texture=O.fabric_weave(51, 0.2))
    p.panel(A.smooth(A.poly([(38, 6), (50, 6.5), (50, 17), (38, 17.5)]), 0.5), bevel=1.2, outline=0.5, material="matte")
    p.d_paint(rrect(42, 5, 48, 19, 0.5), (28, 30, 36), "cloth", bevel=0.8, outline=0.4)
    p.d_paint(rrect(43, 9, 47, 15, 0.4), O.METAL_D, "metal", bevel=0.5, outline=0.35)
    p.blotch("a", A.smooth(A.poly([(38, 6), (50, 6.5), (50, 17), (38, 17.5)]), 0.5))
    p.save("gloves", "gloves")


def gloves_armored():
    """Armoured bracers with plate segments and a reinforced glove."""
    O.canvas("hand")
    thumb = A.smooth(A.ellipse(19, 6.5, 4.4, 3.2, -30), 0.4)
    m = A.union(O.sil_hand(), thumb)
    p = Piece("hand", sil=m, material="matte", bevel=3.2, spec=0.2, outline=0.95)
    kn = A.smooth(A.poly([(15, 9.5), (25, 9.5), (26, 19.5), (15, 19.5)]), 0.8)
    p.panel(kn, bevel=1.8, outline=0.55, material="metal", spec=0.4)
    p.blotch("a", kn)
    for y in (12.5, 15.2, 17.8):
        p.seam([(16, y), (25, y)], 0.35, 0.5, curve=False)
    p.save("gloves", "armored")
    O.canvas("forearm")
    p = Piece("forearm", material="matte", bevel=4.0, spec=0.2)
    segs = [A.smooth(A.poly([(4, 5.5), (18, 6), (18, 18.5), (4, 18)]), 0.8), A.smooth(A.poly([(21, 6), (36, 7), (36, 17.5), (21, 18.5)]), 0.8),
            A.smooth(A.poly([(39, 7), (52, 9), (52, 15.5), (39, 17)]), 0.8)]
    for m in segs:
        p.panel(m, bevel=2.2, outline=0.7, material="metal", spec=0.4)
    p.blotch("a", A.union(*segs))
    p.d_paint(rrect(22, 10, 35, 14, 0.6), O.METAL_D, "metal", bevel=0.6, outline=0.4)
    for x in (7, 14, 25, 32, 42, 48):
        p.d_paint(A.ellipse(x, 12, 0.9, 0.9), O.METAL, "metal", bevel=0.3, outline=0.2)
    p.save("gloves", "armored")


# =============================================================================================== body armour
def armor_vest():
    """Plate carrier: shoulder straps, MOLLE webbing, magazine pouches, cummerbund."""
    O.canvas("torso")
    inner = A.smooth(A.poly([(12, 14), (36, 12), (36, 6), (30, 6), (14, 6)]), 0.5)
    body = A.smooth(A.poly([(10, 16), (30, 12), (40, 22), (46, 20), (58, 20), (66, 22), (76, 12), (86, 16), (84, 40), (76, 66), (70, 84), (34, 84), (24, 66), (12, 40)]), 1.2)
    p = Piece("torso", sil=body, bevel=5.5, ambient=0.5, spec=0.12, texture=O.fabric_weave(60, 0.6), pad=0.4)
    # front plate panel with webbing grid
    plate = A.smooth(A.poly([(40, 24), (82, 24), (80, 66), (74, 72), (44, 72), (38, 66)]), 1.0)
    p.panel(plate, bevel=2.0, outline=0.6, texture=O.fabric_weave(61, 0.5))
    for y in range(28, 70, 5):
        p.d_line([(40, y), (80, y)], 0.55, (24, 26, 30), curve=False, alpha=0.55)
    for x in range(44, 80, 7):
        p.d_line([(x, 26), (x, 70)], 0.35, (24, 26, 30), curve=False, alpha=0.3)
    # three magazine pouches on the belly
    for x0 in (42, 54, 66):
        pc = A.smooth(A.poly([(x0, 52), (x0 + 11, 52), (x0 + 11, 70), (x0, 70)]), 0.8)
        p.panel(pc, bevel=1.8, outline=0.6, texture=O.fabric_weave(62, 0.5))
        p.blotch("a", pc) if False else None
        p.d_paint(rrect(x0 + 1, 52, x0 + 10, 57, 0.5), (36, 38, 42), "cloth", bevel=0.8, outline=0.45)
        p.d_paint(rrect(x0 + 4, 54.5, x0 + 7, 59, 0.3), O.METAL, "metal", bevel=0.4, outline=0.3)
    # chest admin pouch + radio pouch
    adm = A.smooth(A.poly([(46, 30), (74, 30), (74, 44), (46, 44)]), 0.8)
    p.panel(adm, bevel=1.6, outline=0.6, texture=O.fabric_weave(63, 0.5))
    p.d_paint(rrect(50, 30, 70, 36, 0.5), (32, 34, 38), "cloth", bevel=0.8, outline=0.4)
    p.d_paint(A.ellipse(60, 36, 1.3, 1.3), O.METAL, "metal", bevel=0.4, outline=0.3)
    rad = A.smooth(A.poly([(10, 36), (24, 36), (26, 64), (14, 62)]), 0.8)
    p.panel(rad, bevel=1.6, outline=0.55)
    # shoulder straps with velcro tabs and a buckle
    for pts in ([(14, 8), (36, 7), (36, 20), (12, 22)], [(64, 8), (86, 12), (84, 24), (64, 22)]):
        st = A.smooth(A.poly(pts), 0.6)
        p.panel(st, bevel=1.4, outline=0.55, texture=O.fabric_weave(64, 0.5))
        p.d_paint(rrect(pts[0][0] + 6, pts[0][1] + 4, pts[0][0] + 12, pts[0][1] + 11, 0.4), (40, 42, 46), "matte", bevel=0.4, outline=0.3)
    # cummerbund
    cb = A.smooth(A.poly([(30, 74), (74, 74), (72, 88), (34, 88)]), 0.8)
    p.panel(cb, bevel=1.8, outline=0.6, texture=O.fabric_weave(65, 0.6))
    p.d_paint(rrect(44, 77, 60, 85, 0.5), (34, 36, 40), "matte", bevel=0.6, outline=0.4)
    p.d_paint(rrect(50, 78.5, 54, 83.5, 0.4), O.METAL, "metal", bevel=0.5, outline=0.35)
    p.blotch("a", A.union(*(A.smooth(A.poly([(x0, 52), (x0 + 11, 52), (x0 + 11, 70), (x0, 70)]), 0.8) for x0 in (42, 54, 66)), adm, rad))
    p.blotch("b", cb)
    p.save("armor", "vest")


def armor_plated():
    """Heavy plated chest armour: layered angular plates, rivets, trim."""
    O.canvas("torso")
    body = A.smooth(A.poly([(8, 12), (30, 8), (44, 14), (60, 14), (76, 8), (88, 14), (86, 42), (78, 70), (72, 88), (32, 88), (22, 70), (10, 42)]), 1.0)
    p = Piece("torso", sil=body, material="metal", bevel=5.0, ambient=0.5, spec=0.38, texture=None, pad=0.4)
    # layered plates
    chest = A.smooth(A.poly([(40, 20), (84, 20), (86, 40), (76, 54), (46, 54), (36, 40)]), 0.8)
    mid = A.smooth(A.poly([(38, 52), (80, 52), (78, 66), (42, 66)]), 0.8)
    low = A.smooth(A.poly([(36, 64), (76, 64), (72, 78), (38, 78)]), 0.8)
    belt = A.smooth(A.poly([(32, 76), (74, 76), (72, 90), (34, 90)]), 0.8)
    back = A.smooth(A.poly([(8, 18), (30, 16), (34, 52), (24, 64), (12, 44)]), 0.8)
    plates = [back, chest, mid, low, belt]
    for m in plates:
        p.panel(m, bevel=2.8, outline=0.8, material="metal", spec=0.45)
    # central ridge + edge trim
    p.seam([(60, 21), (60, 53)], 0.8, 0.45, curve=False)
    p.light(A.line([(42, 24), (80, 24)], 0.8), 0.28)
    p.light(A.line([(40, 56), (78, 56)], 0.8), 0.22)
    # rivets
    for (x, y) in ((44, 26), (80, 26), (44, 50), (78, 48), (46, 58), (76, 58), (42, 70), (72, 70), (40, 82), (70, 82)):
        p.d_paint(A.ellipse(x, y, 1.1, 1.1), O.METAL, "metal", bevel=0.4, outline=0.25)
    # brass edge trim on the chest plate
    p.d_line(A.curve_pts([(40, 20), (84, 20), (86, 40), (76, 54), (46, 54), (36, 40), (40, 20)], 8), 0.7, O.BRASS, curve=False, alpha=0.65)
    # emblem
    p.d_paint(A.smooth(A.poly([(60, 28), (68, 36), (60, 46), (52, 36)]), 0.4), O.BRASS, "metal", bevel=1.0, outline=0.5)
    p.d_flat(A.smooth(A.poly([(60, 31), (65, 36), (60, 42), (55, 36)]), 0.3), (30, 34, 44), 0.8)
    p.blotch("a", A.union(back, mid, belt))
    p.save("armor", "plated")


# =============================================================================================== pads (shoulder / knee)
def pads():
    """Shoulder pauldron (80x72 px, pivot 36,32) and knee guard (56x56, pivot 28,28). Tinted base + dark trim + untinted shine."""
    A.set_canvas(40, 36, 0, 0, 2, 3)
    dome = A.smooth(A.poly(A.curve_pts([(3, 24), (5, 12), (14, 4), (26, 3), (35, 10), (37, 22), (30, 30), (14, 30)], 10, closed=True)), 0.8)
    seg2 = A.smooth(A.poly([(5, 20), (36, 19), (35, 26), (7, 28)]), 0.8)
    seg3 = A.smooth(A.poly([(8, 25), (34, 24), (31, 31), (12, 32)]), 0.8)
    img = A.paint(dome, (255, 255, 255), "metal", bevel=5.5, outline=1.15, ambient=0.5, spec=0.42)
    img = A.over(A.paint(A.inter(seg2, A.grow(dome, 2.0)), (255, 255, 255), "metal", bevel=2.6, outline=0.9, ambient=0.5, spec=0.4), img)
    img = A.over(A.paint(A.inter(seg3, A.grow(dome, 3.0)), (255, 255, 255), "metal", bevel=2.2, outline=0.9, ambient=0.5, spec=0.4), img)
    ridge = A.empty()
    A.line(A.curve_pts([(8, 22), (14, 11), (24, 8), (32, 14)], 12), 0.8, ridge)
    img = A.over(A.tint_layer(A.blur(A.inter(ridge, dome), 0.4), (14, 18, 30), 0.35), img)
    A.save(img, "art/player/shoulder_pad_base.png")
    trim = A.empty()
    trim_m = A.sub(A.grow(dome, -0.2), A.grow(dome, -2.0))
    tr = A.tint_layer(trim_m, (255, 255, 255), 0.85)
    for (x, y) in ((11, 14), (26, 12), (32, 20), (10, 25), (22, 27)):
        tr = A.over(A.paint(A.ellipse(x, y, 1.3, 1.3), (255, 255, 255), "metal", bevel=0.5, outline=0.3, spec=0.5), tr)
    A.save(tr, "art/player/shoulder_pad_trim.png")
    sh = A.empty()
    A.line(A.curve_pts([(10, 12), (15, 7), (24, 5.5)], 10), 1.4, sh)
    sh2 = A.tint_layer(A.blur(sh, 0.6), (255, 255, 255), 0.9, within=dome)
    A.save(sh2, "art/player/shoulder_pad_shine.png")
    # knee guard
    A.set_canvas(28, 28, 0, 0, 2, 3)
    cap = A.smooth(A.poly(A.curve_pts([(3, 14), (6, 6), (14, 2.5), (22, 6), (25, 14), (22, 22), (14, 25.5), (6, 22)], 10, closed=True)), 0.8)
    img = A.paint(cap, (255, 255, 255), "metal", bevel=4.5, outline=1.1, ambient=0.5, spec=0.42)
    inner = A.smooth(A.ellipse(14, 14, 7.2, 8.2), 0.5)
    img = A.over(A.paint(inner, (255, 255, 255), "metal", bevel=2.4, outline=0.8, ambient=0.5, spec=0.45), img)
    rv = A.empty()
    for (x, y) in ((6.2, 14), (21.8, 14), (14, 5.4), (14, 22.6)):
        A.blob(x, y, 0.9, rv)
    img = A.over(A.tint_layer(rv, (30, 34, 46), 0.8), img)
    A.save(img, "art/player/knee_pad_base.png")
    kshine = A.empty()
    A.line(A.curve_pts([(6, 10), (9, 5.5), (15, 4.2)], 8), 1.2, kshine)
    A.save(A.tint_layer(A.blur(kshine, 0.5), (255, 255, 255), 0.9, within=cap), "art/player/knee_pad_shine.png")


if __name__ == "__main__":
    what = sys.argv[1] if len(sys.argv) > 1 else "all"
    ids = sys.argv[2:]
    if what in ("body", "all"):
        body()
        harness()
    if what in ("tops", "all"):
        for fn in (top_bra, top_tshirt, top_tank, top_tactical, top_uniform, top_jacket, top_suit):
            if not ids or fn.__name__[4:] in ids:
                fn()
    if what in ("pads", "all"):
        pads()
    if what in ("boots", "all"):
        import footwear
        for k, fn in footwear.ALL.items():
            if not ids or k in ids:
                fn()
    if what in ("gloves", "all"):
        for fn in (gloves_gloves, gloves_armored):
            if not ids or fn.__name__[7:] in ids:
                fn()
    if what in ("armor", "all"):
        import armor
        for nm, fn in (("vest", armor.vest), ("plated", armor.plated)):
            if not ids or nm in ids:
                fn()
    if what in ("bottoms", "all"):
        for fn in (bottom_pants, bottom_combat, bottom_military, bottom_tactical, bottom_armored, bottom_shorts, bottom_briefs):
            if not ids or fn.__name__[7:] in ids:
                fn()
