#!/usr/bin/env python3
"""Hairstyles and facial hair, generated to fit a given Head (see headlib).

Every style is built from the head's own silhouette and anchors: the scalp cap is the silhouette grown outward by the
hair's thickness and cut at a hairline that follows that head's forehead / temple / ear, beards grow out of that head's
jaw line, so the same style looks right on a round, a square or a pointed head.

A style returns a dict of layers: {"front": rgba, "back": rgba|None, "glow": rgba|None}. All layers are white-based and
tinted in game (hair colour; glow colour for "glow").
"""
import numpy as np
import cv2
import artlib as A

HAIR_STYLES = {
    # id: (name, tags)   tags: tall = sticks up above a helmet (cannot sit under headgear), long = has a back layer that hangs out
    "none":     ("Bald", []),
    "buzz":     ("Buzz Cut", []),
    "crop":     ("Short Crop", []),
    "sidepart": ("Side Part", []),
    "fade":     ("Fade Quiff", ["tall"]),
    "undercut": ("Slick Undercut", []),
    "spiky":    ("Spiky", ["tall"]),
    "mohawk":   ("Mohawk", ["tall"]),
    "afro":     ("Afro", ["tall"]),
    "curly":    ("Curly", ["tall"]),
    "wavy":     ("Wavy Bob", ["long"]),
    "long":     ("Long Flowing", ["long"]),
    "pony":     ("Ponytail", ["long"]),
    "highpony": ("High Ponytail", ["long", "tall"]),
    "bun":      ("Top Bun", ["tall"]),
    "braids":   ("Braids", ["long"]),
    "dreads":   ("Dreadlocks", ["long"]),
    "cyber":    ("Cyber Crest", ["tall", "glow"]),
    "fantasy":  ("Fantasy Swept", ["long"]),
}
HAIR_IDS = list(HAIR_STYLES.keys())

FACIAL_STYLES = {
    "none":      "Clean Shaven",
    "stubble":   "Stubble",
    "short":     "Short Beard",
    "full":      "Full Beard",
    "goatee":    "Goatee",
    "mustache":  "Mustache",
    "handlebar": "Handlebar",
    "stache_beard": "Mustache + Beard",
    "chinstrap": "Chin Strap",
    "mutton":    "Mutton Chops",
    "long":      "Long Beard",
}
FACIAL_IDS = list(FACIAL_STYLES.keys())


# ------------------------------------------------------------------------------ helpers
def hairline_ctrl(h, off=0.0, sideburn=0.0):
    ex = h.ear[0]
    # the hairline sits a few units higher than before so the forehead and brows read clearly under every style
    return [(h.back - 8, h.eye_y + 18), (ex - 6, h.eye_y + 2), (ex + 2, h.eye_y - 3 + sideburn), (ex + 9, h.brow_y - 9 + off),
            (h.front - 30, h.hairline_y + 2 + off), (h.front - 14, h.brow_y - 15 + off), (h.front + 12, h.brow_y - 12 + off * 0.5)]


def region_above(h, off=0.0, sideburn=0.0, ctrl=None):
    pts = A.curve_pts(ctrl or hairline_ctrl(h, off, sideburn), 12)
    poly = pts + [(h.front + 30, -30), (h.back - 30, -30)]
    return A.poly(poly)


def cap(h, t, off=0.0, sideburn=0.0, base=None):
    sk = h.skull if base is None else base
    return A.inter(A.grow(sk, t), region_above(h, off, sideburn))


def scalp_point(h, fx, fy_off=0.0):
    """A point on the top of the skull at horizontal fraction fx (0 back .. 1 front)."""
    x = h.back + (h.front - h.back) * fx
    y = h.top_y(x)
    return (x, (y if y is not None else h.top) + fy_off)


def flow_strands(h, origin, ends, bow=6.0, n_extra=0, rng_seed=1, wob=1.0):
    """Curved strand control lists from `origin` to each end point, bowed outward (up/back)."""
    rng = np.random.default_rng(rng_seed)
    out = []
    for e in ends:
        mx, my = (origin[0] + e[0]) / 2, (origin[1] + e[1]) / 2
        # push the mid control point away from the head centre so strands follow the dome
        cx, cy = (h.back + h.front) / 2, h.eye_y
        dx, dy = mx - cx, my - cy
        L = max(1e-6, (dx * dx + dy * dy) ** 0.5)
        mx += dx / L * bow * (0.7 + 0.6 * rng.random()) * wob
        my += dy / L * bow * (0.7 + 0.6 * rng.random()) * wob
        out.append([origin, (mx, my), e])
    return out


def hair_paint(m, strands=None, bevel=3.2, seed=0, ambient=0.5, hi=True, texture_scale=1.0):
    tex = A.strand_texture(strands, 0.42, seed) if strands else None
    img = A.paint(m, (255, 255, 255), "hair", bevel=bevel, outline=0.95, ambient=ambient, texture=tex, rim=0.22)
    return img


def arc_ends(h, a0, a1, r_off, n, cy_off=0.0, squash=0.8):
    """Points on an arc around the head (angles in degrees, 180 = back, 0 = front, 90 = top?) used as strand ends."""
    cx, cy = (h.back + h.front) / 2 + 2, h.eye_y - 6 + cy_off
    rx, ry = (h.front - h.back) / 2 + r_off, (h.eye_y - h.top) + r_off
    pts = []
    for a in np.linspace(a0, a1, n):
        t = np.radians(a)
        pts.append((cx + rx * np.cos(t), cy - ry * np.sin(t) * squash if False else cy - ry * np.sin(t)))
    return pts


def lock(pts, w0, w1):
    """A tapered hanging lock along `pts` (design units): union of discs shrinking from w0 to w1."""
    dense = A.curve_pts(pts, 10)
    m = A.empty()
    n = len(dense)
    for i, (x, y) in enumerate(dense):
        r = (w0 + (w1 - w0) * i / max(1, n - 1)) / 2
        A.ellipse(x, y, r, r, 0, m)
    return A.smooth(m, 0.25)


def spike(base_a, base_b, tip):
    return A.poly([base_a, tip, base_b])


# ------------------------------------------------------------------------------ hair
def make_hair(h, style):
    """Returns {"front": rgba, "back": rgba|None, "glow": rgba|None} or None for bald."""
    if style == "none":
        return None
    rng = np.random.default_rng(abs(hash(style)) % 1000)
    front = back = glow = None
    crown = scalp_point(h, 0.45)
    top_front = scalp_point(h, 0.72)
    top_back = scalp_point(h, 0.22)

    def std_strands(ends=None, bow=5.0, org=None, seed=1):
        org = org or (h.front - 36, h.top + 6)
        ends = ends or [(h.back + 4 + i * (h.front - h.back - 2) / 9.0, h.hairline_y + 5 + abs(i - 5) * 0.9 - (i > 6) * (i - 6) * 1.5) for i in range(10)]
        return flow_strands(h, org, ends, bow, rng_seed=seed)

    if style == "buzz":
        m = cap(h, 1.5, off=-3.0)
        m = A.smooth(m, 0.5)
        fine = A.noise(3, 0.7)
        img = A.paint(m, (255, 255, 255), "hair", bevel=1.6, outline=0.7, ambient=0.62, texture=fine * 0.9, rim=0.1)
        front = img
    elif style == "crop":
        m = cap(h, 3.3, off=-1.0)
        # a short forward fringe
        fr = A.poly([(h.front - 44, h.top + 3), (h.front + 1, h.brow_y - 12), (h.front - 4, h.brow_y - 6), (h.front - 24, h.hairline_y + 6)])
        m = A.smooth(A.union(m, A.inter(fr, A.grow(h.skull, 3.6))), 0.9)
        front = hair_paint(m, std_strands(seed=2), bevel=3.0, seed=2)
    elif style == "sidepart":
        m = cap(h, 3.8, off=0.5)
        sweep = A.poly([(h.front - 52, h.top + 1), (h.front + 4, h.brow_y - 14), (h.front + 3, h.brow_y - 3), (h.front - 22, h.hairline_y + 10), (h.front - 40, h.hairline_y + 2)])
        m = A.smooth(A.union(m, A.inter(sweep, A.grow(h.skull, 4.2))), 1.0)
        part = (h.front - 46, h.top + 3)
        ends = [(h.front + 2, h.brow_y - 9 + i * 1.4) for i in range(4)] + [(h.front - 18 - i * 6, h.hairline_y + 8 - i * 0.4) for i in range(5)] + [(h.back + 8, h.hairline_y + 10)]
        st = flow_strands(h, part, ends, 4.0, rng_seed=3)
        front = hair_paint(m, st, bevel=3.4, seed=3)
        # the part line
        pl = A.line([part, (part[0] + 6, part[1] + 7)], 0.7)
        front = A.over(A.tint_layer(pl, (20, 20, 30), 0.55, within=m), front)
    elif style == "fade":
        m = cap(h, 3.0, off=1.5)
        quiff = A.ellipse(h.front - 26, h.top + 2, 26, 11, -8)
        quiff = A.inter(A.union(quiff, A.poly([(h.front - 46, h.top + 8), (h.front + 6, h.brow_y - 13), (h.front - 2, h.top + 12)])), A.grow(h.skull, 11))
        top = A.union(A.inter(cap(h, 3.0), A.half_plane((h.back, h.hairline_y + 2), (h.front, h.hairline_y - 6), below=False)), quiff)
        top = A.smooth(top, 1.0)
        ends = [(h.front + 4 - i * 3.4, h.top - 6 + abs(i - 4) * 1.4 + i * 0.6) for i in range(10)]
        st = flow_strands(h, (h.back + 24, h.hairline_y + 2), ends, 3.0, rng_seed=4)
        top_img = hair_paint(top, st, bevel=4.2, seed=4)
        side = A.sub(cap(h, 1.8, off=3.0), A.grow(top, -1.0))
        # the fade: stubble that thins toward the ear
        ramp = np.linspace(1.0, 0.0, A.IH, dtype=np.float32)[:, None]
        yy = (np.arange(A.IH, dtype=np.float32) / A.F - A.OY)[:, None]
        fade_a = np.clip((h.eye_y + 6 - yy) / 22.0, 0, 1)
        side_img = A.paint(side, (255, 255, 255), "hair", bevel=1.2, outline=0.0, ambient=0.6, texture=A.noise(5, 0.6), rim=0.0)
        side_img[..., 3] *= fade_a * (0.55 + 0.45 * np.clip(A.noise(6, 0.5) + 0.5, 0, 1))
        front = A.over(top_img, side_img)
    elif style == "undercut":
        top = cap(h, 4.2, off=0.0)
        top = A.inter(top, A.half_plane((h.back + 8, h.eye_y - 14), (h.front, h.hairline_y - 2), below=False))
        top = A.smooth(A.union(top, A.inter(A.poly([(h.back + 10, h.top + 14), (h.front - 40, h.top - 3), (h.front + 2, h.brow_y - 12), (h.front - 6, h.hairline_y + 2)]), A.grow(h.skull, 4.6))), 1.2)
        ends = [(h.back + 6 + i * 3.0, h.top + 12 + i * 0.6) for i in range(12)]
        st = flow_strands(h, (h.front - 6, h.brow_y - 14), ends, -4.0, rng_seed=5)
        top_img = hair_paint(top, st, bevel=4.0, seed=5)
        side = A.sub(cap(h, 1.4, off=4.0), A.grow(top, -0.8))
        side_img = A.paint(side, (255, 255, 255), "hair", bevel=1.0, outline=0.0, ambient=0.6, texture=A.noise(7, 0.6), rim=0.0)
        side_img[..., 3] *= 0.6
        front = A.over(top_img, side_img)
    elif style == "spiky":
        m = cap(h, 3.4, off=0.5)
        tips = []
        for i in range(7):
            fx = 0.12 + i * 0.125
            bx, by = scalp_point(h, fx, 1.0)
            tx = bx + (fx - 0.45) * 22 + 3
            ty = by - 14 - 5 * np.sin(np.pi * fx) - (i % 2) * 3
            wdt = 5.8
            tips.append((bx - wdt, by + 3, bx + wdt, by + 3, tx, ty))
        sp = A.empty()
        for t in tips:
            A.poly([(t[0], t[1]), (t[4], t[5]), (t[2], t[3])], sp)
        m = A.smooth(A.union(m, sp), 0.5, 16)
        st = [[(tx[4] - 0.5, tx[5] + 3), (tx[4] - 1, tx[5] + 9)] for tx in tips] + std_strands(seed=6)
        front = hair_paint(m, st, bevel=3.2, seed=6)
    elif style == "mohawk":
        side = A.sub(cap(h, 1.4, off=2.0), A.empty())
        mid = []
        for fx in np.linspace(0.06, 0.82, 13):
            bx, by = scalp_point(h, fx, 2.0)
            mid.append((bx, by - 13 - 6 * np.sin(np.pi * (fx - 0.04) / 0.8)))
        base_pts = [scalp_point(h, fx, 3.0) for fx in np.linspace(0.04, 0.84, 13)]
        ridge = A.poly(base_pts + mid[::-1])
        ridge = A.smooth(A.union(ridge, A.inter(A.grow(h.skull, 3.0), A.poly(base_pts + [(h.front, h.top - 5), (h.back, h.top - 5)]))), 0.6)
        # spiky tips
        tips = A.empty()
        for i in range(0, 13, 1):
            bx, by = mid[i]
            A.poly([(bx - 2.3, by + 4), (bx + 0.5, by - 4.5 - (i % 2) * 2), (bx + 2.3, by + 4)], tips)
        ridge = A.smooth(A.union(ridge, tips), 0.35, 16)
        sh = A.paint(side, (255, 255, 255), "hair", bevel=1.0, outline=0.0, ambient=0.6, texture=A.noise(8, 0.6), rim=0.0)
        sh[..., 3] *= 0.38
        st = [[(x, y + 14), (x - 0.5, y)] for x, y in mid[::2]] + [[(x, y + 4), (x, y - 5)] for x, y in mid[1::2]]
        rg = hair_paint(ridge, st, bevel=3.0, seed=7)
        front = A.over(rg, sh)
    elif style == "afro":
        cx, cy = (h.back + h.front) / 2 - 1, h.top + 12
        m = A.ellipse(cx, cy, 41, 33)
        # scalloped curly edge
        for a in np.linspace(0, 2 * np.pi, 22, endpoint=False):
            A.ellipse(cx + np.cos(a) * 38, cy + np.sin(a) * 30, 6.5, 6.5, 0, m)
        # carve the face: hairline in front
        face_cut = A.sub(A.empty() + 1, region_above(h, off=1.0, sideburn=0.0))
        m = A.sub(m, A.inter(face_cut, A.half_plane((h.back + 24, h.eye_y - 4), (h.back + 24, h.eye_y + 40), below=True)))
        m = A.sub(m, A.inter(face_cut, A.grow(h.skull, -0.3)))
        m = A.smooth(m, 0.5)
        curls = []
        for _ in range(70):
            x = rng.uniform(cx - 36, cx + 36); y = rng.uniform(cy - 28, cy + 26)
            curls.append([(x - 1.6, y + 0.4), (x, y - 1.6), (x + 1.8, y + 0.4)])
        front = hair_paint(m, curls, bevel=7.0, seed=8, ambient=0.46)
    elif style == "curly":
        m = cap(h, 4.6, off=-0.5)
        for fx in np.linspace(0.04, 0.9, 14):
            bx, by = scalp_point(h, fx, 1.0)
            A.ellipse(bx, by - 2.6 - 1.4 * np.sin(np.pi * fx), 5.4, 5.0, 0, m)
        for yy in np.linspace(h.top + 20, h.eye_y + 6, 4):
            bx = h.back_x(yy)
            if bx is not None:
                A.ellipse(bx + 1.5, yy, 5.6, 5.2, 0, m)
        # fringe curls
        for i in range(4):
            A.ellipse(h.front - 8 - i * 7, h.hairline_y + 2 + (i % 2) * 2.4, 5.0, 4.6, 0, m)
        m = A.sub(m, A.inter(A.sub(A.empty() + 1, region_above(h, off=2.0)), A.grow(h.skull, -0.3)))
        m = A.smooth(m, 0.4)
        curls = []
        for _ in range(55):
            x = rng.uniform(h.back + 4, h.front - 6); y = rng.uniform(h.top - 4, h.hairline_y + 14)
            curls.append([(x - 1.8, y + 0.5), (x, y - 1.8), (x + 2, y + 0.5)])
        front = hair_paint(m, curls, bevel=4.0, seed=9, ambient=0.48)
    elif style == "wavy":
        m = cap(h, 4.2, off=0.0)
        fr = A.poly([(h.front - 40, h.top + 2), (h.front + 3, h.brow_y - 12), (h.front, h.brow_y - 4), (h.front - 26, h.hairline_y + 12), (h.front - 44, h.hairline_y + 2)])
        m = A.union(m, A.inter(fr, A.grow(h.skull, 5.0)))
        m = A.smooth(m, 1.0)
        front = hair_paint(m, std_strands(seed=10), bevel=3.8, seed=10)
        bk = A.empty()
        for i, y in enumerate(np.linspace(h.eye_y - 6, h.chin_y - 2, 6)):
            bx = h.back_x(min(y, h.chin_y - 8))
            bx = (bx if bx is not None else h.back + 6)
            A.ellipse(bx + 8 - (i % 2) * 2.5, y, 14 - (i % 2) * 1.5, 5.6, 0, bk)
        bk = A.sub(A.union(bk, A.inter(A.grow(h.skull, 4.6), A.poly([(h.back - 8, h.top), (h.back + 22, h.top), (h.back + 20, h.chin_y), (h.back - 8, h.chin_y)]))), A.grow(h.skull, -1.0) * 0)
        bk = A.sub(bk, A.sub(A.grow(h.skull, -0.5), A.empty()) * 0)
        back = hair_paint(A.smooth(bk, 1.0), None, bevel=3.2, seed=11, ambient=0.42)
    elif style == "long":
        m = cap(h, 4.0, off=0.0)
        fr = A.poly([(h.front - 40, h.top + 2), (h.front + 4, h.brow_y - 13), (h.front + 1, h.brow_y - 3), (h.front - 22, h.hairline_y + 9), (h.front - 44, h.hairline_y + 2)])
        m = A.smooth(A.union(m, A.inter(fr, A.grow(h.skull, 4.6))), 1.0)
        ends = [(h.front + 2, h.brow_y - 9 + i * 1.3) for i in range(3)] + [(h.front - 20 - i * 6, h.hairline_y + 8) for i in range(5)] + [(h.back, h.eye_y + 16)]
        front = hair_paint(m, flow_strands(h, (h.front - 46, h.top + 3), ends, 4.0, rng_seed=12), bevel=3.6, seed=12)
        # long locks falling behind the shoulders
        bk = A.poly([(h.back + 28, h.top + 4), (h.back - 6, h.eye_y - 10), (h.back - 12, h.eye_y + 30), (h.back - 8, 99), (h.back + 22, 99), (h.back + 30, h.eye_y + 20), (h.back + 34, h.eye_y)])
        bk = A.smooth(A.union(bk, A.inter(A.grow(h.skull, 3.8), A.poly([(h.back - 10, h.top), (h.back + 40, h.top), (h.back + 40, h.eye_y + 10), (h.back - 10, h.eye_y + 10)]))), 1.6)
        st = [[(h.back + 26 - i * 2.8, h.eye_y - 8 + i * 0.5), (h.back + 14 - i * 3.6, h.eye_y + 22), (h.back + 12 - i * 3.2, 97)] for i in range(7)]
        back = hair_paint(bk, st, bevel=5.0, seed=13, ambient=0.44)
    elif style == "pony" or style == "highpony":
        m = cap(h, 3.4, off=-0.5)
        # slicked back: fringe tight to the head
        m = A.smooth(m, 0.8)
        ends = [(h.back + 4 + i * 4.5, h.hairline_y + 4 - (i > 5) * (i - 5) * 0.5) for i in range(11)]
        front = hair_paint(m, flow_strands(h, (h.front - 8, h.brow_y - 12), ends, -3.0, rng_seed=14), bevel=3.2, seed=14)
        if style == "pony":
            tie = (h.back + 2, h.eye_y - 6)
            tail = [tie, (h.back - 8, h.eye_y + 6), (h.back - 10, h.eye_y + 26), (h.back - 4, h.eye_y + 42)]
        else:
            tie = (h.back + 16, h.top + 1)
            tail = [tie, (h.back + 2, h.top - 8), (h.back - 10, h.top + 8), (h.back - 10, h.eye_y + 18), (h.back - 4, h.eye_y + 34)]
        tl = lock(tail, 10.0, 3.6)
        bk = A.union(tl, A.blob(tie[0], tie[1], 5.2))
        bk = A.smooth(bk, 0.6)
        st = [[(tail[0][0] + dx, tail[0][1]), tail[1], tail[2], tail[3]] for dx in (-2.5, 0, 2.5)]
        back = hair_paint(bk, [[(a[0] + dx * 0.5, a[1]) for a in c] for c in st for dx in (0,)], bevel=3.4, seed=15)
        tieband = A.blob(tie[0], tie[1], 3.0)
        back = A.over(A.tint_layer(tieband, (255, 255, 255), 1.0), back)
        back = A.over(A.tint_layer(A.sub(A.grow(tieband, 0.8), tieband), (20, 26, 40), 1.0), back)
    elif style == "bun":
        m = cap(h, 3.4, off=-0.5)
        bx, by = scalp_point(h, 0.28, 0)
        m = A.union(m, A.ellipse(bx, by - 6, 11, 10))
        m = A.smooth(m, 0.8)
        ends = [(h.back + 4 + i * 4.5, h.hairline_y + 4) for i in range(11)]
        st = flow_strands(h, (h.front - 8, h.brow_y - 12), ends, -3.0, rng_seed=16) + [[(bx - 6, by - 6), (bx, by - 14), (bx + 6, by - 6)], [(bx - 5, by - 3), (bx, by - 10), (bx + 5, by - 3)]]
        front = hair_paint(m, st, bevel=4.2, seed=16)
    elif style == "braids":
        m = cap(h, 3.0, off=-0.5)
        m = A.smooth(m, 0.7)
        rows = []
        for r in range(5):
            x0 = h.front - 8 - r * 2.4
            rows.append([(h.front - 2 - r * 4.5, h.brow_y - 12 + r * 1.2), (h.front - 24 - r * 4.5, h.top + 1 + r * 3.0), (h.back + 12 - r, h.top + 18 + r * 3.5)])
        front = hair_paint(m, rows, bevel=2.6, seed=17, ambient=0.5)
        # corn-row grooves
        for c in rows:
            ln = A.line(A.curve_pts(c, 14), 0.5)
            front = A.over(A.tint_layer(ln, (10, 10, 20), 0.42, within=m), front)
        # hanging braids behind: chains of plaited segments
        bk = A.empty(); st = []
        for i in range(3):
            x0 = h.back + 6 + i * 6.5; y0 = h.eye_y - 4 + i * 4
            chain = []
            for j in range(9):
                cx = x0 - 4 - (i * 0.6) + np.sin(j * 1.1) * 1.6 - j * 0.5
                cy = y0 + j * 5.8
                A.ellipse(cx, cy, 4.4 - j * 0.25, 3.4, 0, bk)
                chain.append((cx, cy))
            st.append(chain)
        bk = A.smooth(A.union(bk, A.inter(A.grow(h.skull, 2.6), A.poly([(h.back - 6, h.eye_y - 4), (h.back + 24, h.eye_y - 4), (h.back + 24, h.eye_y + 14), (h.back - 6, h.eye_y + 14)]))), 0.35)
        back = hair_paint(bk, None, bevel=2.2, seed=18, ambient=0.46)
        for chain in st:
            for j, (cx, cy) in enumerate(chain):
                seg = A.line([(cx - 3, cy - 1.5), (cx + 2.6, cy + 1.8)], 0.5)
                back = A.over(A.tint_layer(seg, (10, 10, 20), 0.5, within=bk), back)
    elif style == "dreads":
        m = cap(h, 4.6, off=-0.5)
        for fx in np.linspace(0.05, 0.9, 12):
            bx, by = scalp_point(h, fx, 1.5)
            A.ellipse(bx, by - 2.0, 4.8, 4.2, 0, m)
        m = A.smooth(A.sub(m, A.inter(A.sub(A.empty() + 1, region_above(h, off=1.5)), A.grow(h.skull, -0.3))), 0.5)
        st = []
        for i in range(8):
            fx = 0.10 + i * 0.1
            bx, by = scalp_point(h, fx, 1)
            st.append([(bx, by), (bx + (fx - 0.45) * 12, by - 7), (bx + (fx - 0.45) * 22, by - 3)])
        front = hair_paint(m, st, bevel=3.4, seed=19)
        # locks: front few over the shoulder, most behind
        fl = A.empty()
        for i, fx in enumerate((0.78, 0.66)):
            bx, by = scalp_point(h, fx, 3)
        bk = A.empty(); stt = []
        for i in range(8):
            x0 = h.back + 4 + i * 4.2; y0 = h.top_y(x0) or h.top
            ctrl = [(x0, y0 + 4), (x0 - 6 - i * 0.6, y0 + 20 + i * 2), (x0 - 7 - i * 0.8 + (i % 2) * 3, h.eye_y + 22 + (i % 3) * 3), (x0 - 4 + (i % 2) * 2, 94 + (i % 3) * 2)]
            ctrl = [(min(max(x, 0), 106), min(y, 99)) for x, y in ctrl]
            bk = A.union(bk, lock(ctrl, 6.4, 3.4))
            stt.append(ctrl)
        back = hair_paint(A.smooth(bk, 0.3), None, bevel=3.0, seed=20, ambient=0.44)
        for ctrl in stt:
            for j in range(1, 9):
                p = A.curve_pts(ctrl, 8)[min(len(A.curve_pts(ctrl, 8)) - 1, j * 4)]
                seg = A.line([(p[0] - 2.8, p[1]), (p[0] + 2.8, p[1] + 0.6)], 0.4)
                back = A.over(A.tint_layer(seg, (10, 10, 20), 0.4, within=bk), back)
        # two locks falling in front of the ear
        fk = A.empty()
        for i in range(3):
            x0 = h.ear[0] + 7 + i * 5; y0 = h.eye_y - 6 + i * 2
            ctrl = [(x0, y0), (x0 - 1, y0 + 12), (x0 - 2 + i, y0 + 22 + i * 3)]
            fk = A.union(fk, lock(ctrl, 5.6, 3.2))
        fk_img = hair_paint(A.smooth(fk, 0.3), None, bevel=2.8, seed=21, ambient=0.46)
        front = A.over(fk_img, front)
    elif style == "cyber":
        m = A.sub(cap(h, 1.4, off=3.0), A.empty())
        side_img = A.paint(m, (255, 255, 255), "hair", bevel=1.0, outline=0.0, ambient=0.6, texture=A.noise(22, 0.6), rim=0.0)
        side_img[..., 3] *= 0.45
        ridge_pts = []
        for fx in np.linspace(0.08, 0.86, 8):
            bx, by = scalp_point(h, fx, 1.0)
            ridge_pts.append((bx, by))
        crest = A.poly(ridge_pts + [(x + (-1.2 if i % 2 else 2.0), y - 12 - (6 if i % 2 == 0 else 2) - (i == 4) * 3) for i, (x, y) in enumerate(ridge_pts)][::-1])
        crest = A.smooth(crest, 0.2, 20)
        crest = A.union(crest, A.inter(A.grow(h.skull, 3.0), A.poly(ridge_pts + [(h.front, h.top - 5), (h.back, h.top - 5)])))
        st = [[(x, y - 2), (x + 1, y - 12)] for x, y in ridge_pts]
        cr = hair_paint(A.smooth(crest, 0.3, 18), st, bevel=2.6, seed=23)
        front = A.over(cr, side_img)
        # neon stripe along the crest
        stripe = A.line([(x + 0.6, y - 5) for x, y in ridge_pts], 0.9)
        glow = A.over(A.tint_layer(A.blur(stripe, 1.4), (255, 255, 255), 0.7), A.tint_layer(stripe, (255, 255, 255), 1.0))
        glow = A.over(A.tint_layer(A.sub(stripe, stripe * 0), (255, 255, 255), 1.0), A.tint_layer(A.blur(stripe, 1.6), (255, 255, 255), 0.6))
    elif style == "fantasy":
        m = cap(h, 4.2, off=-1.0)
        # swept-back pointed locks over the brow
        sw = A.empty()
        for i in range(6):
            x0 = h.front - 4 - i * 6.0; y0 = h.brow_y - 12 + i * 0.6
            tip = (x0 - 22 - i * 1.5, y0 - 6 - i * 1.4)
            A.poly([(x0 + 4, y0 + 2), tip, (x0 - 3, y0 - 5)], sw)
        m = A.smooth(A.union(m, A.inter(sw, A.grow(h.skull, 14))), 0.5, 16)
        ends = [(h.back + 2 + i * 4.8, h.top + 10 + abs(i - 3) * 1.2) for i in range(10)]
        front = hair_paint(m, flow_strands(h, (h.front - 2, h.brow_y - 12), ends, -4.0, rng_seed=24), bevel=3.6, seed=24)
        bk = A.empty(); stt = []
        for i in range(5):
            x0 = h.back + 28 - i * 6; y0 = h.top + 6 + i * 6
            ctrl = [(x0, y0), (x0 - 18 - i * 3, y0 + 8), (x0 - 28 - i * 3, y0 + 26 + i * 4), (x0 - 22 - i * 3, 98)]
            ctrl = [(max(x, 0), min(y, 99)) for x, y in ctrl]
            bk = A.union(bk, lock(ctrl, 10 - i * 0.9, 1.6))
            stt.append(ctrl)
        back = hair_paint(A.smooth(bk, 0.6), [c for c in stt], bevel=3.6, seed=25, ambient=0.44)
    else:
        raise ValueError(style)
    return {"front": front, "back": back, "glow": glow}


# ------------------------------------------------------------------------------ facial hair
def _lower_face(h, y0, x0_off=8):
    """Region of the lower face in front of the ear and below y0."""
    return A.inter(A.half_plane((0, y0), (108, y0), below=True), A.half_plane((h.ear[0] + x0_off, 0), (h.ear[0] + x0_off, 100), below=False) * 0 + 1 - A.half_plane((h.ear[0] + x0_off, 0), (h.ear[0] + x0_off, 100), below=False))


def make_facial(h, style):
    if style == "none":
        return None
    sk = h.skull
    mouth = h.mouth
    mouth_hole = A.ellipse(h.mouth[0] + 1, h.mouth_y + 0.2, 6.8, 2.4, -4)
    ex = h.ear[0]
    not_back = A.half_plane((ex + 5, 0), (ex + 5, 100), below=False)     # the side of the ear that faces front (vertical line: below=False = right)
    below_nose = A.half_plane((0, h.nose_y + 4), (108, h.nose_y + 4), below=True)
    below_mouth = A.half_plane((0, h.mouth_y + 1.5), (108, h.mouth_y + 1.5), below=True)
    neck_line = A.half_plane((0, h.chin_y + 10), (108, h.chin_y + 10), below=False)
    rng = np.random.default_rng(7)

    def finish(m, strands=None, bevel=2.6, seed=0, alpha=1.0, amb=0.5):
        m = A.smooth(A.sub(m, mouth_hole), 0.5)
        tex = A.strand_texture(strands, 0.38, seed) if strands else None
        img = A.paint(m, (255, 255, 255), "hair", bevel=bevel, outline=0.85, ambient=amb, texture=tex, rim=0.15, alpha_scale=alpha)
        return img

    def chin_strands(n=9, y_lo=None, spread=1.0):
        y_lo = y_lo or h.chin_y
        ends = [(h.mouth_front - 18 + i * 3.4, y_lo + 1 - abs(i - 4) * 0.5) for i in range(n)]
        org = (h.mouth[0] + 2, h.nose_y + 8)
        return flow_strands(h, org, ends, -2.0, rng_seed=31, wob=0.5)

    if style == "stubble":
        zone = A.inter(A.inter(A.grow(sk, 0.4), below_nose), not_back)
        zone = A.sub(zone, A.ellipse(h.mouth[0] + 1, h.mouth_y + 0.2, 7.5, 3.2))
        zone = A.inter(zone, A.half_plane((ex + 14, h.eye_y + 10), (h.front - 14, h.nose_y + 3), below=True) * 0 + 1)
        zone = A.inter(zone, A.poly([(ex + 8, h.eye_y + 6), (h.front + 2, h.nose_y + 3), (h.front + 6, 120), (ex - 4, 120)]))
        dots = (A.noise(40, 0.42) > 0.33).astype(np.float32)
        dots = A.blur(dots, 0.18)
        m = A.inter(zone, np.clip(dots * 1.6, 0, 1))
        img = A.tint_layer(m, (255, 255, 255), 0.9)
        shade = A.tint_layer(A.inter(A.shift(m, 0.35, 0.45), zone), (30, 30, 40), 0.35)
        return {"front": A.over(img, shade)}
    cheek_line = [(ex + 4, h.eye_y + 6), (ex + 14, h.mouth_y - 5), (h.front - 32, h.nose_y + 3), (h.mouth[0] - 7, h.nose_y + 2.5)]
    if style in ("short", "full", "long", "stache_beard"):
        t = {"short": 1.9, "full": 3.3, "long": 3.6, "stache_beard": 2.6}[style]
        drop = {"short": 0.0, "full": 4.0, "long": 11.0, "stache_beard": 2.0}[style]
        boundary = A.curve_pts(cheek_line + [(h.mouth[0] - 7, h.mouth_y - 1.8), (h.mouth[0] + 8, h.mouth_y - 3.0), (h.front - 4, h.mouth_y - 2.0)], 12)
        zone = A.poly(boundary + [(h.front + 30, 140), (ex - 6, 140)])
        beard = A.inter(A.grow(sk, t), zone)
        if drop > 0:
            ext = A.poly([(h.mouth[0] - 28, h.chin_y - 14), (h.front - 2, h.chin_y - 10), (h.front - 12, h.chin_y + drop), (h.mouth[0] - 16, h.chin_y + drop + 1), (ex + 12, h.chin_y - 12)])
            beard = A.union(beard, A.inter(ext, neck_line))
        if style == "long":
            ln = A.poly([(h.mouth[0] - 22, h.chin_y - 8), (h.front - 8, h.chin_y - 6), (h.front - 14, min(99, h.chin_y + 12)), (h.mouth[0] - 6, 99), (h.mouth[0] - 20, min(99, h.chin_y + 13))])
            beard = A.union(beard, ln)
        # moustache over the lip
        stache = A.smooth(A.union(A.ellipse(h.mouth[0] - 2.5, h.mouth_y - 3.0, 6.6, 2.7, -10), A.ellipse(h.mouth[0] + 6.5, h.mouth_y - 3.0, 5.2, 2.4, 14)), 0.5)
        beard = A.union(beard, stache)
        if style == "stache_beard":
            beard = A.union(beard, A.ellipse(h.mouth[0] + 6, h.mouth_y - 3, 9.5, 3.4, 8))
        beard = A.smooth(beard, 0.9)
        # the lip stays open: a smile line inside the beard
        img = finish(beard, chin_strands(), bevel=3.2, seed=32)
        return {"front": img}
    if style == "goatee":
        patch = A.union(A.ellipse(h.mouth[0] + 6, h.chin_y - 7.5, 9.5, 7.5), A.ellipse(h.mouth[0] + 8, h.mouth_y + 4.5, 6.5, 3.2))
        ring = A.sub(A.ellipse(h.mouth[0] + 1.5, h.mouth_y - 0.4, 10.6, 5.6), A.ellipse(h.mouth[0] + 1.5, h.mouth_y + 0.2, 6.8, 2.4))
        m = A.union(patch, ring)
        m = A.inter(m, A.grow(sk, 3.2))
        return {"front": finish(m, chin_strands(7), bevel=2.6, seed=33)}
    if style in ("mustache", "handlebar"):
        base = A.union(A.ellipse(h.mouth[0] - 2.5, h.mouth_y - 3.4, 7.0, 3.0, -12), A.ellipse(h.mouth[0] + 7.2, h.mouth_y - 3.4, 6.2, 2.8, 16))
        if style == "handlebar":
            tipl = A.line([(h.mouth[0] - 8, h.mouth_y - 3.2), (h.mouth[0] - 13, h.mouth_y - 3.6), (h.mouth[0] - 15.5, h.mouth_y - 6.4)], 1.9)
            tipr = A.line([(h.mouth[0] + 12, h.mouth_y - 3.0), (h.mouth[0] + 16.5, h.mouth_y - 3.2), (h.mouth[0] + 18, h.mouth_y - 6.2)], 1.8)
            base = A.union(base, A.union(tipl, tipr))
        st = [[(h.mouth[0] + 2, h.mouth_y - 5), (h.mouth[0] - 6 + i * 3, h.mouth_y - 2.2)] for i in range(5)]
        return {"front": finish(base, st, bevel=2.0, seed=34)}
    if style == "chinstrap":
        jaw = A.sub(A.grow(sk, 2.4), A.grow(sk, -1.2))
        zone = A.poly([(ex + 8, h.eye_y + 6), (ex + 20, h.mouth_y + 4), (h.front - 24, h.chin_y - 8), (h.front + 6, h.chin_y - 4), (h.front + 12, 140), (ex - 6, 140)])
        m = A.inter(A.inter(A.grow(sk, 2.4), zone), A.sub(A.empty() + 1, A.ellipse(h.mouth[0] + 4, h.chin_y - 9, 14, 12)))
        m = A.inter(m, neck_line)
        return {"front": finish(m, chin_strands(), bevel=2.2, seed=35)}
    if style == "mutton":
        sb = A.poly([(ex + 3, h.eye_y - 4), (ex + 12, h.eye_y - 3), (ex + 24, h.mouth_y - 3), (h.mouth[0] - 6, h.mouth_y + 1), (h.mouth[0] - 6, h.mouth_y + 5), (ex + 22, h.chin_y - 8), (ex + 8, h.chin_y - 14), (ex + 2, h.eye_y + 8)])
        m = A.inter(A.grow(sk, 3.4), A.smooth(sb, 1.4))
        st = [[(ex + 8, h.eye_y), (ex + 14 + i * 3, h.mouth_y + 4)] for i in range(6)]
        stache = A.union(A.ellipse(h.mouth[0] - 2.5, h.mouth_y - 3.2, 6.8, 2.8, -10), A.ellipse(h.mouth[0] + 6.5, h.mouth_y - 3.2, 5.4, 2.5, 14))
        return {"front": finish(A.union(m, stache), st, bevel=2.8, seed=36)}
    raise ValueError(style)
