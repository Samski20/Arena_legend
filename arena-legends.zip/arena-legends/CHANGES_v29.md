# v25 changes
- NEW art/scripts/zoom_config.gd  (per-weapon zoom ranges, dual-wield rules; edit numbers here)
- NEW art/scripts/camera_zoom.gd  (replaces ScopeZoom: zoom, per-weapon memory, aim framing)
- player.gd: CameraZoom.attach, semi-auto trigger logic, FIRE-button shooting, respawn = starting guns + zoom reset
- touch_controls.gd: right stick: aim inside the inner circle, drag out to shoot, ZOOM +/- buttons, focus-loss release
- weapon_data.gd: `automatic` tickbox (off = semi-auto) - set OFF on Desert Eagle, Colt Python, Barrett, Double Barrel, SPAS-12
- game_settings.gd / settings_menu.gd: "Start with Maximum Weapon Zoom" (default OFF, saved)
- match_manager.gd: tap / click / Enter / controller A restarts; arena_controller.gd + map_registry.gd: restart stays on the same map
- zoom: BASE_VIEW = 4.0 (your original camera is 4x, so 2x is much closer)
- v26: every gun fires while held again (the `automatic` tickbox stays, default ON, if you want a semi-auto gun later)
- v26: held guns drawn bigger (player_rig.gd gun_scale: GUN_BOOST / GUN_VIEW_MIN / GUN_VIEW_MAX)
- v27: AK-47 and M4A1 zoom 2.5x-4.0x (default 3.0x)
- v28: red Laser Sight on the player's gun(s), Settings > Laser Sight (ON by default)
- v29: thinner bullets (bullet.tscn sprite scale), casings stay ~14 s then fade, empty magazines drop on reload with a shape per gun (WeaponData magazine_kind)
- v30: all 11 guns redrawn bolder (dark outline, brighter metal, rails, rivets, grip stipple, sight dots, wood grain, brass/orange accents); held guns drawn bigger (GUN_BOOST 1.5)
- v30: every gun has a far range (pistols 1400-1900, SMGs 1300-1500, rifles/MG 1800-2000, shotguns 1000-1100, sniper 3500) and higher bullet speed
- v30: NEW burst fire in WeaponData (burst_count, burst_pause): M4A1, MP5 and Glock 18 fire 3-round bursts. Set burst_count = 0 to turn it off
- v30: natural bullet colours (warm brass/orange tracers, red-orange tracer on the M249); shotgun pellets are short sparks
- v31: COMPLETE FIRING SYSTEM. WeaponData now lists the firing modes each gun really has (fire_modes: semi / auto / burst / single), default_fire_mode, burst_count, burst_interval, burst_pause, semi_fire_rate, projectile_kind, blast_radius, sound_style
- v31: NEW fire_state.gd + one shared trigger routine in player.gd (_tick_trigger) for both hands and every input (touch, mouse, controller):
    SEMI/SINGLE = one shot per press; AUTO = fires while held; BURST = repeating burst - pause - burst while held, release stops NEW bursts, a running burst finishes, never fires rounds that don't exist
    reload / stun / death / weapon swap / mode change drop a burst on the spot
- v31: FIRE MODE button (touch: above the weapon box, only for guns with 2+ modes; PC: B; controller: left shoulder). Ignored while the trigger is held. Each gun remembers its mode during a life. Ammo label shows [MODE]
- v31: NEW guns: Thompson (auto, 50-rd drum), M16A4 (semi + 3-round burst), SVD Dragunov (semi), RPG-7 (single-shot rocket, area damage + knockback, no casings). Art + .tres + catalog entries
- v31: modes: Desert Eagle semi, Colt Python semi, Uzi auto(+semi), MP5 semi+auto, M249 auto. The v30 burst on M4A1 / MP5 / Glock was removed (burst now belongs to the M16A4)
- v31: gun sounds made in code (gun_audio.gd): one sound per shot, per-style (pistol, magnum, revolver, SMG, Thompson, rifle, DMR, MG, shotgun, sniper, rocket, explosion), 4 players per shooter so auto fire never stacks
- v31: rocket.gd (RPG projectile with smoke trail; explosion reuses the grenade blast code)
