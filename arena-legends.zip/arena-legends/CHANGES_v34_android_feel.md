# v34: Android feel pass

**New files**
- `art/scripts/ui_theme.gd` (UITheme): shared colours (one accent: Android green), Material-style button / panel / glass styles, haptics, fade / pop-in motion, safe-area insets.
- `art/scripts/ui_boot.gd` (autoload `UIBoot`): every Button gets a press-down scale and a short haptic tick; owns the soft screen vignette (Graphics Quality MEDIUM / HIGH only).
- `art/ui/arena_theme.tres` + `art/fonts/Inter-*.otf`: project-wide default theme and font (set in Project Settings > GUI > Theme). Inter is SIL OFL.
- `art/scripts/damage_number.gd`: floating damage numbers (bigger / red on a kill) over whatever you hit.
- `art/ui/icon_*.png`, `splash.png`: adaptive launcher icon (+ monochrome for themed icons) and boot splash. Wired into the Android export preset.

**Changed**
- Menus (pause, settings, LAN lobby): big rounded corners, tonal buttons, one green primary action per screen, filled text fields, round colour dots, on/off settings as green chips, screens fade in, pause panel pops in.
- HUD: one glass card with pill meters (moved below MENU), red screen-edge flash when hit, slow red heartbeat glow under 30% health.
- Touch controls: drop shadows, glowing knob while held, press-down shrink, thinner rings, Inter font.
- Haptics (Settings > Haptics, on by default): fire tick, hit buzz, kill pulse, death. `permissions/vibrate` enabled in the Android preset.
- Not changed: gameplay, networking, maps, weapon stats.
