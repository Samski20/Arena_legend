# v35 - main menu, game modes, match config (UNTESTED: written without a Godot binary)

New: art/scripts/match/ (match_config, match_store, match_presets, match_session, match_setup, main_menu, menu_kit, menu_scroll)
Hooks: arena_controller, match_manager, player, bullet, throwable, weapon_pickup, throwable_spawner, throwable_catalog, bot, bot_difficulty, out_of_bounds, map_registry.
NOT DONE: LAN host settings (the task text was cut off at "Host-configurable settings"), jetpack character art on the menu, bot aggression / weapon-pickup options.
First thing to do: open in Godot 4.7, check the Output panel for parse errors, then play each mode.

## RPG + body-part damage patch (also untested)
player.gd (_tick_trigger: launchers repeat while held), rocket.gd (direct hit = kill), throwable.gd (skip_bodies), bullet.gd (zone multiplier), new art/scripts/hit_zones.gd (head x2.0, torso x1.0, legs x0.6).

## Customization + cosmetics (untested)
New: art/scripts/look/ (appearance_catalog, cosmetic_catalog, appearance, appearance_store, customize_menu), tools/gen_character_art.py + 25 generated parts in art/player/.
Changed: player_rig.gd (new layers + apply_appearance), main_menu.gd (CUSTOMIZE), arena_controller.gd, net_manager.gd (PROTOCOL 2, _c_set_app, apply_player_look), net_match.gd, remote_player.gd.

## Cosmetic overhaul: full-anatomy cosmetics (untested)
New: tools/gen_cosmetic_art.py + art/cosmetics/{insectoid,lumen,guardian}/, art/scripts/look/{cosmetic_fx,wings_fx,levitate_fx,cape_fx}.gd
Changed: player_rig.gd (body slots, apply_anatomy, hue-shift variants, FX hook, lean), appearance*.gd, cosmetic_catalog.gd (insectoid_drone, lumen_seer, night_guardian), customize_menu.gd (5 tabs), net code carries the variant.
