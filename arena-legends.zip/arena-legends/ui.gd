extends CanvasLayer
 
