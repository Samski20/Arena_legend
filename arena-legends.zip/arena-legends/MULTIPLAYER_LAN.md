# Arena Legends – LAN multiplayer (same Wi-Fi only)

Godot 4.7, high-level multiplayer API + ENet. No internet service is used anywhere.

## How to play
**Host:** MULTIPLAYER (LAN / same Wi-Fi) → HOST GAME → room name, map, max players (2–8, default 4), kill limit → CREATE LOBBY.
The lobby shows your local IPv4 address and port. Press START MATCH when everyone is in.
**Join:** MULTIPLAYER → JOIN GAME. Hosts on the same network appear in the list automatically; tap one to join.
If none appear, type the host's IP (shown in its lobby) and port (default 24680) and press JOIN.
Only the host can change the map, max players and kill limit and start the match. Everyone can change name and appearance.
In a match: Esc / MENU → LEAVE MATCH. When the kill limit is reached the scoreboard shows, then everyone returns to the lobby (connection kept) so you can play again.

## Lobby options (v33.1)
Host (HOST GAME screen and live in the lobby until START): **map**, max players, kills to win, **time limit** (No limit / 2 / 3 / 5 / 10 / 15 min), **weapon spawns** (Rare 0.5x / Normal / Frequent 2x / Plenty 3x: how fast map guns come back) and **throwables** (Off / Rare / Normal / Frequent / Plenty: how often they appear). Clients see these but cannot change them.
When time runs out the player with the most kills wins; a tie for first is a draw. The clock is shown next to the score and follows the host's clock.
Every player can set their **name** (unique; duplicates get a number) and pick one of 6 **colours** in the lobby. Colours are unique per player: a taken one is greyed out and the host refuses it. The colour appears on the character, in the lobby list and on the name above their head in the match.

## Ports / firewall
* UDP **24680** – game traffic (host listens).
* UDP **24681** (host) / **24682** (clients) – LAN discovery broadcasts.
Allow the game through the host computer's firewall for private networks. Wi-Fi routers with "AP/client isolation" (many guest networks, some school/office Wi-Fi) block device-to-device traffic: nothing will connect there. If discovery fails but the manual IP works, broadcasts are being blocked.

## Architecture
* `Net` (autoload, `art/scripts/net/net_manager.gd`): connection state, roster, lobby, settings, match phases (LOBBY → LOADING → COUNTDOWN → PLAYING → ENDED), join validation (protocol version, full, match running), timeouts, clean disconnect.
* `Net/Game` (`net_match.gd`): in-match replication and all host-side validation.
* `Net/Discovery` (`lan_discovery.gd`): UDP broadcast beacons / queries.
* `RemotePlayer` (`remote_player.gd`): the stand-in body for every other player (interpolated ~0.1 s behind).
* `LanMenu` (`lan_menu.gd`): responsive lobby UI.
* `NetSpawn` (`net_spawn.gd`): ground-snapping spawn resolver that uses the real player capsule.

Model: each player moves its own character (smooth controls, jetpack-only flight unchanged) and sends state at 20 Hz (unreliable-ordered). The host relays it. Everything that affects another player is decided by the host:
firing (validated: rate limit, muzzle near the body, weapon must match the host's record), bullets/pellets/rockets (real ones exist only on the host; clients draw cosmetic copies that never deal damage), damage and health, death/kill credit/score, respawn place and timing, weapon pickups, drops, ammo grabs, throwables inventory/throw/explosion/zones/portal teleports, and the match clock/kill limit. Clients receive results (`_s_hit`, periodic health sync) and cannot claim a kill or damage.

## New scripts
`art/scripts/net/`: net_manager.gd, net_match.gd, remote_player.gd, lan_discovery.gd, lan_menu.gd, net_spawn.gd.  `tests/`: lan_test.gd, run_lan_test.sh, probe_spawns.gd.
## Modified scripts
project.godot (autoload `Net`), player.gd, bullet.gd, art/scripts/{arena_controller, match_manager, rocket, throwable, throwable_zone, throwable_pickup, throwable_spawner, weapon_pickup}.gd. Offline play keeps its original code paths. A backup of the original project is `arena-legends-backup-v32`.

## Two-instance test (one computer)
Editor/desktop: run the game twice. Instance A: HOST GAME → CREATE LOBBY. Instance B: JOIN GAME → it should list the room (or enter 127.0.0.1 / 24680). Start from A.
Headless automated: `tests/run_lan_test.sh <godot-binary> mcgpkd` (m movement, c combat/kill/respawn, g grenades, p pickups, k kill-limit→lobby, d disconnect, r discovery, o lobby options/time limit). Env `LAN_MAP=cavern_isles` picks the map. Prints TEST PASS / TEST FAIL.

## What was tested (headless Godot 4.7, two instances on one machine, localhost)
Pass: lobby name/colour changes (unique colours enforced), time limit / spawn-rate settings synced to the client, throwables Off, shorter weapon respawn timers, match ending when time runs out (on both sides), host/join, discovery (room name), lobby, load/countdown/start, movement sync, client shooting → host damage → kill credit → respawn, host grenade damage and cosmetic copies, client throw request, weapon pickup via host, kill-limit end → return to lobby, client leave / host close, offline start unchanged. Combat/grenade/pickup/end/disconnect run on Abandoned Station; Cavern Isles passed the full run except a movement check that was blocked by the map edge at that spawn (positions matched on both sides).
**Not tested:** how the new lobby controls look on a screen (headless only; they use the same layout code as the rest of the menu), the effect of the Frequent/Plenty throwable rates on gameplay balance, real Wi-Fi/two physical devices, Android/touch in a match, more than 2 players (the code supports up to 8, no claim made), packet loss/latency, every throwable type individually (only grenade exercised; the others share the same host-authoritative path), portal teleport in a live two-player match, visual look/feel (headless only), firewall/AP isolation behaviour.

## Limitations
* The project has **no power-ups** (invisibility, decoy etc. do not exist), so none were added.
* Maps are Abandoned Station and Cavern Isles (there is no Labyrinth Outpost).
* Bots are disabled in network matches.
* No late join or mid-match reconnect: a dropped player can rejoin once the host is back in the lobby. No host migration (host leaving ends the match).
* Ammo counts are tracked on each player's own device; the host enforces fire rate, weapon ownership and pickup distance, not exact magazine counts.
* No lag compensation; hits are decided on the host's world, so high latency is felt by shooters.
* Spawn points for network matches are listed in `arena_controller.gd` (`NET_SPAWNS`) and snapped to the ground.

## v33.2 – hotspot play + mobile scrolling
**Mini Militia style:** one player turns on the phone hotspot, everyone else connects to that hotspot's Wi-Fi. Host: MULTIPLAYER → HOST GAME → CREATE LOBBY. Others: MULTIPLAYER → JOIN GAME → tap the game in the list. No IP typing. (Turn mobile data OFF on joining phones if the list stays empty: some phones send traffic over mobile data when the Wi-Fi has no internet.)
Discovery now also sends direct (unicast) queries to the usual hotspot addresses (.1, .2, .254, iOS 172.20.10.x) and sweeps the whole local /24, so it works even when the hotspot swallows broadcast packets. The manual IP box is still there as a last resort.
Android export now has INTERNET, ACCESS_NETWORK_STATE, ACCESS_WIFI_STATE and CHANGE_WIFI_MULTICAST_STATE enabled (they were off, which blocks all networking in an installed APK).
Touch scrolling: the lobby/host/join screens now scroll with a finger drag (same method as the Settings menu) and a scroll drag no longer presses the button it started on.

## v33.3 – weapon ranges (Mini Militia style, in pixels; edit `max_range` in each weapon's .tres)
SPAS-12 380 · Double Barrel 320 · Glock 650 · Desert Eagle 800 · Colt Python 850 · Uzi 600 · MP5 750 · Thompson 700 · AK-47 1100 · M4A1 1100 · M16A4 1300 · M249 1200 · SVD 2200 · Barrett 2800 · RPG-7 1500.
Shorter ranges also mean fewer bullets alive at once (cheaper for weak phones).
