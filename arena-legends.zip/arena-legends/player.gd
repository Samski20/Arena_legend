extends CharacterBody2D

signal died(victim, killer)

# =========================
# CHARACTER + WEAPON LOOK
# =========================
@export var starting_weapon: WeaponData
@onready var visuals: PlayerRig = $Visuals
@export var show_hud := true      # health/fuel meters + weapon icons (the HUD builds itself)
var hud: PlayerHUD

# =========================
# HEALTH SYSTEM
# =========================
@export var max_health := 100
var health := max_health
@onready var health_bar := $HealthBar

@export var knockback_force := 250.0
var is_dead := false

# ---- offline match rules (set by apply_match_rules; the defaults below ARE the normal game) ----
var rule_gravity_mult := 1.0
var rule_speed_mult := 1.0
var rule_infinite_fuel := false
var rule_infinite_grenades := false
var rule_unlimited_ammo := false
var rule_instant_reload := false
var rule_infinite_health := false
var rule_regen := true
var rule_damage_mult := 1.0
var _match_throwables: Array = []          # [[throwable id, quantity], ...] from a match loadout (empty = default starter bombs)

# health regeneration (like Mini Militia: heals slowly after a few seconds without being hit)
@export var regen_delay := 3.0       # seconds without damage before healing starts
@export var regen_rate := 12.0       # health per second while healing
var _time_since_hit := 0.0
var _regen_accum := 0.0
var last_attacker: Node = null   # who hit us last (set by the bullet), for kill credit

# =========================
# NORMAL MOVEMENT
# =========================
@export var speed := 205.0           # walking speed (was 300, felt too fast)
@export var jump_force := 500.0
@export var gravity := 900.0

# =========================
# CROUCH + BLOCK
# =========================
@export var crouch_speed_mult := 0.5
@export var block_damage_mult := 0.2    # blocked hits do 20% damage

var crouching := false
var blocking := false
var aim_dir := Vector2.RIGHT      # where the shield points (updated every frame)

@onready var col: CollisionShape2D = $CollisionShape2D
var _col_pos := Vector2.ZERO
var _col_scale := Vector2.ONE
var _col_h := 0.0

# =========================
# JETPACK
# =========================
@export var thrust_power := 1100.0
@export var max_fuel := 100.0
@export var fuel_burn_rate := 5.0      # seconds of flight = max_fuel / burn rate (100 / 5 = 20 s)
@export var fuel_regen_rate := 30.0
@export var fuel_regen_delay := 1.0   # seconds after thrusting before fuel refills in the air (stops tap-flying forever)

@export var max_jetpack_speed := 400.0
@export var hover_speed := -12.0     # almost no drift while hovering, so you can aim steadily
@export var jet_move_speed := 285.0   # sideways speed while flying
@export var jet_accel := 780.0        # how quickly flying speed changes (lower = floaty, Mini Militia-like glide)

var fuel := 100.0
var _regen_wait := 0.0
var jetpack_active := false      # true while thrusting (drives the flames)
var jetpack_toggled := false     # hover mode switched on by the jetpack button

# =========================
# AIR ACROBATICS (Mini Militia style flips while flying)
# =========================
# Double-tap left/right in the air (or press Shift) to do a flip with a quick burst of speed.
# While flying the body also leans into the direction you move (that part is in player_rig.gd).
@export var double_tap_flip := false        # double-tap a direction to flip
@export var flip_fuel_cost := 9.0           # fuel used per flip
@export var flip_dash_speed := 620.0        # sideways burst at the start of the flip
@export var flip_time := 0.55               # how long one flip takes
@export var flip_cooldown := 0.75
@export var double_tap_window := 0.26       # seconds between the two taps
var _flip_left := 0.0                       # time left in the current flip (0 = not flipping)
var _flip_cd := 0.0
var _flip_dir := 1.0                        # direction of the current flip (replicated to other players)
var _tap_time := {"move_left": -10.0, "move_right": -10.0}

# =========================
# TOUCH CONTROLS (Mini Militia style)
# =========================
const TOUCH_AIM_DISTANCE := 330.0
@export var touch_fly_start := 0.5
var touch: TouchControls
var _touch_flying := false
var _touch_fly_lock := false
var _touch_dir_prev := 0

# =========================
# SHOOTING
# =========================
@export var bullet_scene: PackedScene

var weapon: WeaponData          # the weapon currently held
var _fire_cooldown := 0.0
var _fs_main := FireState.new()            # firing mode / burst / trigger state of the main hand
var _fs_off := FireState.new()             # ... and of the off hand (dual wield)
# On a touchscreen there is no trigger to release: you hold the drag. With this ON, SEMI guns keep firing one shot
# at a time (at their semi cadence) while you hold the drag. Set false for strict one-shot-per-drag on touch.
const TOUCH_SEMI_REPEAT := true
var _mode_store := {}                      # WeaponData -> the firing mode it was last set to (a gun keeps its mode while you swap)
var _spawn_loadout: Array[WeaponData] = []   # the guns you start (and respawn) with

# weapon switching (E key). Drag rifle.tres, shotgun.tres... into this array in the Inspector.
@export var weapons: Array[WeaponData] = []
var weapon_index := 0
@export var max_weapons := 2     # how many weapons you can carry (pickups replace the one in hand when full)
var _reload_id := 0             # lets a swapped-out reload cancel itself
var _ammo_store := {}           # remembers each weapon's ammo while you switch
var _last_pickup_frame := -1    # stops two overlapping pickups both equipping on one key press

# ammo
var ammo := 0                   # bullets in the magazine
var reserve := 0                # spare bullets
var reloading := false
var ammo_label: Label

# dual wield (Mini Militia style): walk up to a one-handed gun lying on the floor while holding a one-handed gun,
# then press DUAL WIELD (Q / touch button) and it goes in your other hand. Pick Up equips it normally instead.
var dual := false
var off_weapon: WeaponData       # the gun in the off hand
var off_ammo := 0
var off_reserve := 0
var off_reloading := false
var _off_reload_id := 0
var _off_cooldown := 0.0


# =========================
# THROWABLES (their own slot, separate from the guns)
# =========================
@export var throwable_loadout: Array[ThrowableData] = []   # empty = grenade + knockback bomb for testing
@export var use_test_loadout := false     # true = always start with every throwable (for testing only; pickups now exist)
@export var starting_throwables := PackedStringArray(["grenade"])   # what you spawn with (ids from ThrowableCatalog)
@export var starting_throwable_count := 2
var throwable_index := 0
var _throw_counts := {}          # how many of each type you're carrying
var _throw_cooldown := 0.0

# =========================
# STATUS EFFECTS (burn, poison, cryo, slow...) applied by throwable zones
# =========================
var _status := {}                # type -> {"t": seconds left, "power": strength, "src": who caused it}
var _dot_accum := {}             # leftover fractions of damage-over-time


func _ready():
	add_to_group("player")
	floor_snap_length = 14.0          # stick to slopes instead of skipping down them
	floor_max_angle = deg_to_rad(72.0)   # every slope is walkable; only near-vertical faces act as walls
	floor_stop_on_slope = true
	floor_block_on_wall = false
	# a gently following camera keeps your aim steady while you fly and shoot
	var cam := get_node_or_null("Camera2D") as Camera2D
	if cam != null:
		cam.position_smoothing_enabled = true
		cam.position_smoothing_speed = 7.0
	floor_constant_speed = true       # same walking speed uphill and downhill
	# fall back to the rifle if no weapon was assigned in the Inspector
	if starting_weapon == null:
		starting_weapon = load("res://art/scripts/rifle.tres")
	if weapons.is_empty():
		weapons.append(starting_weapon)
	weapon = weapons[0]
	visuals.equip_weapon(weapon)
	_spawn_loadout.assign(weapons)               # a new life starts with these guns
	LaserSight.attach(self)                     # red laser aid (Settings > Laser Sight)
	CameraZoom.attach(self)                     # per-weapon camera zoom (mouse wheel, - / =, touch ZOOM buttons)

	# ammo counter on the HUD (a Label named AmmoLabel anywhere in the scene)
	ammo_label = get_tree().current_scene.find_child("AmmoLabel", true, false) as Label
	_setup_ammo()

	# HUD: meters + weapon icons
	if show_hud:
		hud = PlayerHUD.new()
		add_child(hud)
	_refresh_loadout()
	_setup_throwables()
	_setup_touch()
	_setup_fire_inputs()

	# remember the hitbox so crouching can shrink it and restore it
	_col_pos = col.position
	_col_scale = col.scale
	_col_h = _shape_height(col.shape)

	# Load the bullet scene automatically if it isn't set in the Inspector
	if not bullet_scene:
		bullet_scene = preload("res://bullet.tscn")


func _physics_process(delta):

	# ----- Health regeneration -----
	_time_since_hit += delta
	if rule_regen and _time_since_hit >= regen_delay and health < max_health and not _net_client():
		_regen_accum += regen_rate * delta
		if _regen_accum >= 1.0:
			var gain := int(_regen_accum)
			_regen_accum -= gain
			health = mini(health + gain, max_health)
			health_bar.value = health

	_tick_statuses(delta)
	_apply_net_pull(delta)

	# ----- Air acrobatics (flip timers + input) -----
	_flip_cd -= delta
	_flip_left = maxf(0.0, _flip_left - delta)
	_check_flip_input()

	# ----- Aim (mouse on PC, right stick on touch) -----
	var shoulder: Vector2 = visuals.aim_pivot.global_position
	var mouse_pos: Vector2 = _aim_point(shoulder)
	var aim_direction: Vector2 = (mouse_pos - shoulder).normalized()
	aim_dir = aim_direction

	# (blocking happens automatically while crouching, see the crouch section below)

	# ----- Reload -----
	if _just("reload"):
		start_reload()
		if dual:
			start_off_reload()

	# ----- Switch weapon (E) -----
	if _just("switch_weapon"):
		switch_weapon(weapon_index + 1)

	# ----- Firing mode toggle (B / controller shoulder / touch FIRE MODE button) -----
	if _just("fire_mode"):
		toggle_fire_mode()

	# ----- Shoot: one shared trigger logic for every input (touch, mouse, controller) and both hands -----
	_fire_cooldown -= delta
	_off_cooldown -= delta
	var shooting := _shoot_held() and not is_stunned() and not is_dead      # a stunned player can't shoot
	var interrupted := is_stunned() or is_dead                              # drops any burst that was under way
	_tick_trigger(0, _bound_state(_fs_main, weapon), shooting, interrupted, aim_direction)
	if dual:
		_tick_trigger(1, _bound_state(_fs_off, off_weapon), shooting, interrupted, aim_direction)
	elif _fs_off.weapon != null:
		_fs_off.bind(null)                                                  # off hand put away: forget its burst

	# ----- Throwables: G throws toward the mouse, T switches type -----
	_throw_cooldown -= delta
	if _just("switch_throwable"):
		switch_throwable()
	if _just("throw") and _throw_cooldown <= 0.0 and not is_stunned():
		throw_throwable(aim_direction)

	# ----- Jetpack: button toggles hover mode, pushing up flies -----
	if _just("jetpack") and fuel > 0 and not _flight_blocked():
		jetpack_toggled = not jetpack_toggled

	var fly_up := Input.get_action_strength("move_up") > 0.4
	_update_touch_flight()

	if fuel <= 0:
		fuel = 0
		jetpack_toggled = false
		if _touch_flying:
			_touch_flying = false
			_touch_fly_lock = true

	if _flight_blocked():
		jetpack_toggled = false                 # EMP / flight disruptor: the jetpack cuts out
	jetpack_active = (jetpack_toggled or fly_up or _touch_flying or _flip_left > 0.0) and fuel > 0 and not _flight_blocked()

	# ----- Crouch (hold down, on the ground only) -----
	crouching = (Input.is_action_pressed("move_down") or _touch_crouch()) and is_on_floor() and not jetpack_active and not is_stunned()
	_set_crouch_collision(crouching)
	blocking = crouching            # crouching raises the shield, and you can still shoot

	# ----- Left / right movement -----
	var direction := _move_axis()
	# (while flying, the jetpack section below controls both axes)
	if not jetpack_active:
		var move_speed := speed * _speed_mult()
		if crouching:
			move_speed *= crouch_speed_mult
		if is_stunned():
			# stunned: no steering. The blast's push carries you and fades with friction (less in the air)
			velocity.x = move_toward(velocity.x, 0.0, (STUN_GROUND_FRICTION if is_on_floor() else STUN_AIR_DRAG) * delta)
		else:
			velocity.x = move_toward(velocity.x, direction * move_speed, speed * 10.0 * delta)

	# ----- Jetpack / gravity -----
	if jetpack_active:
		if not rule_infinite_fuel:
			fuel -= fuel_burn_rate * delta
		fuel = max(fuel, 0)
		_regen_wait = fuel_regen_delay

		# Free flight: keyboard or touch stick steers in any direction; no input = hover
		var fly := Input.get_vector("move_left", "move_right", "move_up", "move_down")
		var analog := false
		if fly == Vector2.ZERO and _touch_on():
			fly = (touch.move_vec * 1.15).limit_length(1.0)
			analog = true
		var jet_speed := jet_move_speed * _speed_mult()
		var target_x := fly.x * jet_speed
		var target_y := fly.y * max_jetpack_speed * _speed_mult() if absf(fly.y) > 0.1 else hover_speed
		if analog:
			var vy_range := (max_jetpack_speed + hover_speed) if fly.y < 0.0 else (max_jetpack_speed - hover_speed)
			target_y = hover_speed + fly.y * vy_range * _speed_mult()
		var accel_mult := 0.4 if _flip_left > 0.0 else 1.0       # let the flip's burst carry you a bit
		velocity.x = move_toward(velocity.x, target_x, jet_accel * _jet_response() * accel_mult * delta)
		velocity.y = move_toward(velocity.y, target_y, thrust_power * _jet_response() * delta)

	else:
		# Normal gravity (a stunned player who was just blasted upward must leave the floor, not be pinned to it)
		if not is_on_floor() or (is_stunned() and velocity.y < -1.0):
			velocity.y += gravity * rule_gravity_mult * delta
		else:
			velocity.y = 0

		# Refuel: full speed on the ground, 30% in the air
		_regen_wait = maxf(_regen_wait - delta, 0.0)
		if is_on_floor() or _regen_wait <= 0.0:
			var regen := fuel_regen_rate if is_on_floor() else fuel_regen_rate * 0.3
			fuel = min(fuel + regen * delta, max_fuel)

	if hud:
		hud.set_stats(health, max_health, fuel, max_fuel)

	# ----- Move + animate -----
	move_and_slide()
	visuals.update_visuals(velocity, mouse_pos, jetpack_active, is_on_floor(), delta, crouching, blocking)


# ============================================================
# TOUCH / INPUT HELPERS
# ============================================================
func _setup_touch() -> void:
	if not show_hud:
		return
	var layer := CanvasLayer.new()
	layer.name = "TouchLayer"
	layer.layer = 8
	touch = TouchControls.new()
	touch.player = self
	layer.add_child(touch)
	add_child(layer)


func _touch_on() -> bool:
	return touch != null and TouchControls.active


func on_touch_mode_changed(on: bool) -> void:
	if ammo_label != null:
		ammo_label.visible = not on
	if hud != null:
		hud.set_touch_mode(on)
	if not on:
		_touch_flying = false
		_touch_fly_lock = false


func _just(action: String) -> bool:
	if Input.is_action_just_pressed(action):
		return true
	return _touch_on() and touch.take(action)


func _shoot_held() -> bool:
	if _touch_on():
		return touch.fire_held and not is_dead         # the FIRE button (the right stick only aims)
	return Input.is_action_pressed("shoot")


func _aim_point(shoulder: Vector2) -> Vector2:
	if _touch_on():
		return shoulder + touch.aim_vec * TOUCH_AIM_DISTANCE
	return get_global_mouse_position()


func _move_axis() -> float:
	var d := Input.get_axis("move_left", "move_right")
	if _touch_on():
		var tx: float = touch.move_vec.x
		var t := signf(tx) * minf(1.0, absf(tx) * 1.6)
		if t != 0.0:
			d = t
	return d


func _touch_crouch() -> bool:
	if not _touch_on():
		return false
	var m: Vector2 = touch.move_vec
	return m.y > 0.55 and absf(m.x) < m.y


func _update_touch_flight() -> void:
	if not _touch_on() or not touch.left_down():
		_touch_flying = false
		_touch_fly_lock = false
		return
	var m: Vector2 = touch.move_vec
	var in_up_zone := m.length() > touch_fly_start and (-m.y) / m.length() > 0.5
	if _touch_fly_lock:
		if not in_up_zone:
			_touch_fly_lock = false
		return
	if not _touch_flying:
		if in_up_zone and fuel > 0.0 and not _flight_blocked():
			_touch_flying = true
	elif is_on_floor() and m.y > 0.35:
		_touch_flying = false


func _register_tap(act: String) -> void:
	var now := Time.get_ticks_msec() / 1000.0
	if now - float(_tap_time[act]) <= double_tap_window:
		try_flip(-1.0 if act == "move_left" else 1.0)
		_tap_time[act] = -10.0
	else:
		_tap_time[act] = now


# ============================================================
# AIR ACROBATICS
# ============================================================
func _check_flip_input() -> void:
	if not InputMap.has_action("flip"):
		var ev := InputEventKey.new()
		ev.physical_keycode = KEY_SHIFT
		InputMap.add_action("flip")
		InputMap.action_add_event("flip", ev)

	if double_tap_flip:
		for act in ["move_left", "move_right"]:
			if Input.is_action_just_pressed(act):
				_register_tap(act)

		# (flicking the touch stick no longer flips: it triggered by accident while steering and shooting;
		#  use the FLIP button)

	if _just("flip"):
		var dir := _move_axis()
		if dir == 0.0:
			dir = 1.0 if aim_dir.x >= 0.0 else -1.0       # no direction held: flip toward where you aim
		try_flip(signf(dir))


# dir: -1 = flip to the left, +1 = to the right. Returns true if the flip started.
func try_flip(dir: float) -> bool:
	if is_dead or _flip_left > 0.0 or _flip_cd > 0.0:
		return false
	if is_on_floor() or _flight_blocked() or fuel < flip_fuel_cost:
		return false                       # flips are for the air, and cost fuel
	fuel -= flip_fuel_cost
	_flip_left = flip_time
	_flip_dir = dir
	_flip_cd = flip_time + flip_cooldown
	velocity.x = dir * flip_dash_speed
	velocity.y = minf(velocity.y, -90.0)   # tiny hop upward so the flip has room
	visuals.start_flip(dir, flip_time)
	_flip_fx(dir)
	return true


func is_flipping() -> bool:
	return _flip_left > 0.0


# quick burst of streaks behind you
func _flip_fx(dir: float) -> void:
	var p := CPUParticles2D.new()
	p.position = global_position + Vector2(0, -20)
	p.emitting = true
	p.one_shot = true
	p.explosiveness = 0.9
	p.amount = 20
	p.lifetime = 0.4
	p.direction = Vector2(-dir, 0.0)
	p.spread = 35.0
	p.initial_velocity_min = 120.0
	p.initial_velocity_max = 280.0
	p.gravity = Vector2.ZERO
	p.scale_amount_min = 2.5
	p.scale_amount_max = 5.0
	var g := Gradient.new()
	var tint: Color = visuals.loadout["visor"]
	g.colors = PackedColorArray([Color(tint.r, tint.g, tint.b, 0.9), Color(tint.r, tint.g, tint.b, 0.0)])
	g.offsets = PackedFloat32Array([0.0, 1.0])
	p.color_ramp = g
	var mat := CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	p.material = mat
	get_tree().current_scene.add_child(p)
	get_tree().create_timer(1.0).timeout.connect(p.queue_free)


# ============================================================
# CROUCH HITBOX
# ============================================================
func _shape_height(shape: Shape2D) -> float:
	if shape is RectangleShape2D:
		return shape.size.y
	if shape is CapsuleShape2D:
		return shape.height
	if shape is CircleShape2D:
		return shape.radius * 2.0
	return 0.0


func _set_crouch_collision(is_crouching: bool) -> void:
	# shrink the hitbox to 70% height, keeping the feet on the ground
	var f := 0.7 if is_crouching else 1.0
	col.scale.y = _col_scale.y * f
	col.position.y = _col_pos.y + _col_h * _col_scale.y * 0.5 * (1.0 - f)


# ============================================================
# AMMO + RELOAD
# ============================================================
func _setup_ammo() -> void:
	ammo = weapon.magazine_size
	reserve = weapon.reserve_ammo
	reloading = false
	_update_ammo_label()


func switch_weapon(index: int) -> void:
	if dual:
		if weapons.size() < 2:
			_exit_dual()               # nothing on the back to switch to: the off-hand gun goes on your back instead
			return
		if reloading:
			return
		_stash_off()                   # the pair goes to the back together; they come out together again
	elif weapons.size() < 2 or reloading:
		return
	_ammo_store[weapon] = [ammo, reserve]       # remember the old weapon's ammo
	weapon_index = index % weapons.size()
	weapon = weapons[weapon_index]
	visuals.equip_weapon(weapon, true)          # swings out from the back
	if _ammo_store.has(weapon):
		ammo = _ammo_store[weapon][0]
		reserve = _ammo_store[weapon][1]
	else:
		ammo = weapon.magazine_size
		reserve = weapon.reserve_ammo
	_fire_cooldown = 0.25                       # short delay before you can fire
	_restore_off()                              # a stored pair comes back out together
	_update_ammo_label()
	_refresh_loadout()


# While dual wielding, switching puts the pair away: the main gun stays in its slot and the off-hand gun is
# remembered with it (nothing is duplicated or lost). Switching back brings both out again.
var _off_stash := {}                 # main-hand WeaponData -> [off-hand WeaponData, its ammo, its reserve]


func _stash_off() -> void:
	_off_stash[weapon] = [off_weapon, off_ammo, off_reserve]
	dual = false
	off_reloading = false
	_off_reload_id += 1
	visuals.unequip_off_hand()


func _restore_off() -> void:
	if not _off_stash.has(weapon):
		return
	var st: Array = _off_stash[weapon]
	_off_stash.erase(weapon)
	dual = true
	off_weapon = st[0]
	off_ammo = int(st[1])
	off_reserve = int(st[2])
	off_reloading = false
	_off_reload_id += 1
	_off_cooldown = 0.25
	visuals.equip_off_hand(off_weapon)


# The gun we carry but aren't holding (null if we only have one).
func _secondary_weapon() -> WeaponData:
	if weapons.size() < 2:
		return null
	return weapons[(weapon_index + 1) % weapons.size()]


# Updates the carried-gun visual on the body and the HUD icons.
# Call whenever the weapons, the held gun, or dual wield changes.
func _refresh_loadout() -> void:
	var other := _secondary_weapon()
	visuals.set_secondary(other)         # the stored gun always hangs on the back (also while dual wielding)
	if hud:
		hud.set_weapons(weapon, off_weapon if dual else other, dual)
	if Net.match_active():
		Net.game.local_loadout_changed()


func has_weapon(w: WeaponData) -> bool:
	if weapons.has(w) or (dual and w == off_weapon):
		return true
	for k in _off_stash:
		if _off_stash[k][0] == w:
			return true                                   # an off-hand gun stored with its pair
	return false


# Adds spare bullets to a gun we carry (in hand, in the off hand, or on the back) and returns how many
# were actually taken. It never changes which guns we carry: collecting ammo can't cost you a weapon.
func add_ammo(w: WeaponData, amount: int) -> int:
	if is_dead or amount <= 0 or not has_weapon(w):
		return 0
	var taken := 0
	if dual and w == off_weapon and (w != weapon or off_reserve <= reserve):   # the gun in the off hand (two of the same: the emptier one first)
		taken = clampi(w.reserve_ammo - off_reserve, 0, amount)
		off_reserve += taken
	elif w == weapon:                                    # the gun in the main hand
		taken = clampi(w.reserve_ammo - reserve, 0, amount)
		reserve += taken
	elif not weapons.has(w):                             # an off-hand gun stored with its pair
		for k in _off_stash:
			if _off_stash[k][0] == w:
				taken = clampi(w.reserve_ammo - int(_off_stash[k][2]), 0, amount)
				_off_stash[k][2] = int(_off_stash[k][2]) + taken
				break
	else:                                                # carried on the back: its ammo is stored
		var saved: Array = _ammo_store.get(w, [w.magazine_size, w.reserve_ammo])
		taken = clampi(w.reserve_ammo - int(saved[1]), 0, amount)
		_ammo_store[w] = [saved[0], int(saved[1]) + taken]
	if taken > 0:
		_update_ammo_label()
	return taken


# How many spare bullets a pickup could still give us for this gun (used to ask the host for ammo in a network match).
func ammo_room(w: WeaponData) -> int:
	if is_dead or w == null or not has_weapon(w):
		return 0
	if dual and w == off_weapon and (w != weapon or off_reserve <= reserve):
		return maxi(w.reserve_ammo - off_reserve, 0)
	if w == weapon:
		return maxi(w.reserve_ammo - reserve, 0)
	if not weapons.has(w):
		for k in _off_stash:
			if _off_stash[k][0] == w:
				return maxi(w.reserve_ammo - int(_off_stash[k][2]), 0)
		return 0
	var saved: Array = _ammo_store.get(w, [w.magazine_size, w.reserve_ammo])
	return maxi(w.reserve_ammo - int(saved[1]), 0)


# ---- what is lying within reach (the touch buttons, the keys and the pickups all ask these) ----
var _near_pickups: Array = []        # WeaponPickup nodes whose range we are standing in


# WeaponPickup tells us when we step into / out of its range.
func pickup_in_range(p: Node, inside: bool) -> void:
	if inside:
		if not _near_pickups.has(p):
			_near_pickups.append(p)
	else:
		_near_pickups.erase(p)


# The pickup you would take right now: the closest one in range that can actually be taken. Null if none.
func nearby_pickup() -> WeaponPickup:
	var best: WeaponPickup = null
	var best_d := INF
	for p in _near_pickups:
		if not is_instance_valid(p) or not p.is_available():
			continue
		var d := global_position.distance_squared_to(p.global_position)
		if d < best_d:
			best_d = d
			best = p
	return best


# PICK UP button / key: shown only while something can be picked up.
func pickup_available() -> bool:
	return not is_dead and nearby_pickup() != null


# DUAL WIELD button / key: shown only while you hold a one-handed gun and the gun in reach is one-handed too.
func dual_available() -> bool:
	if is_dead:
		return false
	var p := nearby_pickup()
	return p != null and can_dual_with(p.weapon)


func can_dual_with(w: WeaponData) -> bool:
	return not is_dead and not dual and weapon != null and weapon.one_handed and w != null and w.one_handed


# The gun that picking up `new_weapon` the normal way would leave on the floor (null = nothing is dropped).
func would_drop_for(new_weapon: WeaponData) -> WeaponData:
	if weapons.has(new_weapon) and not dual:
		return null                                       # same gun: handled as a swap by the pickup
	if dual:
		return weapon                                     # picking up while dual wielding ends it: the gun in hand is replaced
	if weapons.size() >= max_weapons:
		return weapon
	return null


# DUAL WIELD: the gun on the floor goes into the other hand. A gun stored on your back stays there.
# Returns true if the floor gun was used.
func dual_wield_pickup(new_weapon: WeaponData, new_ammo := -1, new_reserve := -1) -> bool:
	if not can_dual_with(new_weapon):
		return false
	var frame := Engine.get_process_frames()
	if frame == _last_pickup_frame:
		return false                                        # one press equips one gun, even if pickups overlap
	_last_pickup_frame = frame

	dual = true
	off_weapon = new_weapon
	off_ammo = new_ammo if new_ammo >= 0 else new_weapon.magazine_size
	off_reserve = new_reserve if new_reserve >= 0 else new_weapon.reserve_ammo
	off_reloading = false
	_off_reload_id += 1
	_off_cooldown = 0.25
	visuals.equip_off_hand(off_weapon)
	_update_ammo_label()
	_refresh_loadout()
	return true


# Called by a weapon pickup when you press the pickup key: equips that gun. Returns true if used.
# With both slots full, the gun in hand is replaced and dropped at your feet as a normal pickup.
# If it is the same type you already carry, the two copies swap places (yours drops, theirs is equipped).
# new_ammo / new_reserve are -1 for a fresh weapon, or the ammo a dropped gun still had.
func pickup_weapon(new_weapon: WeaponData, new_ammo := -1, new_reserve := -1) -> bool:
	if is_dead:
		return false
	var frame := Engine.get_process_frames()
	if frame == _last_pickup_frame:
		return false                                        # one key press equips one gun, even if pickups overlap
	_last_pickup_frame = frame

	# a new weapon ends dual wield first
	if dual:
		_exit_dual()

	# SAME gun type as one we already carry: swap copies. The one we carry drops on the floor
	# (keeping its ammo) and the one from the floor takes its place, ammo and all.
	if weapons.has(new_weapon):
		var idx := weapons.find(new_weapon)
		var swap_a: int
		var swap_r: int
		if idx == weapon_index:                             # the copy in hand
			swap_a = ammo
			swap_r = reserve
			_reload_id += 1                                 # cancel any reload in progress
			reloading = false
			ammo = new_ammo if new_ammo >= 0 else new_weapon.magazine_size
			reserve = new_reserve if new_reserve >= 0 else new_weapon.reserve_ammo
			_fire_cooldown = 0.25
			visuals.equip_weapon(weapon)                    # replay the equip animation
		else:                                               # the copy on the back
			var saved: Array = _ammo_store.get(new_weapon, [new_weapon.magazine_size, new_weapon.reserve_ammo])
			swap_a = int(saved[0])
			swap_r = int(saved[1])
			_ammo_store[new_weapon] = [
				new_ammo if new_ammo >= 0 else new_weapon.magazine_size,
				new_reserve if new_reserve >= 0 else new_weapon.reserve_ammo]
		_update_ammo_label()
		_refresh_loadout()
		_drop_weapon(new_weapon, swap_a, swap_r)
		return true

	# if both slots are full, the gun in hand is replaced and DROPS on the floor
	var dropped: WeaponData = null
	var drop_a := 0
	var drop_r := 0
	if weapons.size() >= max_weapons:
		dropped = weapon
		drop_a = ammo
		drop_r = reserve
		weapons[weapon_index] = new_weapon
	else:
		_ammo_store[weapon] = [ammo, reserve]
		weapons.append(new_weapon)
		weapon_index = weapons.size() - 1

	weapon = new_weapon
	_reload_id += 1                                     # cancel any reload in progress
	reloading = false
	visuals.equip_weapon(weapon)
	ammo = new_ammo if new_ammo >= 0 else weapon.magazine_size
	reserve = new_reserve if new_reserve >= 0 else weapon.reserve_ammo
	_fire_cooldown = 0.25
	_update_ammo_label()
	_refresh_loadout()

	if dropped != null:
		_drop_weapon(dropped, drop_a, drop_r)
	return true


# Leaves a weapon on the floor, keeping the ammo it had.
func _drop_weapon(w: WeaponData, a: int, r: int) -> void:
	if _off_stash.has(w):                      # a stored pair never loses its partner: it drops too
		var st: Array = _off_stash[w]
		_off_stash.erase(w)
		_drop_weapon(st[0], int(st[1]), int(st[2]))
	if Net.match_active():
		Net.game.local_drop(w, a, r, global_position + Vector2(0, 6))      # the host creates the gun for everybody
		return
	var drop := WeaponPickup.new()
	drop.weapon = w
	drop.is_drop = true
	drop.drop_ammo = a
	drop.drop_reserve = r
	drop.global_position = global_position + Vector2(0, 6)
	drop.ignore_body = self                    # we don't instantly suck the ammo back out of the gun we just dropped
	get_tree().current_scene.add_child(drop)


func start_reload() -> void:
	if reloading or ammo >= weapon.magazine_size or reserve <= 0:
		return
	reloading = true
	_reload_id += 1
	var my_id := _reload_id
	visuals.eject_reload_casings(0, weapon.magazine_size - ammo)       # revolvers: the spent cases fall out now
	visuals.drop_magazine(0)                                           # magazine guns: the empty magazine drops out
	_update_ammo_label()

	await get_tree().create_timer(maxf(weapon.reload_time * (0.0 if rule_instant_reload else 1.0), 0.02)).timeout

	if is_dead or my_id != _reload_id:
		return                          # respawn refills the ammo
	var taken := mini(weapon.magazine_size - ammo, reserve)
	ammo += taken
	if not rule_unlimited_ammo:
		reserve -= taken
	reloading = false
	_update_ammo_label()


func _update_ammo_label() -> void:
	if ammo_label == null:
		return
	if dual:
		ammo_label.text = "%s\n%s" % [
			_hand_text(weapon, ammo, reserve, reloading, 0),
			_hand_text(off_weapon, off_ammo, off_reserve, off_reloading, 1)]
		return
	var head := "%s  [%s]" % [weapon.display_name.to_upper(), _mode_tag(weapon, 0)]
	if reloading:
		ammo_label.text = "%s\nRELOADING..." % head
	elif ammo == 0 and reserve == 0:
		ammo_label.text = "%s\nNO AMMO" % head
	else:
		ammo_label.text = "%s\n%d / %d" % [head, ammo, reserve]


# ============================================================
# THROWABLES
# ============================================================
func _setup_throwables() -> void:
	# make sure the keys exist even if you haven't added them in Project Settings
	for entry in [["throw", KEY_G], ["switch_throwable", KEY_T]]:
		if not InputMap.has_action(entry[0]):
			InputMap.add_action(entry[0])
			var ev := InputEventKey.new()
			ev.physical_keycode = entry[1]
			InputMap.action_add_event(entry[0], ev)

	throwable_loadout.clear()                    # ignores anything saved in the Inspector
	_throw_counts.clear()
	if use_test_loadout:
		# testing: every throwable, full stacks
		for id in ThrowableCatalog.IDS:
			var d := ThrowableCatalog.get_data(id)
			if d != null:
				throwable_loadout.append(d)
				_throw_counts[d] = d.start_count
	else:
		# match loadout: exactly the bombs (and quantities) that were chosen
		for entry in _match_throwables:
			var ld := ThrowableCatalog.get_data(str(entry[0]))
			if ld != null and not throwable_loadout.has(ld):
				throwable_loadout.append(ld)
				_throw_counts[ld] = mini(int(entry[1]), ld.max_count)
	if not use_test_loadout and _match_throwables.is_empty():
		# real match: spawn with a couple of starter bombs, everything else comes from pickups
		for id in starting_throwables:
			var d := ThrowableCatalog.get_data(id)
			if d != null:
				throwable_loadout.append(d)
				_throw_counts[d] = mini(starting_throwable_count, d.max_count)
	throwable_index = 0
	_update_throwable_hud()


func current_throwable() -> ThrowableData:
	if throwable_loadout.is_empty():
		return null
	return throwable_loadout[throwable_index % throwable_loadout.size()]


func switch_throwable() -> void:
	if throwable_loadout.size() < 2:
		return
	# jump to the next type you actually have (skips empty ones)
	for i in range(1, throwable_loadout.size() + 1):
		var idx := (throwable_index + i) % throwable_loadout.size()
		if int(_throw_counts.get(throwable_loadout[idx], 0)) > 0:
			throwable_index = idx
			break
	_update_throwable_hud()


# True if this type isn't full yet (pickups use this so they don't waste themselves).
func throwable_room(t: ThrowableData) -> bool:
	return not is_dead and int(_throw_counts.get(t, 0)) < t.max_count


func throw_throwable(dir: Vector2) -> void:
	if _status.has("emp"):
		_flash_message("EMP: THROWING DISABLED")
		_throw_cooldown = 0.5
		return
	var t := current_throwable()
	if t == null or int(_throw_counts.get(t, 0)) <= 0:
		return
	if rule_infinite_grenades:
		_throw_counts[t] = t.max_count                 # Infinite Grenades: the stock never goes down
	else:
		_throw_counts[t] = int(_throw_counts[t]) - 1
	_throw_cooldown = 0.5

	var shoulder: Vector2 = visuals.aim_pivot.global_position
	var dist := _aim_point(shoulder).distance_to(shoulder)
	var power := clampf(dist * 2.0, 250.0, t.throw_speed)        # farther cursor = harder throw

	if Net.match_active():
		# network match: the host makes the real bomb (and checks we own it); we see it when the host's copy arrives
		var start := shoulder + dir * 22.0
		var launch := dir * power + velocity * 0.5
		if Net.is_host():
			Net.game.host_throw(Net.my_id(), self, t, start, launch)
		else:
			Net.game.client_throw(t, start, launch)
	else:
		var bomb := Throwable.new()
		bomb.setup(t, self, dir * power + velocity * 0.5)
		get_tree().current_scene.add_child(bomb)
		bomb.global_position = shoulder + dir * 22.0
	if int(_throw_counts[t]) <= 0:
		switch_throwable()                       # that was the last one: move on to another type
	_update_throwable_hud()


# Called by pickups later: adds bombs of a type (keeps the stack under its max).
func add_throwable(t: ThrowableData, amount := 1) -> void:
	if not throwable_loadout.has(t):
		throwable_loadout.append(t)
	var had_any: bool = int(_throw_counts.get(current_throwable(), 0)) > 0
	_throw_counts[t] = mini(int(_throw_counts.get(t, 0)) + amount, t.max_count)
	if not had_any:
		throwable_index = throwable_loadout.find(t)      # nothing ready to throw: switch to what you just got
	_update_throwable_hud()


func _update_throwable_hud() -> void:
	var t := current_throwable()
	if hud:
		hud.set_throwable(t, int(_throw_counts.get(t, 0)))
	# body visual only: the selected grenade hangs from the belt (hidden when none is left)
	if visuals:
		var have: bool = t != null and int(_throw_counts.get(t, 0)) > 0
		visuals.set_hip_throwable(t.icon if have else null)
	if Net.match_active():
		Net.game.local_loadout_changed()


# ============================================================
# STATUS EFFECTS
# ============================================================
# Called by throwable zones (and later by special weapons: Freeze, Slow, Poison...).
# type: "burn" / "poison" (power = damage per second), "cryo" / "slow" (power = fraction slower).
func apply_status(type: String, duration: float, power := 1.0, source: Node = null) -> void:
	if is_dead:
		return
	StatusFX.attach(self)                       # status visuals (rings, frost, sparks...)
	if _status.has(type):
		var cur: Dictionary = _status[type]
		cur["t"] = maxf(cur["t"], duration)
		cur["power"] = maxf(cur["power"], power)
		if source != null:
			cur["src"] = source
	else:
		_status[type] = {"t": duration, "power": power, "src": source}


func has_status(type: String) -> bool:
	return _status.has(type)


func status_power(type: String) -> float:
	return float(_status[type]["power"]) if _status.has(type) else 0.0


func clear_statuses() -> void:
	_status.clear()
	_dot_accum.clear()
	if visuals:
		visuals.modulate = Color(1, 1, 1)
	if health_bar:
		health_bar.visible = true
	if hud:
		hud.set_smoke(false)


func _speed_mult() -> float:
	var m := rule_speed_mult
	for type in ["cryo", "slow"]:
		if _status.has(type):
			m *= 1.0 - clampf(status_power(type), 0.0, 0.9)
	return m


# EMP and the flight disruptor shut the jetpack down while they last.
func _flight_blocked() -> bool:
	return _status.has("emp") or _status.has("noflight") or _status.has("stun")   # EMP, flight disruptor and stun cut the jetpack


# Cold makes the jetpack respond sluggishly.
func _jet_response() -> float:
	return 0.45 if _status.has("cryo") else 1.0


# Where blasts aim: the middle of the body, not the feet.
func blast_center() -> Vector2:
	return global_position + Vector2(0, -18)


# ---- stun (knockback bomb) ----
const STUN_GROUND_FRICTION := 1500.0     # px/s^2 the blast's push fades on the ground while stunned
const STUN_AIR_DRAG := 140.0             # ... and in the air (so you coast in an arc instead of stopping dead)
var _stun_immune := 0.0                  # seconds left of "can't be stunned again"
var _stun_immunity_len := 1.0


func is_stunned() -> bool:
	return _status.has("stun")


# Called by the knockback bomb. No stacking: a second blast never adds time (the longer stun wins), and right
# after a stun ends you are immune for `immunity` seconds so nobody can chain-stun you forever.
func apply_stun(duration: float, immunity := 1.0, source: Node = null) -> void:
	if is_dead or duration <= 0.0:
		return
	if _status.has("stun"):
		_status["stun"]["t"] = maxf(float(_status["stun"]["t"]), duration)
		return
	if _stun_immune > 0.0:
		return
	_stun_immunity_len = immunity
	jetpack_toggled = false
	_touch_flying = false
	apply_status("stun", duration, 1.0, source)


func _tick_statuses(delta: float) -> void:
	_stun_immune = maxf(0.0, _stun_immune - delta)
	if is_dead:
		return
	for type in _status.keys():
		if not _status.has(type):
			continue                            # cleared by a death during this loop
		var s: Dictionary = _status[type]
		s["t"] -= delta
		if type == "burn" or type == "poison":
			_dot_accum[type] = float(_dot_accum.get(type, 0.0)) + float(s["power"]) * delta
			if _dot_accum[type] >= 1.0:
				var dmg := int(_dot_accum[type])
				_dot_accum[type] -= dmg
				if is_instance_valid(s["src"]) and s["src"] != self:
					last_attacker = s["src"]     # kill credit
				take_damage(dmg, Vector2.ZERO, true)
				if is_dead:
					return
		if s["t"] <= 0.0:
			_status.erase(type)
			_dot_accum.erase(type)
			if type == "stun":
				_stun_immune = _stun_immunity_len       # controls are back right away; the immunity starts now

	# tint the character while affected
	var tint := Color(1, 1, 1)
	if _status.has("cryo"):
		tint = Color(0.65, 0.9, 1.3)
	elif _status.has("burn"):
		tint = Color(1.25, 0.8, 0.6) if int(Time.get_ticks_msec() / 120) % 2 == 0 else Color(1.1, 0.7, 0.5)
	elif _status.has("poison"):
		tint = Color(0.7, 1.15, 0.6)
	elif _status.has("stun"):
		tint = Color(1.4, 1.4, 0.8) if int(Time.get_ticks_msec() / 70) % 2 == 0 else Color(1.0, 1.0, 1.0)     # dazed flicker
	elif _status.has("emp"):
		tint = Color(0.8, 1.0, 1.4) if int(Time.get_ticks_msec() / 90) % 2 == 0 else Color(1.0, 1.1, 1.0)    # sparking
	elif _status.has("noflight"):
		tint = Color(1.15, 1.1, 0.8)
	var smoked := _status.has("smoked")
	tint.a = 0.07 if smoked else 1.0          # inside smoke you're practically invisible
	visuals.modulate = tint
	if health_bar:
		health_bar.visible = not smoked
	if hud:
		hud.set_smoke(smoked)                  # your own screen gets hazy too


# ============================================================
# DUAL WIELD
# ============================================================
# Leaves dual wield: the off-hand gun goes on your back (or on the floor if your back slot can't take it).
func _exit_dual() -> void:
	if not dual:
		return
	dual = false
	off_reloading = false
	_off_reload_id += 1
	visuals.unequip_off_hand()
	if weapons.has(off_weapon) or weapons.size() >= max_weapons:
		_drop_weapon(off_weapon, off_ammo, off_reserve)
	else:
		weapons.append(off_weapon)
		_ammo_store[off_weapon] = [off_ammo, off_reserve]
	_update_ammo_label()
	_refresh_loadout()


func start_off_reload() -> void:
	if not dual or off_reloading or off_ammo >= off_weapon.magazine_size or off_reserve <= 0:
		return
	off_reloading = true
	_off_reload_id += 1
	var my_id := _off_reload_id
	visuals.eject_reload_casings(1, off_weapon.magazine_size - off_ammo)
	visuals.drop_magazine(1)
	_update_ammo_label()

	await get_tree().create_timer(maxf(off_weapon.reload_time * (0.0 if rule_instant_reload else 1.0), 0.02)).timeout

	if is_dead or not dual or my_id != _off_reload_id:
		return                          # died, left dual wield, or swapped: cancelled
	var taken := mini(off_weapon.magazine_size - off_ammo, off_reserve)
	off_ammo += taken
	if not rule_unlimited_ammo:
		off_reserve -= taken
	off_reloading = false
	_update_ammo_label()


func _hand_text(w: WeaponData, a: int, r: int, is_reloading: bool, hand := 0) -> String:
	var head := "%s [%s]" % [w.display_name.to_upper(), _mode_tag(w, hand)]
	if is_reloading:
		return "%s RELOADING..." % head
	if a == 0 and r == 0:
		return "%s NO AMMO" % head
	return "%s %d / %d" % [head, a, r]


func _flash_message(text: String) -> void:
	if ammo_label == null:
		return
	ammo_label.text = text
	await get_tree().create_timer(1.2).timeout
	_update_ammo_label()


# ============================================================
# SHOOTING
# ============================================================
# ============================================================
# TRIGGER LOGIC (semi / auto / burst / single) - the same code for both hands and every input device
# ============================================================
# Gives back the hand's FireState, re-binding it first if the gun in that hand changed. Re-binding clears any
# burst that was running, so a gun you swapped away from can never keep firing.
func _bound_state(fs: FireState, w: WeaponData) -> FireState:
	if fs.weapon != w:
		fs.bind(w, _mode_store.get(w, ""))
	return fs


func _tick_trigger(hand: int, fs: FireState, held: bool, interrupted: bool, dir: Vector2) -> void:
	var w: WeaponData = fs.weapon
	if w == null:
		return
	var cd: float = _fire_cooldown if hand == 0 else _off_cooldown
	var busy: bool = reloading if hand == 0 else off_reloading
	var rounds: int = ammo if hand == 0 else off_ammo
	if not held:
		fs.trigger_ready = true                                  # semi / single guns need a fresh press for every shot
	if interrupted or busy:
		fs.burst_left = 0                                        # reloading / stun / death ends a burst on the spot
		return
	# A burst that is under way carries on by itself, even if the finger has lifted since (it finishes cleanly).
	if fs.burst_left > 0:
		if cd > 0.0:
			return
		if rounds <= 0:
			fs.burst_left = 0
			return
		_discharge(hand, dir)
		fs.burst_left -= 1
		_set_cooldown(hand, w.burst_pause if fs.burst_left == 0 else w.burst_interval)
		return
	if not held or cd > 0.0:
		return
	if (fs.mode == "semi" or fs.mode == "single") and not fs.trigger_ready:
		# A launcher (RPG) keeps firing while the trigger stays held, on every input: after the reload it fires
		# again at its normal rate. Only when it has a round loaded; an empty one still gets one reload try per press.
		var launcher_repeat: bool = w.projectile_kind == "rocket" and rounds > 0
		if not launcher_repeat and not (fs.mode == "semi" and TOUCH_SEMI_REPEAT and _touch_on()):     # touch: semi repeats while the drag is held
			return
	if rounds <= 0:
		fs.trigger_ready = false                                 # empty: one reload attempt per press, no click spam
		if hand == 0:
			start_reload()
		else:
			start_off_reload()
		return
	match fs.mode:
		"burst":
			# fire the first round now; the rest (never more than the rounds that exist) follow on the burst interval.
			# Holding the trigger starts the next burst after burst_pause - no new press needed.
			_discharge(hand, dir)
			fs.burst_left = mini(maxi(w.burst_count, 1), rounds) - 1
			_set_cooldown(hand, w.burst_pause if fs.burst_left == 0 else w.burst_interval)
			fs.trigger_ready = false
		"auto":
			_discharge(hand, dir)
			_set_cooldown(hand, w.shot_gap("auto"))
		_:                                                       # "semi" and "single": exactly one shot per press
			_discharge(hand, dir)
			_set_cooldown(hand, w.shot_gap(fs.mode))
			fs.trigger_ready = false


func _set_cooldown(hand: int, seconds: float) -> void:
	if hand == 0:
		_fire_cooldown = maxf(seconds, 0.03)
	else:
		_off_cooldown = maxf(seconds, 0.03)


# One round leaves the gun: the bullet / rocket, the effects, exactly one unit of ammo, and the auto-reload.
func _discharge(hand: int, dir: Vector2) -> void:
	if hand == 0:
		shoot(dir)
		ammo -= 1
		_update_ammo_label()
		if ammo <= 0:
			start_reload()
	else:
		shoot_off(dir)
		off_ammo -= 1
		_update_ammo_label()
		if off_ammo <= 0:
			start_off_reload()


# Switches the selected firing mode of the gun(s) in your hands. Only modes the gun really has can be picked,
# guns with one mode ignore it, and it is ignored while the trigger is held (no accidental changes mid-fight).
func toggle_fire_mode() -> void:
	if is_dead or _shoot_held():
		return
	var changed := false
	for hand in (2 if dual else 1):
		var fs := _bound_state(_fs_main, weapon) if hand == 0 else _bound_state(_fs_off, off_weapon)
		if fs.cycle():
			_mode_store[fs.weapon] = fs.mode
			changed = true
	if changed:
		_update_ammo_label()


# True if the gun(s) in your hands have more than one firing mode (the touch FIRE MODE button only shows then).
func fire_mode_available() -> bool:
	if weapon != null and weapon.modes().size() > 1:
		return true
	return dual and off_weapon != null and off_weapon.modes().size() > 1


func fire_held_now() -> bool:
	return _shoot_held()


# "SEMI", "BURST"... for the main hand (the touch button and the ammo label show it).
func fire_mode_text() -> String:
	if weapon == null:
		return ""
	return WeaponData.mode_label(_bound_state(_fs_main, weapon).mode)


func _mode_tag(w: WeaponData, hand: int) -> String:
	if w == null:
		return ""
	var fs := _bound_state(_fs_main, w) if hand == 0 else _bound_state(_fs_off, w)
	return WeaponData.mode_label(fs.mode)


# Cleans up every firing operation (death, respawn): no burst, no held trigger, nothing pending.
func _reset_firing() -> void:
	_fs_main.bind(null)
	_fs_off.bind(null)


# Adds the FIRE MODE key / button and a controller trigger to the Input Map if the project does not have them yet.
func _setup_fire_inputs() -> void:
	if not InputMap.has_action("fire_mode"):
		InputMap.add_action("fire_mode")
		var k := InputEventKey.new()
		k.physical_keycode = KEY_B
		InputMap.action_add_event("fire_mode", k)
		var jb := InputEventJoypadButton.new()
		jb.button_index = JOY_BUTTON_LEFT_SHOULDER
		InputMap.action_add_event("fire_mode", jb)
	if InputMap.has_action("shoot"):
		var has_pad := false
		for ev in InputMap.action_get_events("shoot"):
			if ev is InputEventJoypadMotion or ev is InputEventJoypadButton:
				has_pad = true
		if not has_pad:
			var rt := InputEventJoypadMotion.new()
			rt.axis = JOY_AXIS_TRIGGER_RIGHT
			rt.axis_value = 1.0
			InputMap.action_add_event("shoot", rt)


func shoot(dir: Vector2):
	_fire(weapon, visuals.muzzle, dir, 0)


func shoot_off(dir: Vector2):
	_fire(off_weapon, visuals.off_muzzle, dir, 1)


func _fire(w: WeaponData, muzzle_node: Node2D, dir: Vector2, hand := 0):
	GunAudio.shoot(self, w)                           # one sound per shot (a whole shotgun blast / one round of a burst)
	UITheme.haptic(7)                                 # light recoil tick (throttled, and Settings > Haptics can turn it off)
	var net := Net.match_active()
	var origin: Vector2 = muzzle_node.global_position
	if w.projectile_kind == "rocket":
		var err := deg_to_rad(randf_range(-w.spread_degrees, w.spread_degrees))
		var rdir := dir.rotated(err)
		if net and Net.is_client():
			Net.game.client_fire(w, hand, origin, PackedVector2Array([rdir]))   # the host launches the real rocket
		else:
			var rocket := Rocket.launch(w, origin, rdir, self, get_tree())
			if net and Net.is_host():
				rocket.net_id = Net.game._new_id()
				Net.game.host_fire_event(w, hand, origin, PackedVector2Array([rdir]), rocket.net_id)
		visuals.fire_effects(hand)
		return
	if not bullet_scene:
		print("ERROR: bullet_scene is empty!")
		return

	# one bullet per pellet (shotguns fire several), each with random spread
	var dirs := PackedVector2Array()
	for i in w.pellets:
		var angle_error := deg_to_rad(randf_range(-w.spread_degrees, w.spread_degrees))
		var bdir := dir.rotated(angle_error)
		dirs.append(bdir)
		var bullet = bullet_scene.instantiate()
		bullet.global_position = origin
		bullet.setup(w, bdir, self)
		if net and Net.is_client():
			bullet.net_visual = true                  # cosmetic only: the host's copy does the damage
		get_tree().current_scene.add_child(bullet)
	MatchSession.note_shots(w.pellets)                # accuracy: bullets fired (rockets are not counted)
	if net:
		if Net.is_client():
			Net.game.client_fire(w, hand, origin, dirs)
		else:
			Net.game.host_fire_event(w, hand, origin, dirs, 0)
	visuals.fire_effects(hand)         # muzzle flash, recoil kick, spent casing (each hand has its own)


# ============================================================
# RECEIVE DAMAGE
# ============================================================
# True if we're crouch-blocking AND the shot came from inside the shield's arc.
func _shield_covers(hit_direction: Vector2) -> bool:
	if not blocking:
		return false
	var from_dir := Vector2.ZERO                  # direction from us toward the attacker
	if hit_direction != Vector2.ZERO:
		from_dir = -hit_direction.normalized()    # the bullet travels opposite to that
	elif is_instance_valid(last_attacker) and last_attacker is Node2D:
		from_dir = (last_attacker.global_position - visuals.aim_pivot.global_position).normalized()
	else:
		return false                              # can't tell where it came from
	return absf(aim_dir.angle_to(from_dir)) <= PlayerRig.SHIELD_HALF_ANGLE


# True if we're crouching AND the shield is pointing toward world_point (an explosion, etc).
# Only the front cone counts, so crouching with your back to a blast protects nothing.
func is_shielding_toward(world_point: Vector2) -> bool:
	if not blocking or is_dead:
		return false
	var to_point: Vector2 = world_point - visuals.aim_pivot.global_position
	if to_point.length() < 1.0:
		return true                                # blast right on top of the shield
	return absf(aim_dir.angle_to(to_point.normalized())) <= PlayerRig.SHIELD_HALF_ANGLE


func take_damage(amount, hit_direction := Vector2.ZERO, ignore_shield := false):
	if is_dead or _net_client():
		return                      # in a network match only the host decides damage; we are TOLD our health (net_apply_hit)
	if rule_infinite_health and not has_meta("_oob"):
		return                      # Infinite Health: combat damage does nothing (out-of-bounds still hurts)
	_time_since_hit = 0.0           # taking damage pauses regeneration

	# Blocking: only works if the hit comes from the side the shield faces
	if not ignore_shield and _shield_covers(hit_direction):
		amount = maxi(1, roundi(amount * block_damage_mult))
		hit_direction *= 0.3
		visuals.shield_hit()

	health -= amount
	health = max(health, 0)
	health_bar.value = health
	_hurt_feedback(amount)

	# Knockback
	if hit_direction != Vector2.ZERO:
		velocity += hit_direction     # size comes from the weapon's knockback

	# Hit flash
	if health > 0:
		modulate = Color(1, 0.3, 0.3)
		await get_tree().create_timer(0.1).timeout
		if not is_dead:
			modulate = Color(1, 1, 1)

	if health <= 0:
		die()


# Red screen-edge flash + a buzz when YOU take damage (the harder the hit, the stronger it is).
func _hurt_feedback(amount) -> void:
	if float(amount) <= 0.0:
		return
	if hud:
		hud.flash_damage(float(amount) / maxf(float(max_health), 1.0))
	UITheme.haptic(clampi(int(float(amount) * 0.8), 18, 55))


# ============================================================
# OFFLINE MATCH RULES (MatchSession). Called once when a configured match starts, before the first shot.
# Everything is a plain multiplier / flag, so with no match config the game plays exactly as before.
# ============================================================
func apply_match_rules(cfg: MatchConfig) -> void:
	max_health = cfg.start_health
	health = max_health
	health_bar.max_value = max_health
	health_bar.value = health
	rule_regen = cfg.health_regen
	rule_infinite_health = cfg.is_mod("infinite_health")
	rule_infinite_fuel = cfg.is_mod("infinite_fuel")
	rule_infinite_grenades = cfg.is_mod("infinite_grenades")
	rule_unlimited_ammo = cfg.is_mod("unlimited_ammo")
	rule_instant_reload = cfg.is_mod("no_reload")
	rule_gravity_mult = MatchSession.LOW_GRAVITY if cfg.is_mod("low_gravity") else 1.0
	rule_speed_mult = MatchSession.FAST_MOVE if cfg.is_mod("fast_movement") else 1.0
	rule_damage_mult = MatchSession.DAMAGE_MULT if cfg.is_mod("increased_damage") else 1.0
	if cfg.use_loadouts and not cfg.loadout.is_empty():
		_apply_match_loadout(cfg.loadout)
	if hud:
		hud.set_stats(health, max_health, fuel, max_fuel)


# Starting equipment from a loadout dictionary (see MatchStore.make_loadout). Pickups still work as normal.
func _apply_match_loadout(lo: Dictionary) -> void:
	var primary := WeaponCatalog.get_weapon(str(lo.get("primary", "")))
	var secondary := WeaponCatalog.get_weapon(str(lo.get("secondary", "")))
	if primary == null:
		return
	_exit_dual()
	weapons.clear()
	weapons.append(primary)
	if secondary != null and secondary != primary:
		weapons.append(secondary)
	weapon_index = 0
	weapon = weapons[0]
	_spawn_loadout.assign(weapons)
	_ammo_store.clear()
	_off_stash.clear()
	visuals.equip_weapon(weapon)
	_setup_ammo()
	_match_throwables = []
	for k in ["t1", "t2"]:
		var tid := str(lo.get(k, ""))
		if tid != "":
			_match_throwables.append([tid, int(lo.get(k + "_qty", 1))])
	_setup_throwables()
	_refresh_loadout()


# ============================================================
# DEATH + RESPAWN
# ============================================================
func die():
	if is_dead:
		return
	is_dead = true
	UITheme.haptic(140)
	_reset_firing()                              # no burst / held trigger survives a death
	if touch != null:
		touch.cancel_fire()                       # stop shooting even if the finger is still down
	died.emit(self, last_attacker)
	if hud:
		hud.set_stats(0, max_health, fuel, max_fuel)

	set_physics_process(false)

	# Fade out
	var tween = create_tween()
	tween.tween_property(self, "modulate:a", 0.0, 0.3)
	await tween.finished

	visible = false
	var networked := Net.match_active()
	var respawn_pos := Vector2.ZERO
	if networked:
		respawn_pos = await Net.game.request_respawn_position(self)      # host picks the spot and the moment
	else:
		if not MatchSession.player_may_respawn():
			MatchSession.on_player_out(self)         # no respawn (or out of lives): stay down, the match manager reacts
			return
		await get_tree().create_timer(MatchSession.player_respawn_delay(2.0)).timeout
	if not is_inside_tree():
		return

	# Reset
	health = max_health
	health_bar.value = health
	velocity = Vector2.ZERO
	jetpack_active = false
	jetpack_toggled = false
	_touch_flying = false
	_touch_fly_lock = false
	_flip_left = 0.0
	_exit_dual()
	# a new life starts with the starting guns, at the starting zoom
	if not _spawn_loadout.is_empty() and (weapon != _spawn_loadout[0] or weapons != _spawn_loadout):
		weapons.clear()
		weapons.append_array(_spawn_loadout)
		weapon_index = 0
		weapon = weapons[0]
		visuals.equip_weapon(weapon)
		_refresh_loadout()
	var cz := get_node_or_null("CameraZoom")
	if cz != null:
		cz.on_respawn()
	clear_statuses()
	_ammo_store.clear()
	_off_stash.clear()
	_mode_store.clear()                          # a new life: every gun is back in its default mode
	_reset_firing()
	_setup_ammo()
	_setup_throwables()           # respawn refills your bombs

	# Respawn
	if networked:
		global_position = respawn_pos
	else:
		global_position = get_tree().current_scene.get_node("SpawnPoint").global_position

	modulate = Color(1, 1, 1, 1)
	visible = true
	is_dead = false
	set_physics_process(true)


# ============================================================
# NETWORK MATCH (LAN multiplayer). Everything here is only used while Net.match_active().
# The player still drives its own movement exactly like offline; the host decides damage, health and deaths.
# ============================================================
var _net_pull := {}                  # gravity well the host says we are in: {c, s, r, t}


func _net_client() -> bool:
	return Net.match_active() and Net.is_client()


# What the other players need to draw us (sent 20x a second, see net_match.gd). Layout matches RemotePlayer.net_receive.
func net_pack_state() -> PackedFloat32Array:
	var flags := 0
	if jetpack_active:
		flags |= RemotePlayer.F_JET
	if crouching:
		flags |= RemotePlayer.F_CROUCH
	if is_on_floor():
		flags |= RemotePlayer.F_FLOOR
	if is_dead:
		flags |= RemotePlayer.F_DEAD
	if dual:
		flags |= RemotePlayer.F_DUAL
	if _flip_left > 0.0:
		flags |= RemotePlayer.F_FLIP
		if _flip_dir > 0.0:
			flags |= RemotePlayer.F_FLIP_RIGHT
	for type in RemotePlayer.STATUS_BITS:
		if _status.has(type):
			flags |= int(RemotePlayer.STATUS_BITS[type])
	return PackedFloat32Array([global_position.x, global_position.y, velocity.x, velocity.y, aim_dir.angle(), float(flags), fuel])


# The host's verdict for a hit on us: new health plus the knockback (bullets / blasts push us).
func net_apply_hit(hp: int, push: Vector2) -> void:
	if is_dead:
		return
	_time_since_hit = 0.0
	var lost := health - hp
	health = hp
	health_bar.value = health
	_hurt_feedback(lost)
	if push != Vector2.ZERO:
		velocity += push
	modulate = Color(1, 0.3, 0.3)
	await get_tree().create_timer(0.1).timeout
	if not is_dead:
		modulate = Color(1, 1, 1)


func net_set_health(hp: int) -> void:
	if is_dead:
		return
	health = clampi(hp, 0, max_health)
	health_bar.value = health


# The host says we died (client side). Runs the normal death + waits for the host's respawn.
func net_die() -> void:
	if is_dead:
		return
	health = 0
	health_bar.value = 0
	die()


func net_teleport_local(pos: Vector2) -> void:
	global_position = pos
	velocity = Vector2.ZERO


# A gravity well the host evaluated: we pull ourselves toward its centre while it lasts.
func net_gravity(center: Vector2, speed: float, radius: float, seconds: float) -> void:
	_net_pull = {"c": center, "s": speed, "r": radius, "t": seconds}


func _apply_net_pull(delta: float) -> void:
	if _net_pull.is_empty():
		return
	_net_pull["t"] = float(_net_pull["t"]) - delta
	if float(_net_pull["t"]) <= 0.0 or is_dead:
		_net_pull = {}
		return
	var to: Vector2 = (_net_pull["c"] as Vector2) - global_position
	var d := to.length()
	if d < 12.0 or d > float(_net_pull["r"]) * 1.25:
		return
	var sp := float(_net_pull["s"]) * lerpf(0.5, 1.0, clampf(d / float(_net_pull["r"]), 0.0, 1.0))
	move_and_collide(to / d * minf(sp * delta, d))
	velocity = velocity.move_toward(Vector2.ZERO, 900.0 * delta)
