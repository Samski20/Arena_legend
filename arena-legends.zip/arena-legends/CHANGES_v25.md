# v25 changes
- NEW art/scripts/zoom_config.gd  (per-weapon zoom ranges, dual-wield rules; edit numbers here)
- NEW art/scripts/camera_zoom.gd  (replaces ScopeZoom: zoom, per-weapon memory, aim framing)
- player.gd: CameraZoom.attach, semi-auto trigger logic, FIRE-button shooting, respawn = starting guns + zoom reset
- touch_controls.gd: right stick: aim inside the inner circle, drag out to shoot, ZOOM +/- buttons, focus-loss release
- weapon_data.gd: `automatic` tickbox (off = semi-auto) - set OFF on Desert Eagle, Colt Python, Barrett, Double Barrel, SPAS-12
- game_settings.gd / settings_menu.gd: "Start with Maximum Weapon Zoom" (default OFF, saved)
- match_manager.gd: tap / click / Enter / controller A restarts; arena_controller.gd + map_registry.gd: restart stays on the same map
- zoom: BASE_VIEW = 4.0 (your original camera is 4x, so 2x is much closer)
