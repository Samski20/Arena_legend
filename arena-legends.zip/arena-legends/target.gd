extends StaticBody2D

@export var max_health := 100
var health := max_health


func take_damage(amount, hit_direction := Vector2.ZERO):
	health -= amount

	print("TARGET HEALTH: ", health)

	if health <= 0:
		die()


func die():
	print("TARGET DESTROYED")
	queue_free()
