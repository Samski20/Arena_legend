# v24 changes
- NEW art/scripts/zoom_config.gd  (per-weapon zoom ranges, dual-wield rules; edit numbers here)
- NEW art/scripts/camera_zoom.gd  (replaces ScopeZoom: zoom, per-weapon memory, aim framing)
- player.gd: CameraZoom.attach, semi-auto trigger logic, FIRE-button shooting, respawn = starting guns + zoom reset
- touch_controls.gd: FIRE button, right stick aims only, ZOOM +/- buttons, focus-loss release
- weapon_data.gd: `automatic` tickbox (off = semi-auto) - set OFF on Desert Eagle, Colt Python, Barrett, Double Barrel, SPAS-12
- game_settings.gd / settings_menu.gd: "Start with Maximum Weapon Zoom" (default OFF, saved)
- match_manager.gd: tap / click / Enter / controller A restarts; arena_controller.gd + map_registry.gd: restart stays on the same map
