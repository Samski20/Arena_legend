#!/bin/bash
# Usage: tests/run_lan_test.sh <godot binary> <steps>   e.g.  tests/run_lan_test.sh godot mc
# Starts a host and a client Godot instance (headless) on this computer and prints both logs.
GODOT=${1:-godot}
STEPS=${2:-m}
DIR="$(cd "$(dirname "$0")/.." && pwd)"
LOG=${TMPDIR:-/tmp}/lan_test_$$
mkdir -p "$LOG"
"$GODOT" --headless --path "$DIR" --script res://tests/lan_test.gd -- host "$STEPS" > "$LOG/host.log" 2>&1 &
HP=$!
sleep 3
"$GODOT" --headless --path "$DIR" --script res://tests/lan_test.gd -- client "$STEPS" 127.0.0.1 > "$LOG/client.log" 2>&1 &
CP=$!
wait $HP $CP
echo "===== HOST ====="; cat "$LOG/host.log"
echo "===== CLIENT ====="; cat "$LOG/client.log"
echo "===== SUMMARY ====="; grep -h "^TEST" "$LOG/host.log" "$LOG/client.log"
