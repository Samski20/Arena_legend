extends SceneTree
## Renders the real PlayerRig in every animation state into one PNG sheet (development tool).
## godot --path . --script res://tests/render_rig.gd -- out.png [cosmetic] [key=value ...] [zoom=1]
## key=value overrides appearance options, e.g. top=jacket bottom=shorts boots=sneakers avatar=female
const STATES := ["idle", "walk", "aim", "fly", "fall", "fire", "turn", "head"]
var CELL := Vector2(300, 360)

func _init() -> void:
	var args := OS.get_cmdline_user_args()
	var out := str(args[0]) if args.size() > 0 else "/tmp/sheet.png"
	var cos := ""
	var app := Appearance.default_for("male")
	var zoom := 2.6
	var states: Array = STATES
	for i in range(1, args.size()):
		var a := str(args[i])
		if "=" in a:
			var kv := a.split("=")
			if kv[0] == "zoom": zoom = float(kv[1])
			elif kv[0] == "cw": CELL.x = float(kv[1])
			elif kv[0] == "ch": CELL.y = float(kv[1])
			elif kv[0] == "states": states = kv[1].split(",")
			elif kv[0] == "avatar": app = Appearance.with_avatar(app, kv[1])
			elif kv[0] in ["skin", "top_col", "bottom_col", "gear_col", "jp_col", "hair_col", "eye_col"]: app[kv[0]] = int(kv[1])
			else: app[kv[0]] = kv[1]
		else:
			cos = a
	var sv := SubViewport.new()
	sv.size = Vector2i(int(CELL.x * states.size()), int(CELL.y))
	sv.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(sv)
	var bg := ColorRect.new()
	bg.color = Color("5b6b80")
	bg.size = Vector2(CELL.x * states.size(), CELL.y)
	sv.add_child(bg)
	var ground := ColorRect.new()
	ground.color = Color("3a4658")
	sv.add_child(ground)
	var rigs := []
	var params := Appearance.resolve(app, cos, 0)
	for i in states.size():
		var holder := Node2D.new()
		holder.position = Vector2(CELL.x * (i + 0.5), CELL.y * 0.52)
		holder.scale = Vector2(zoom, zoom)
		holder.z_index = 20
		sv.add_child(holder)
		var rig := PlayerRig.new()
		rig.preview = true
		holder.add_child(rig)
		rigs.append([rig, holder, states[i]])
	await process_frame
	for r in rigs:
		r[0].apply_appearance(params)
	await process_frame
	for r in rigs:
		var rig: PlayerRig = r[0]
		var st: String = r[2]
		if st in ["aim", "fire"]:
			rig.equip_weapon(WeaponCatalog.get_weapon("m4a1"))
		var vel := Vector2.ZERO; var jet := false; var fl := true; var left := false
		match st:
			"walk": vel = Vector2(150, 0)
			"fly": vel = Vector2(240, -60); jet = true; fl = false
			"fall": vel = Vector2(40, 380); fl = false
			"turn": left = true
		var holder: Node2D = r[1]
		var aim: Vector2 = holder.global_position + Vector2(-300 if left else 300, -40)
		for k in 90:
			rig.update_visuals(vel, aim, jet, fl, 1.0 / 60.0, false, false)
		if st == "fire":
			rig.fire_effects(0)
			for k in 2:
				rig.update_visuals(vel, aim, jet, fl, 1.0 / 60.0, false, false)
		if st == "head":
			holder.scale = Vector2(zoom * 2.2, zoom * 2.2)
			holder.position.y = CELL.y * 0.52 + 58 * zoom * 2.2
		# ground line under feet
	ground.position = Vector2.ZERO
	ground.size = Vector2.ZERO
	await process_frame
	await process_frame
	await RenderingServer.frame_post_draw
	var img := sv.get_texture().get_image()
	img.save_png(out)
	print("saved ", out, " ", img.get_size())
	quit()
