extends SceneTree
## Dev smoke test: applies every clothing / footwear / armour option and every cosmetic variant to a real PlayerRig,
## runs a few animation frames and opens the customise menu. Errors show up on stderr.
func _init() -> void:
	var n := 0
	var rigs: Array = []
	var holder := Node2D.new()
	root.add_child(holder)
	var rig := PlayerRig.new()
	rig.preview = true
	holder.add_child(rig)
	await process_frame
	var cos_ids: Array = [""]
	cos_ids.append_array(CosmeticCatalog.DEFS.keys())
	for av in ["male", "female"]:
		for cid in cos_ids:
			var vars := 1
			if cid != "":
				vars = maxi(1, (CosmeticCatalog.DEFS[cid].get("variants", []) as Array).size())
			for v in vars:
				var app := Appearance.default_for(av)
				var p := Appearance.resolve(app, cid, v)
				rig.apply_appearance(p)
				for st in [[Vector2.ZERO, false, true], [Vector2(200, 0), false, true], [Vector2(240, -60), true, false], [Vector2(40, 300), false, false]]:
					for k in 6:
						rig.update_visuals(st[0], Vector2(300, -40), st[1], st[2], 1.0 / 60.0, false, false)
				n += 1
	# every option of every clothing table on both avatars
	for av in ["male", "female"]:
		for key in ["top", "bottom", "boots", "gloves", "armor", "shoulder", "kneepads", "jetpack", "back"]:
			var table: Dictionary = {}
			match key:
				"top": table = AppearanceCatalog.TOPS
				"bottom": table = AppearanceCatalog.BOTTOMS
				"boots": table = AppearanceCatalog.BOOTS
				"gloves": table = AppearanceCatalog.GLOVES
				"armor": table = AppearanceCatalog.ARMOR
				"shoulder": table = AppearanceCatalog.SHOULDER
				"kneepads": table = AppearanceCatalog.KNEEPADS
				"jetpack": table = AppearanceCatalog.JETPACKS
				"back": table = AppearanceCatalog.BACK
			for id in table:
				var app := Appearance.default_for(av)
				app[key] = id
				rig.apply_appearance(Appearance.resolve(app, "", 0))
				for k in 4:
					rig.update_visuals(Vector2(240, -60), Vector2(300, -40), true, false, 1.0 / 60.0, false, false)
				n += 1
	print("SMOKE rigs applied: ", n)
	var menu := CustomizeMenu.new()
	root.add_child(menu)
	await process_frame
	menu.open()
	await process_frame
	await process_frame
	print("SMOKE menu opened")
	quit()
