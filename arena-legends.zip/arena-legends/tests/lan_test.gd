extends SceneTree
## Headless LAN integration test: run TWO copies of this (one "host", one "client") on the same computer.
##   godot --headless --path <project> --script res://tests/lan_test.gd -- host   <steps>
##   godot --headless --path <project> --script res://tests/lan_test.gd -- client <steps> [ip] [port]
## Steps are letters: m = movement sync, c = combat (shots, damage, kill, respawn), g = grenade (host and client),
## p = weapon pickup, k = kill limit -> match over -> back to lobby, d = disconnect handling, r = discover (LAN discovery).
## Every check prints "TEST PASS ..." or "TEST FAIL ...". See tests/README.md.

var role := ""
var steps := ""
var ip := "127.0.0.1"
var port := 24680
var net: Node
var t0 := 0.0
const SpawnSafety = preload("res://art/scripts/spawn_safety.gd")


func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	role = args[0]
	steps = args[1] if args.size() > 1 else "m"
	if args.size() > 2:
		ip = args[2]
	if args.size() > 3:
		port = int(args[3])
	t0 = Time.get_ticks_msec() / 1000.0
	change_scene_to_file("res://test_arena.tscn")
	_run.call_deferred()


func log_(msg: String) -> void:
	print("[%s %5.1f] %s" % [role, Time.get_ticks_msec() / 1000.0 - t0, msg])


func check(ok: bool, what: String) -> void:
	print("TEST %s [%s] %s" % ["PASS" if ok else "FAIL", role, what])


func wait(sec: float) -> void:
	await create_timer(sec).timeout


func until(cond: Callable, timeout: float, what: String) -> bool:
	var t := 0.0
	while t < timeout:
		if cond.call():
			return true
		await create_timer(0.1).timeout
		t += 0.1
	log_("TIMEOUT waiting for: " + what)
	return false


func lp() -> Node2D:
	return net.game.local_player


func puppet(id: int) -> Node2D:
	return net.game.puppets.get(id)


func _run() -> void:
	await wait(1.5)
	net = root.get_node("/root/Net")
	if role == "host":
		await _host()
	else:
		await _client()
	log_("DONE")
	await wait(0.5)
	quit()


func _host() -> void:
	var err: String = net.host_game("Test Room", (OS.get_environment("LAN_MAP") if OS.get_environment("LAN_MAP") != "" else "abandoned_station"), 4, 3, 24680, ({"time_limit": 3, "weapon_rate": 3, "throwable_rate": 0} if steps.contains("o") else {}))
	check(err == "", "host_game returned no error (%s)" % err)
	if steps.contains("r"):
		await wait(12.0)
	var ok: bool = await until(func() -> bool: return net.roster.size() >= 2, 40.0, "client to join")
	check(ok, "client joined the lobby (%s)" % str(net.roster))
	await wait(1.0)
	if steps.contains("o"):
		net.set_my_name("Hosty")
		net.set_my_look(2)
		await wait(1.5)
		var cid: int = int(net.roster.keys()[1])
		check(str(net.roster[1]["name"]) == "Hosty" and int(net.roster[1]["look"]) == 2, "host name/colour set in lobby")
		check(str(net.roster[cid]["name"]) == "Zed", "client's lobby name reached the host (%s)" % str(net.roster[cid]["name"]))
		check(int(net.roster[cid]["look"]) == 4, "client got its free colour and was refused the taken one (look %d)" % int(net.roster[cid]["look"]))
	net.host_start_match()
	ok = await until(func() -> bool: return net.phase == net.Phase.PLAYING, 40.0, "PLAYING")
	check(ok, "match reached PLAYING")
	log_("spawn host=%s puppet(client)=%s" % [str(lp().global_position), str(puppet(net.roster.keys()[1]).global_position) if puppet(net.roster.keys()[1]) else "none"])
	await wait(1.0)
	await _scenarios()


func _client() -> void:
	if steps.contains("r"):
		# discovery: look for the host instead of typing its address
		net.discovery.start_searching()
		var found: bool = await until(func() -> bool: return not net.discovery.hosts.is_empty(), 25.0, "discovery")
		check(found, "LAN discovery found a host: %s" % str(net.discovery.hosts.keys()))
		if found:
			var h: Dictionary = net.discovery.hosts.values()[0]
			ip = h["ip"]
			port = h["port"]
			check(str(h["room"]) == "Test Room", "discovery room name is right (%s)" % h["room"])
		net.discovery.stop_searching()
	net.join_game(ip, port)
	var ok: bool = await until(func() -> bool: return net.phase == net.Phase.LOBBY, 15.0, "lobby")
	check(ok, "joined the host's lobby")
	if steps.contains("o"):
		net.set_my_name("Zed")
		net.set_my_look(2)             # taken by the host: must be refused
		await wait(0.5)
		net.set_my_look(4)
		await wait(1.0)
		check(int(net.settings.get("time_limit", -1)) == 3 and int(net.settings.get("weapon_rate", -1)) == 3 and int(net.settings.get("throwable_rate", -1)) == 0, "host's time limit / spawn rates reached the client (%s)" % str(net.settings))
	ok = await until(func() -> bool: return net.phase == net.Phase.PLAYING, 60.0, "PLAYING")
	check(ok, "match reached PLAYING")
	await wait(1.0)
	await _scenarios()


func _scenarios() -> void:
	for ch in steps:
		match ch:
			"m": await _step_move()
			"c": await _step_combat()
			"g": await _step_grenade()
			"p": await _step_pickup()
			"k": await _step_end()
			"d": await _step_disconnect()
			"o": await _step_options()


# ----------------------------------------------------------------------------------------------- movement
func _step_move() -> void:
	log_("--- movement sync")
	var other: int = 1 if role == "client" else int(net.roster.keys()[1])
	var p := puppet(other)
	check(p != null and p.visible, "puppet of the other player exists and is visible")
	var before: Vector2 = p.global_position if p else Vector2.ZERO
	if role == "host":
		Input.action_press("move_right")
		await wait(1.5)
		Input.action_release("move_right")
		await wait(0.5)
		log_("host local pos now %s" % str(lp().global_position))
	else:
		await wait(2.0)
		var after: Vector2 = p.global_position
		log_("client sees host puppet %s -> %s" % [str(before), str(after)])
		check(after.x - before.x > 60.0, "host's movement (move_right) is visible on the client (dx=%.0f)" % (after.x - before.x))
	await wait(1.0)


# ----------------------------------------------------------------------------------------------- combat
func _step_combat() -> void:
	log_("--- combat")
	# the CLIENT shoots the HOST. Put the client 220 px to the right of the host, both on safe ground.
	if role == "client":
		var host_pos: Vector2 = puppet(1).global_position
		var spot: Vector2 = NetSpawn.resolve_near(lp().get_world_2d().direct_space_state, host_pos + Vector2(-220, 0), [lp().get_rid()])
		current_scene.net_place_local(spot)
		log_("client moved next to host: %s (host puppet %s)" % [str(spot), str(host_pos)])
	await wait(1.5)
	if role == "host":
		var hp0: int = lp().health
		await wait(0.5)
		# wait for the shots to land
		var hit: bool = await until(func() -> bool: return lp().health < hp0 or lp().is_dead, 12.0, "host to be hit")
		check(hit, "host took damage from the client's bullets (hp %d -> %d)" % [hp0, lp().health])
		var died: bool = await until(func() -> bool: return lp().is_dead or lp().health <= 0, 20.0, "host death")
		check(died, "host died (host-authoritative kill)")
		await wait(0.5)
		log_("scores now %s" % str(net.game.scores))
		check(int(net.game.scores[net.roster.keys()[1]]["kills"]) >= 1, "client got the kill credit")
		var pos_dead: Vector2 = lp().global_position
		var back: bool = await until(func() -> bool: return not lp().is_dead and lp().visible, 8.0, "respawn")
		check(back, "host respawned (health %d, at %s)" % [lp().health, str(lp().global_position)])
		check(lp().health == 100, "respawn restored full health")
	else:
		# aim left at the host and keep firing until it dies (client does not decide damage; the host does)
		var shots := 0
		var host_p := puppet(1)
		while shots < 80 and not (host_p.is_dead):
			var dir: Vector2 = (host_p.global_position - lp().visuals.muzzle.global_position).normalized()
			lp().aim_dir = dir
			lp().shoot(dir)
			shots += 1
			await wait(0.11)
			if shots == 6:
				log_("client sees host puppet hp=%d after 6 shots" % host_p.health)
		check(host_p.is_dead or shots >= 80, "client fired %d shots; host puppet dead=%s" % [shots, str(host_p.is_dead)])
		var k: bool = await until(func() -> bool: return int(net.game.scores.get(net.my_id(), {}).get("kills", 0)) >= 1, 6.0, "kill credit")
		check(k, "client's scoreboard shows its kill: %s" % str(net.game.scores))
		await wait(3.5)
		check(not host_p.is_dead and host_p.visible, "client sees the host respawn")
	await wait(1.0)


# ----------------------------------------------------------------------------------------------- grenades
func _step_grenade() -> void:
	log_("--- grenade")
	var grenade: ThrowableData = ThrowableCatalog.get_data("grenade")
	if role == "host":
		var cid: int = int(net.roster.keys()[1])
		var cp := puppet(cid)
		var hp0: int = cp.health
		net.game.host_throw(1, lp(), grenade, cp.global_position + Vector2(0, -30), Vector2.ZERO)
		log_("host threw a grenade at the client puppet (hp %d)" % hp0)
		await wait(3.5)
		check(cp.health < hp0 or cp.is_dead, "host-side grenade hurt the client puppet (hp %d)" % cp.health)
	else:
		var hp0: int = lp().health
		var seen := await until(func() -> bool: return not get_nodes_in_group("throwable").is_empty(), 3.0, "cosmetic grenade copy")
		check(seen, "client sees the host's thrown grenade (cosmetic copy)")
		var gone := await until(func() -> bool: return get_nodes_in_group("throwable").is_empty(), 5.0, "grenade to vanish")
		check(gone, "the cosmetic grenade went away after the explosion")
		check(lp().health < hp0 or lp().is_dead, "client was hurt by the host's grenade (hp %d -> %d, dead=%s)" % [hp0, lp().health, str(lp().is_dead)])
		await wait(3.5)
		# client throws one itself (request path)
		var before := get_nodes_in_group("throwable").size()
		net.game.client_throw(grenade, lp().global_position + Vector2(40, -20), Vector2(200, -100))
		var seen2 := await until(func() -> bool: return get_nodes_in_group("throwable").size() > before, 3.0, "own grenade copy")
		check(seen2, "client's own throw came back from the host as a cosmetic copy")
	await wait(3.0)


# ----------------------------------------------------------------------------------------------- pickups
func _step_pickup() -> void:
	log_("--- weapon pickup")
	if role == "client":
		await until(func() -> bool: return not lp().is_dead, 10.0, "alive")
		var pk: Node = null
		for n in get_nodes_in_group("weapon_pickup"):
			if not n.is_drop and n.net_id != "" and n._active and n.weapon.display_name != lp().weapon.display_name:
				pk = n
				break
		check(pk != null, "client has weapon pickups with network ids")
		if pk == null:
			return
		log_("going to pickup %s (%s) at %s" % [pk.net_id, pk.weapon.display_name, str(pk.global_position)])
		var w_before: WeaponData = lp().weapon
		var wname: String = pk.weapon.display_name
		# pickups can hang in mid air: pin the player on top of it while the pickup key is pressed
		for i in 14:
			current_scene.net_place_local(pk.global_position + Vector2(0, -10))
			await wait(0.05)
		var ev := InputEventAction.new()
		ev.action = "pickup"
		ev.pressed = true
		Input.parse_input_event(ev)
		for i in 6:
			current_scene.net_place_local(pk.global_position + Vector2(0, -10))
			await wait(0.05)
		var ev2 := InputEventAction.new()
		ev2.action = "pickup"
		ev2.pressed = false
		Input.parse_input_event(ev2)
		await wait(1.0)
		check(lp().weapon.display_name == wname or lp().weapons.size() > 1, "client picked up %s via the host (now %s, %d guns)" % [wname, lp().weapon.display_name, lp().weapons.size()])
		check(not pk._active, "the pickup disappeared on the client")
	else:
		await wait(6.0)
		var gone := 0
		for n in get_nodes_in_group("weapon_pickup"):
			if not n.is_drop and not n._active:
				gone += 1
		check(gone >= 1, "host sees the taken pickup disabled (%d)" % gone)
	await wait(2.0)


## A spot on the ground near `target` with nothing solid between it and the target (so test bullets can land).
func _clear_shot_spot(target: Vector2) -> Vector2:
	var space := lp().get_world_2d().direct_space_state
	for off in [-200.0, -140.0, -300.0, 200.0, 140.0, 300.0]:
		var spot: Vector2 = NetSpawn.resolve_near(space, target + Vector2(off, 0), [lp().get_rid()])
		var clear := true
		for h in [-10.0, -30.0, -50.0, -65.0]:           # feet, torso, muzzle and head height
			var q := PhysicsRayQueryParameters2D.create(spot + Vector2(0, h), target + Vector2(0, h), 1)
			if not space.intersect_ray(q).is_empty():
				clear = false
		if clear:
			return spot
	return NetSpawn.resolve_near(space, target + Vector2(200, 0), [lp().get_rid()])


# ----------------------------------------------------------------------------------------------- match end
func _step_end() -> void:
	log_("--- kill limit -> match over -> lobby")
	if role == "client":
		var host_p := puppet(1)
		var tries := 0
		await wait(2.5)                                   # let the host settle on the ground first
		while net.phase == net.Phase.PLAYING and tries < 900:
			if not host_p.is_dead and not lp().is_dead:
				if lp().global_position.distance_to(host_p.global_position) > 400.0 or absf(lp().global_position.y - host_p.global_position.y) > 40.0:
					current_scene.net_place_local(_clear_shot_spot(host_p.global_position))
				var dir: Vector2 = (host_p.global_position - lp().visuals.muzzle.global_position).normalized()
				lp().aim_dir = dir
				lp().shoot(dir)
			tries += 1
			if tries % 40 == 1:
				log_("kill loop: me %s host %s hostdead=%s hp=%d medead=%s playing=%s w=%s ammo=%d" % [str(lp().global_position), str(host_p.global_position), str(host_p.is_dead), host_p.health, str(lp().is_dead), str(net.game.playing), lp().weapon.display_name, lp().ammo])
			await wait(0.11)
		check(net.phase == net.Phase.ENDED or net.phase == net.Phase.LOBBY, "match ended (phase %d)" % net.phase)
	else:
		for i in 4:
			await wait(3.0)
			log_("host real pos %s layer=%d mask=%d dead=%s phys=%s" % [str(lp().global_position), lp().collision_layer, lp().collision_mask, str(lp().is_dead), str(lp().is_physics_processing())])
		var over: bool = await until(func() -> bool: return net.phase == net.Phase.ENDED, 120.0, "ENDED")
		check(over, "host: match ended at the kill limit; scores %s" % str(net.game.scores))
	var lobby: bool = await until(func() -> bool: return net.phase == net.Phase.LOBBY and current_scene != null and current_scene.has_method("net_prepare_match"), 20.0, "back to LOBBY")
	check(lobby, "returned to the lobby after the match")
	await wait(2.0)


# ----------------------------------------------------------------------------------------------- lobby options
func _step_options() -> void:
	log_("--- options: time limit + spawn rates")
	var g = net.game
	check(absf(g.time_limit - 180.0) < 0.1 and g.time_left > 100.0, "match clock started at the 3 min limit (left %.0f)" % g.time_left)
	check(get_nodes_in_group("throwable_pickup").is_empty(), "throwables 'Off': none lying around (%d)" % get_nodes_in_group("throwable_pickup").size())
	if role == "host":
		var faster := true
		for n in get_nodes_in_group("weapon_pickup"):
			if not n.is_drop and n.respawn_time > 6.7:
				faster = false
		check(faster, "weapon respawn timers are 3x shorter (<= 6.7s)")
		await wait(2.0)
		g.time_left = 3.0                          # fast-forward the host's clock
		var over: bool = await until(func() -> bool: return net.phase == net.Phase.ENDED, 8.0, "time up")
		check(over, "match ended when the time limit ran out (scores %s)" % str(g.scores))
	else:
		await wait(2.0)
		var left0: float = g.time_left
		await wait(2.5)
		check(g.time_left < left0 + 0.5, "client clock follows the host (%.0f)" % g.time_left)
		var over: bool = await until(func() -> bool: return net.phase == net.Phase.ENDED, 10.0, "time up")
		check(over, "client saw the match end on time")
	await wait(1.0)


# ----------------------------------------------------------------------------------------------- disconnects
func _step_disconnect() -> void:
	log_("--- disconnect")
	if role == "client":
		await wait(1.0)
		net.leave("test: client leaves")
		await wait(1.5)
		check(net.mode == net.Mode.OFFLINE, "client is offline after leaving")
	else:
		var gone: bool = await until(func() -> bool: return net.roster.size() == 1, 15.0, "client to be removed")
		check(gone, "host noticed the client leaving (roster %s)" % str(net.roster))
		await wait(1.0)
		net.leave("test: host closes")
		await wait(1.0)
		check(net.mode == net.Mode.OFFLINE, "host is offline after closing")
