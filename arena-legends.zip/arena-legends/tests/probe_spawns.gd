extends SceneTree
## Dev tool: lists valid network spawn spots on a grid for a map.
##   godot --headless --path . --script res://tests/probe_spawns.gd -- abandoned_station
func _initialize() -> void:
	change_scene_to_file("res://test_arena.tscn")
	_run.call_deferred(OS.get_cmdline_user_args()[0])
func _run(map_id: String) -> void:
	await create_timer(1.0).timeout
	var arena := current_scene
	await arena.net_prepare_match(map_id)
	await physics_frame
	var player: Node2D = arena.get_node("Player")
	var space := player.get_world_2d().direct_space_state
	var ex: Array[RID] = [player.get_rid()]
	var out: Array = []
	for x in range(100, 5400, 150):
		var last_y := -1000.0
		for y in range(0, 2700, 40):
			var s := NetSpawn.resolve_column(space, Vector2(x, y), ex)
			if s != Vector2.INF and absf(s.y - last_y) > 60.0:
				out.append(s)
				last_y = s.y
	print("SPAWNS ", map_id, " ", out.size())
	var line := ""
	for s in out:
		line += "(%d,%d) " % [s.x, s.y]
	print(line)
	for c in arena.net_spawn_candidates():
		print("candidate ", c, " -> ", NetSpawn.resolve_near(space, c, ex))
	quit()
