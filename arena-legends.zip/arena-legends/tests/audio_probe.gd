extends SceneTree
func _init() -> void:
	await process_frame
	await process_frame
	var mgr := root.get_node("AudioMgr")
	print("buses: ", AudioServer.get_bus_index("SFX"), " ", AudioServer.get_bus_index("Music"))
	paused = true
	await process_frame; await process_frame
	print("paused -> sfx muted: ", AudioServer.is_bus_mute(AudioServer.get_bus_index("SFX")))
	GameSettings.sfx_volume = 0.5
	paused = false
	await process_frame; await process_frame; await process_frame
	print("playing -> sfx muted: ", AudioServer.is_bus_mute(AudioServer.get_bus_index("SFX")), " db ", AudioServer.get_bus_volume_db(AudioServer.get_bus_index("SFX")), " music playing: ", mgr._music.playing)
	var a := AudioStreamPlayer2D.new(); root.add_child(a); print("new player bus: ", a.bus)
	quit()
