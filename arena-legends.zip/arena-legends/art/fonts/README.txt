Inter (Inter-Medium.otf, Inter-Bold.otf) by Rasmus Andersson, https://rsms.me/inter
Licensed under the SIL Open Font License 1.1 (https://openfontlicense.org). Free to use and bundle in games.
