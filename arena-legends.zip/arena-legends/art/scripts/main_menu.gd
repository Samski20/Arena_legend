class_name MainMenu
extends CanvasLayer
## Top-level main menu: PLAY GAME / MULTIPLAYER / SETTINGS.
## Starts as the entry point; transitions into the arena with a MatchConfig or opens LAN / Settings.

signal play_requested(config: MatchConfig)
signal multiplayer_requested
signal settings_requested

var _root: Control
var _main_panel: PanelContainer
var _mode_panel: Control
var _custom_panel: CanvasLayer
var _current_config: MatchConfig
var _dim: ColorRect


func _ready() -> void:
	layer = 120
	process_mode = Node.PROCESS_MODE_ALWAYS
	_current_config = MatchConfig.new()
	_build()
	UITheme.pop_in(_main_panel)


func _build() -> void:
	_dim = ColorRect.new()
	_dim.color = Color(UITheme.SCRIM.r, UITheme.SCRIM.g, UITheme.SCRIM.b, 0.88)
	_dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_dim.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_dim)

	# subtle animated background bars
	var bg := ColorRect.new()
	bg.color = Color(0.04, 0.06, 0.07, 1)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_dim.add_child(bg)
	var accent_strip := ColorRect.new()
	accent_strip.color = Color(UITheme.PRIMARY.r, UITheme.PRIMARY.g, UITheme.PRIMARY.b, 0.12)
	accent_strip.set_anchors_preset(Control.PRESET_LEFT_WIDE)
	accent_strip.offset_right = 8
	_dim.add_child(accent_strip)

	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_root)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.add_child(center)

	_main_panel = PanelContainer.new()
	_main_panel.custom_minimum_size = Vector2(420, 0)
	_main_panel.add_theme_stylebox_override("panel", UITheme.panel_box(28, 24))
	center.add_child(_main_panel)

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 14)
	_main_panel.add_child(col)

	var title := Label.new()
	title.text = "ARENA LEGENDS"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 32)
	title.add_theme_font_override("font", UITheme.font(true))
	title.add_theme_color_override("font_color", UITheme.ON_SURFACE)
	col.add_child(title)

	var sub := Label.new()
	sub.text = "Side-view combat  ·  Jetpack  ·  LAN"
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_font_size_override("font_size", 14)
	sub.add_theme_color_override("font_color", UITheme.ON_VARIANT)
	col.add_child(sub)

	col.add_child(HSeparator.new())

	_add_primary_btn(col, "PLAY GAME", _on_play)
	_add_tonal_btn(col, "MULTIPLAYER", _on_multiplayer)
	_add_tonal_btn(col, "SETTINGS", _on_settings)

	var ver := Label.new()
	ver.text = "v34  ·  Android feel"
	ver.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ver.add_theme_font_size_override("font_size", 12)
	ver.add_theme_color_override("font_color", UITheme.ON_VARIANT)
	col.add_child(ver)

	# safe area padding
	var insets := UITheme.safe_insets()
	if insets != Vector4.ZERO:
		_root.offset_left = insets.x
		_root.offset_top = insets.y
		_root.offset_right = -insets.z
		_root.offset_bottom = -insets.w


func _add_primary_btn(parent: VBoxContainer, text: String, cb: Callable) -> void:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 58)
	b.add_theme_font_size_override("font_size", 20)
	UITheme.style_button(b, "primary")
	b.pressed.connect(cb)
	parent.add_child(b)


func _add_tonal_btn(parent: VBoxContainer, text: String, cb: Callable) -> void:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 54)
	b.add_theme_font_size_override("font_size", 18)
	UITheme.style_button(b, "tonal")
	b.pressed.connect(cb)
	parent.add_child(b)


func _on_play() -> void:
	UITheme.haptic(10)
	_show_mode_select()


func _on_multiplayer() -> void:
	UITheme.haptic(10)
	multiplayer_requested.emit()


func _on_settings() -> void:
	UITheme.haptic(10)
	settings_requested.emit()


func _show_mode_select() -> void:
	_main_panel.visible = false
	if _mode_panel != null:
		_mode_panel.queue_free()
	_mode_panel = _build_mode_panel()
	_root.add_child(_mode_panel)
	UITheme.pop_in(_mode_panel.get_child(0) as Control)


func _build_mode_panel() -> Control:
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(460, 0)
	panel.add_theme_stylebox_override("panel", UITheme.panel_box(28, 22))
	center.add_child(panel)

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	panel.add_child(col)

	var head := Label.new()
	head.text = "SELECT MODE"
	head.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	head.add_theme_font_size_override("font_size", 24)
	head.add_theme_font_override("font", UITheme.font(true))
	head.add_theme_color_override("font_color", UITheme.ON_SURFACE)
	col.add_child(head)

	_mode_btn(col, "SURVIVAL", "Score attack vs bots. Track personal records.", MatchConfig.Mode.SURVIVAL)
	_mode_btn(col, "DEATHMATCH", "Free-for-all. First to kill limit or time wins.", MatchConfig.Mode.DEATHMATCH)
	_mode_btn(col, "TRAINING", "Practice movement, jetpack, weapons & throwables.", MatchConfig.Mode.TRAINING)
	_mode_btn(col, "CUSTOM MATCH", "Full control over rules, weapons, bots & modifiers.", MatchConfig.Mode.CUSTOM)

	var back := Button.new()
	back.text = "BACK"
	back.custom_minimum_size = Vector2(0, 48)
	UITheme.style_button(back, "tonal")
	back.pressed.connect(func() -> void:
		_mode_panel.queue_free()
		_mode_panel = null
		_main_panel.visible = true)
	col.add_child(back)
	return center


func _mode_btn(parent: VBoxContainer, title: String, desc: String, mode: MatchConfig.Mode) -> void:
	var b := Button.new()
	b.custom_minimum_size = Vector2(0, 64)
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.add_theme_font_size_override("font_size", 17)
	UITheme.style_button(b, "tonal")
	b.text = "%s\n%s" % [title, desc]
	b.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	b.pressed.connect(func() -> void:
		UITheme.haptic(10)
		_current_config = MatchConfig.new()
		_current_config.mode = mode
		if mode == MatchConfig.Mode.TRAINING:
			_current_config.duration_sec = 0
			_current_config.kill_limit = 0
			_current_config.bot_count = 0
		elif mode == MatchConfig.Mode.SURVIVAL:
			_current_config.duration_sec = 0
			_current_config.kill_limit = 0
			_current_config.bot_count = 4
		_open_custom_or_start(mode))
	parent.add_child(b)


func _open_custom_or_start(mode: MatchConfig.Mode) -> void:
	# Always open the configuration screen so the player can tweak
	_show_custom_match()


func _show_custom_match() -> void:
	if _mode_panel != null:
		_mode_panel.visible = false
	if _custom_panel != null:
		_custom_panel.queue_free()
		_custom_panel = null
	var setup_ui := MatchSetupUI.new()
	setup_ui.setup(_current_config)
	setup_ui.back_pressed.connect(_on_setup_back)
	setup_ui.start_pressed.connect(_on_setup_start)
	_custom_panel = setup_ui
	add_child(setup_ui)  # CanvasLayer child of MainMenu (also CanvasLayer)


func _on_setup_back() -> void:
	if _custom_panel != null:
		_custom_panel.queue_free()
		_custom_panel = null
	if _mode_panel != null:
		_mode_panel.visible = true
	else:
		_main_panel.visible = true


func _on_setup_start(cfg: MatchConfig) -> void:
	_current_config = cfg
	play_requested.emit(cfg)


func show_main() -> void:
	if _custom_panel != null:
		_custom_panel.queue_free()
		_custom_panel = null
	if _mode_panel != null:
		_mode_panel.queue_free()
		_mode_panel = null
	_main_panel.visible = true
	visible = true
