extends Node2D
## Main arena controller: owns the map selection UI and swaps the active map scene.
## The menu remains usable while gameplay is paused and supports touch input.

const MapRegistry = preload("res://art/scripts/map_registry.gd")
const SpawnSafety = preload("res://art/scripts/spawn_safety.gd")
const BotDifficulty = preload("res://art/scripts/bot_difficulty.gd")

const PLAYER_SPAWNS := {
	"abandoned_station": Vector2(1200, 1440),
	"cavern_isles": Vector2(364, 1782)
}
const BOT_SPAWNS := {
	"abandoned_station": [Vector2(400, 1440), Vector2(2800, 1440)],
	"cavern_isles": [Vector2(4830, 1725), Vector2(2740, 1272)]
}
# The two weapon pickups that live in the main scene are moved onto each map's surfaces.
const ROOT_PICKUP_SPOTS := {
	"abandoned_station": [Vector2(960, 920), Vector2(1600, 1090)],
	"cavern_isles": [Vector2(1420, 2070), Vector2(3356, 1700)]
}

var active_map_id := "abandoned_station"
var _menu_layer: CanvasLayer
var _shortcut_layer: CanvasLayer
var _menu_open := false
var _map_host: Node2D
var _map_buttons: Array[Button] = []
var _main_panel: PanelContainer
var _settings_panel: SettingsMenu
var _dim: ColorRect
var _diff_button: Button
var _diff_hint: Label
var _lan_menu: LanMenu
var _net_menu: Control            # small in-match menu (resume / leave); the game never pauses in a network match
var _notice_layer: CanvasLayer
var _main_menu: MainMenu
var _customize_menu: CustomizeMenu
var _pause_menu: Control
var _settings_return := ""          # where BACK in the settings screen goes: "" (old map menu), "main" or "pause"


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_map_host = get_node_or_null("MapHost") as Node2D
	if _map_host == null:
		_map_host = Node2D.new()
		_map_host.name = "MapHost"
		add_child(_map_host)
	active_map_id = "abandoned_station"
	set_meta("active_map_id", active_map_id)
	_create_menu()
	GameSettings.ensure_loaded()
	GameSettings.apply_resolution()                                  # Settings > Resolution (Fast / Sharp)
	add_child(preload("res://art/scripts/fps_overlay.gd").new())     # FPS counter (Settings > Show FPS)
	_lan_menu = LanMenu.new()
	_lan_menu.visible = false
	_lan_menu.back_pressed.connect(func() -> void:
		_lan_menu.close()
		_show_front_menu())
	add_child(_lan_menu)
	_main_menu = MainMenu.new()
	_main_menu.visible = false
	_main_menu.multiplayer_pressed.connect(_open_lan_menu)
	_main_menu.settings_pressed.connect(func() -> void: _open_settings_from("main"))
	_main_menu.start_match.connect(_start_configured_match)
	_main_menu.customize_pressed.connect(func() -> void:
		_main_menu.close()
		_customize_menu.open())
	add_child(_main_menu)
	_customize_menu = CustomizeMenu.new()
	_customize_menu.closed.connect(func() -> void:
		_apply_local_look()
		_main_menu.open())
	add_child(_customize_menu)
	_apply_local_look()
	if Net.mode != Net.Mode.OFFLINE and Net.phase == Net.Phase.LOBBY:
		# back from a LAN match: the connection is still up, so go straight to the lobby
		_menu_layer.visible = false
		_lan_menu.open()
		get_tree().paused = false
	elif Net.phase >= Net.Phase.LOADING and Net.mode != Net.Mode.OFFLINE:
		_menu_layer.visible = false             # joining a match that is already loading: net_prepare_match drives the scene
	elif MapRegistry.restart_map_id != "":
		# "play again" after a match: straight back into the same map, no map menu
		var again: String = MapRegistry.restart_map_id
		MapRegistry.restart_map_id = ""
		_menu_layer.visible = false
		_on_map_selected.call_deferred(again)
	elif MatchSession.restart_pending and MatchSession.cfg != null:
		# "play again": the scene was reloaded, so start the same configured match straight away
		_menu_layer.visible = false
		_start_configured_match.call_deferred(MatchSession.cfg)
	else:
		_menu_layer.visible = false
		_show_front_menu()
	var why := Net.consume_notice()
	if why != "":
		_show_notice(why)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if Net.match_active():
			_toggle_net_menu()
			return
		if _lan_menu != null and _lan_menu.visible:
			return
		if _main_menu != null and _main_menu.visible:
			return                                   # the main menu handles its own BACK
		if MatchSession.active:
			_toggle_pause_menu()
			return
		if _menu_open:
			close_map_menu()
		else:
			open_map_menu()


func open_map_menu() -> void:
	if _menu_layer == null:
		return
	_menu_open = true
	_close_settings()
	_menu_layer.visible = true
	get_tree().paused = true
	_update_map_buttons()
	(func() -> void: UITheme.pop_in(_main_panel)).call_deferred()      # panel pops in (after it has been laid out)


func close_map_menu() -> void:
	_menu_open = false
	_menu_layer.visible = false
	get_tree().paused = false
	if _shortcut_layer != null:
		var shortcut := _shortcut_layer.get_node_or_null("MapMenuShortcut") as Button
		if shortcut != null:
			shortcut.visible = true


func _create_menu() -> void:
	_menu_layer = CanvasLayer.new()
	_menu_layer.name = "MapSelectionUI"
	_menu_layer.layer = 100
	_menu_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_menu_layer)

	var dim := ColorRect.new()
	dim.name = "DimBackground"
	dim.color = Color(UITheme.SCRIM.r, UITheme.SCRIM.g, UITheme.SCRIM.b, 0.82)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_menu_layer.add_child(dim)
	_dim = dim

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_menu_layer.add_child(center)

	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(440, 0)
	panel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	panel.add_theme_stylebox_override("panel", _panel_style())
	center.add_child(panel)
	_main_panel = panel

	_settings_panel = SettingsMenu.new()
	_settings_panel.visible = false
	_settings_panel.back_pressed.connect(_close_settings)
	_settings_panel.edit_layout_pressed.connect(_start_layout_edit)
	center.add_child(_settings_panel)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 12)
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_child(column)

	var heading := Label.new()
	heading.text = "ARENA LEGENDS"
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	heading.add_theme_font_size_override("font_size", 28)
	heading.add_theme_font_override("font", UITheme.font(true))
	heading.add_theme_color_override("font_color", UITheme.ON_SURFACE)
	column.add_child(heading)

	var subheading := Label.new()
	subheading.text = "SELECT YOUR BATTLEFIELD"
	subheading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subheading.add_theme_font_size_override("font_size", 15)
	subheading.add_theme_color_override("font_color", UITheme.ON_VARIANT)
	column.add_child(subheading)

	var separator := HSeparator.new()
	column.add_child(separator)

	for map_info in MapRegistry.all_maps():
		var button := Button.new()
		button.custom_minimum_size = Vector2(0, 66)
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.add_theme_font_size_override("font_size", 18)
		UITheme.style_button(button, "tonal")
		button.text = "%s\n%s" % [map_info["name"], map_info["description"]]
		button.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		button.pressed.connect(_on_map_selected.bind(map_info["id"]))
		column.add_child(button)
		_map_buttons.append(button)

	# BOT DIFFICULTY: tap to cycle ROOKIE > NORMAL > VETERAN > LEGEND. Applies to the bots right away and is saved.
	_diff_button = Button.new()
	_diff_button.custom_minimum_size = Vector2(0, 54)
	_diff_button.add_theme_font_size_override("font_size", 18)
	_diff_button.pressed.connect(_on_difficulty_pressed)
	column.add_child(_diff_button)
	_diff_hint = Label.new()
	_diff_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_diff_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_diff_hint.custom_minimum_size = Vector2(380, 0)
	_diff_hint.add_theme_font_size_override("font_size", 13)
	_diff_hint.add_theme_color_override("font_color", UITheme.ON_VARIANT)
	column.add_child(_diff_hint)
	GameSettings.ensure_loaded()
	_refresh_difficulty_button()

	var lan_button := Button.new()
	lan_button.custom_minimum_size = Vector2(0, 54)
	lan_button.text = "MULTIPLAYER  (LAN / same Wi-Fi)"
	lan_button.add_theme_font_size_override("font_size", 18)
	UITheme.style_button(lan_button, "tonal")
	lan_button.pressed.connect(_open_lan_menu)
	column.add_child(lan_button)

	var settings_button := Button.new()
	settings_button.custom_minimum_size = Vector2(0, 54)
	settings_button.text = "SETTINGS  (touch controls)"
	settings_button.add_theme_font_size_override("font_size", 18)
	UITheme.style_button(settings_button, "tonal")
	settings_button.pressed.connect(_open_settings)
	column.add_child(settings_button)

	var resume_button := Button.new()
	resume_button.custom_minimum_size = Vector2(0, 54)
	resume_button.text = "RESUME MATCH"
	resume_button.add_theme_font_size_override("font_size", 18)
	UITheme.style_button(resume_button, "primary")
	resume_button.pressed.connect(close_map_menu)
	column.add_child(resume_button)

	var hint := Label.new()
	hint.text = "ESC: resume match"
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_font_size_override("font_size", 13)
	hint.add_theme_color_override("font_color", UITheme.ON_VARIANT)
	column.add_child(hint)

	# A separate layer keeps the map shortcut visible when the menu overlay is hidden.
	_shortcut_layer = CanvasLayer.new()
	_shortcut_layer.name = "MapShortcutUI"
	_shortcut_layer.layer = 90
	_shortcut_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_shortcut_layer)
	var shortcut := Button.new()
	shortcut.name = "MapMenuShortcut"
	shortcut.text = "MENU"
	shortcut.position = Vector2(18, 18)
	shortcut.size = Vector2(90, 44)
	shortcut.add_theme_font_size_override("font_size", 15)
	UITheme.style_button(shortcut, "tonal")
	var sc_style := UITheme.box(Color(UITheme.SURFACE.r, UITheme.SURFACE.g, UITheme.SURFACE.b, 0.62), 22, false, 14, 6)
	shortcut.add_theme_stylebox_override("normal", sc_style)             # translucent so it never fights the game view
	shortcut.add_theme_color_override("font_color", UITheme.ON_SURFACE)
	shortcut.pressed.connect(func() -> void:
		if Net.match_active():
			_toggle_net_menu()
		elif MatchSession.active:
			_toggle_pause_menu()
		else:
			open_map_menu())
	_shortcut_layer.add_child(shortcut)
	shortcut.visible = false


func _on_difficulty_pressed() -> void:
	GameSettings.bot_difficulty = (BotDifficulty.level() + 1) % BotDifficulty.NAMES.size()
	GameSettings.save()
	_refresh_difficulty_button()
	get_tree().call_group("bot", "apply_difficulty")      # bots change right now: health, aim, guns, bombs


func _refresh_difficulty_button() -> void:
	if _diff_button == null:
		return
	var tint: Color = [Color("2f5a3c"), Color("2f4f6b"), Color("6b5a2f"), Color("7a2f2f")][BotDifficulty.level()]
	_diff_button.text = "BOT DIFFICULTY:  %s   (tap to change)" % BotDifficulty.level_name()
	_diff_button.add_theme_stylebox_override("normal", _button_style(tint))
	_diff_button.add_theme_stylebox_override("hover", _button_style(tint.lightened(0.15)))
	_diff_button.add_theme_stylebox_override("pressed", _button_style(tint.lightened(0.3)))
	_diff_hint.text = BotDifficulty.description()


func _open_settings() -> void:
	_main_panel.visible = false
	_settings_panel.visible = true
	_dim.color.a = 0.30            # lighter, so the sticks and buttons in the corners stay visible while you tune them


# Hides the menu (the game stays paused) and lets the player drag the touch controls around.
func _start_layout_edit() -> void:
	var editors := get_tree().get_nodes_in_group("touch_controls")
	if editors.is_empty():
		return
	var touch := editors[0] as TouchControls
	_menu_layer.visible = false
	if _shortcut_layer != null:
		_shortcut_layer.visible = false
	touch.edit_finished.connect(_end_layout_edit, CONNECT_ONE_SHOT)
	touch.begin_edit()


func _end_layout_edit() -> void:
	_menu_layer.visible = true
	if _shortcut_layer != null:
		_shortcut_layer.visible = true
	_open_settings()


func _close_settings() -> void:
	_settings_panel.visible = false
	_main_panel.visible = true
	_dim.color.a = 0.82
	var back := _settings_return
	_settings_return = ""
	if back == "main":
		_menu_layer.visible = false
		_main_menu.open()
	elif back == "pause":
		_menu_layer.visible = false
		if _pause_menu != null:
			_pause_menu.visible = true


func _panel_style() -> StyleBoxFlat:
	return UITheme.panel_box(24, 22)


# Colour-tinted tonal button (the bot-difficulty button uses this so its colour still tells the level).
func _button_style(color: Color) -> StyleBoxFlat:
	var role := UITheme.role_of(color)
	var fill := color.lerp(UITheme.SURFACE_3, 0.35)
	if role == "danger":
		fill = UITheme.ERROR_CONT
	var style := UITheme.box(fill, 24, true, 20, 10)
	return style


func _update_map_buttons() -> void:
	var infos := MapRegistry.all_maps()
	for i in mini(_map_buttons.size(), infos.size()):
		var info: Dictionary = infos[i]
		var prefix := "▶  " if info["id"] == active_map_id else "   "
		_map_buttons[i].text = "%s%s\n%s" % [prefix, info["name"], info["description"]]


func _on_map_selected(map_id: String) -> void:
	var info := MapRegistry.get_map(map_id)
	if info.is_empty():
		push_warning("Map selection ignored: unknown map id '%s'." % map_id)
		return
	var map_changed := map_id != active_map_id
	if map_changed:
		if not _load_map(map_id, str(info["scene"])):
			return
		active_map_id = map_id
		set_meta("active_map_id", active_map_id)
		_position_fighters(map_id)
	close_map_menu()                                  # unpauses, so the physics space can update
	if map_changed:
		get_tree().call_group("bot", "apply_difficulty")   # new map = new bomb pool for the bots
		_place_bots_safely(map_id)
	var shortcut := _shortcut_layer.get_node_or_null("MapMenuShortcut") as Button
	if shortcut != null:
		shortcut.visible = true


func _load_map(map_id: String, scene_path: String, no_bots := false) -> bool:
	if not ResourceLoader.exists(scene_path):
		push_error("Map scene does not exist: %s" % scene_path)
		return false
	var packed := load(scene_path) as PackedScene
	if packed == null:
		push_error("Could not load map scene: %s" % scene_path)
		return false
	for child in _map_host.get_children():
		_map_host.remove_child(child)
		child.queue_free()
	var new_map := packed.instantiate()
	if no_bots and "bot_count" in new_map:
		new_map.set("bot_count", 0)               # network matches are player-vs-player only
	new_map.name = "ActiveMap_%s" % map_id
	_map_host.add_child(new_map)
	return true


func _position_fighters(map_id: String) -> void:
	var player := get_node_or_null("Player") as Node2D
	var spawn := get_node_or_null("SpawnPoint") as Node2D
	var spawn_position: Vector2 = PLAYER_SPAWNS.get(map_id, Vector2(250, 2310))
	if spawn != null:
		spawn.position = spawn_position
	if player != null:
		player.global_position = spawn_position
		if player is CharacterBody2D:
			(player as CharacterBody2D).velocity = Vector2.ZERO
	var pickup_spots: Array = ROOT_PICKUP_SPOTS.get(map_id, [])
	var pickup_names := ["Area2D", "Area2D2"]
	for i in mini(pickup_names.size(), pickup_spots.size()):
		var pickup := get_node_or_null(str(pickup_names[i])) as Node2D
		if pickup != null:
			pickup.global_position = pickup_spots[i]
	# Bots are set to their preferred spots for now; _place_bots_safely() then checks each spot against
	# the new map's collision (it has to wait a physics frame until the new map exists in the physics
	# space) and moves a bot if its spot is inside a rock or too cramped.
	var bot_positions: Array = BOT_SPAWNS.get(map_id, [])
	var bot_names := ["Bot", "Bot2"]
	for i in mini(bot_names.size(), bot_positions.size()):
		var bot := get_node_or_null(str(bot_names[i])) as Node2D
		if bot != null:
			if bot.has_method("place_at"):
				bot.call("place_at", bot_positions[i])      # also updates the bot's respawn anchor
			else:
				bot.global_position = bot_positions[i]
			if bot is CharacterBody2D:
				(bot as CharacterBody2D).velocity = Vector2.ZERO


# Validates the bots' starting spots on the freshly loaded map. Bots wait (no AI, hidden) until it is done.
func _place_bots_safely(map_id: String) -> void:
	var bots: Array[Node2D] = []
	for n in ["Bot", "Bot2"]:
		var b := get_node_or_null(str(n)) as Node2D
		if b != null and b.get("dead") != true:
			bots.append(b)
			b.set_physics_process(false)
			b.visible = false
	await get_tree().physics_frame
	await get_tree().physics_frame
	if active_map_id != map_id:
		for b in bots:
			if is_instance_valid(b):
				b.set_physics_process(true)
				b.visible = true
		return
	var taken: Array[Vector2] = []
	var player := get_node_or_null("Player") as Node2D
	if player != null:
		taken.append(player.global_position)
	for b in bots:
		if not is_instance_valid(b):
			continue
		var wanted: Vector2 = b.get("start_position")
		var spot := SpawnSafety.find_safe_spawn(b, wanted, taken, 400.0)
		if b.has_method("place_at"):
			b.call("place_at", spot)
		else:
			b.global_position = spot
		taken.append(spot)
		b.visible = true
		b.set_physics_process(true)


# =========================================================================================== LAN multiplayer
# Spawn spots for network matches: the project's own player / bot start points for each map (SpawnSafety checks
# every one against the real collision before anybody is placed on it).
const NET_SPAWNS := {
	"abandoned_station": [Vector2(1200, 1440), Vector2(400, 1440), Vector2(2800, 1440), Vector2(330, 2150), Vector2(4870, 2150), Vector2(4300, 1810)],
	"cavern_isles": [Vector2(364, 1782), Vector2(4830, 1725), Vector2(2740, 1272)],
}


func _open_lan_menu() -> void:
	_menu_layer.visible = false
	if _main_menu != null:
		_main_menu.close()
	_lan_menu.open()


func net_spawn_candidates() -> Array:
	var out: Array = []
	for p in NET_SPAWNS.get(active_map_id, [PLAYER_SPAWNS.get(active_map_id, Vector2(250, 2310))]):
		out.append(p)
	return out


# Loads the host's chosen map for a network match and clears everything that is single-player only (bots).
func net_prepare_match(map_id: String) -> void:
	var info := MapRegistry.get_map(map_id)
	if info.is_empty():
		info = MapRegistry.get_map("abandoned_station")
		map_id = "abandoned_station"
	MatchSession.end_session()                      # a LAN match never inherits offline rules or restrictions
	if _main_menu != null:
		_main_menu.close()
	_lan_menu.close()
	_lan_menu.visible = false
	_menu_layer.visible = false
	_menu_open = false
	get_tree().paused = false
	for b in get_tree().get_nodes_in_group("bot"):
		b.get_parent().remove_child(b)
		b.queue_free()
	if not _load_map(map_id, str(info["scene"]), true):
		Net.leave("Could not load the map \"%s\"." % map_id)
		return
	active_map_id = map_id
	set_meta("active_map_id", active_map_id)
	_position_fighters(map_id)
	for b in get_tree().get_nodes_in_group("bot"):         # a map that spawned its own bots anyway
		b.get_parent().remove_child(b)
		b.queue_free()
	# Some maps (Abandoned Station) add their OWN MatchManager inside the map. It would keep showing the
	# single-player "YOU - BOTS" score on top of the network score, so only this node's MatchManager is kept.
	for extra in find_children("MatchManager", "CanvasLayer", true, false):
		if extra.get_parent() != self:
			extra.get_parent().remove_child(extra)
			extra.queue_free()
	var mm := get_node_or_null("MatchManager")
	if mm != null and mm.has_method("enter_net_mode"):
		mm.call("enter_net_mode")
	if _shortcut_layer != null:
		var shortcut := _shortcut_layer.get_node_or_null("MapMenuShortcut") as Button
		if shortcut != null:
			shortcut.visible = true
	await get_tree().physics_frame                          # let the new map's collision enter the physics space
	await get_tree().physics_frame


func net_place_local(pos: Vector2) -> void:
	var player := get_node_or_null("Player") as CharacterBody2D
	if player != null:
		player.global_position = pos
		player.velocity = Vector2.ZERO


func _toggle_net_menu() -> void:
	if _net_menu == null:
		_build_net_menu()
	_net_menu.visible = not _net_menu.visible


func _build_net_menu() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 101
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(layer)
	var root := CenterContainer.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)
	_net_menu = root
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _panel_style())
	panel.custom_minimum_size = Vector2(320, 0)
	root.add_child(panel)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	panel.add_child(col)
	var title := Label.new()
	title.text = "LAN MATCH"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 24)
	col.add_child(title)
	var info := Label.new()
	info.text = "The match keeps running while this is open."
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.add_theme_font_size_override("font_size", 13)
	info.add_theme_color_override("font_color", UITheme.ON_VARIANT)
	col.add_child(info)
	var resume := Button.new()
	resume.text = "RESUME"
	resume.custom_minimum_size = Vector2(0, 54)
	UITheme.style_button(resume, "primary")
	resume.pressed.connect(func() -> void: _net_menu.visible = false)
	col.add_child(resume)
	var leave := Button.new()
	leave.text = "LEAVE MATCH"
	leave.custom_minimum_size = Vector2(0, 54)
	UITheme.style_button(leave, "danger")
	leave.pressed.connect(func() -> void: Net.leave("You left the match."))
	col.add_child(leave)
	_net_menu.visible = false


# A short message after being sent back to the menu (host left, connection lost, kicked ...).
func _show_notice(text: String) -> void:
	_notice_layer = CanvasLayer.new()
	_notice_layer.layer = 120
	_notice_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_notice_layer)
	var root := CenterContainer.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_notice_layer.add_child(root)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _panel_style())
	panel.custom_minimum_size = Vector2(340, 0)
	root.add_child(panel)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 12)
	panel.add_child(col)
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(300, 0)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", 18)
	col.add_child(l)
	var ok := Button.new()
	ok.text = "OK"
	ok.custom_minimum_size = Vector2(0, 50)
	UITheme.style_button(ok, "primary")
	ok.pressed.connect(func() -> void: _notice_layer.queue_free())
	col.add_child(ok)


# =========================================================================================== main menu + configured offline matches
# The front screen: the main menu (paused game behind it).
func _show_front_menu() -> void:
	get_tree().paused = true
	_menu_open = false
	var shortcut := _shortcut_layer.get_node_or_null("MapMenuShortcut") as Button
	if shortcut != null:
		shortcut.visible = false
	_main_menu.open()


func _open_settings_from(where: String) -> void:
	_settings_return = where
	if where == "main":
		_main_menu.close()
	elif _pause_menu != null:
		_pause_menu.visible = false
	_menu_layer.visible = true
	_open_settings()


# Starts an offline match from a MatchConfig: rules first (so spawners obey them), then the map, then the
# per-node settings, bots and the player's loadout. The same map code (_load_map) is used as always.
func _start_configured_match(cfg: MatchConfig) -> void:
	var problems := cfg.validate()
	if not problems.is_empty():
		_show_notice(str(problems[0]["text"]))
		return
	MatchSession.begin(cfg)
	_main_menu.close()
	_menu_layer.visible = false
	var info := MapRegistry.get_map(cfg.map_id)
	if not _load_map(cfg.map_id, str(info["scene"])):
		MatchSession.end_session()
		_show_notice("Could not load the map \"%s\"." % str(info.get("name", cfg.map_id)))
		_show_front_menu()
		return
	active_map_id = cfg.map_id
	set_meta("active_map_id", active_map_id)
	_position_fighters(cfg.map_id)
	# a map may add its own MatchManager: only this scene's one keeps score
	for extra in find_children("MatchManager", "CanvasLayer", true, false):
		if extra.get_parent() != self:
			extra.get_parent().remove_child(extra)
			extra.queue_free()
	_menu_open = false
	get_tree().paused = false
	await get_tree().physics_frame
	await get_tree().physics_frame
	var mm := get_node_or_null("MatchManager")
	if mm != null and mm.has_method("start_session"):
		mm.call("start_session")
	await MatchSession.apply_to_scene(self)
	var shortcut := _shortcut_layer.get_node_or_null("MapMenuShortcut") as Button
	if shortcut != null:
		shortcut.visible = true


func _toggle_pause_menu() -> void:
	var mm := get_node_or_null("MatchManager")
	if mm != null and bool(mm.get("match_over")):
		return
	if _pause_menu == null:
		_build_pause_menu()
	_pause_menu.visible = not _pause_menu.visible
	get_tree().paused = _pause_menu.visible


func _build_pause_menu() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 101
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(layer)
	var root := ColorRect.new()
	root.color = Color(UITheme.SCRIM.r, UITheme.SCRIM.g, UITheme.SCRIM.b, 0.7)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(root)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _panel_style())
	panel.custom_minimum_size = Vector2(340, 0)
	center.add_child(panel)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	panel.add_child(col)
	var title := MenuKit.label("PAUSED", 24, UITheme.ON_SURFACE, true)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(title)
	var resume := MenuKit.button("RESUME", "primary", 54, 18)
	resume.pressed.connect(_toggle_pause_menu)
	col.add_child(resume)
	var restart := MenuKit.button("RESTART MATCH", "tonal", 54, 18)
	restart.pressed.connect(func() -> void:
		var mm := get_node_or_null("MatchManager")
		if mm != null:
			get_tree().paused = false
			mm.call("restart_match"))
	col.add_child(restart)
	var settings := MenuKit.button("SETTINGS", "tonal", 54, 18)
	settings.pressed.connect(func() -> void: _open_settings_from("pause"))
	col.add_child(settings)
	var quit := MenuKit.button("MAIN MENU", "danger", 54, 18)
	quit.pressed.connect(func() -> void:
		var mm := get_node_or_null("MatchManager")
		if mm != null:
			mm.call("go_to_main_menu"))
	col.add_child(quit)
	_pause_menu = root
	_pause_menu.visible = false


# The saved look on the local player (offline). In a LAN match net_match applies the roster look instead.
func _apply_local_look() -> void:
	if Net.match_active():
		return
	var p := get_node_or_null("Player")
	if p != null and p.get("visuals") != null:
		p.visuals.apply_appearance(AppearanceStore.rig_params())
