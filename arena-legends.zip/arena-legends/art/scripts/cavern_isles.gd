extends Node2D
## DAYTIME MAP: CAVERN ISLES
## Built from the user's layout sketch: a long rocky ground with a stone bunker (blue flag) on a
## floating island in the west and a log bunker (red flag) in the east, sky islands in between,
## and now TUNNELS, ROCKS and OBSTACLES.
##
##   TUNNELS
##     * Long Tunnel (west/middle): enter from the Drop Shaft (west), the Skylight (middle) or the
##       Pit mouth (east). About 150 px tall, so low rocks make you crouch.
##     * East Tunnel: runs under the east ground from the Pit to the East Hatch (a wide shaft up to
##       the surface). It ends in a dead-end alcove with a weapon.
##   ROCKS     - boulders, mounds, stalagmites on floors, stalactites hanging from tunnel roofs.
##   OBSTACLES - crates, crate stacks, barrels, sandbag walls and plank barricades. All solid:
##               take cover behind them or jump on top.
##
## BUNKER    - the west (blue flag) bunker is a riveted steel bunker with TWO doorways: the original one on
##              the east side and a new one on the west side. Both are 225 px tall gaps in the wall, so
##              a character walks straight through.
## OUT OF BOUNDS - there are no invisible walls on the left, right or top: you may fly past the edge.
##              See out_of_bounds.gd and the oob_* exports below for the distance / damage settings.
##
## Everything is painted from code. All shapes are written in the IMAGE coordinates of the sketch
## (1200 x 415) inside _define_world() and scaled up by S, so you can edit the layout by changing
## numbers there. Collision is built from the same shapes that are painted.

const TERRAIN_SHADER_PATH := "res://art/shaders/outpost_terrain.gdshader"

const WeaponCatalog = preload("res://art/scripts/weapon_catalog.gd")
const WeaponPickup = preload("res://art/scripts/weapon_pickup.gd")
const ThrowableSpawner = preload("res://art/scripts/throwable_spawner.gd")
const OutOfBoundsRule = preload("res://art/scripts/out_of_bounds.gd")

const S := 4.4                              # sketch pixel -> world pixel
const ORIGIN := Vector2(100.0, 560.0)       # where the sketch's (0, 0) lands in the world
const MAP_LEFT := 232.0                     # world x of the ground's west edge (left edge of the safe area)
const MAP_RIGHT := 5125.0                   # world x of the ground's east edge (right edge of the safe area)
const MAP_BOTTOM := 2640.0
const CEILING_Y := 640.0                    # top edge of the safe area (you can fly above it)
const CLOUD_PERIOD := 1800.0

const SKY_TOP := Color("5a97d2")
const SKY_MID := Color("9cc9e6")
const SKY_HORIZON := Color("e6e2cf")
const ROCK_LIGHT := Color("9b9380")
const ROCK_DARK := Color("6f695b")
const ROCK_COLORS := [Color("8d928c"), Color("77807c"), Color("a29f93"), Color("96877a")]
const PEBBLE_EDGE := Color(0.14, 0.12, 0.09, 0.75)
const OUTLINE := Color(0.10, 0.09, 0.07, 0.9)
const GRASS := Color("5f9a45")
const GRASS_HI := Color("8fc45a")
const GRASS_DARK := Color("2f5a2a")
const BACK_TUNNEL := Color("3a352b")
const BACK_HULL := Color("575140")
const PILLAR_EDGE := Color(0.10, 0.09, 0.07, 0.8)
const SOIL := Color(0.42, 0.34, 0.24, 0.55)
const FLOWER_COLORS := [Color("f4efe0"), Color("f2d35b"), Color("e89fb0")]
const ROOT_COLOR := Color(0.24, 0.17, 0.10, 0.9)
# riveted steel (west bunker)
const STEEL := Color("6e757b")
const STEEL_LIGHT := Color("9aa2a8")
const STEEL_DARK := Color("43494e")
const STEEL_EDGE := Color("1f2327")
const STEEL_BACK := Color("30353a")
const RUST := Color(0.55, 0.28, 0.12)
const HAZARD := Color("dcae2a")

# --- organic terrain shaping (see _shape_solid). Collision uses the SAME shaped outline. ---
const ORGANIC_TOP_AMP := 4.5          # px of gentle rise and fall along walkable tops
const ORGANIC_TOP_STEP := 38.0
const ORGANIC_SIDE_AMP := 9.0         # px of craggy variation on cliff faces and undersides
const ORGANIC_SIDE_STEP := 46.0
const ORGANIC_VERTEX_JITTER := 4.5
# Tops next to bunkers stay closer to the original height.
const TOP_AMP_SCALE := {"west_island": 0.4, "east_body": 0.45}
# Solids whose outline touches tunnels: only these edges (edge e runs from point e to e + 1) are
# roughened. An empty list means the outline stays exactly as designed (tunnel roofs). Every solid
# not listed here roughens all of its non-top edges.
const FIXED_OUTLINES := {
	"west_ground": [10, 99],
	"roof_a": [], "roof_b": [], "east_roof_a": [], "east_cap": [],
	"east_body": [3, 17],
}
const ROOT_ISLANDS := ["west_island", "center", "east_mid", "peak", "bowl", "top_right", "diagonal", "tiny", "tip"]

# Weapon pickup and throwable spawn spots: surface id, x in sketch pixels.
const PICKUP_SPOTS := [
	["tun1", 300.0], ["tun2", 930.0], ["west_island", 175.0], ["east_body", 1070.0],
	["bowl", 450.0], ["center", 690.0], ["diagonal", 1018.0], ["east_mid", 880.0],
	["top_right", 820.0], ["peak", 460.0], ["tun1", 590.0], ["roof_b", 420.0],
]
const THROWABLE_SPOTS := [
	["west_ground", 70.0], ["tun1", 270.0], ["tun1", 470.0], ["tun2", 700.0], ["tun2", 880.0],
	["east_body", 1120.0], ["east_body", 1030.0], ["east_roof_a", 780.0], ["roof_b", 420.0],
	["west_island", 215.0], ["bowl", 400.0], ["center", 620.0], ["east_mid", 835.0],
	["diagonal", 995.0], ["ledge_c", 520.0],
]
# World positions that arena_controller.gd uses on this map (player spawn, the two root-scene pickups).
const ROOT_SPOTS := [Vector2(364.0, 1782.0), Vector2(1420.0, 2070.0), Vector2(3356.0, 1700.0)]
# Surfaces that are open to the sky (rock clusters and loose stones only go on these, never in tunnels).
const OPEN_SURFACES := ["west_ground", "roof_a", "roof_b", "east_roof_a", "east_body", "west_island", "center",
		"bowl", "east_mid", "top_right", "ledge_a", "ledge_b", "ledge_c", "ledge_d", "ledge_e"]

@export var map_id := "cavern_isles"
const SHADER_LITE_PATH := "res://art/shaders/outpost_terrain_lite.gdshader"
const LITE_COLLISION_TOL := 4.5        # collision outline simplification on phones (a device thing, not a graphics-quality thing)
const SKY_BANDS := [20, 48, 48]        # sky gradient steps for Low / Medium / High

## GRAPHICS QUALITY (Settings > Graphics Quality): GameSettings.quality = 0 Low, 1 Medium, 2 High.
##   LOW    terrain drawn flat (no shader), thinned detail, steady lantern glow, simple sky.
##   MEDIUM full detail (denser grass, flowers, stones, brick/mortar), a light terrain shader (mottling +
##          sun/shade tint), full sky, gently flickering lanterns.
##   HIGH   everything in Medium plus the full terrain shader (pebbly bump lighting), extra stones and grass,
##          soft shadow under bunker walls, lanterns flicker every frame.
## On every level the terrain is split into small pieces so the engine skips whatever is off screen.
var _q := 0
var _mobile := false
var _frame := 0
var _art_nodes: Array = []             # everything build_nodes made, so a quality change can rebuild it

## Small read-out in the top-left corner: quality level, piece count and draw calls (for finding what is slow).
## Use Settings > Show FPS for a plain FPS counter.
@export var show_perf_overlay := false

@export_group("Out of bounds")
@export var oob_enabled := true
## Distance past the edge (px) where the "turn back" warning appears.
@export var oob_warning_distance := 150.0
## Distance past the edge (px) where the health drain starts. Inside it you are never hurt.
@export var oob_damage_distance := 400.0
## Distance (px) where the drain reaches its maximum rate (it rises in a straight line from the start).
@export var oob_full_damage_distance := 1400.0
## Distance (px) where you die at once, so nobody can fly away forever.
@export var oob_kill_distance := 2200.0
@export var oob_min_damage_per_second := 10.0
@export var oob_max_damage_per_second := 60.0
@export var oob_bots_too := true

var _solids: Array = []        # Dictionary: id, poly, top, top_count, grass, rect
var _paths: Dictionary = {}    # id -> PackedVector2Array of world points (surfaces to stand things on)
var _rocks: Array = []         # Dictionary: poly, kind
var _props: Array = []         # Dictionary: type, rect
var _bunkers: Array = []       # Dictionary: style, back, solids, flag, flag_color
var _backs: Array = []         # Dictionary: poly, color, edge, speckle
var _cavities: Array = []      # Dictionary: poly, alpha   (tunnel / pit interiors that get shaded)
var _lanterns: Array = []      # Vector2 world positions (hang from tunnel roofs)
var _stones: Array = []        # Dictionary: poly, base, moss   (decoration only, NOT solid)
var _keepout: Array = []       # Dictionary: p (Vector2), r (float)   places that must stay clear of new rocks
var _static_body: StaticBody2D
var _front: Node2D
var _sky: Node2D
var _clouds: Node2D
var _elapsed := 0.0


func _ready() -> void:
	z_index = -10
	_mobile = OS.has_feature("mobile") or OS.has_feature("web_android") or OS.has_feature("web_ios")
	GameSettings.ensure_loaded()
	_q = GameSettings.quality
	add_to_group("quality_aware")             # the settings menu calls apply_quality() on us
	add_to_group("map_" + map_id)
	add_to_group("surface_provider")          # GroundContact asks us what a footstep lands on
	add_to_group("bot_spawn_provider")        # SpawnSafety asks us for walkable spawn points
	if show_perf_overlay:
		_make_perf_overlay()
	_define_world()
	_define_environment()
	_build_collisions()
	_build_weapon_pickups()
	_build_throwable_spawner()
	_build_nodes()
	_set_camera_limits()
	_build_out_of_bounds()


var _bake_state := "pending"      # (kept name) how many terrain pieces were built
var _perf_label: Label
var _perf_timer := 0.0

func _make_perf_overlay() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 120
	_perf_label = Label.new()
	_perf_label.position = Vector2(8.0, 8.0)
	_perf_label.add_theme_font_size_override("font_size", 14)
	_perf_label.add_theme_color_override("font_color", Color(1, 1, 0.4))
	_perf_label.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	_perf_label.add_theme_constant_override("outline_size", 4)
	_perf_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(_perf_label)
	add_child(layer)


func _process(delta: float) -> void:
	if _perf_label != null:
		_perf_timer += delta
		if _perf_timer >= 0.5:
			_perf_timer = 0.0
			_perf_label.text = "FPS %d | quality %s | res %s | %s | draw calls %d" % [Engine.get_frames_per_second(), GameSettings.quality_name(), "FAST" if GameSettings.fast_resolution else "SHARP", _bake_state, int(RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME))]
	_elapsed += delta
	var cloud_x := fmod(_elapsed * 9.0, CLOUD_PERIOD)
	if _clouds != null:
		_clouds.position.x = cloud_x
	_frame += 1
	var flicker_every: int = [0, 3, 1][_q]     # Low: steady glow; Medium: ~20 fps flicker; High: every frame
	if _front != null and flicker_every > 0 and _frame % flicker_every == 0:
		_front.queue_redraw()


# Called by the settings menu when Graphics Quality changes: rebuilds just the artwork, live.
func apply_quality() -> void:
	var nq := GameSettings.quality
	if nq == _q and not _art_nodes.is_empty():
		return
	_q = nq
	for n in _art_nodes:
		if is_instance_valid(n):
			n.queue_free()
	_art_nodes.clear()
	_sky = null
	_clouds = null
	_front = null
	_build_nodes()


# =====================================================================
#  HELPERS (sketch coordinates -> world)
# =====================================================================

func _w(x: float, y: float) -> Vector2:
	return Vector2(x * S + ORIGIN.x, y * S + ORIGIN.y)


func _wp(pairs: Array) -> PackedVector2Array:
	var out := PackedVector2Array()
	for p in pairs:
		out.append(_w(float(p[0]), float(p[1])))
	return out


func _wr(x: float, y: float, w: float, h: float) -> Rect2:
	return Rect2(_w(x, y), Vector2(w * S, h * S))


func _bounds(poly: PackedVector2Array) -> Rect2:
	var lo := poly[0]
	var hi := poly[0]
	for p in poly:
		lo = Vector2(minf(lo.x, p.x), minf(lo.y, p.y))
		hi = Vector2(maxf(hi.x, p.x), maxf(hi.y, p.y))
	return Rect2(lo, hi - lo)


# A solid piece of land. `pairs` run along the walkable top edge first (left to right, that is
# `top_count` points), then back along the underside. The outline is then made organic
# (_shape_solid) and BOTH the painting and the collision use the result.
func _add_solid(id: String, pairs: Array, top_count: int, grass: bool = true) -> void:
	var shaped := _shape_solid(id, _wp(pairs), top_count)
	var poly: PackedVector2Array = shaped["poly"]
	var tc: int = shaped["top_count"]
	var top := PackedVector2Array()
	for i in tc:
		top.append(poly[i])
	_solids.append({
		"id": id, "poly": poly, "top": top, "top_count": tc, "grass": grass,
		"rect": _bounds(poly), "seed": _hash_str(id),
	})
	if tc > 1:
		_paths[id] = top


# ---------- organic outline helpers ----------

func _hash_str(text: String) -> float:
	return float(text.hash() % 100000) / 100000.0


func _h(a: float, b: float) -> float:
	var v := sin(a * 12.9898 + b * 78.233) * 43758.5453
	return v - floor(v)


func _edge_free(id: String, e: int, n: int, top_count: int) -> bool:
	if FIXED_OUTLINES.has(id):
		var r: Array = FIXED_OUTLINES[id]
		return not r.is_empty() and e >= int(r[0]) and e <= int(r[1]) and e < n
	return e >= top_count - 1 and e < n


# Cuts the corners of the walkable top (Chaikin) while keeping both end points exactly where
# they were, so neighbouring pieces still join up. Every segment keeps an angle between its
# neighbours' angles, so no slope becomes steeper than the steepest original one.
func _chaikin_open(pts: PackedVector2Array) -> PackedVector2Array:
	if pts.size() < 3:
		return pts
	var out := PackedVector2Array()
	out.append(pts[0])
	for i in range(pts.size() - 1):
		var a := pts[i]
		var b := pts[i + 1]
		if i == 0:
			out.append(a.lerp(b, 0.75))
		elif i == pts.size() - 2:
			out.append(a.lerp(b, 0.25))
		else:
			out.append(a.lerp(b, 0.25))
			out.append(a.lerp(b, 0.75))
	out.append(pts[pts.size() - 1])
	return out


# Adds a soft, low-frequency rise and fall to the walkable top. The wobble fades out as the
# slope gets steeper (zero at 38 degrees and above), so walkable slopes can never be pushed past
# the walk limit and steep slopes never get bumpier.
func _roughen_top(top: PackedVector2Array, sd: float, amp_scale: float) -> PackedVector2Array:
	if top.size() < 2:
		return top
	var ph1 := sd * TAU
	var ph2 := fmod(sd * 7.31, 1.0) * TAU
	var dense := PackedVector2Array()
	dense.append(top[0])
	for i in range(top.size() - 1):
		var a := top[i]
		var b := top[i + 1]
		var segs := maxi(int(ceil(a.distance_to(b) / ORGANIC_TOP_STEP)), 1)
		for k in range(1, segs + 1):
			dense.append(a.lerp(b, float(k) / float(segs)))
	var out := PackedVector2Array()
	for i in dense.size():
		var pt := dense[i]
		if i > 0 and i < dense.size() - 1:
			var d := dense[i + 1] - dense[i - 1]
			var ang := rad_to_deg(atan2(absf(d.y), maxf(absf(d.x), 0.001)))
			var fade := clampf(1.0 - ang / 38.0, 0.0, 1.0)
			var nz := 0.6 * sin(pt.x * 0.013 + ph1) + 0.4 * sin(pt.x * 0.031 + ph2)
			pt.y -= ORGANIC_TOP_AMP * amp_scale * fade * nz
		out.append(pt)
	return out


func _is_simple(poly: PackedVector2Array) -> bool:
	var n := poly.size()
	for i in n:
		var a := poly[i]
		var b := poly[(i + 1) % n]
		for j in range(i + 2, n):
			if i == 0 and j == n - 1:
				continue
			if Geometry2D.segment_intersects_segment(a, b, poly[j], poly[(j + 1) % n]) != null:
				return false
	return true


# One round of corner cutting on a closed outline. A point flagged "locked" stays exactly where it
# is; every other point is replaced by two points a quarter of the way along its two edges, which
# rounds every corner. `lock` and `istop` (is this point on the walkable top?) are carried along.
func _cut_corners(pts: PackedVector2Array, lock: Array, istop: Array) -> Dictionary:
	var n := pts.size()
	var out := PackedVector2Array()
	var out_lock: Array = []
	var out_top: Array = []
	for i in n:
		var v := pts[i]
		var pv := pts[(i + n - 1) % n]
		var nv := pts[(i + 1) % n]
		if lock[i]:
			out.append(v)
			out_lock.append(true)
			out_top.append(istop[i])
		else:
			out.append(v + (pv - v) * 0.25)
			out_lock.append(false)
			out_top.append(istop[i] and istop[(i + n - 1) % n])
			out.append(v + (nv - v) * 0.25)
			out_lock.append(false)
			out_top.append(istop[i] and istop[(i + 1) % n])
	return {"pts": out, "lock": out_lock, "top": out_top}


# Turns the designer's straight-edged outline into a natural one: a gently rolling walkable top,
# softly wavy cliff faces and undersides, and every corner rounded off (no spikes). Tunnel walls
# and floors (FIXED_OUTLINES) stay exactly as designed. Collision uses the result, so it always
# matches what you see.
func _shape_solid(id: String, raw: PackedVector2Array, top_count: int) -> Dictionary:
	var plain := {"poly": raw, "top_count": top_count}
	var n := raw.size()
	if n < 4 or top_count < 2:
		return plain
	var sd := _hash_str(id)
	var fixed_solid := FIXED_OUTLINES.has(id)
	var top := PackedVector2Array()
	for i in top_count:
		top.append(raw[i])
	top = _roughen_top(_chaikin_open(top), sd, float(TOP_AMP_SCALE.get(id, 1.0)))
	var area := 0.0
	for i in n:
		var pa := raw[i]
		var pb := raw[(i + 1) % n]
		area += pa.x * pb.y - pb.x * pa.y
	var clockwise := area > 0.0
	var bb := _bounds(raw)
	var amp := ORGANIC_SIDE_AMP * (0.5 if minf(bb.size.x, bb.size.y) < 130.0 else 1.0)
	var pts := PackedVector2Array(top)
	var lock: Array = []
	var istop: Array = []
	for i in top.size():
		# tunnel-roof / ground tops keep exact end points so neighbours still join up
		lock.append(fixed_solid and (i == 0 or i == top.size() - 1))
		istop.append(true)
	for e in range(top_count - 1, n):
		var a := raw[e]
		var nxt := (e + 1) % n
		var b := raw[nxt]
		var edge_ok := _edge_free(id, e, n, top_count)
		if edge_ok:
			var d := b - a
			var length := d.length()
			var segs := int(round(length / ORGANIC_SIDE_STEP))
			if segs >= 2:
				var dir := d / length
				var nrm := Vector2(dir.y, -dir.x) if clockwise else Vector2(-dir.y, dir.x)
				for k in range(1, segs):
					var t := (float(k) + (_h(sd * 91.0 + float(e), float(k) * 3.7) - 0.5) * 0.4) / float(segs)
					var r := _h(sd * 53.0 + float(e) * 1.7, float(k) * 5.3 + 11.0) * 2.0 - 1.0
					pts.append(a.lerp(b, t) + nrm * amp * r)
					lock.append(false)
					istop.append(false)
		if nxt != 0:
			var q := raw[nxt]
			var q_locked := not (edge_ok and _edge_free(id, nxt, n, top_count))
			if not q_locked:
				q += Vector2(_h(sd * 29.0, float(nxt) * 2.9) - 0.5, _h(sd * 31.0, float(nxt) * 6.1) - 0.5) * 2.0 * ORGANIC_VERTEX_JITTER
			pts.append(q)
			lock.append(q_locked)
			istop.append(false)
	# the top's end points are corners of the island: round them too, unless they must stay put
	# (their lock flag was set above only for tunnel pieces)
	var res := {"pts": pts, "lock": lock, "top": istop}
	var rounds := 1 if fixed_solid else 2
	for it in rounds:
		res = _cut_corners(res["pts"], res["lock"], res["top"])
	var all_pts: PackedVector2Array = res["pts"]
	var flags: Array = res["top"]
	# rotate so the walkable top comes first: find the start of the run of top points
	var m := all_pts.size()
	var start := -1
	for i in m:
		if flags[i] and not flags[(i + m - 1) % m]:
			start = i
			break
	if start < 0:
		return plain
	var rotated := PackedVector2Array()
	var count := 0
	var in_run := true
	for i in m:
		var idx := (start + i) % m
		rotated.append(all_pts[idx])
		if in_run and flags[idx]:
			count += 1
		else:
			in_run = false
	if count < 2 or not _is_simple(rotated):
		push_warning("Cavern Isles: organic outline of '%s' was not usable; keeping the original shape." % id)
		return plain
	return {"poly": rotated, "top_count": count}


# Same corner cutting for plain background shapes (hanging columns etc.).
func _smooth_poly(poly: PackedVector2Array, rounds: int) -> PackedVector2Array:
	var lock: Array = []
	var flags: Array = []
	for i in poly.size():
		lock.append(false)
		flags.append(false)
	var res := {"pts": poly, "lock": lock, "top": flags}
	for it in rounds:
		res = _cut_corners(res["pts"], res["lock"], res["top"])
	var out: PackedVector2Array = res["pts"]
	return out if _is_simple(out) else poly


func _add_path(id: String, pairs: Array) -> void:
	_paths[id] = _wp(pairs)


func _add_back(pairs: Array, color: Color, edge: bool, speckle: bool) -> void:
	var poly := _wp(pairs)
	if edge:
		poly = _smooth_poly(poly, 2)          # rock columns are rounded; tunnel interiors keep their exact shape
	_backs.append({"poly": poly, "color": color, "edge": edge, "speckle": speckle})


func _add_cavity(pairs: Array, alpha: float) -> void:
	_cavities.append({"poly": _wp(pairs), "alpha": alpha})


func _path_y(id: String, ximg: float) -> float:
	if not _paths.has(id):
		push_warning("Cavern Isles: unknown surface '%s'" % id)
		return 0.0
	var path: PackedVector2Array = _paths[id]
	var x := ximg * S + ORIGIN.x
	if x <= path[0].x:
		return path[0].y
	for i in range(path.size() - 1):
		var a := path[i]
		var b := path[i + 1]
		if x <= b.x:
			if is_equal_approx(a.x, b.x):
				return a.y
			return lerpf(a.y, b.y, (x - a.x) / (b.x - a.x))
	return path[path.size() - 1].y


func _spot(path_id: String, ximg: float, lift: float) -> Vector2:
	return Vector2(ximg * S + ORIGIN.x, _path_y(path_id, ximg) - lift)


# A rock sitting on a surface. kind: "mound" (low dome you can jump on), "spire" (stalagmite) or
# "hang" (stalactite hanging from a ceiling path). w and h are in world pixels.
func _add_rock(path_id: String, ximg: float, kind: String, w: float, h: float) -> void:
	var cx := ximg * S + ORIGIN.x
	var hw := w * 0.5
	var y_c := _path_y(path_id, ximg)
	var y_l := _path_y(path_id, (cx - hw - ORIGIN.x) / S)
	var y_r := _path_y(path_id, (cx + hw - ORIGIN.x) / S)
	var seed_v := cx * 0.013
	var poly := PackedVector2Array()
	var n := 16
	if kind == "hang":
		# a blunt, rounded drip of rock hanging from the roof (no sharp point)
		var base_h := minf(y_c, minf(y_l, y_r)) - 8.0       # ceiling: smaller y is higher up
		for i in range(0, n + 1):
			var a := PI * float(i) / float(n)
			var lump := 1.0 - 0.07 * sin(float(i) * 1.9 + seed_v)
			poly.append(Vector2(cx - cos(a) * hw * (1.0 - 0.45 * sin(a)), base_h + sin(a) * h * lump))
	elif kind == "spire":
		# a rounded stone column: wide at the foot, softly domed top
		var base_s := maxf(y_c, maxf(y_l, y_r)) + 8.0
		for i in range(0, n + 1):
			var a := PI * float(i) / float(n)
			var lump := 1.0 - 0.08 * sin(float(i) * 2.1 + seed_v)
			var foot := 1.0 + 0.35 * pow(1.0 - sin(a), 3.0)          # flares out toward the ground
			poly.append(Vector2(cx - cos(a) * hw * 0.7 * foot, base_s - pow(sin(a), 0.55) * h * lump))
	else:
		# a low, rounded boulder that eases into the ground, so it can be walked over
		var base_m := maxf(y_c, maxf(y_l, y_r)) + 8.0
		var skew := 0.12 * sin(seed_v * 3.0)
		var hh := minf(h + 8.0, hw * 1.5)               # low enough that every side is a walkable slope
		for i in range(0, n + 1):
			var u := -1.0 + 2.0 * float(i) / float(n)
			var bell := pow(cos(u * PI * 0.5), 1.35)
			var lump := 1.0 - 0.10 * absf(sin(float(i) * 1.7 + seed_v))
			var tilt := 1.0 + skew * u
			poly.append(Vector2(cx + u * hw, base_m - bell * hh * lump * tilt))
	_rocks.append({
		"poly": poly, "kind": kind, "path": path_id, "x": ximg, "w": w,
		"moss": kind == "mound" and not path_id.begins_with("tun"),
	})


# A solid obstacle. type: crate, crate_stack, barrel, sandbags, barricade.
func _add_prop(path_id: String, ximg: float, type: String) -> void:
	var cx := ximg * S + ORIGIN.x
	var y := _path_y(path_id, ximg) + 4.0
	match type:
		"crate":
			_props.append({"type": "crate", "rect": Rect2(cx - 23.0, y - 46.0, 46.0, 46.0)})
		"crate_stack":
			_props.append({"type": "crate", "rect": Rect2(cx - 23.0, y - 46.0, 46.0, 46.0)})
			_props.append({"type": "crate", "rect": Rect2(cx - 18.0, y - 84.0, 38.0, 38.0)})
		"barrel":
			_props.append({"type": "barrel", "rect": Rect2(cx - 19.0, y - 52.0, 38.0, 52.0)})
		"sandbags":
			_props.append({"type": "sandbags", "rect": Rect2(cx - 62.0, y - 44.0, 124.0, 44.0)})
		"barricade":
			_props.append({"type": "barricade", "rect": Rect2(cx - 11.0, y - 70.0, 22.0, 70.0)})


func _add_lantern(path_id: String, ximg: float) -> void:
	_lanterns.append(Vector2(ximg * S + ORIGIN.x, _path_y(path_id, ximg) + 2.0))


# =====================================================================
#  THE WORLD  (all numbers are in sketch pixels; see the sketch for reference)
# =====================================================================

func _define_world() -> void:
	# ---------- background rock (not solid): columns, hulls, tunnel interiors ----------
	# hanging columns that hold the islands up
	_add_back([[100, 190], [135, 190], [124, 222], [136, 250], [131, 290], [95, 290], [105, 250], [112, 222]], BACK_HULL, true, true)
	_add_back([[240, 215], [275, 215], [272, 250], [262, 290], [235, 290], [245, 250]], BACK_HULL, true, true)
	_add_back([[240, 172], [246, 142], [257, 127], [268, 142], [277, 172]], BACK_HULL, true, true)
	_add_back([[338, 138], [356, 138], [368, 190], [380, 232], [388, 262], [392, 292], [352, 292], [358, 262], [366, 238], [358, 215], [346, 178]], BACK_HULL, true, true)
	_add_back([[428, 126], [444, 128], [452, 152], [450, 192], [430, 192], [437, 160]], BACK_HULL, true, true)
	_add_back([[405, 238], [455, 238], [452, 262], [463, 290], [398, 290], [408, 262]], BACK_HULL, true, true)
	_add_back([[548, 262], [562, 232], [640, 222], [692, 232], [702, 262], [692, 292], [612, 292], [612, 366], [548, 366], [545, 300]], BACK_HULL, true, true)
	_add_back([[812, 208], [860, 208], [872, 240], [866, 290], [818, 290], [830, 245]], BACK_HULL, true, true)
	_add_back([[896, 222], [914, 222], [911, 250], [896, 254]], BACK_HULL, true, true)
	_add_back([[815, 115], [840, 110], [852, 142], [886, 162], [906, 186], [880, 192], [850, 172], [826, 150]], BACK_HULL, true, true)
	_add_back([[962, 100], [986, 100], [992, 142], [982, 182], [966, 182], [972, 142]], BACK_HULL, true, true)
	_add_back([[1030, 100], [1060, 126], [1090, 152], [1096, 172], [1070, 166], [1036, 132]], BACK_HULL, true, true)
	# tunnel interiors (darker). Drawn behind the solids, so the solids' edges give the tunnel walls.
	_add_back([[165, 289], [188, 289], [188, 312], [358, 312], [358, 266], [384, 270], [384, 312], [566, 311], [566, 366], [548, 366], [520, 360], [480, 349], [300, 352], [200, 349], [165, 349]], BACK_TUNNEL, false, true)
	_add_back([[566, 289], [612, 289], [612, 366], [566, 366]], BACK_TUNNEL, false, true)
	_add_back([[610, 322], [880, 322], [880, 289], [916, 289], [916, 322], [951, 322], [951, 362], [880, 360], [800, 360], [700, 362], [610, 364]], BACK_TUNNEL, false, true)

	# front shading so characters look darker inside the tunnels
	_add_cavity([[165, 289], [188, 289], [188, 312], [358, 312], [358, 289], [384, 289], [384, 312], [566, 311], [566, 366], [548, 366], [520, 360], [480, 349], [300, 352], [200, 349], [165, 349]], 0.30)
	_add_cavity([[566, 300], [612, 300], [612, 366], [566, 366]], 0.16)
	_add_cavity([[610, 322], [880, 322], [880, 289], [916, 289], [916, 322], [951, 322], [951, 362], [880, 360], [800, 360], [700, 362], [610, 364]], 0.30)

	# ---------- the big ground: west block + Long Tunnel floor ----------
	_add_solid("west_ground", [
		[30, 290], [165, 288],
		[165, 347], [200, 347], [300, 350], [420, 347], [480, 347], [520, 358], [548, 362], [612, 362],
		[612, 396], [560, 388], [520, 396], [470, 386], [420, 394], [370, 384], [320, 397], [270, 385],
		[220, 393], [175, 384], [130, 390], [85, 381], [45, 384], [30, 350],
	], 2)
	_add_path("tun1", [[200, 347], [300, 350], [420, 347], [480, 347], [520, 358], [548, 362], [612, 362]])
	_add_path("ceil1", [[200, 312], [358, 312]])
	_add_path("ceil1b", [[385, 311], [566, 311]])
	# the two roofs over the Long Tunnel (with the Skylight gap between them)
	_add_solid("roof_a", [
		[188, 294], [205, 284], [228, 276], [262, 274], [290, 277], [304, 289], [335, 288], [350, 268], [358, 264],
		[360, 271], [358, 312], [300, 315], [250, 313], [205, 312], [188, 306],
	], 9)
	_add_solid("roof_b", [
		[382, 272], [400, 282], [440, 288], [455, 266], [472, 266], [488, 285], [510, 290], [545, 288], [566, 288],
		[566, 312], [520, 313], [470, 310], [420, 313], [385, 311], [382, 300],
	], 9)

	# ---------- east ground: roof over the East Tunnel, hatch gap, end cap, body ----------
	_add_solid("east_roof_a", [
		[610, 290], [660, 285], [685, 248], [700, 252], [720, 265], [800, 268], [840, 286], [880, 289],
		[880, 322], [820, 324], [760, 321], [700, 324], [650, 321], [610, 322],
	], 8)
	_add_solid("east_cap", [[915, 289], [950, 290], [950, 322], [915, 322]], 2)
	_add_solid("east_body", [
		[950, 290], [985, 278], [1010, 275], [1142, 275],
		[1142, 300], [1136, 340], [1116, 368], [1082, 376], [1060, 368], [1022, 380], [960, 386], [900, 382],
		[840, 390], [780, 384], [720, 392], [680, 396], [645, 408], [626, 410], [610, 396],
		[610, 362], [700, 360], [800, 358], [880, 358], [950, 358],
	], 4)
	_add_path("tun2", [[610, 362], [700, 360], [800, 358], [880, 358], [950, 358]])
	_add_path("ceil2", [[610, 322], [880, 322]])

	# ---------- sky islands ----------
	_add_solid("west_island", [
		[78, 158], [90, 162], [235, 164], [262, 171], [293, 176],
		[293, 184], [285, 203], [268, 216], [250, 224], [232, 212], [215, 196], [190, 192], [170, 205], [150, 222], [125, 212], [100, 195], [84, 178], [78, 168],
	], 5)
	_add_solid("tiny", [[332, 116], [347, 104], [362, 115], [356, 128], [347, 138], [338, 128]], 3)
	_add_solid("peak", [
		[420, 110], [440, 94], [458, 80], [478, 94], [500, 110],
		[486, 124], [470, 138], [458, 150], [446, 140], [432, 124],
	], 5)
	_add_solid("bowl", [
		[378, 196], [395, 194], [440, 192], [478, 194], [481, 200],
		[470, 222], [450, 236], [428, 243], [405, 236], [388, 224], [380, 206],
	], 5)
	_add_solid("center", [
		[558, 176], [585, 173], [610, 172], [628, 163], [646, 150], [662, 137], [678, 128], [690, 124], [708, 132],
		[700, 150], [682, 182], [655, 214], [625, 234], [600, 240], [572, 226], [560, 202],
	], 9)
	_add_solid("east_mid", [
		[815, 196], [838, 190], [865, 186], [890, 179], [912, 172],
		[912, 184], [906, 222], [896, 250], [884, 232], [868, 214], [842, 216], [820, 212], [814, 204],
	], 5)
	_add_solid("top_right", [
		[770, 82], [790, 78], [830, 80], [850, 90],
		[846, 98], [826, 108], [805, 115], [785, 110], [773, 98],
	], 4)
	_add_solid("diagonal", [
		[934, 152], [968, 128], [996, 104], [1020, 82], [1032, 86],
		[1030, 98], [994, 134], [962, 166], [942, 170],
	], 5)
	_add_solid("tip", [[1068, 157], [1084, 150], [1100, 156], [1094, 168], [1082, 174], [1072, 168]], 3)
	# small rock ledges that link the islands together
	_add_solid("ledge_a", [[104, 234], [132, 234], [130, 244], [118, 250], [106, 244]], 2)
	_add_solid("ledge_b", [[238, 240], [272, 240], [268, 250], [255, 256], [242, 250]], 2)
	_add_solid("ledge_c", [[500, 246], [540, 246], [536, 256], [520, 262], [504, 256]], 2)
	_add_solid("ledge_d", [[742, 208], [790, 208], [784, 219], [766, 226], [748, 218]], 2)
	_add_solid("ledge_e", [[886, 140], [925, 140], [920, 150], [905, 156], [890, 150]], 2)

	# ---------- bunkers ----------
	# The west bunker is steel. It has TWO doorways, one in each end wall: the original one in the east
	# wall (x 214 to 232) and a new one in the west wall (x 112 to 126). Each wall is now only a short
	# lintel under the roof (y 86 to 112), leaving a 51-sketch-px (225 world px) gap down to the floor.
	_bunkers.append({
		"style": "metal", "back": _wr(126, 86, 88, 77),
		"solids": [_wr(112, 68, 120, 18), _wr(112, 86, 14, 26), _wr(214, 86, 18, 26)],
		"doors": [_wr(112, 112, 14, 51), _wr(214, 112, 18, 51)],
		"flag": _w(150, 68), "flag_color": Color("3d78d8"),
	})
	_bunkers.append({
		"style": "wood", "back": _wr(1030, 203, 84, 72),
		"solids": [_wr(1012, 185, 120, 18), _wr(1012, 203, 18, 35), _wr(1114, 203, 18, 35)],
		"flag": _w(1100, 185), "flag_color": Color("c9402f"),
	})

	# ---------- ROCKS ----------
	# Long Tunnel: low humps (jump them), a chunky boulder (crouch under the roof), stalactites
	_add_rock("tun1", 245, "mound", 70.0, 30.0)
	_add_rock("tun1", 335, "mound", 62.0, 50.0)
	_add_rock("tun1", 445, "mound", 84.0, 34.0)
	_add_rock("ceil1", 275, "hang", 56.0, 52.0)
	_add_rock("ceil1b", 430, "hang", 60.0, 56.0)
	_add_rock("tun1", 580, "mound", 74.0, 52.0)           # boulder in the pit
	# East Tunnel
	_add_rock("tun2", 690, "mound", 76.0, 30.0)
	_add_rock("tun2", 835, "spire", 46.0, 58.0)
	_add_rock("ceil2", 660, "hang", 44.0, 40.0)
	_add_rock("ceil2", 770, "hang", 64.0, 60.0)
	# Surface cover
	_add_rock("west_ground", 128, "mound", 84.0, 46.0)
	_add_rock("roof_a", 250, "mound", 90.0, 34.0)
	_add_rock("roof_b", 520, "mound", 80.0, 40.0)
	_add_rock("east_roof_a", 765, "mound", 90.0, 52.0)
	_add_rock("east_body", 968, "mound", 66.0, 38.0)
	_add_rock("bowl", 420, "mound", 150.0, 80.0)
	_add_rock("center", 585, "mound", 100.0, 48.0)
	_add_rock("east_mid", 850, "mound", 80.0, 34.0)
	_add_rock("west_island", 268, "mound", 90.0, 38.0)

	# ---------- OBSTACLES ----------
	_add_prop("west_ground", 98, "sandbags")
	_add_prop("west_ground", 152, "crate_stack")
	_add_prop("west_island", 150, "crate")
	_add_prop("west_island", 192, "crate_stack")
	_add_prop("tun1", 215, "barrel")
	_add_prop("tun1", 382, "crate_stack")
	_add_prop("tun1", 505, "barricade")
	_add_prop("tun1", 603, "barrel")
	_add_prop("roof_b", 500, "barrel")
	_add_prop("bowl", 460, "crate")
	_add_prop("east_roof_a", 812, "crate")
	_add_prop("tun2", 640, "crate")
	_add_prop("tun2", 745, "sandbags")
	_add_prop("tun2", 912, "crate_stack")
	_add_prop("top_right", 805, "barrel")
	_add_prop("east_mid", 892, "barricade")
	_add_prop("east_body", 1000, "sandbags")
	_add_prop("east_body", 1056, "crate")
	_add_prop("east_body", 1090, "barrel")

	# ---------- lanterns along the tunnel roofs ----------
	for x in [210.0, 300.0, 330.0, 420.0, 520.0]:
		_add_lantern("ceil1" if x < 358.0 else "ceil1b", x)
	for x in [655.0, 745.0, 835.0]:
		_add_lantern("ceil2", x)



# =====================================================================
#  ENVIRONMENT: rock clusters, loose stones, keep-out zones
# =====================================================================
# Rock clusters mix four sizes. "pebble" and "stone" are loose decoration you walk past (they sit
# at ankle height). "rock" and "boulder" are SOLID low domes you can walk over or take cover behind.
# Every piece is checked against the keep-out zones below (pickups, throwable spawns, crates and
# barrels, the bunker, the player spawn) and against the slope of the ground, and is silently skipped
# if it would block a route. Tunnels are never touched.

func _define_environment() -> void:
	_build_keepouts()

	# ---- clusters (path id, x in sketch px, parts: [offset px, kind, width px, height px]) ----
	_add_cluster("roof_a", 322.0, [[0, "boulder", 74, 42], [-56, "stone", 24, 15], [-70, "pebble", 12, 8], [52, "stone", 20, 13], [64, "pebble", 10, 7]])
	_add_cluster("roof_b", 548.0, [[0, "boulder", 66, 38], [-48, "stone", 22, 14], [-60, "pebble", 11, 7], [42, "stone", 18, 12]])
	_add_cluster("east_roof_a", 726.0, [[0, "boulder", 72, 42], [-54, "stone", 24, 15], [-66, "pebble", 12, 8], [50, "stone", 22, 14]])
	_add_cluster("east_roof_a", 644.0, [[0, "rock", 50, 30], [-40, "stone", 20, 13], [-52, "pebble", 10, 7], [38, "stone", 18, 12]])
	_add_cluster("west_ground", 40.6, [[0, "rock", 48, 30]])
	_add_cluster("east_body", 1104.0, [[0, "rock", 40, 24], [30, "pebble", 11, 7], [-30, "stone", 18, 12]])
	_add_cluster("east_body", 1132.0, [[0, "stone", 22, 14], [-18, "pebble", 10, 7]])
	_add_cluster("east_mid", 902.0, [[0, "stone", 22, 14], [16, "pebble", 10, 7], [-18, "stone", 16, 10]])
	_add_cluster("center", 606.0, [[0, "stone", 24, 15], [20, "pebble", 10, 7], [-22, "stone", 16, 10]])
	_add_cluster("bowl", 386.0, [[0, "stone", 22, 14], [16, "pebble", 10, 7]])
	_add_cluster("top_right", 792.0, [[0, "stone", 22, 14], [18, "pebble", 10, 7]])
	_add_cluster("ledge_e", 908.0, [[0, "stone", 24, 14], [22, "pebble", 11, 7], [-24, "pebble", 10, 6]])
	_add_cluster("ledge_a", 122.0, [[0, "stone", 20, 12], [14, "pebble", 9, 6]])
	_add_cluster("ledge_b", 262.0, [[0, "stone", 20, 12], [-14, "pebble", 9, 6]])
	_add_cluster("ledge_d", 756.0, [[0, "stone", 22, 13], [16, "pebble", 10, 6]])
	_add_cluster("west_island", 285.0, [[0, "stone", 24, 15], [-20, "pebble", 10, 7], [20, "stone", 16, 10]])

	# ---- loose stones at the foot of the existing boulders, so they do not stand alone ----
	for item in _rocks.duplicate():
		var r: Dictionary = item
		if String(r["kind"]) != "mound" or not OPEN_SURFACES.has(String(r["path"])):
			continue
		var w: float = r["w"]
		var sw := clampf(w * 0.16, 14.0, 24.0)
		var path_id := String(r["path"])
		var x_img: float = r["x"]
		_add_stone_checked(path_id, x_img - (w * 0.5 + sw * 0.35) / S, sw, sw * 0.62, "stone")
		_add_stone_checked(path_id, x_img + (w * 0.5 + sw * 0.15) / S, sw * 0.6, sw * 0.4, "pebble")

	# ---- a sparse scatter of pebbles along the open tops so long stretches are not bare ----
	var rng := RandomNumberGenerator.new()
	rng.seed = 5150
	for id in OPEN_SURFACES:
		if not _paths.has(String(id)):
			continue
		var path: PackedVector2Array = _paths[String(id)]
		var x_img := (path[0].x - ORIGIN.x) / S + 14.0
		var x_end := (path[path.size() - 1].x - ORIGIN.x) / S - 14.0
		while x_img < x_end:
			x_img += rng.randf_range(20.0, 38.0)
			if rng.randf() < 0.45:
				var kind := "stone" if rng.randf() < 0.3 else "pebble"
				var sz := rng.randf_range(15.0, 21.0) if kind == "stone" else rng.randf_range(7.0, 12.0)
				_add_stone_checked(String(id), x_img, sz, sz * 0.62, kind)


func _build_keepouts() -> void:
	_keepout.clear()
	for s in PICKUP_SPOTS:
		var p := _spot(String(s[0]), float(s[1]), 0.0)
		_keepout.append(Rect2(p + Vector2(-36.0, -70.0), Vector2(72.0, 90.0)))
	for s in THROWABLE_SPOTS:
		var p2 := _spot(String(s[0]), float(s[1]), 0.0)
		_keepout.append(Rect2(p2 + Vector2(-34.0, -56.0), Vector2(68.0, 80.0)))
	for p3 in ROOT_SPOTS:
		_keepout.append(Rect2((p3 as Vector2) + Vector2(-50.0, -90.0), Vector2(100.0, 180.0)))
	for item in _props:
		var pr: Dictionary = item
		_keepout.append((pr["rect"] as Rect2).grow(10.0))
	for item in _bunkers:
		var b: Dictionary = item
		_keepout.append((b["back"] as Rect2).grow(26.0))
		for rect in b["solids"]:
			_keepout.append((rect as Rect2).grow(26.0))
		_keepout.append(Rect2((b["flag"] as Vector2) + Vector2(-30.0, -90.0), Vector2(110.0, 100.0)))


func _blocked_by_keepout(r: Rect2) -> bool:
	for k in _keepout:
		if (k as Rect2).intersects(r):
			return true
	return false


# Is there room on `path_id` at `ximg` for a piece `w` px wide and `h` px tall?
func _site_ok(path_id: String, ximg: float, w: float, h: float, solid: bool) -> bool:
	if not _paths.has(path_id):
		return false
	var path: PackedVector2Array = _paths[path_id]
	var cx := ximg * S + ORIGIN.x
	var hw := w * 0.5
	var margin := hw + (22.0 if solid else 6.0)          # keep off the very end of a surface
	if cx - margin < path[0].x or cx + margin > path[path.size() - 1].x:
		return false
	var y_c := _path_y(path_id, ximg)
	var y_l := _path_y(path_id, (cx - hw - ORIGIN.x) / S)
	var y_r := _path_y(path_id, (cx + hw - ORIGIN.x) / S)
	var tilt := absf(y_r - y_l) / maxf(w, 1.0)
	if tilt > (0.34 if solid else 0.55):
		return false                                       # too steep: it would sit badly and block a slope
	var base := maxf(y_c, maxf(y_l, y_r)) + 8.0
	var top := base - (minf(h + 8.0, hw * 1.5) if solid else h)
	var foot := Rect2(cx - hw - (10.0 if solid else 3.0), top - 6.0, w + (20.0 if solid else 6.0), base - top + 10.0)
	if _blocked_by_keepout(foot):
		return false
	if solid:
		for item in _rocks:
			var r: Dictionary = item
			if _bounds(r["poly"] as PackedVector2Array).grow(8.0).intersects(foot):
				return false
	return true


func _add_cluster(path_id: String, ximg: float, parts: Array) -> void:
	for part in parts:
		var x_img := ximg + float(part[0]) / S
		var kind := String(part[1])
		var w := float(part[2])
		var h := float(part[3])
		if kind == "rock" or kind == "boulder":
			if _site_ok(path_id, x_img, w, h, true):
				_add_rock(path_id, x_img, "mound", w, h)
		else:
			_add_stone_checked(path_id, x_img, w, h, kind)


func _add_stone_checked(path_id: String, ximg: float, w: float, h: float, kind: String) -> void:
	if _site_ok(path_id, ximg, w, h, false):
		_add_stone(path_id, ximg, w, h, kind)


# A loose stone: a rounded lump sunk a few pixels into the ground. Decoration only (no collision).
func _add_stone(path_id: String, ximg: float, w: float, h: float, kind: String) -> void:
	var cx := ximg * S + ORIGIN.x
	var hw := w * 0.5
	var y_c := _path_y(path_id, ximg)
	var y_l := _path_y(path_id, (cx - hw - ORIGIN.x) / S)
	var y_r := _path_y(path_id, (cx + hw - ORIGIN.x) / S)
	var base := maxf(y_c, maxf(y_l, y_r)) + 4.0
	var seed_v := cx * 0.017 + w
	var poly := PackedVector2Array()
	var n := 12
	for i in range(n + 1):
		var u := -1.0 + 2.0 * float(i) / float(n)
		var bell := pow(maxf(cos(u * PI * 0.5), 0.0), 0.8)
		var lump := 1.0 - 0.14 * absf(sin(float(i) * 2.3 + seed_v))
		var skew := 1.0 + 0.2 * u * sin(seed_v)
		poly.append(Vector2(cx + u * hw, base - bell * h * lump * skew))
	_stones.append({"poly": poly, "base": Vector2(cx, base), "kind": kind, "seed": seed_v})


# =====================================================================
#  COLLISION, PICKUPS, SPAWNERS
# =====================================================================

func _build_collisions() -> void:
	_static_body = StaticBody2D.new()
	_static_body.name = "MapCollision"
	_static_body.add_to_group("map_solid")
	add_child(_static_body)
	for item in _solids:
		var s: Dictionary = item
		_add_collision_poly(s["poly"] as PackedVector2Array)
	for item in _rocks:
		var r: Dictionary = item
		_add_collision_poly(r["poly"] as PackedVector2Array)
	for item in _bunkers:
		var b: Dictionary = item
		for rect in b["solids"]:
			_add_collision_rect(rect as Rect2)
	for item in _props:
		var p: Dictionary = item
		_add_collision_rect(p["rect"] as Rect2)
	# There are NO side, ceiling or floor colliders: fighters can fly past the edge or fall off the bottom,
	# and out_of_bounds.gd drains their health the farther they go (and kills them at the kill distance).
	# Nothing below the islands is solid, so a fall is always fatal unless you jet back up in time.


func _add_collision_poly(poly: PackedVector2Array) -> void:
	var shape := CollisionPolygon2D.new()
	shape.polygon = _simplify_poly(poly, LITE_COLLISION_TOL if _mobile else 1.6)   # far fewer physics pieces, within ~1.6 px (3 px on phones) of the art
	_static_body.add_child(shape)


# Douglas-Peucker on a closed outline: drops points that barely change the shape. Used for collision
# only, so the physics stays light on phones while the painted outline keeps every curve.
func _simplify_poly(poly: PackedVector2Array, tol: float) -> PackedVector2Array:
	var n := poly.size()
	if n < 10:
		return poly
	var far := 0
	var best := -1.0
	for i in n:
		var d := poly[i].distance_to(poly[0])
		if d > best:
			best = d
			far = i
	var keep := PackedByteArray()
	keep.resize(n)
	keep[0] = 1
	keep[far] = 1
	_dp_chain(poly, 0, far, tol, keep)
	_dp_chain(poly, far, n, tol, keep)
	var out := PackedVector2Array()
	for i in n:
		if keep[i] == 1:
			out.append(poly[i])
	if out.size() < 3 or not _is_simple(out):
		return poly
	return out


func _dp_chain(poly: PackedVector2Array, i0: int, i1: int, tol: float, keep: PackedByteArray) -> void:
	if i1 - i0 < 2:
		return
	var a := poly[i0]
	var b := poly[i1 % poly.size()]
	var worst := -1.0
	var worst_i := -1
	for i in range(i0 + 1, i1):
		var d := Geometry2D.get_closest_point_to_segment(poly[i], a, b).distance_to(poly[i])
		if d > worst:
			worst = d
			worst_i = i
	if worst > tol:
		keep[worst_i] = 1
		_dp_chain(poly, i0, worst_i, tol, keep)
		_dp_chain(poly, worst_i, i1, tol, keep)


func _add_collision_rect(rect: Rect2) -> void:
	var collision := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = rect.size
	collision.shape = shape
	collision.position = rect.position + rect.size * 0.5
	_static_body.add_child(collision)


func _build_weapon_pickups() -> void:
	var pool := WeaponCatalog.all()
	if pool.is_empty():
		push_warning("Cavern Isles: weapon catalog is empty; no map weapons spawned.")
		return
	# two more guns come from the main scene via the arena controller (see ROOT_SPOTS)
	for s in PICKUP_SPOTS:
		var pickup := WeaponPickup.new()
		pickup.weapon_pool = pool
		pickup.respawn_time = 15.0
		pickup.position = _spot(String(s[0]), float(s[1]), 26.0)
		add_child(pickup)


func _build_throwable_spawner() -> void:
	var spawner := ThrowableSpawner.new()
	spawner.name = "CavernThrowableSpawner"
	spawner.map_id = map_id
	spawner.interval = 7.0
	spawner.max_active = 6
	spawner.initial_spawns = 4
	var points := PackedVector2Array()
	for s in THROWABLE_SPOTS:
		points.append(_spot(String(s[0]), float(s[1]), 2.0))
	spawner.spawn_points = points
	add_child(spawner)


# How far past the safe area anything can ever be (the kill distance plus some slack).
func _oob_reach() -> float:
	return maxf(oob_kill_distance, oob_full_damage_distance) + 800.0


# The safe area: left, right and top edges are the old invisible walls; the bottom is where the old cloud floor used to be (now a bottomless drop).
func get_playable_rect() -> Rect2:
	return Rect2(MAP_LEFT, CEILING_Y, MAP_RIGHT - MAP_LEFT, (MAP_BOTTOM - 120.0) - CEILING_Y)


func _set_camera_limits() -> void:
	var scene := get_tree().current_scene
	if scene == null:
		return
	var camera := scene.find_child("Camera2D", true, false) as Camera2D
	if camera != null:
		# The camera keeps following you past the edge, all the way to where the kill distance is.
		var reach := int(_oob_reach())
		camera.limit_left = int(MAP_LEFT) - reach
		camera.limit_right = int(MAP_RIGHT) + reach
		camera.limit_top = int(CEILING_Y) - reach
		camera.limit_bottom = int(MAP_BOTTOM) + reach      # keeps following you all the way down


func _build_out_of_bounds() -> void:
	if not oob_enabled:
		return
	var rule := OutOfBoundsRule.new()
	rule.name = "OutOfBounds"
	rule.safe_rect = get_playable_rect()
	rule.check_bottom = true
	rule.warning_distance = oob_warning_distance
	rule.damage_distance = oob_damage_distance
	rule.full_damage_distance = oob_full_damage_distance
	rule.kill_distance = oob_kill_distance
	rule.min_damage_per_second = oob_min_damage_per_second
	rule.max_damage_per_second = oob_max_damage_per_second
	rule.affect_bots = oob_bots_too
	add_child(rule)


# Walkable points for SpawnSafety: every top surface and both tunnel floors, every 70 px. Most of
# them are rejected there if a rock, crate or wall is in the way; only the clear ones are used.
func get_bot_spawn_candidates() -> PackedVector2Array:
	var out := PackedVector2Array()
	for item in _solids:
		var s: Dictionary = item
		var top: PackedVector2Array = s["top"]
		if top.size() >= 2:
			out.append_array(_sample_line(top, 70.0, 26.0))
	for id in ["tun1", "tun2"]:
		if _paths.has(id):
			out.append_array(_sample_line(_paths[id] as PackedVector2Array, 70.0, 20.0))
	return out


func _sample_line(pts: PackedVector2Array, step: float, trim: float) -> PackedVector2Array:
	var out := PackedVector2Array()
	var total := 0.0
	for i in range(pts.size() - 1):
		total += pts[i].distance_to(pts[i + 1])
	if total <= trim * 2.0:
		return out
	var want := trim
	var walked := 0.0
	for i in range(pts.size() - 1):
		var a := pts[i]
		var b := pts[i + 1]
		var seg := a.distance_to(b)
		while want <= walked + seg and want <= total - trim:
			var t := (want - walked) / maxf(seg, 0.001)
			out.append(a.lerp(b, t))
			want += step
		walked += seg
	return out


# What is under a footstep at this point (used by GroundContact for dust colour and sound).
func surface_kind_at(p: Vector2) -> String:
	for item in _bunkers:
		var b: Dictionary = item
		var back: Rect2 = b["back"]
		if back.grow(24.0).has_point(p):
			var style := String(b["style"])
			return "metal" if style == "metal" else ("stone" if style == "stone" else "wood")
	for item in _cavities:
		var cav: Dictionary = item
		if Geometry2D.is_point_in_polygon(p, cav["poly"] as PackedVector2Array):
			return "stone"
	return "grass"


# =====================================================================
#  NODES
# =====================================================================

func _build_nodes() -> void:
	_sky = Node2D.new()
	_sky.name = "Sky"
	_sky.z_index = -50
	_sky.draw.connect(_paint_sky.bind(_sky))
	add_child(_sky)
	_art_nodes.append(_sky)

	_clouds = Node2D.new()
	_clouds.name = "Clouds"
	_clouds.z_index = -40
	_build_cloud_nodes()                         # one small node per cloud, so off-screen clouds are skipped
	add_child(_clouds)
	_art_nodes.append(_clouds)

	_build_terrain_chunks()                      # terrain split into many small pieces (see below)

	# Drawn OVER the characters (the map sits at -10, so +12 is just above them): tunnel shade (painted
	# once) and, in a separate node, the flickering lantern glow.
	var shade := Node2D.new()
	shade.name = "TunnelShade"
	shade.z_index = 12
	shade.draw.connect(_paint_shade.bind(shade))
	add_child(shade)
	_art_nodes.append(shade)
	_front = Node2D.new()
	_front.name = "ForegroundFx"
	_front.z_index = 12
	_front.draw.connect(_paint_front.bind(_front))
	add_child(_front)
	_art_nodes.append(_front)


# ---- PHONES: why the terrain is split ---------------------------------------------------------
# The engine only skips drawing things that are completely off screen, and it decides that per node.
# The old terrain was ONE node holding thousands of shapes (about 8,000 draw calls), so the whole map was
# redrawn every frame even when you saw a tenth of it. Here every rock mass, bunker, prop and each ~500 px
# stretch of grass is its own node, so only what is on screen costs anything. No bake, no shader, no
# texture memory; the look is the same minus a few small details.
# NOTE: painter.bind(n) puts the node FIRST, then the arguments bound earlier, so every _chunk_* function
# takes the canvas item `c` as its first parameter.
func _spawn_chunk(parent: Node2D, painter: Callable) -> void:
	var n := Node2D.new()
	n.use_parent_material = true               # Medium / High put the terrain shader on the parent
	n.draw.connect(painter.bind(n))
	parent.add_child(n)


func _build_terrain_chunks() -> void:
	var root := Node2D.new()
	root.name = "TerrainChunks"
	if _q == 0:
		root.modulate = Color(0.93, 0.93, 0.94)      # Low: no shader; this stands in for its slightly darker, cooler tone
	else:
		var shader := load(TERRAIN_SHADER_PATH if _q == 2 else SHADER_LITE_PATH) as Shader
		if shader != null:                           # if the file is missing the terrain just draws flat (safe fallback)
			var mat := ShaderMaterial.new()
			mat.shader = shader
			root.material = mat
	add_child(root)
	_art_nodes.append(root)
	var n := 0
	for item in _backs:
		n += 1
		_spawn_chunk(root, _chunk_back.bind(item, 90417 + n))
	for item in _solids:
		var s: Dictionary = item
		n += 1
		_spawn_chunk(root, _chunk_solid.bind(s, 90417 + n))
		var top: PackedVector2Array = s["top"]
		if bool(s["grass"]) and int(s["top_count"]) > 1 and top.size() >= 2:
			var start := 0
			while start < top.size() - 1:
				var piece := PackedVector2Array()
				piece.append(top[start])
				var run := 0.0
				var j := start
				while j < top.size() - 1 and run < 500.0:
					run += top[j].distance_to(top[j + 1])
					j += 1
					piece.append(top[j])
				n += 1
				_spawn_chunk(root, _chunk_grass.bind(piece, float(s["seed"]), 777 + n))
				start = j
	for item in _bunkers:
		_spawn_chunk(root, _chunk_bunker.bind(item))
	for item in _rocks:
		_spawn_chunk(root, _chunk_rock.bind(item))
	for item in _stones:
		_spawn_chunk(root, _chunk_stone.bind(item))
	for item in _props:
		_spawn_chunk(root, _chunk_prop.bind(item))
	for p in _lanterns:
		_spawn_chunk(root, _chunk_lantern.bind(p))
	_bake_state = "%d pieces" % root.get_child_count()


func _chunk_back(c: CanvasItem, d: Dictionary, sd: int) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = sd
	_paint_back(c, d, rng)


func _chunk_solid(c: CanvasItem, s: Dictionary, sd: int) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = sd
	_paint_solid(c, s, rng, false)


func _chunk_grass(c: CanvasItem, piece: PackedVector2Array, sd: float, rseed: int) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = rseed
	_paint_grass(c, piece, rng, sd)
	if _q >= 1:
		_paint_flowers(c, piece, sd)


func _chunk_bunker(c: CanvasItem, d: Dictionary) -> void:
	_paint_bunker(c, d)


func _chunk_rock(c: CanvasItem, d: Dictionary) -> void:
	_paint_rock_solid(c, d)


func _chunk_stone(c: CanvasItem, d: Dictionary) -> void:
	_paint_stone(c, d)


func _chunk_prop(c: CanvasItem, d: Dictionary) -> void:
	_paint_prop(c, d)


func _chunk_lantern(c: CanvasItem, p: Vector2) -> void:
	_paint_lantern(c, p)


# One node per cloud (each tiled copy), instead of one node with ~180 circles.
func _build_cloud_nodes() -> void:
	var layout := _cloud_layout()
	for tile in range(-3, 6):
		for item in layout:
			_spawn_chunk(_clouds, _chunk_cloud.bind(float(tile) * CLOUD_PERIOD + float(item[0]), float(item[1]), float(item[2])))


func _chunk_cloud(c: CanvasItem, cx: float, cy: float, sz: float) -> void:
	_cloud_puff(c, cx, cy, sz)


# =====================================================================
#  PAINTING: SKY
# =====================================================================

func _paint_sky(c: CanvasItem) -> void:
	# The sky reaches past the out-of-bounds zone so there is never a blank edge while you fly out.
	var reach := _oob_reach()
	var x0 := minf(-1500.0, MAP_LEFT - reach - 1500.0)
	var w := (MAP_RIGHT + reach + 1500.0) - x0
	var y0 := -800.0
	var h := MAP_BOTTOM + 1600.0
	var top_fill := minf(0.0, CEILING_Y - reach - 1600.0)
	c.draw_rect(Rect2(x0, top_fill, w, y0 - top_fill + 2.0), SKY_TOP)
	var bands: int = SKY_BANDS[_q]
	for i in bands:
		var t := float(i) / float(bands - 1)
		var col: Color
		if t < 0.6:
			col = SKY_TOP.lerp(SKY_MID, t / 0.6)
		else:
			col = SKY_MID.lerp(SKY_HORIZON, (t - 0.6) / 0.4)
		c.draw_rect(Rect2(x0, y0 + h * float(i) / float(bands), w, h / float(bands) + 2.0), col)
	# low sun with a soft halo
	var sun := Vector2(MAP_RIGHT * 0.70, 1000.0)
	if _q == 0:
		for k in 3:                                      # fewer, slightly stronger rings: less see-through overdraw
			c.draw_circle(sun, 430.0 - float(k) * 124.0, Color(1.0, 0.95, 0.78, 0.09))
	else:
		for k in 6:
			c.draw_circle(sun, 430.0 - float(k) * 62.0, Color(1.0, 0.95, 0.78, 0.05))
	c.draw_circle(sun, 84.0, Color("fff3cf"))
	# distant floating islands (hazy silhouettes)
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242
	for i in 9:
		var cx := lerpf(MAP_LEFT - 300.0, MAP_RIGHT + 300.0, float(i) / 8.0) + rng.randf_range(-120.0, 120.0)
		var cy := rng.randf_range(1100.0, 2050.0)
		var iw := rng.randf_range(160.0, 330.0)
		var pts := PackedVector2Array()
		pts.append(Vector2(cx - iw, cy))
		pts.append(Vector2(cx - iw * 0.4, cy - 22.0))
		pts.append(Vector2(cx + iw * 0.5, cy - 18.0))
		pts.append(Vector2(cx + iw, cy))
		pts.append(Vector2(cx + iw * 0.45, cy + iw * 0.42))
		pts.append(Vector2(cx, cy + iw * 0.62))
		pts.append(Vector2(cx - iw * 0.5, cy + iw * 0.38))
		c.draw_colored_polygon(pts, Color(0.55, 0.66, 0.78, 0.38))
	# (no cloud sea: nothing below the islands is solid any more, so nothing should look like a floor)


func _cloud_layout() -> Array:
	var rng := RandomNumberGenerator.new()
	rng.seed = 777
	var layout: Array = []
	for i in 5:
		layout.append([rng.randf_range(0.0, CLOUD_PERIOD), rng.randf_range(760.0, 1900.0), rng.randf_range(0.7, 1.4)])
	return layout


func _cloud_puff(c: CanvasItem, cx: float, cy: float, sz: float) -> void:
	var base := Color(1.0, 1.0, 1.0, 0.55)
	c.draw_circle(Vector2(cx, cy), 46.0 * sz, base)
	c.draw_circle(Vector2(cx + 58.0 * sz, cy - 16.0 * sz), 56.0 * sz, base)
	c.draw_circle(Vector2(cx + 120.0 * sz, cy), 44.0 * sz, base)
	c.draw_circle(Vector2(cx + 60.0 * sz, cy + 14.0 * sz), 50.0 * sz, base)


# =====================================================================
#  PAINTING: TERRAIN (painted once)
# =====================================================================

func _paint_terrain(c: CanvasItem) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 90417
	for item in _backs:
		_paint_back(c, item as Dictionary, rng)
	for item in _solids:
		_paint_solid(c, item as Dictionary, rng)
	for item in _bunkers:
		_paint_bunker(c, item as Dictionary)
	for item in _rocks:
		_paint_rock_solid(c, item as Dictionary)
	for item in _stones:
		_paint_stone(c, item as Dictionary)
	for item in _props:
		_paint_prop(c, item as Dictionary)
	for p in _lanterns:
		_paint_lantern(c, p as Vector2)


func _paint_back(c: CanvasItem, d: Dictionary, rng: RandomNumberGenerator) -> void:
	var poly: PackedVector2Array = d["poly"]
	var col: Color = d["color"]
	c.draw_colored_polygon(poly, col)
	if bool(d["speckle"]):
		var bounds := _bounds(poly)
		var count := clampi(int(bounds.size.x * bounds.size.y / 5200.0), 4, 70)
		for i in count:
			var pt := Vector2(rng.randf_range(bounds.position.x, bounds.end.x), rng.randf_range(bounds.position.y, bounds.end.y))
			if Geometry2D.is_point_in_polygon(pt, poly):
				var lit := rng.randf() < 0.5
				c.draw_circle(pt, rng.randf_range(2.5, 6.0), col.lightened(0.12) if lit else col.darkened(0.2))
	if bool(d["edge"]):
		var closed := PackedVector2Array(poly)
		closed.append(poly[0])
		c.draw_polyline(closed, PILLAR_EDGE, 4.0, true)


# Warm/cool shift by position so the west and east of the map feel like different places.
func _rock_tint(x: float, sd: float) -> Color:
	var warm := clampf((x - 230.0) / 4900.0, 0.0, 1.0)
	var j := (sd - 0.5) * 0.06
	return Color(0.97 + warm * 0.07 + j, 0.99 + warm * 0.01, 1.03 - warm * 0.08 - j)


func _rock_colors(poly: PackedVector2Array, rect: Rect2, tint: Color, k: float) -> PackedColorArray:
	var colors := PackedColorArray()
	for pt in poly:
		var t := clampf((pt.y - rect.position.y) / maxf(rect.size.y, 1.0), 0.0, 1.0)
		var col := ROCK_LIGHT.lerp(ROCK_DARK, t) * tint
		colors.append(Color(col.r * k, col.g * k, col.b * k, 1.0))
	return colors


func _rand_in(rect: Rect2, rng: RandomNumberGenerator) -> Vector2:
	return Vector2(rng.randf_range(rect.position.x, rect.end.x), rng.randf_range(rect.position.y, rect.end.y))


func _inside_margin(poly: PackedVector2Array, pt: Vector2, m: float) -> bool:
	return Geometry2D.is_point_in_polygon(pt, poly) \
			and Geometry2D.is_point_in_polygon(pt + Vector2(0.0, -m), poly) \
			and Geometry2D.is_point_in_polygon(pt + Vector2(m, 0.0), poly) \
			and Geometry2D.is_point_in_polygon(pt + Vector2(-m, 0.0), poly)


func _paint_solid(c: CanvasItem, s: Dictionary, rng: RandomNumberGenerator, with_grass: bool = true) -> void:
	var poly: PackedVector2Array = s["poly"]
	var rect: Rect2 = s["rect"]
	var top_count: int = s["top_count"]
	var sd: float = s["seed"]
	var tint := _rock_tint(rect.get_center().x, sd)
	var area_n := rect.size.x * rect.size.y * 0.5
	# body: three soft steps from a darker rim to the lit core, so every mass reads as rounded
	c.draw_polygon(poly, _rock_colors(poly, rect, tint, 0.74))
	for step in [[-6.0, 0.87], [-14.0, 1.0]]:
		for inner in Geometry2D.offset_polygon(poly, float(step[0]), Geometry2D.JOIN_ROUND):
			var ip := inner as PackedVector2Array
			if ip.size() >= 3:
				c.draw_polygon(ip, _rock_colors(ip, rect, tint, float(step[1])))
	# broad, faint patches of lighter and darker stone (smooth, not speckled)
	for i in clampi(int(area_n / 26000.0), 2, 14):
		var pt := _rand_in(rect, rng)
		var rad := rng.randf_range(16.0, 38.0)
		if _inside_margin(poly, pt, rad * 0.8):
			var blob := PackedVector2Array()
			for k in 12:
				var ang := TAU * float(k) / 12.0
				blob.append(pt + Vector2(cos(ang) * rad * rng.randf_range(0.8, 1.15), sin(ang) * rad * 0.7 * rng.randf_range(0.8, 1.15)))
			var lit := rng.randf() < 0.5
			c.draw_colored_polygon(blob, Color(1.0, 1.0, 1.0, 0.05) if lit else Color(0.0, 0.0, 0.0, 0.06))
	# a few long, gently curving cracks (dark line with a faint light twin)
	for i in clampi(int(area_n / 90000.0), 0, 3):
		var start := _rand_in(rect, rng)
		if not _inside_margin(poly, start, 30.0):
			continue
		var cur := start
		var ang := rng.randf_range(1.0, 2.1)
		var line := PackedVector2Array([cur])
		for st in 6:
			ang += rng.randf_range(-0.28, 0.28)
			cur += Vector2(cos(ang), sin(ang)) * rng.randf_range(12.0, 18.0)
			if not Geometry2D.is_point_in_polygon(cur, poly):
				break
			line.append(cur)
		if line.size() >= 3:
			var twin := PackedVector2Array()
			for q in line:
				twin.append(q + Vector2(1.6, -1.2))
			c.draw_polyline(twin, Color(1.0, 1.0, 1.0, 0.13), 1.6, true)
			c.draw_polyline(line, Color(0.09, 0.07, 0.05, 0.38), 1.7, true)
	# stones embedded in the rock: mostly small, a few bigger
	for i in clampi(int(area_n / ([18000.0, 9000.0, 7000.0][_q])), 2, 40):
		var pt := _rand_in(rect, rng)
		var r := 3.8 + 8.0 * pow(rng.randf(), 2.2)
		if _inside_margin(poly, pt, 18.0):
			_pebble(c, pt, r, rng, tint)
	# rock layers: gently curving strata lines across the big masses
	_paint_strata(c, poly, rect, sd)
	# outline
	var closed := PackedVector2Array(poly)
	closed.append(poly[0])
	c.draw_polyline(closed, OUTLINE, 3.0, true)
	# stones resting on the outline of undersides and cut walls, spaced out
	var last := Vector2(-99999.0, -99999.0)
	for i in range(top_count, poly.size()):
		if poly[i].distance_to(last) > ([80.0, 46.0, 46.0][_q]) and rng.randf() < 0.7:
			var r2 := rng.randf_range(5.5, 10.0)
			_pebble(c, poly[i] + Vector2(0.0, -r2 * 0.35), r2, rng, tint)
			last = poly[i]
	if ROOT_ISLANDS.has(String(s["id"])):
		_paint_roots(c, poly, top_count, rect, sd)
	if with_grass and bool(s["grass"]) and top_count > 1:
		_paint_grass(c, s["top"] as PackedVector2Array, rng, sd)
		_paint_flowers(c, s["top"] as PackedVector2Array, sd)


func _pebble(c: CanvasItem, center: Vector2, r: float, rng: RandomNumberGenerator, tint: Color = Color(1, 1, 1, 1)) -> void:
	var n := 10
	var pts := PackedVector2Array()
	var wob := rng.randf_range(0.0, TAU)
	for i in n:
		var a := TAU * float(i) / float(n)
		var rr := r * (1.0 + 0.10 * sin(a * 2.0 + wob))
		pts.append(center + Vector2(cos(a) * rr, sin(a) * rr * 0.8))
	var col: Color = ROCK_COLORS[rng.randi_range(0, ROCK_COLORS.size() - 1)] * tint
	c.draw_colored_polygon(pts, col.darkened(0.12))
	var core := PackedVector2Array()
	for q in pts:
		core.append(center + (q - center) * 0.82 + Vector2(-r * 0.06, -r * 0.08))
	c.draw_colored_polygon(core, col)
	var closed := PackedVector2Array(pts)
	closed.append(pts[0])
	c.draw_polyline(closed, Color(PEBBLE_EDGE.r, PEBBLE_EDGE.g, PEBBLE_EDGE.b, 0.6), 1.5, true)


func _grass_blade(c: CanvasItem, p: Vector2, h: float, lean: float, col: Color) -> void:
	c.draw_colored_polygon(PackedVector2Array([p + Vector2(-3.0, 2.0), p + Vector2(lean, -h), p + Vector2(3.0, 2.0)]), col)


# Grass cap that follows the real top contour. Rock -> soil band -> grass, with a smoothly varying
# thickness that thins out on steep faces, and short, even tufts.
func _paint_grass(c: CanvasItem, top: PackedVector2Array, rng: RandomNumberGenerator, sd: float) -> void:
	if top.size() < 2:
		return
	var green := GRASS.lerp(GRASS_HI, sd * 0.3)
	var ph := sd * TAU
	var th := PackedFloat32Array()
	for i in top.size():
		var nb := top[mini(i + 1, top.size() - 1)] - top[maxi(i - 1, 0)]
		var ang := rad_to_deg(atan2(absf(nb.y), maxf(absf(nb.x), 0.001)))
		var steep := clampf(ang / 60.0, 0.0, 1.0)
		var wave := 0.55 * sin(top[i].x * 0.045 + ph) + 0.45 * sin(top[i].x * 0.11 + ph * 2.0)
		th.append((10.0 + 3.0 * wave) * (1.0 - 0.45 * steep))
	for i in range(top.size() - 1):
		var a := top[i]
		var b := top[i + 1]
		var t0 := th[i]
		var t1 := th[i + 1]
		c.draw_colored_polygon(PackedVector2Array([a + Vector2(0, -2), b + Vector2(0, -2), b + Vector2(0, t1 + 9.0), a + Vector2(0, t0 + 9.0)]), SOIL)
		c.draw_colored_polygon(PackedVector2Array([a + Vector2(0, -4), b + Vector2(0, -4), b + Vector2(0, t1 + 3.0), a + Vector2(0, t0 + 3.0)]), GRASS_DARK)
		c.draw_colored_polygon(PackedVector2Array([a + Vector2(0, -5), b + Vector2(0, -5), b + Vector2(0, t1), a + Vector2(0, t0)]), green)
		var ang_seg := rad_to_deg(atan2(absf(b.y - a.y), maxf(absf(b.x - a.x), 0.001)))
		if ang_seg > 55.0:
			continue
		var steps := maxi(int(a.distance_to(b) / ([30.0, 15.0, 11.0][_q])), 1)
		for k in steps:
			var pt := a.lerp(b, (float(k) + rng.randf_range(0.2, 0.8)) / float(steps)) + Vector2(0.0, -2.0)
			var h := rng.randf_range(6.0, 12.0)
			var lean := rng.randf_range(-4.0, 4.0)
			_grass_blade(c, pt, h, lean, GRASS_HI if rng.randf() < 0.35 else green)
	var hi := PackedVector2Array()
	for pt in top:
		hi.append(pt + Vector2(0.0, -4.0))
	c.draw_polyline(hi, Color(GRASS_HI.r, GRASS_HI.g, GRASS_HI.b, 0.55), 2.0, true)


func _ellipse(c: CanvasItem, center: Vector2, rx: float, ry: float, color: Color) -> void:
	var pts := PackedVector2Array()
	for i in 14:
		var a := TAU * float(i) / 14.0
		pts.append(center + Vector2(cos(a) * rx, sin(a) * ry))
	c.draw_colored_polygon(pts, color)


# Fills the part of `poly` that lies on one side of the line p0 -> p1 (side -1 = the side the
# normal (-dy, dx) points away from). Used for lit and shaded facets on rocks.
func _facet(c: CanvasItem, poly: PackedVector2Array, p0: Vector2, p1: Vector2, side: float, color: Color) -> void:
	var dir := (p1 - p0).normalized()
	var nrm := Vector2(-dir.y, dir.x) * side
	var big := 600.0
	var quad := PackedVector2Array([p0 - dir * big, p1 + dir * big, p1 + dir * big + nrm * big, p0 - dir * big + nrm * big])
	for piece in Geometry2D.intersect_polygons(poly, quad):
		var pp := piece as PackedVector2Array
		if pp.size() >= 3:
			c.draw_colored_polygon(pp, color)


func _paint_rock_solid(c: CanvasItem, r: Dictionary) -> void:
	var poly: PackedVector2Array = r["poly"]
	var kind := String(r["kind"])
	var rng := RandomNumberGenerator.new()
	rng.seed = int(poly[0].x * 7.0) + int(poly[0].y)
	var b := _bounds(poly)
	var col: Color = ROCK_COLORS[rng.randi_range(0, ROCK_COLORS.size() - 1)] * _rock_tint(poly[0].x, 0.5)
	if kind == "hang":
		col = col.darkened(0.22)
	else:
		_ellipse(c, Vector2(b.get_center().x, b.end.y - 3.0), b.size.x * 0.6, 5.0, Color(0.0, 0.0, 0.0, 0.2))   # contact shadow
	# darker rim, body, then a soft highlight toward the sun (upper left) and shade underneath
	c.draw_colored_polygon(poly, col.darkened(0.18))
	for inner in Geometry2D.offset_polygon(poly, -5.0, Geometry2D.JOIN_ROUND):
		var ip := inner as PackedVector2Array
		if ip.size() >= 3:
			c.draw_colored_polygon(ip, col)
	var hi_alpha := 0.10 if kind == "hang" else 0.17
	for inner in Geometry2D.offset_polygon(poly, -11.0, Geometry2D.JOIN_ROUND):
		var ip2 := PackedVector2Array()
		for q in (inner as PackedVector2Array):
			ip2.append(q + Vector2(-3.0, -3.5))
		if ip2.size() >= 3:
			c.draw_colored_polygon(ip2, Color(1.0, 1.0, 1.0, hi_alpha))
	var lower := PackedVector2Array([Vector2(b.position.x - 2.0, b.position.y + b.size.y * 0.62), Vector2(b.end.x + 2.0, b.position.y + b.size.y * 0.62), Vector2(b.end.x + 2.0, b.end.y + 2.0), Vector2(b.position.x - 2.0, b.end.y + 2.0)])
	for piece in Geometry2D.intersect_polygons(poly, lower):
		c.draw_colored_polygon(piece as PackedVector2Array, Color(0.0, 0.0, 0.0, 0.12))
	# faceted planes: a lit face on the upper left, a shaded one on the right (bigger rocks only)
	if kind == "mound" and b.size.x > 44.0:
		var cc := b.get_center()
		_facet(c, poly, Vector2(b.position.x, b.position.y + b.size.y * 0.6), Vector2(cc.x + b.size.x * 0.1, b.position.y - 4.0), -1.0, Color(1.0, 1.0, 1.0, 0.10))
		_facet(c, poly, Vector2(cc.x + b.size.x * 0.14, b.position.y), Vector2(b.end.x - b.size.x * 0.1, b.end.y), -1.0, Color(0.0, 0.0, 0.0, 0.11))
		# two bedding lines across the face
		for k in 2:
			var yy := b.position.y + b.size.y * (0.42 + 0.22 * float(k))
			var line := PackedVector2Array()
			var xx := b.position.x
			while xx <= b.end.x:
				line.append(Vector2(xx, yy + sin(xx * 0.09 + float(k) * 2.0 + b.position.x) * 2.5))
				xx += 8.0
			for seg in Geometry2D.intersect_polyline_with_polygon(line, poly):
				var sp := seg as PackedVector2Array
				if sp.size() >= 2:
					c.draw_polyline(sp, Color(0.08, 0.06, 0.04, 0.16), 1.5, true)
	# one gentle crack on bigger boulders
	if kind == "mound" and b.size.x > 60.0:
		var cur := b.get_center() + Vector2(rng.randf_range(-b.size.x * 0.2, b.size.x * 0.2), -b.size.y * 0.25)
		var line2 := PackedVector2Array([cur])
		var ang := rng.randf_range(1.2, 1.9)
		for st in 4:
			ang += rng.randf_range(-0.25, 0.25)
			cur += Vector2(cos(ang), sin(ang)) * rng.randf_range(7.0, 11.0)
			if Geometry2D.is_point_in_polygon(cur, poly):
				line2.append(cur)
		if line2.size() >= 3:
			c.draw_polyline(line2, Color(0.1, 0.08, 0.06, 0.42), 1.8, true)
	# moss on the sunny top of rocks that sit in the open
	if kind == "mound" and bool(r.get("moss", false)):
		var yline := b.position.y + b.size.y * 0.3
		var band := PackedVector2Array([Vector2(b.position.x - 4.0, b.position.y - 6.0)])
		var xm := b.position.x - 4.0
		while xm <= b.end.x + 4.0:
			band.append(Vector2(xm, yline + sin(xm * 0.19 + b.position.x) * 3.5 + rng.randf_range(-1.5, 1.5)))
			xm += 9.0
		band.append(Vector2(b.end.x + 4.0, b.position.y - 6.0))
		for piece in Geometry2D.intersect_polygons(poly, band):
			var pm := piece as PackedVector2Array
			if pm.size() >= 3:
				c.draw_colored_polygon(pm, Color(GRASS_DARK.r, GRASS_DARK.g, GRASS_DARK.b, 0.5))
				var lifted := PackedVector2Array()
				for q in pm:
					lifted.append(q + Vector2(0.0, -2.0))
				c.draw_colored_polygon(lifted, Color(GRASS.r, GRASS.g, GRASS.b, 0.55))
	var closed := PackedVector2Array(poly)
	closed.append(poly[0])
	c.draw_polyline(closed, OUTLINE, 2.8, true)
	# short grass tufts where an open-air rock meets the ground
	if kind == "mound" and bool(r.get("moss", false)):
		for end_pt in [poly[0], poly[poly.size() - 1]]:
			for k in 3:
				_grass_blade(c, (end_pt as Vector2) + Vector2(rng.randf_range(-7.0, 7.0), 3.0), rng.randf_range(5.0, 10.0), rng.randf_range(-3.0, 3.0), GRASS_HI if rng.randf() < 0.4 else GRASS)


# A loose stone or pebble (decoration only): shaded dome with a lit side and a thin outline.
func _paint_stone(c: CanvasItem, d: Dictionary) -> void:
	var poly: PackedVector2Array = d["poly"]
	var base: Vector2 = d["base"]
	var kind := String(d["kind"])
	var sv: float = d["seed"]
	var b := _bounds(poly)
	var col: Color = ROCK_COLORS[int(absf(sv) * 10.0) % ROCK_COLORS.size()] * _rock_tint(base.x, 0.5)
	_ellipse(c, base + Vector2(1.0, 0.5), b.size.x * 0.6, 2.8, Color(0.0, 0.0, 0.0, 0.2))
	c.draw_colored_polygon(poly, col.darkened(0.2))
	var core := PackedVector2Array()
	for q in poly:
		core.append(base + (q - base) * 0.86)
	c.draw_colored_polygon(core, col)
	if kind == "stone":
		var lit := PackedVector2Array()
		for q in poly:
			lit.append(base + (q - base) * 0.6 + Vector2(-b.size.x * 0.1, -b.size.y * 0.05))
		c.draw_colored_polygon(lit, Color(1.0, 1.0, 1.0, 0.15))
		_facet(c, poly, Vector2(base.x + b.size.x * 0.1, b.position.y), Vector2(base.x + b.size.x * 0.25, b.end.y), -1.0, Color(0.0, 0.0, 0.0, 0.12))
	c.draw_polyline(poly, Color(PEBBLE_EDGE.r, PEBBLE_EDGE.g, PEBBLE_EDGE.b, 0.85), 1.5 if kind == "stone" else 1.2, true)


# Layers of rock: faint curving bands inside the larger masses.
func _paint_strata(c: CanvasItem, poly: PackedVector2Array, rect: Rect2, sd: float) -> void:
	if rect.size.y < 110.0 or rect.size.x < 120.0:
		return
	var rng := RandomNumberGenerator.new()
	rng.seed = int(sd * 100000.0) + 3
	var inners := Geometry2D.offset_polygon(poly, -9.0, Geometry2D.JOIN_ROUND)
	var spacing := 46.0 + 14.0 * sd
	var y := rect.position.y + spacing * 0.9
	var guard := 0
	while y < rect.end.y - 24.0 and guard < 10:
		guard += 1
		var ph := rng.randf_range(0.0, TAU)
		var amp := rng.randf_range(4.0, 8.0)
		var tilt := rng.randf_range(-0.10, 0.10)
		var line := PackedVector2Array()
		var x := rect.position.x - 6.0
		while x <= rect.end.x + 6.0:
			line.append(Vector2(x, y + (x - rect.position.x) * tilt + sin(x * 0.021 + ph) * amp + sin(x * 0.057 + ph * 1.7) * amp * 0.4))
			x += 20.0
		for inner in inners:
			for seg in Geometry2D.intersect_polyline_with_polygon(line, inner as PackedVector2Array):
				var sp := seg as PackedVector2Array
				if sp.size() >= 3 and sp[0].distance_to(sp[sp.size() - 1]) > 40.0:
					var twin := PackedVector2Array()
					for q in sp:
						twin.append(q + Vector2(0.0, 2.2))
					c.draw_polyline(twin, Color(1.0, 1.0, 1.0, 0.07), 1.8, true)
					c.draw_polyline(sp, Color(0.08, 0.06, 0.04, 0.17), 1.8, true)
		y += spacing * rng.randf_range(0.8, 1.25)


# Thin roots hanging from the undersides of the floating islands.
func _paint_roots(c: CanvasItem, poly: PackedVector2Array, top_count: int, rect: Rect2, sd: float) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = int(sd * 100000.0) + 11
	var last_x := -99999.0
	for i in range(top_count, poly.size()):
		var pt := poly[i]
		if pt.y < rect.position.y + rect.size.y * 0.45:
			continue
		if absf(pt.x - last_x) < 70.0 or rng.randf() > 0.35:
			continue
		if not Geometry2D.is_point_in_polygon(pt + Vector2(0.0, -5.0), poly) or Geometry2D.is_point_in_polygon(pt + Vector2(0.0, 7.0), poly):
			continue                                   # only roots that hang from a downward-facing edge
		last_x = pt.x
		var rlen := rng.randf_range(26.0, 62.0)
		var sway := rng.randf_range(-12.0, 12.0)
		var prev := pt + Vector2(0.0, -2.0)
		for k in range(1, 6):
			var t := float(k) / 5.0
			var cur := pt + Vector2(sway * t * t + sin(t * 3.1 + sway) * 3.0, rlen * t)
			c.draw_line(prev, cur, ROOT_COLOR, lerpf(3.2, 0.9, t), true)
			prev = cur
		var mid := pt + Vector2(sway * 0.25, rlen * 0.5)
		c.draw_line(mid, mid + Vector2(signf(sway + 0.1) * 9.0, 12.0), ROOT_COLOR, 1.2, true)


# A few small wildflowers in the grass.
func _paint_flowers(c: CanvasItem, top: PackedVector2Array, sd: float) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = int(sd * 100000.0) + 23
	for i in range(top.size() - 1):
		var a := top[i]
		var b := top[i + 1]
		if absf(b.y - a.y) > absf(b.x - a.x) * 0.5 or rng.randf() > 0.2:
			continue
		var pt := a.lerp(b, rng.randf_range(0.2, 0.8)) + Vector2(0.0, -3.0)
		var stem := rng.randf_range(7.0, 11.0)
		if _blocked_by_keepout(Rect2(pt + Vector2(-5.0, -stem - 4.0), Vector2(10.0, stem + 6.0))):
			continue
		var head: Color = FLOWER_COLORS[rng.randi_range(0, FLOWER_COLORS.size() - 1)]
		c.draw_line(pt, pt + Vector2(0.0, -stem), GRASS_DARK, 1.4, true)
		c.draw_circle(pt + Vector2(0.0, -stem), 2.7, head)
		c.draw_circle(pt + Vector2(0.0, -stem), 1.1, Color("e0a02a"))


# ---------- props ----------

func _paint_prop(c: CanvasItem, d: Dictionary) -> void:
	var rect: Rect2 = d["rect"]
	match String(d["type"]):
		"crate":
			_paint_crate(c, rect)
		"barrel":
			_paint_barrel(c, rect)
		"sandbags":
			_paint_sandbags(c, rect)
		"barricade":
			_paint_barricade(c, rect)


func _paint_crate(c: CanvasItem, r: Rect2) -> void:
	var size := r.size.x
	c.draw_rect(Rect2(r.position + Vector2(5.0, 6.0), r.size), Color(0.1, 0.1, 0.05, 0.18))
	c.draw_rect(r, Color("9a7448"))
	c.draw_rect(Rect2(r.position + Vector2(3.0, 3.0), Vector2(size - 6.0, size * 0.14)), Color("b8905c"))
	c.draw_line(r.position + Vector2(6.0, 6.0), r.position + Vector2(size - 6.0, size - 6.0), Color("8a5d2e"), 4.0)
	c.draw_line(r.position + Vector2(size - 6.0, 6.0), r.position + Vector2(6.0, size - 6.0), Color("8a5d2e"), 4.0)
	c.draw_rect(r, Color("5a3a1c"), false, 3.0)


func _paint_barrel(c: CanvasItem, r: Rect2) -> void:
	c.draw_rect(r, Color("9c4a38"))
	c.draw_rect(Rect2(r.position.x + 4.0, r.position.y, 7.0, r.size.y), Color(1, 1, 1, 0.22))
	c.draw_rect(Rect2(r.position.x, r.position.y + 10.0, r.size.x, 5.0), Color("7b2f26"))
	c.draw_rect(Rect2(r.position.x, r.end.y - 15.0, r.size.x, 5.0), Color("7b2f26"))
	c.draw_rect(r, Color("4f2018"), false, 3.0)
	c.draw_rect(Rect2(r.position.x - 1.0, r.position.y - 4.0, r.size.x + 2.0, 6.0), Color("b96a58"))


func _paint_sandbags(c: CanvasItem, r: Rect2) -> void:
	for row in 2:
		var cols_n := 4 - row
		for col in cols_n:
			var cx := r.position.x + 31.0 + float(col) * 31.0 + float(row) * 15.5
			var cy := r.end.y - 11.0 - float(row) * 20.0
			c.draw_set_transform(Vector2(cx, cy), 0.0, Vector2(1.0, 0.68))
			c.draw_circle(Vector2.ZERO, 19.0, Color("b9aa7c"))
			c.draw_circle(Vector2.ZERO, 19.0, Color("6b5d3a"), false, 2.0, true)
			c.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _paint_barricade(c: CanvasItem, r: Rect2) -> void:
	var planks := 3
	var pw := r.size.x / float(planks)
	for i in planks:
		var x := r.position.x + float(i) * pw
		c.draw_rect(Rect2(x, r.position.y, pw, r.size.y), Color("a67c4e") if i % 2 == 0 else Color("94693d"))
		c.draw_rect(Rect2(x, r.position.y, pw, r.size.y), Color("4a3017"), false, 2.0)
	c.draw_rect(Rect2(r.position.x - 6.0, r.position.y + 12.0, r.size.x + 12.0, 8.0), Color("c19a68"))
	c.draw_rect(Rect2(r.position.x - 6.0, r.position.y + 12.0, r.size.x + 12.0, 8.0), Color("4a3017"), false, 2.0)
	c.draw_rect(Rect2(r.position.x - 6.0, r.end.y - 22.0, r.size.x + 12.0, 8.0), Color("c19a68"))
	c.draw_rect(Rect2(r.position.x - 6.0, r.end.y - 22.0, r.size.x + 12.0, 8.0), Color("4a3017"), false, 2.0)


func _paint_lantern(c: CanvasItem, p: Vector2) -> void:
	c.draw_line(p, p + Vector2(0.0, 14.0), Color("3a3028"), 2.5)
	var body := Rect2(p + Vector2(-6.0, 14.0), Vector2(12.0, 18.0))
	c.draw_rect(body, Color("f2b552"))
	c.draw_rect(Rect2(body.position + Vector2(2.0, 3.0), Vector2(8.0, 11.0)), Color("fff0b0"))
	c.draw_rect(body, Color("3a3028"), false, 2.0)
	c.draw_rect(Rect2(p + Vector2(-8.0, 11.0), Vector2(16.0, 4.0)), Color("3a3028"))


# ---------- bunkers ----------

# ---------- the steel bunker ----------

func _rivet(c: CanvasItem, p: Vector2, r: float = 2.4) -> void:
	c.draw_circle(p + Vector2(0.8, 0.9), r, Color(0.0, 0.0, 0.0, 0.35))
	c.draw_circle(p, r, Color("5b6268"))
	c.draw_circle(p + Vector2(-0.6, -0.7), r * 0.5, Color("c2c8cc"))


# A bolt plate: a small square with a bolt in each corner.
func _bolt_plate(c: CanvasItem, center: Vector2, size: float) -> void:
	var r := Rect2(center - Vector2(size, size) * 0.5, Vector2(size, size))
	c.draw_rect(r, STEEL_DARK)
	c.draw_rect(r, STEEL_EDGE, false, 1.5)
	var o := size * 0.3
	for sx in [-1.0, 1.0]:
		for sy in [-1.0, 1.0]:
			_rivet(c, center + Vector2(o * float(sx), o * float(sy)), 1.8)


# Yellow and black warning stripes inside a rectangle.
func _hazard_strip(c: CanvasItem, r: Rect2) -> void:
	c.draw_rect(r, Color("2a2c2e"))
	var clip := PackedVector2Array([r.position, Vector2(r.end.x, r.position.y), r.end, Vector2(r.position.x, r.end.y)])
	var x := r.position.x - r.size.y
	while x < r.end.x:
		var slab := PackedVector2Array([Vector2(x, r.end.y), Vector2(x + r.size.y, r.position.y), Vector2(x + r.size.y + 7.0, r.position.y), Vector2(x + 7.0, r.end.y)])
		for piece in Geometry2D.intersect_polygons(slab, clip):
			c.draw_colored_polygon(piece as PackedVector2Array, HAZARD)
		x += 14.0


# Dents, scratches and rust streaks over a steel rectangle. Deterministic and sparse.
func _steel_wear(c: CanvasItem, r: Rect2, rng: RandomNumberGenerator, amount: float) -> void:
	for i in int(r.size.x * r.size.y / 5200.0 * amount) + 2:
		var p := Vector2(rng.randf_range(r.position.x + 6.0, r.end.x - 6.0), rng.randf_range(r.position.y + 6.0, r.end.y - 6.0))
		match rng.randi_range(0, 2):
			0:      # scratch
				var d := Vector2(rng.randf_range(6.0, 16.0), rng.randf_range(-4.0, 4.0))
				c.draw_line(p, p + d, Color(1.0, 1.0, 1.0, 0.13), 1.2, true)
				c.draw_line(p + Vector2(0.0, 1.4), p + d + Vector2(0.0, 1.4), Color(0.0, 0.0, 0.0, 0.14), 1.0, true)
			1:      # dent
				_ellipse(c, p, rng.randf_range(5.0, 9.0), rng.randf_range(3.0, 6.0), Color(0.0, 0.0, 0.0, 0.07))
			_:      # rust streak running down from a seam
				var ln := rng.randf_range(8.0, 22.0)
				var py := minf(p.y, r.end.y - ln - 2.0)
				c.draw_rect(Rect2(p.x, py, 2.4, ln), Color(RUST.r, RUST.g, RUST.b, 0.22))
				c.draw_rect(Rect2(p.x - 1.5, py, 5.4, minf(ln * 0.35, 6.0)), Color(RUST.r, RUST.g, RUST.b, 0.12))


# One steel slab (roof or wall): panels with seams and bolt plates, reinforced edge bands with a
# row of rivets, and wear. `vertical` flips the panel direction for the wall lintels.
func _steel_slab(c: CanvasItem, r: Rect2, vertical: bool, rng: RandomNumberGenerator) -> void:
	c.draw_rect(r, STEEL)
	# soft shading so the slab does not read as flat
	c.draw_rect(Rect2(r.position, Vector2(r.size.x, r.size.y * 0.45)), Color(1.0, 1.0, 1.0, 0.06))
	c.draw_rect(Rect2(r.position.x, r.position.y + r.size.y * 0.7, r.size.x, r.size.y * 0.3), Color(0.0, 0.0, 0.0, 0.10))
	# panel seams
	if vertical:
		var y := r.position.y + 38.0
		while y < r.end.y - 14.0:
			c.draw_line(Vector2(r.position.x, y), Vector2(r.end.x, y), STEEL_EDGE, 2.0)
			c.draw_line(Vector2(r.position.x, y + 2.0), Vector2(r.end.x, y + 2.0), Color(1.0, 1.0, 1.0, 0.12), 1.2)
			y += 38.0
	else:
		var x := r.position.x + 60.0
		while x < r.end.x - 10.0:
			c.draw_line(Vector2(x, r.position.y), Vector2(x, r.end.y), STEEL_EDGE, 2.0)
			c.draw_line(Vector2(x + 2.0, r.position.y), Vector2(x + 2.0, r.end.y), Color(1.0, 1.0, 1.0, 0.12), 1.2)
			_bolt_plate(c, Vector2(x, r.position.y + r.size.y * 0.5), 15.0)
			x += 60.0
	_steel_wear(c, r, rng, 1.0)
	# reinforced edge bands: bright on the sunny top, heavy and dark along the bottom
	var top_h := minf(9.0, r.size.y * 0.3)
	var bot_h := minf(12.0, r.size.y * 0.3)
	c.draw_rect(Rect2(r.position, Vector2(r.size.x, top_h)), STEEL_LIGHT)
	c.draw_line(r.position + Vector2(0.0, 1.0), Vector2(r.end.x, r.position.y + 1.0), Color(1.0, 1.0, 1.0, 0.35), 1.5)
	c.draw_rect(Rect2(r.position.x, r.end.y - bot_h, r.size.x, bot_h), STEEL_DARK)
	var rx := r.position.x + 8.0
	while rx < r.end.x - 4.0:
		_rivet(c, Vector2(rx, r.position.y + top_h * 0.5))
		_rivet(c, Vector2(rx, r.end.y - bot_h * 0.5))
		rx += 16.0
	# vertical end bands
	for ex in [r.position.x, r.end.x - 8.0]:
		c.draw_rect(Rect2(float(ex), r.position.y, 8.0, r.size.y), STEEL_DARK)
	c.draw_rect(r, STEEL_EDGE, false, 3.0)


func _paint_i_beam(c: CanvasItem, x: float, y0: float, y1: float) -> void:
	c.draw_rect(Rect2(x - 4.0, y0, 8.0, y1 - y0), STEEL_DARK)
	c.draw_line(Vector2(x - 3.0, y0), Vector2(x - 3.0, y1), Color(1.0, 1.0, 1.0, 0.14), 1.5)
	c.draw_line(Vector2(x + 4.0, y0), Vector2(x + 4.0, y1), Color(0.0, 0.0, 0.0, 0.3), 1.5)
	for fy in [y0, y1 - 7.0]:
		c.draw_rect(Rect2(x - 11.0, float(fy), 22.0, 7.0), Color("565d63"))
		c.draw_rect(Rect2(x - 11.0, float(fy), 22.0, 7.0), STEEL_EDGE, false, 1.5)
		_rivet(c, Vector2(x - 6.0, float(fy) + 3.5), 1.6)
		_rivet(c, Vector2(x + 6.0, float(fy) + 3.5), 1.6)


func _paint_metal_bunker(c: CanvasItem, d: Dictionary) -> void:
	var back: Rect2 = d["back"]
	var rng := RandomNumberGenerator.new()
	rng.seed = 7707
	var doors: Array = d["doors"]
	# interior wall (also visible through both doorways): dark painted steel with seams
	c.draw_rect(back, STEEL_BACK)
	var wall_x := back.position.x
	var wall_end := back.end.x
	for door in doors:
		var dr: Rect2 = door
		c.draw_rect(dr, STEEL_BACK.darkened(0.12))
		wall_x = minf(wall_x, dr.position.x)
		wall_end = maxf(wall_end, dr.end.x)
	var sx := wall_x + 44.0
	while sx < wall_end - 10.0:
		c.draw_line(Vector2(sx, back.position.y), Vector2(sx, back.end.y), Color(0.0, 0.0, 0.0, 0.28), 2.0)
		c.draw_line(Vector2(sx + 2.0, back.position.y), Vector2(sx + 2.0, back.end.y), Color(1.0, 1.0, 1.0, 0.05), 1.2)
		sx += 44.0
	_steel_wear(c, back, rng, 0.6)
	# a pipe run along the top of the wall, with clamps
	c.draw_rect(Rect2(wall_x, back.position.y + 3.0, wall_end - wall_x, 7.0), Color("4d5459"))
	c.draw_line(Vector2(wall_x, back.position.y + 4.5), Vector2(wall_end, back.position.y + 4.5), Color(1.0, 1.0, 1.0, 0.2), 1.5)
	var cx := wall_x + 30.0
	while cx < wall_end - 20.0:
		c.draw_rect(Rect2(cx, back.position.y + 1.0, 6.0, 11.0), STEEL_EDGE)
		cx += 78.0
	# floor shadow strip
	c.draw_rect(Rect2(back.position.x, back.end.y - 10.0, back.size.x, 10.0), Color(0, 0, 0, 0.25))
	# vertical I-beam supports between the windows, with diagonal braces up to the roof
	for fx in [0.36, 0.65]:
		var bx := back.position.x + back.size.x * float(fx)
		for dir in [-1.0, 1.0]:
			var dd := float(dir)
			c.draw_line(Vector2(bx, back.position.y + 52.0), Vector2(bx + 40.0 * dd, back.position.y + 12.0), STEEL_DARK, 7.0)
			c.draw_line(Vector2(bx - 1.0, back.position.y + 52.0), Vector2(bx - 1.0 + 40.0 * dd, back.position.y + 12.0), Color(1.0, 1.0, 1.0, 0.12), 1.5)
		_paint_i_beam(c, bx, back.position.y + 10.0, back.end.y - 8.0)
	# windows: steel frame, glass, mullions and corner bolts
	for i in 3:
		var win := Rect2(back.position.x + back.size.x * (0.12 + 0.29 * float(i)), back.position.y + 16.0, back.size.x * 0.19, 26.0)
		c.draw_rect(win.grow(5.0), STEEL_DARK)
		c.draw_rect(win.grow(5.0), STEEL_EDGE, false, 1.5)
		c.draw_rect(win, Color("9ccfe6"))
		c.draw_rect(Rect2(win.position, Vector2(win.size.x, win.size.y * 0.35)), Color(1.0, 1.0, 1.0, 0.18))
		c.draw_line(win.position + Vector2(win.size.x * 0.5, 0.0), win.position + Vector2(win.size.x * 0.5, win.size.y), STEEL_EDGE, 3.0)
		c.draw_line(win.position + Vector2(0.0, win.size.y * 0.5), win.position + Vector2(win.size.x, win.size.y * 0.5), STEEL_EDGE, 2.0)
		for ox in [-1.0, 1.0]:
			for oy in [-1.0, 1.0]:
				_rivet(c, win.get_center() + Vector2((win.size.x * 0.5 + 2.5) * float(ox), (win.size.y * 0.5 + 2.5) * float(oy)), 1.5)
	# steel floor plate that follows the real ground line, through both doorways
	var top_pts := PackedVector2Array()
	var bot_pts := PackedVector2Array()
	var gx := wall_x
	while true:
		var gy := _path_y("west_island", (gx - ORIGIN.x) / S)
		top_pts.append(Vector2(gx, gy - 2.0))
		bot_pts.append(Vector2(gx, gy + 9.0))
		if gx >= wall_end:
			break
		gx = minf(gx + 12.0, wall_end)
	bot_pts.reverse()
	var plate := PackedVector2Array(top_pts)
	plate.append_array(bot_pts)
	c.draw_colored_polygon(plate, Color("4a5157"))
	c.draw_polyline(top_pts, Color(1.0, 1.0, 1.0, 0.28), 1.6, true)
	for k in range(0, top_pts.size(), 2):
		_rivet(c, top_pts[k] + Vector2(0.0, 5.0), 1.6)
	# the roof and the two door lintels
	var solids: Array = d["solids"]
	for i in solids.size():
		_steel_slab(c, solids[i] as Rect2, i > 0, rng)
	# heavy header with warning stripes over each doorway
	for i in range(1, solids.size()):
		var lr: Rect2 = solids[i]
		_hazard_strip(c, Rect2(lr.position.x + 8.0, lr.end.y - 7.0, lr.size.x - 16.0, 7.0))
	# corner gussets where the lintels meet the roof
	var roof: Rect2 = solids[0]
	for gxs in [roof.position.x + 8.0, roof.end.x - 8.0]:
		var gxv := float(gxs)
		var dirx := 1.0 if gxv < roof.get_center().x else -1.0
		var gp := PackedVector2Array([Vector2(gxv, roof.end.y), Vector2(gxv + 26.0 * dirx, roof.end.y), Vector2(gxv, roof.end.y + 26.0)])
		c.draw_colored_polygon(gp, STEEL_DARK)
		c.draw_polyline(PackedVector2Array([gp[0], gp[2], gp[1]]), STEEL_EDGE, 2.0, true)
		_rivet(c, Vector2(gxv + 6.0 * dirx, roof.end.y + 6.0), 1.6)
	# team flag on the roof
	var base: Vector2 = d["flag"]
	var col: Color = d["flag_color"]
	c.draw_line(base, base + Vector2(0.0, -64.0), Color("2f353a"), 4.0)
	c.draw_circle(base + Vector2(0.0, -65.0), 3.5, STEEL_LIGHT)
	c.draw_colored_polygon(PackedVector2Array([base + Vector2(2.0, -64.0), base + Vector2(46.0, -54.0), base + Vector2(2.0, -40.0)]), col)


func _paint_bunker(c: CanvasItem, d: Dictionary) -> void:
	if String(d["style"]) == "metal":
		_paint_metal_bunker(c, d)
		return
	var stone := String(d["style"]) == "stone"
	var back: Rect2 = d["back"]
	c.draw_rect(back, Color("3b3d40") if stone else Color("4a3a28"))
	# floor shadow strip
	c.draw_rect(Rect2(back.position.x, back.end.y - 10.0, back.size.x, 10.0), Color(0, 0, 0, 0.25))
	for i in 3:
		var win := Rect2(back.position.x + back.size.x * (0.12 + 0.29 * float(i)), back.position.y + 16.0, back.size.x * 0.19, 26.0)
		c.draw_rect(win.grow(4.0), Color("26292c"))
		c.draw_rect(win, Color("9ccfe6") if stone else Color("e9d9a0"))
		c.draw_line(win.position + Vector2(win.size.x * 0.5, 0.0), win.position + Vector2(win.size.x * 0.5, win.size.y), Color("26292c"), 3.0)
	for item in d["solids"]:
		var r: Rect2 = item
		if stone:
			c.draw_rect(r, Color("86898d"))
			c.draw_rect(Rect2(r.position, Vector2(r.size.x, minf(6.0, r.size.y))), Color("b4b8bc"))
			c.draw_rect(Rect2(r.position.x, r.end.y - 5.0, r.size.x, 5.0), Color("5c5f63"))
			c.draw_rect(r, Color("2c2f32"), false, 3.0)
			if _q >= 1:                                    # Medium+: brick / mortar lines on the stone walls
				var row := 0
				var my := r.position.y + 22.0
				while my < r.end.y - 4.0:
					c.draw_line(Vector2(r.position.x, my), Vector2(r.end.x, my), Color(0.17, 0.18, 0.2, 0.45), 1.5)
					var bx := r.position.x + (20.0 if row % 2 == 0 else 40.0)
					while bx < r.end.x - 2.0:
						c.draw_line(Vector2(bx, my - 22.0), Vector2(bx, my), Color(0.17, 0.18, 0.2, 0.45), 1.5)
						bx += 40.0
					my += 22.0
					row += 1
		else:
			c.draw_rect(r, Color("86653a"))
			var y := r.position.y + 14.0
			while y < r.end.y - 2.0:
				c.draw_line(Vector2(r.position.x, y), Vector2(r.end.x, y), Color("4a3017"), 2.0)
				y += 14.0
			var x := r.position.x + 7.0
			while x < r.end.x:
				c.draw_circle(Vector2(x, r.position.y + 7.0), 4.0, Color("c19a68"))
				x += 14.0
			c.draw_rect(r, Color("3c2712"), false, 3.0)
		if _q == 2:                                        # High: soft shadow under every wall / floor slab
			c.draw_rect(Rect2(r.position.x, r.end.y, r.size.x, 8.0), Color(0, 0, 0, 0.18))
			c.draw_rect(Rect2(r.position.x, r.end.y + 8.0, r.size.x, 6.0), Color(0, 0, 0, 0.08))
	# team flag on the roof
	var base: Vector2 = d["flag"]
	var col: Color = d["flag_color"]
	c.draw_line(base, base + Vector2(0.0, -64.0), Color("4b3a2b"), 4.0)
	c.draw_colored_polygon(PackedVector2Array([base + Vector2(2.0, -64.0), base + Vector2(46.0, -54.0), base + Vector2(2.0, -40.0)]), col)


# =====================================================================
#  PAINTING: FOREGROUND (tunnel shade + lantern glow; redrawn every frame)
# =====================================================================

func _paint_shade(c: CanvasItem) -> void:
	for item in _cavities:
		var cav: Dictionary = item
		c.draw_colored_polygon(cav["poly"] as PackedVector2Array, Color(0.02, 0.03, 0.05, float(cav["alpha"])))


func _paint_front(c: CanvasItem) -> void:
	for i in _lanterns.size():
		var p: Vector2 = _lanterns[i]
		var flick := 0.86 + 0.14 * sin(_elapsed * 7.0 + float(i) * 2.1) + 0.04 * sin(_elapsed * 13.0 + float(i))
		var center := p + Vector2(0.0, 24.0)
		c.draw_circle(center, 150.0, Color(1.0, 0.72, 0.35, 0.05 * flick))
		c.draw_circle(center, 92.0, Color(1.0, 0.74, 0.38, 0.07 * flick))
		c.draw_circle(center, 40.0, Color(1.0, 0.82, 0.5, 0.10 * flick))
