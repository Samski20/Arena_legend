class_name BlastFX
extends Node2D
## The explosion you see when a bomb goes off. Built from particles: flash, fireball,
## flame tongues, sparks, debris, a smoke plume and a faint shockwave. Frees itself when done.
## style: "fire" (grenade), "energy" (knockback bomb), "ignite" (small fireball that starts a
## fire zone), "toxic", "frost", "smoke" (small puff when those zone bombs pop), "pulse" (colored ring + sparks, no shake).

var radius := 120.0
var color := Color.ORANGE
var style := "fire"
var shake_scale := 1.0

var _t := 0.0
var _norm: FXField
var _add: FXField


func setup(r: float, c: Color, s := "fire") -> void:
	radius = r
	color = c
	style = s


func _ready() -> void:
	z_index = 10
	_norm = FXField.new()
	add_child(_norm)
	_add = FXField.new()
	_add.additive = true
	add_child(_add)
	match style:
		"energy": _energy()
		"ignite": _fire(0.75, false)
		"toxic": _gas(Color(0.55, 0.95, 0.2), 0.8)
		"smoke": _gas(Color(0.5, 0.52, 0.58), 0.95)
		"frost": _frost()
		"pulse": _pulse()
		_: _fire(1.0, true)
	if (style == "fire" or style == "energy") and shake_scale > 0.0:
		_shake()


func _process(delta: float) -> void:
	_t += delta
	if _t > 0.4 and _norm.count() == 0 and _add.count() == 0:
		queue_free()


func _dir(ang: float) -> Vector2:
	return Vector2(cos(ang), sin(ang))


# ---------------- fire explosion ----------------
func _fire(scale: float, big: bool) -> void:
	var R := radius * scale
	var glow := FXArt.tex("glow")
	# white-hot flash + warm light
	_add.emit(FXField.P(glow, Vector2.ZERO, Vector2.ZERO, 0.18, FXField.V(R * 1.2), FXField.V(R * 3.0),
		Color(1, 0.97, 0.85, 1), Color(1, 0.6, 0.2, 0), {"fade_in": 0.0}))
	_add.emit(FXField.P(glow, Vector2(0, -R * 0.1), Vector2.ZERO, 0.55, FXField.V(R * 1.6), FXField.V(R * 2.6),
		Color(1, 0.5, 0.12, 0.7), Color(1, 0.2, 0.05, 0), {"fade_in": 0.05}))
	# fireball
	for i in 18:
		var ang := randf() * TAU
		var spd := randf_range(0.5, 1.7) * R * 1.6
		var vel := Vector2(cos(ang), sin(ang) * 0.85) * spd + Vector2(0, -R * 0.3)
		_add.emit(FXField.P(FXArt.pick("puff", 4), Vector2.ZERO, vel, randf_range(0.35, 0.6),
			FXField.V(R * 0.35), FXField.V(R * randf_range(0.8, 1.15)),
			Color(1, 0.92, 0.55, 0.95), Color(1, 0.28, 0.05, 0),
			{"drag": 3.2, "spin": randf_range(-2.0, 2.0), "rot": randf() * TAU, "fade_in": 0.05, "delay": randf() * 0.06}))
	# flame tongues thrown outward
	for i in 12:
		var ang := randf() * TAU
		var w := R * randf_range(0.22, 0.34)
		_add.emit(FXField.P(FXArt.pick("flame", 3), Vector2.ZERO, _dir(ang) * R * randf_range(0.9, 1.5),
			randf_range(0.3, 0.5), Vector2(w, w * 2.2), Vector2(w * 0.4, w * 1.6),
			Color(1, 0.8, 0.35, 0.95), Color(1, 0.25, 0.05, 0),
			{"drag": 4.0, "rot": ang + PI / 2.0, "anchor": Vector2(0.5, 1.0), "fade_in": 0.05}))
	# sparks
	for i in 26:
		var ang := randf() * TAU
		var spd := randf_range(260.0, 720.0) * (R / 130.0)
		_add.emit(FXField.P(null, Vector2.ZERO, _dir(ang) * spd + Vector2(0, -120), randf_range(0.45, 1.0),
			FXField.V(2.6), FXField.V(0.8), Color(1, 0.9, 0.45, 1), Color(1, 0.4, 0.1, 0),
			{"mode": "streak", "acc": Vector2(0, 950), "drag": 0.6, "fade_in": 0.0, "trail": 0.03}))
	# debris
	if big:
		for i in 10:
			var ang := randf() * TAU
			var sz := randf_range(4.0, 9.0)
			_norm.emit(FXField.P(null, Vector2.ZERO, _dir(ang) * randf_range(180.0, 460.0) + Vector2(0, -120),
				randf_range(0.7, 1.2), FXField.V(sz), FXField.V(sz * 0.7),
				Color(0.2, 0.17, 0.15, 1), Color(0.2, 0.17, 0.15, 0),
				{"mode": "box", "acc": Vector2(0, 1100), "spin": randf_range(-12.0, 12.0), "hold": 0.6, "fade_in": 0.0}))
	# smoke plume
	for i in (10 if big else 5):
		var off := Vector2(randf_range(-0.4, 0.4), randf_range(-0.3, 0.2)) * R
		_norm.emit(FXField.P(FXArt.pick("puff", 4), off, Vector2(randf_range(-40, 40), -randf_range(40, 110)),
			randf_range(1.1, 1.8), FXField.V(R * 0.4), FXField.V(R * 1.0),
			Color(0.2, 0.19, 0.18, 0.7), Color(0.32, 0.31, 0.3, 0),
			{"drag": 0.8, "spin": randf_range(-0.6, 0.6), "rot": randf() * TAU, "fade_in": 0.2, "delay": randf_range(0.05, 0.25)}))
	# faint shockwave
	_add.emit(FXField.P(FXArt.tex("ring"), Vector2.ZERO, Vector2.ZERO, 0.3, FXField.V(R * 0.3), FXField.V(R * 2.0),
		Color(1, 0.85, 0.5, 0.35), Color(1, 0.5, 0.2, 0), {"fade_in": 0.0}))


# ---------------- knockback bomb (energy blast) ----------------
func _energy() -> void:
	var R := radius
	var glow := FXArt.tex("glow")
	_add.emit(FXField.P(glow, Vector2.ZERO, Vector2.ZERO, 0.2, FXField.V(R * 1.2), FXField.V(R * 3.0),
		Color(0.9, 1, 1, 1), Color(0.3, 0.85, 1, 0), {"fade_in": 0.0}))
	# the first ring grows out to EXACTLY the blast radius (diameter 2R) so players can see how far it reaches
	_add.emit(FXField.P(FXArt.tex("ring"), Vector2.ZERO, Vector2.ZERO, 0.32, FXField.V(R * 0.2), FXField.V(R * 2.0),
		Color(0.7, 1, 1, 1.0), Color(0.3, 0.8, 1, 0.0), {"fade_in": 0.0, "hold": 0.5}))
	_add.emit(FXField.P(FXArt.tex("ring"), Vector2.ZERO, Vector2.ZERO, 0.4, FXField.V(R * 0.1), FXField.V(R * 1.5),
		Color(0.5, 0.95, 1, 0.8), Color(0.2, 0.7, 1, 0), {"fade_in": 0.0, "delay": 0.07}))
	for i in 14:
		_add.emit(FXField.P(FXArt.pick("puff", 4), Vector2.ZERO, _dir(randf() * TAU) * randf_range(120.0, 360.0),
			randf_range(0.3, 0.5), FXField.V(R * 0.3), FXField.V(R * randf_range(0.7, 1.0)),
			Color(0.8, 1, 1, 0.85), Color(0.2, 0.75, 1, 0),
			{"drag": 3.0, "rot": randf() * TAU, "spin": randf_range(-2.0, 2.0), "fade_in": 0.05}))
	for i in 30:
		_add.emit(FXField.P(null, Vector2.ZERO, _dir(randf() * TAU) * randf_range(300.0, 800.0), randf_range(0.3, 0.6),
			FXField.V(3.0), FXField.V(0.8), Color(0.8, 1, 1, 1), Color(0.3, 0.8, 1, 0),
			{"mode": "streak", "drag": 2.2, "fade_in": 0.0, "trail": 0.04}))


# ---------------- small pops for the zone bombs ----------------
func _gas(col: Color, alpha: float) -> void:
	var R := radius
	for i in 14:
		_norm.emit(FXField.P(FXArt.pick("puff", 4), Vector2.ZERO, _dir(randf() * TAU) * randf_range(120.0, 300.0) + Vector2(0, -40),
			randf_range(0.7, 1.1), FXField.V(R * 0.4), FXField.V(R * 1.1),
			Color(col.r, col.g, col.b, alpha), Color(col.r * 0.7, col.g * 0.7, col.b * 0.7, 0),
			{"drag": 3.0, "rot": randf() * TAU, "spin": randf_range(-1.0, 1.0), "fade_in": 0.1}))


func _frost() -> void:
	var R := radius
	_add.emit(FXField.P(FXArt.tex("glow"), Vector2.ZERO, Vector2.ZERO, 0.25, FXField.V(R * 1.0), FXField.V(R * 2.6),
		Color(0.7, 0.92, 1, 0.9), Color(0.5, 0.8, 1, 0), {"fade_in": 0.0}))
	_add.emit(FXField.P(FXArt.tex("ring"), Vector2.ZERO, Vector2.ZERO, 0.35, FXField.V(R * 0.2), FXField.V(R * 2.0),
		Color(0.75, 0.95, 1, 0.6), Color(0.5, 0.85, 1, 0), {"fade_in": 0.0}))
	_gas(Color(0.8, 0.94, 1.0), 0.7)
	for i in 24:
		_add.emit(FXField.P(FXArt.tex("spark"), Vector2.ZERO, _dir(randf() * TAU) * randf_range(120.0, 380.0), randf_range(0.5, 1.0),
			FXField.V(8.0), FXField.V(3.0), Color(0.85, 0.97, 1, 1), Color(0.6, 0.9, 1, 0),
			{"drag": 2.0, "fade_in": 0.0}))


# ---------------- utility pop (decoy, gravity, EMP, portal...): glow + rings in the bomb's color, no shake ----------------
func _pulse() -> void:
	var R := radius
	var c := color
	_add.emit(FXField.P(FXArt.tex("glow"), Vector2.ZERO, Vector2.ZERO, 0.3, FXField.V(R * 0.8), FXField.V(R * 2.6),
		Color(c.r, c.g, c.b, 0.9), Color(c.r, c.g, c.b, 0), {"fade_in": 0.0}))
	for k in 2:
		_add.emit(FXField.P(FXArt.tex("ring"), Vector2.ZERO, Vector2.ZERO, 0.4, FXField.V(R * 0.2), FXField.V(R * 2.0),
			Color(c.r, c.g, c.b, 0.8), Color(c.r, c.g, c.b, 0), {"fade_in": 0.0, "delay": k * 0.1}))
	for i in 16:
		_add.emit(FXField.P(FXArt.tex("spark"), Vector2.ZERO, _dir(randf() * TAU) * randf_range(120.0, 340.0), randf_range(0.4, 0.8),
			FXField.V(7.0), FXField.V(2.0), Color(c.r, c.g, c.b, 1), Color(c.r, c.g, c.b, 0), {"drag": 2.0, "fade_in": 0.0}))


# little camera kick so it feels heavy
func _shake() -> void:
	var cam := get_viewport().get_camera_2d()
	if cam == null:
		return
	var amp := clampf(radius * 0.07, 2.0, 9.0) * shake_scale
	var base := cam.offset
	var tw := create_tween()
	for i in 6:
		tw.tween_property(cam, "offset", base + Vector2(randf_range(-1, 1), randf_range(-1, 1)) * amp * (1.0 - i / 6.0), 0.04)
	tw.tween_property(cam, "offset", base, 0.04)
