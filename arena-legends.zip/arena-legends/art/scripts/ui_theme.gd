class_name UITheme
extends RefCounted
## Shared "modern Android" look for every menu and the HUD: one accent colour (Android green), soft tonal surfaces,
## big rounded corners, no hard outlines. The project-wide Theme (art/ui/arena_theme.tres) covers anything that has
## no style of its own; the helpers here build the styles that menus set from code.

const PRIMARY := Color("3ddc84")
const ON_PRIMARY := Color("00391c")
const SURFACE := Color("111418")
const SURFACE_1 := Color("181c20")      # panels
const SURFACE_2 := Color("1f2429")      # text fields, inset rows
const SURFACE_3 := Color("2a3036")      # tonal buttons
const OUTLINE := Color("42494f")
const ON_SURFACE := Color("e1e3e8")
const ON_VARIANT := Color("a9b3bb")     # secondary text
const ERROR := Color("ffb4ab")
const ERROR_CONT := Color("6a1b17")
const ON_ERROR_CONT := Color("ffdad6")
const SCRIM := Color(0.02, 0.03, 0.04, 0.80)
const FLY := Color("5ff0ff")
const WARM := Color("ff9a5c")

static var _fonts := {}
static var _last_haptic := 0


## Inter (bundled in art/fonts). Falls back to Godot's built-in font if the file has not been imported yet.
static func font(bold := false) -> Font:
	var key := "bold" if bold else "medium"
	if not _fonts.has(key):
		var path := "res://art/fonts/Inter-Bold.otf" if bold else "res://art/fonts/Inter-Medium.otf"
		var f: Font = null
		if ResourceLoader.exists(path):
			f = load(path) as Font
		_fonts[key] = f if f != null else ThemeDB.fallback_font
	return _fonts[key]


static func is_mobile() -> bool:
	return OS.has_feature("mobile") or OS.has_feature("web_android") or OS.has_feature("web_ios")


## Short vibration for taps, hits and kills. Respects Settings > Haptics and never fires more than every 40 ms.
static func haptic(ms := 12, amplitude := -1.0) -> void:
	if not is_mobile():
		return
	GameSettings.ensure_loaded()
	if not GameSettings.haptics:
		return
	var now := Time.get_ticks_msec()
	if now - _last_haptic < 40:
		return
	_last_haptic = now
	Input.vibrate_handheld(ms, amplitude)


## Space the screen cut-outs / rounded corners take, in game pixels: (left, top, right, bottom). Zero on PC.
static func safe_insets() -> Vector4:
	if not is_mobile():
		return Vector4.ZERO
	var safe := DisplayServer.get_display_safe_area()
	var screen := DisplayServer.screen_get_size()
	var tree := Engine.get_main_loop() as SceneTree
	if tree == null or safe.size.x <= 0 or screen.x <= 0 or screen.y <= 0:
		return Vector4.ZERO
	var vp := tree.root.get_visible_rect().size
	var k := Vector2(vp.x / float(screen.x), vp.y / float(screen.y))
	return Vector4(maxf(0.0, safe.position.x * k.x), maxf(0.0, safe.position.y * k.y),
		maxf(0.0, (screen.x - safe.end.x) * k.x), maxf(0.0, (screen.y - safe.end.y) * k.y))


# ---------------------------------------------------------------- styles
static func box(fill: Color, radius := 24, shadow := true, pad_h := 20, pad_v := 10) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = fill
	s.set_corner_radius_all(radius)
	s.content_margin_left = pad_h
	s.content_margin_right = pad_h
	s.content_margin_top = pad_v
	s.content_margin_bottom = pad_v
	if shadow:
		s.shadow_color = Color(0, 0, 0, 0.28)
		s.shadow_size = 5
		s.shadow_offset = Vector2(0, 2)
	return s


static func panel_box(pad_h := 20, pad_v := 18, radius := 28) -> StyleBoxFlat:
	var s := box(SURFACE_1, radius, false, pad_h, pad_v)
	s.bg_color = Color(SURFACE_1.r, SURFACE_1.g, SURFACE_1.b, 0.97)
	s.set_border_width_all(1)
	s.border_color = Color(1, 1, 1, 0.06)
	s.shadow_color = Color(0, 0, 0, 0.45)
	s.shadow_size = 22
	s.shadow_offset = Vector2(0, 8)
	return s


## Glass card used by the HUD (translucent, soft corners, no outline).
static func glass_box(radius := 20, pad := 10, alpha := 0.55) -> StyleBoxFlat:
	var s := box(Color(SURFACE.r, SURFACE.g, SURFACE.b, alpha), radius, false, pad, pad)
	s.set_border_width_all(1)
	s.border_color = Color(1, 1, 1, 0.07)
	return s


## Fixed roles instead of the old per-screen colours: "primary" (the main action), "tonal" (everything else),
## "danger" (leave / quit) and "text" (flat, no fill).
static func style_button(b: Button, role := "tonal") -> void:
	var fill := SURFACE_3
	var text := ON_SURFACE
	match role:
		"primary":
			fill = PRIMARY
			text = ON_PRIMARY
		"danger":
			fill = ERROR_CONT
			text = ON_ERROR_CONT
		"text":
			fill = Color(0, 0, 0, 0)
			text = PRIMARY
		"field":                       # a tappable setting that looks like a text field (cycle choices)
			fill = SURFACE_2
	var shadow := role != "text" and role != "field"
	b.add_theme_stylebox_override("normal", box(fill, 24, shadow))
	b.add_theme_stylebox_override("hover", box(fill.lerp(Color.WHITE, 0.08), 24, shadow))
	b.add_theme_stylebox_override("pressed", box(fill.lerp(Color.WHITE, 0.16), 24, false))
	b.add_theme_stylebox_override("disabled", box(fill.lerp(SURFACE_1, 0.65), 24, false))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_color_override("font_color", text)
	b.add_theme_color_override("font_hover_color", text)
	b.add_theme_color_override("font_pressed_color", text)
	b.add_theme_color_override("font_focus_color", text)
	b.add_theme_color_override("font_disabled_color", Color(text.r, text.g, text.b, 0.38))
	b.add_theme_font_override("font", font(true))


## A button that shows an on/off state (Settings toggles): green "chip" when on, quiet tonal when off.
static func style_toggle(b: Button, on: bool) -> void:
	style_button(b, "primary" if on else "tonal")


## Picks a role from one of the old hand-picked fill colours (green = go, red = leave, anything else = tonal).
static func role_of(color: Color) -> String:
	if color.g > color.r + 0.08 and color.g > color.b + 0.02:
		return "primary"
	if color.r > color.g + 0.12 and color.r > color.b + 0.12:
		return "danger"
	return "tonal"


# ---------------------------------------------------------------- motion
## Fades a menu / screen in (and nudges it up a few pixels). Safe to call on a hidden node: it just returns.
static func fade_in(c: CanvasItem, dur := 0.2) -> void:
	if c == null or not c.is_inside_tree():
		return
	c.modulate.a = 0.0
	var t := c.create_tween()
	t.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	t.set_ease(Tween.EASE_OUT)
	t.set_trans(Tween.TRANS_CUBIC)
	t.tween_property(c, "modulate:a", 1.0, dur)


## Panel pop-up: scales from 94% and fades in around its centre.
static func pop_in(c: Control, dur := 0.22) -> void:
	if c == null or not c.is_inside_tree():
		return
	c.pivot_offset = c.size * 0.5
	c.scale = Vector2(0.94, 0.94)
	c.modulate.a = 0.0
	var t := c.create_tween()
	t.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	t.set_parallel(true)
	t.set_ease(Tween.EASE_OUT)
	t.set_trans(Tween.TRANS_BACK)
	t.tween_property(c, "scale", Vector2.ONE, dur)
	t.tween_property(c, "modulate:a", 1.0, dur * 0.8)


## Soft radial texture: transparent in the middle, `edge` colour at the borders (vignette / damage flash).
static func radial_edge(edge: Color, inner := 0.55) -> GradientTexture2D:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, inner, 1.0])
	g.colors = PackedColorArray([Color(edge.r, edge.g, edge.b, 0.0), Color(edge.r, edge.g, edge.b, 0.0), edge])
	var tex := GradientTexture2D.new()
	tex.gradient = g
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.5)
	tex.fill_to = Vector2(1.0, 0.5)
	tex.width = 128
	tex.height = 128
	return tex
