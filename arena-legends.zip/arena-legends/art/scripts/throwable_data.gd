class_name ThrowableData
extends Resource
## One of these per throwable. The throwable slot is separate from the guns.
## Blast types (grenade, knockback bomb) go off instantly. Zone types
## (incendiary, toxic, cryo, smoke) go off and leave a lingering area behind.
## Mines, portals, decoys etc. will plug into the same slot later.

const ART := "res://art/throwables/"
const ZONE_ART := "res://art/zones/"

@export var display_name := "Grenade"
@export var color := Color("5be37d")          # body tint + blast tint
@export var icon: Texture2D                   # smooth 64x64 bomb art (HUD + flying bomb)

@export_group("Throw")
@export var throw_speed := 650.0              # hardest possible throw (farther cursor = harder)
@export var fuse_time := 2.0                  # seconds until it goes off
@export var bounciness := 0.45                # 0 = dead stop, 1 = perfect bounce
@export var explode_on_impact := false        # true = contact bomb (no bouncing)

@export_group("Blast")
@export var damage := 70                      # damage at the very center (0 + no knockback = no blast)
@export var radius := 130.0
@export var knockback := 420.0                # launch strength at the center
@export_enum("fire", "energy", "ignite", "toxic", "frost", "smoke", "pulse") var explosion_style := "fire"   # how the pop looks
@export var lethal_radius := 0.0              # inside this distance of the center = instant kill (0 = no kill zone)
@export var crouch_blast_mult := 0.5          # crouching dodges the kill zone and takes this fraction of the normal damage
@export var knockback_min := 0.25             # fraction of the knockback left at the very edge of the blast (1 at the center)
@export var knockback_cap := 1100.0           # nobody is ever launched faster than this (px/s), so a blast can't send you across the map
@export var knockback_up_bias := 0.35         # how much the blast also pops people upward (so grounded players leave the floor)

@export_group("Stun")
@export var stun_time := 0.0                  # base stun in seconds for someone caught by the blast (0 = this bomb does not stun)
@export var stun_edge_mult := 0.5             # stun at the very edge of the blast = stun_time x this
@export var stun_center_mult := 1.4           # stun at the center = stun_time x this
@export var stun_cap := 1.0                   # a stun is NEVER longer than this many seconds
@export var stun_immunity := 1.0              # after a stun ends you can't be stunned again for this long (no stun-lock)
@export var self_stun_mult := 0.5             # if the thrower is caught in their own blast, their stun is this fraction
@export var shake := 1.0                      # camera shake strength of the blast (0 = none)

@export_group("Lingering zone")
@export var leaves_zone := false              # true = spawns a ThrowableZone where it goes off
@export var zone_texture: Texture2D
@export var zone_radius := 120.0
@export var zone_duration := 5.0              # seconds the area stays
@export_enum("burn", "poison", "cryo", "smoke", "decoy", "gravity", "emp", "noflight", "portal") var zone_effect := "burn"
@export var zone_power := 10.0                # burn/poison = damage per second, cryo = slow fraction (0.5 = 50% slower)
@export var zone_tick := 0.25                 # how often the area re-applies its effect
@export var zone_status_time := 0.8           # effect lingers this long after you step out
@export var zone_spin := 0.0                  # radians/second the picture turns
@export var zone_anchor_floor := false        # true = picture stands on the floor (decoy, portal) instead of a disc around the center
@export var zone_art_scale := 0.5             # size of a floor-standing picture
# zone_power meaning: burn/poison = damage per second, cryo = slow fraction, gravity = pull speed (px/s)

@export_group("Mine")
@export var is_mine := false                  # true = sticks where it lands, arms, then blows when someone walks close
@export var arm_time := 1.0                   # seconds after landing before it can trigger
@export var trigger_radius := 55.0
@export var mine_life := 40.0                 # seconds before an unused mine fizzles out

@export_group("Carry")
@export var start_count := 3                  # how many you spawn with / refill to
@export var max_count := 3

@export_group("Spawning")
@export var catalog_id := ""                  # set by ThrowableCatalog ("grenade", "emp"...)
@export var allowed_maps := PackedStringArray()   # empty = can spawn on every map; otherwise only the listed map ids
@export var spawn_weight := 5.0               # higher = shows up more often in random spawns
@export var pickup_amount := 1                # how many you get from one pickup


static func _tex(path: String) -> Texture2D:
	return load(path) as Texture2D if ResourceLoader.exists(path) else null


static func make_grenade() -> ThrowableData:
	var d := ThrowableData.new()
	d.icon = _tex(ART + "grenade.png")
	d.lethal_radius = 80.0                     # one-hit kill this close (radius is 130), unless crouching
	return d


static func make_knockback_bomb() -> ThrowableData:
	var d := ThrowableData.new()
	d.display_name = "Knockback Bomb"
	d.icon = _tex(ART + "knockback.png")
	d.color = Color("5ff0ff")
	d.explosion_style = "energy"
	d.fuse_time = 1.6
	d.damage = 6                               # it is about displacement, not damage
	d.radius = 175.0
	d.knockback = 880.0                        # launch speed at the center (falls off to knockback_min x this at the edge)
	d.stun_time = 0.6                          # base stun: 0.3 s at the edge up to 0.84 s at the center, capped at 1.0 s
	d.start_count = 2
	d.max_count = 2
	return d


static func make_incendiary() -> ThrowableData:
	var d := ThrowableData.new()
	d.display_name = "Incendiary Grenade"
	d.icon = _tex(ART + "incendiary.png")
	d.color = Color("ff7a28")
	d.explode_on_impact = true                 # bursts into flames on contact
	d.explosion_style = "ignite"
	d.damage = 0
	d.knockback = 0.0
	d.radius = 90.0
	d.leaves_zone = true
	d.zone_effect = "burn"
	d.zone_radius = 110.0
	d.zone_duration = 5.0
	d.zone_power = 20.0                        # ~100 damage if you stand in it the whole 5s (toxic is stronger)
	d.start_count = 2
	d.max_count = 2
	return d


static func make_toxic() -> ThrowableData:
	var d := ThrowableData.new()
	d.display_name = "Toxic Grenade"
	d.icon = _tex(ART + "toxic.png")
	d.color = Color("8ce037")
	d.fuse_time = 1.3
	d.explosion_style = "toxic"
	d.damage = 0
	d.knockback = 0.0
	d.radius = 80.0
	d.leaves_zone = true
	d.zone_effect = "poison"
	d.zone_radius = 120.0
	d.zone_duration = 6.0
	d.zone_power = 30.0                        # ~180 damage over 6s: lethal in ~3.5s, always stronger than incendiary
	d.zone_spin = 0.15
	d.start_count = 2
	d.max_count = 2
	return d


static func make_cryo() -> ThrowableData:
	var d := ThrowableData.new()
	d.display_name = "Cryo Bomb"
	d.icon = _tex(ART + "cryo.png")
	d.color = Color("6ec8ff")
	d.fuse_time = 1.3
	d.explosion_style = "frost"
	d.damage = 0
	d.knockback = 0.0
	d.radius = 90.0
	d.leaves_zone = true
	d.zone_effect = "cryo"
	d.zone_radius = 120.0
	d.zone_duration = 5.0
	d.zone_power = 0.5
	d.zone_status_time = 2.5                    # stays chilled (and visibly frosted) after leaving
	d.zone_spin = 0.1
	d.start_count = 2
	d.max_count = 2
	return d


static func make_smoke() -> ThrowableData:
	var d := ThrowableData.new()
	d.display_name = "Smoke Grenade"
	d.icon = _tex(ART + "smoke.png")
	d.color = Color("a0a8bc")
	d.fuse_time = 1.0
	d.explosion_style = "smoke"
	d.damage = 0
	d.knockback = 0.0
	d.radius = 90.0
	d.leaves_zone = true
	d.zone_effect = "smoke"
	d.zone_radius = 150.0
	d.zone_duration = 8.0
	d.zone_tick = 0.1                           # checks often so hiding is snappy
	d.zone_status_time = 0.35                   # visible again almost right after leaving
	d.start_count = 2
	d.max_count = 2
	return d


# ---------------- utility throwables ----------------

static func make_decoy() -> ThrowableData:
	var d := ThrowableData.new()
	d.display_name = "Decoy"
	d.icon = _tex(ART + "decoy.png")
	d.color = Color("6ec8ff")
	d.fuse_time = 0.9
	d.bounciness = 0.2
	d.explosion_style = "pulse"
	d.damage = 0
	d.knockback = 0.0
	d.radius = 50.0
	d.leaves_zone = true
	d.zone_effect = "decoy"                     # bots shoot at it instead of you
	d.zone_texture = _tex(ZONE_ART + "decoy.png")
	d.zone_anchor_floor = true
	d.zone_art_scale = 0.5
	d.zone_radius = 40.0
	d.zone_duration = 10.0
	d.start_count = 2
	d.max_count = 2
	return d


static func make_gravity() -> ThrowableData:
	var d := ThrowableData.new()
	d.display_name = "Gravity Bomb"
	d.icon = _tex(ART + "gravity.png")
	d.color = Color("a58cff")
	d.fuse_time = 1.2
	d.explosion_style = "pulse"
	d.damage = 0
	d.knockback = 0.0
	d.radius = 90.0
	d.leaves_zone = true
	d.zone_effect = "gravity"                   # drags everyone in range toward the middle
	d.zone_radius = 150.0
	d.zone_duration = 6.0
	d.zone_power = 420.0                        # pull speed in px/s (flying at full speed is 360, so jetpacks can't just outrun it)
	d.zone_status_time = 0.6                    # the 'gravity' status shows the well's grip on the player
	d.zone_tick = 0.1
	d.zone_spin = 1.2
	d.start_count = 2
	d.max_count = 2
	return d


static func make_emp() -> ThrowableData:
	var d := ThrowableData.new()
	d.display_name = "EMP"
	d.icon = _tex(ART + "emp.png")
	d.color = Color("6ee7ff")
	d.fuse_time = 1.0
	d.explosion_style = "pulse"
	d.damage = 0
	d.knockback = 0.0
	d.radius = 110.0
	d.leaves_zone = true
	d.zone_effect = "emp"                       # no jetpack, no throwing, scrambled aim; wipes bombs, mines + gadgets inside
	d.zone_radius = 140.0
	d.zone_duration = 4.0
	d.zone_status_time = 2.5                    # still shocked for a moment after leaving
	d.zone_tick = 0.2
	d.zone_spin = 0.3
	d.start_count = 2
	d.max_count = 2
	return d


static func make_flight_disruption() -> ThrowableData:
	var d := ThrowableData.new()
	d.display_name = "Flight Disruptor"
	d.icon = _tex(ART + "flight_disruption.png")
	d.color = Color("ffd84a")
	d.fuse_time = 1.0
	d.explosion_style = "pulse"
	d.damage = 0
	d.knockback = 0.0
	d.radius = 100.0
	d.leaves_zone = true
	d.zone_effect = "noflight"                  # jetpacks cut out inside
	d.zone_radius = 150.0
	d.zone_duration = 7.0
	d.zone_status_time = 2.0                    # jetpack stays disrupted a moment after leaving
	d.zone_tick = 0.2
	d.zone_spin = -0.4
	d.start_count = 2
	d.max_count = 2
	return d


static func make_trap_mine() -> ThrowableData:
	var d := ThrowableData.new()
	d.display_name = "Trap Mine"
	d.icon = _tex(ART + "trap_mine.png")
	d.color = Color("ff5a4a")
	d.is_mine = true
	d.throw_speed = 450.0
	d.bounciness = 0.0
	d.explosion_style = "fire"
	d.damage = 80
	d.radius = 120.0
	d.knockback = 600.0
	d.arm_time = 1.0
	d.trigger_radius = 55.0
	d.mine_life = 40.0
	d.start_count = 2
	d.max_count = 2
	return d


static func make_portal() -> ThrowableData:
	var d := ThrowableData.new()
	d.display_name = "Portal"
	d.icon = _tex(ART + "portal.png")
	d.color = Color("ff5cf0")
	d.fuse_time = 0.9
	d.bounciness = 0.2
	d.explosion_style = "pulse"
	d.damage = 0
	d.knockback = 0.0
	d.radius = 60.0
	d.leaves_zone = true
	d.zone_effect = "portal"                    # teleports the thrower to where it lands
	d.zone_texture = _tex(ZONE_ART + "portal.png")
	d.zone_anchor_floor = true
	d.zone_art_scale = 0.4
	d.zone_radius = 50.0
	d.zone_duration = 1.5
	d.start_count = 2
	d.max_count = 2
	return d
