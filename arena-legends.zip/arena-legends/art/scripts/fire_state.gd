class_name FireState
extends RefCounted
## Trigger bookkeeping for ONE hand: which firing mode is selected, whether the trigger has been
## released since the last shot (semi / single), and how many rounds of the current burst are still to come.
## player.gd keeps one for the main hand and one for the off hand. It is re-bound automatically whenever the
## gun in that hand changes, which also drops any burst that was under way (so a swapped-out gun never keeps firing).

var weapon: WeaponData = null
var mode := "auto"
var burst_left := 0            # rounds of the current burst that have not been fired yet
var trigger_ready := true      # semi / single: true once the trigger was released after the last shot


func bind(w: WeaponData, saved_mode := "") -> void:
	weapon = w
	burst_left = 0
	trigger_ready = false      # a trigger that is already held when the gun comes out has to be released first
	if w == null:
		mode = "auto"
	else:
		mode = saved_mode if (saved_mode != "" and w.modes().has(saved_mode)) else w.default_mode()


# Next supported mode (wraps around). Returns false if the gun only has one.
func cycle() -> bool:
	if weapon == null:
		return false
	var list := weapon.modes()
	if list.size() < 2:
		return false
	var i := list.find(mode)
	mode = list[(i + 1) % list.size()]
	burst_left = 0             # a pending burst is cancelled by the change
	trigger_ready = false
	return true
