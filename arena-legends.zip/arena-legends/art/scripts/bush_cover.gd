class_name BushCover
extends Node
## Lets a character hide in a hide-bush (like the bushes in Mini Militia). The map's bush areas
## attach this to any character that walks in.
##   * while hidden, the character fades out (you still see yourself dimly; bots are almost
##     invisible to you unless you are close)
##   * bots lose sight of a hidden player unless they are within REVEAL_DISTANCE
##   * shooting or taking damage reveals you for a moment, so a bush is cover from being SEEN,
##     not from bullets
## It only reads the host's state; it never changes movement, health or physics.

const REVEAL_DISTANCE := 170.0
const SHOT_REVEAL_TIME := 1.6
const HIT_REVEAL_TIME := 0.9
const FIRE_VARS := ["_fire_cooldown", "_off_cooldown", "_fire_timer"]   # player + bot reload timers

var host: Node2D
var _areas: Array = []
var _reveal := 0.0
var _alpha := 1.0
var _dirty := false
var _was_concealed := false
var _prev := {}
var _prev_hit := 99.0
var _is_player := false


static func attach(body: Node) -> BushCover:
	var found := body.get_node_or_null("BushCover") as BushCover
	if found != null:
		return found
	var cover := BushCover.new()
	cover.name = "BushCover"
	body.add_child(cover)
	return cover


func _ready() -> void:
	host = get_parent() as Node2D
	_is_player = host != null and host.is_in_group("player")


func enter(area: Area2D) -> void:
	if not _areas.has(area):
		_areas.append(area)


func is_inside() -> bool:
	return not _areas.is_empty()


func _exit_tree() -> void:
	if host != null and is_instance_valid(host):
		host.set_meta("bush_concealed", false)


func _prune() -> void:
	for i in range(_areas.size() - 1, -1, -1):
		var a = _areas[i]
		if not is_instance_valid(a) or not (a as Area2D).is_inside_tree() or not (a as Area2D).overlaps_body(host as Node):
			_areas.remove_at(i)


func _watch_actions() -> void:
	for v in FIRE_VARS:
		var cur = host.get(v)
		if cur == null:
			continue
		if _prev.has(v) and float(cur) > float(_prev[v]) + 0.01:
			_reveal = maxf(_reveal, SHOT_REVEAL_TIME)        # muzzle flash gives you away
		_prev[v] = float(cur)
	var hit = host.get("_time_since_hit")
	if hit != null:
		if float(hit) < _prev_hit - 0.01:
			_reveal = maxf(_reveal, HIT_REVEAL_TIME)
		_prev_hit = float(hit)


func _player_distance() -> float:
	var p := get_tree().get_first_node_in_group("player") as Node2D
	if p == null or p == host:
		return 99999.0
	return host.global_position.distance_to(p.global_position)


func _process(delta: float) -> void:
	if host == null or not is_instance_valid(host):
		return
	_watch_actions()
	_reveal = maxf(0.0, _reveal - delta)
	_prune()
	var dead: bool = (host.get("dead") == true) or (host.get("is_dead") == true)
	var inside := is_inside() and not dead
	var concealed := inside and _reveal <= 0.0
	if concealed != _was_concealed:
		_was_concealed = concealed
		host.set_meta("bush_concealed", concealed)
		host.queue_redraw()                                   # (bots hide their health bar while hidden)

	var target := 1.0
	if inside:
		if _is_player:
			target = 0.42 if concealed else 0.8
		else:
			target = 0.12 if (concealed and _player_distance() > REVEAL_DISTANCE) else 0.8
	_alpha = lerpf(_alpha, target, 1.0 - exp(-9.0 * delta))

	var vis := host.get("visuals") as Node2D
	if vis == null:
		return
	if host.has_method("has_status") and host.has_status("smoked"):
		return                                                # smoke already controls the fade
	if _alpha < 0.995:
		vis.modulate.a = _alpha
		_dirty = true
	elif _dirty:
		vis.modulate.a = 1.0
		_dirty = false
