extends CanvasLayer
## Small FPS counter in the top-right corner. Shown or hidden by the "Show FPS" switch in the settings menu
## (GameSettings.show_fps). Created once by arena_controller.gd, so it works on every map.

var _label: Label
var _timer := 0.0


func _ready() -> void:
	layer = 110                                    # above the pause menu
	process_mode = Node.PROCESS_MODE_ALWAYS        # keeps counting while the game is paused
	GameSettings.ensure_loaded()
	_label = Label.new()
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_label.add_theme_font_size_override("font_size", 14)
	_label.add_theme_color_override("font_color", UITheme.PRIMARY)
	_label.add_theme_color_override("font_outline_color", Color(0.0, 0.0, 0.0, 0.7))
	_label.add_theme_constant_override("outline_size", 5)
	_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	_label.offset_left = -170.0
	_label.offset_right = -12.0
	_label.offset_top = 8.0
	add_child(_label)
	_label.visible = GameSettings.show_fps


func _process(delta: float) -> void:
	_label.visible = GameSettings.show_fps
	if not _label.visible:
		return
	_timer += delta
	if _timer >= 0.4:
		_timer = 0.0
		_label.text = "FPS %d" % Engine.get_frames_per_second()
