extends CanvasLayer
## Match loop: counts kills, shows the score, ends the match at the kill limit.
## Setup: add a CanvasLayer node to your level, name it MatchManager,
## and attach this script. Nothing else to wire up.

@export var kill_limit := 10

var player_kills := 0
var bot_kills := 0
var match_over := false
var _restarting := false            # true once a restart has started, so one tap can never restart twice
var _over_at_ms := 0                # when the match ended (paused time does not count, so we use the real clock)

const RESTART_DELAY_MS := 600       # ignore input right after the end, so a finger still on a stick can't skip the screen
const MapRegistry = preload("res://art/scripts/map_registry.gd")

var score_label: Label
var message_label: Label
var net_mode := false               # LAN match: the host keeps score (net_match.gd); this node only shows it
var _feed_label: Label
var _feed: Array = []               # [text, expires_ms]

# ---- configured offline match (MatchSession). When MatchSession.active is false none of this runs and the
# ---- original first-to-N behaviour above is untouched.
var sess := false
var _cfg: MatchConfig
var elapsed := 0.0                  # seconds of play (menus / pauses do not count)
var alive_time := 0.0               # seconds the player was alive (Survival time)
var kills := 0
var deaths := 0
var streak := 0
var best_streak := 0
var bot_scores := {}                # bot instance id -> kills (free-for-all)
var _player_out := false            # player is down and will not come back
var _end_panel: Control


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS   # keep working while the game is paused
	layer = 10

	# score at the top of the screen
	score_label = Label.new()
	score_label.set_anchors_preset(Control.PRESET_TOP_WIDE)
	score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	score_label.position.y = 12
	score_label.add_theme_font_size_override("font_size", 26)
	score_label.add_theme_font_override("font", UITheme.font(true))
	score_label.add_theme_color_override("font_color", UITheme.ON_SURFACE)
	score_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.6))
	score_label.add_theme_constant_override("outline_size", 5)
	add_child(score_label)

	# big win / lose message in the middle (hidden until the match ends)
	message_label = Label.new()
	message_label.set_anchors_preset(Control.PRESET_FULL_RECT)
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	message_label.add_theme_font_size_override("font_size", 44)
	message_label.add_theme_font_override("font", UITheme.font(true))
	message_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.75))
	message_label.add_theme_constant_override("outline_size", 9)
	message_label.visible = false
	add_child(message_label)

	# listen to every fighter already in the level, and any spawned later
	for n in get_tree().current_scene.find_children("*", "CharacterBody2D", true, false):
		_connect_fighter(n)
	get_tree().node_added.connect(_connect_fighter)

	# only the arena's own MatchManager runs a configured match (a map may add a second one; the arena removes it)
	sess = MatchSession.active and not net_mode and get_parent() == get_tree().current_scene
	if sess:
		_begin_session()
	_update_score()


# Called by the arena when a configured match begins (the node already exists, so _ready could not know yet).
func start_session() -> void:
	sess = true
	match_over = false
	elapsed = 0.0
	alive_time = 0.0
	kills = 0
	deaths = 0
	streak = 0
	best_streak = 0
	_streak_bonus_total = 0
	bot_scores.clear()
	_player_out = false
	message_label.visible = false
	_begin_session()
	_update_score()


func _connect_fighter(node: Node) -> void:
	if node.has_signal("died") and not node.died.is_connected(_on_died):
		node.died.connect(_on_died)


func _on_died(victim: Node, killer: Node) -> void:
	if net_mode:
		return
	if sess:
		_session_died(victim, killer)
		return
	if match_over or killer == null or killer == victim:
		return

	if victim.is_in_group("player"):
		bot_kills += 1
	elif killer.is_in_group("player"):
		player_kills += 1
	_update_score()

	if player_kills >= kill_limit:
		_end_match("YOU WIN!")
	elif bot_kills >= kill_limit:
		_end_match("YOU LOSE")


func _update_score() -> void:
	if net_mode:
		_update_net_score()
		return
	if sess:
		_update_session_score()
		return
	score_label.text = "YOU  %d   -   %d  BOTS      (first to %d)" % [player_kills, bot_kills, kill_limit]


func _end_match(text: String) -> void:
	match_over = true
	_over_at_ms = Time.get_ticks_msec()
	_end_text = text
	# let go of every touch stick / button: nothing keeps firing or flying under the end screen
	for t in get_tree().get_nodes_in_group("touch_controls"):
		t.call("apply_settings")
	_show_end_message()
	get_tree().paused = true


var _end_text := ""


func _show_end_message() -> void:
	var hint := "Tap to play again" if TouchControls.active else "Press Enter, click or press A to play again"
	message_label.text = "%s\n\n%s" % [_end_text, hint]
	message_label.visible = true


# Any of these starts the next match: Enter / Space (ui_accept), a controller confirm button, a mouse click,
# or a tap on the touch screen. (The old code only listened for Enter, which a phone does not have.)
func _input(event: InputEvent) -> void:
	if sess or not match_over or _restarting:
		return                              # a configured match shows an end panel with its own buttons
	if Time.get_ticks_msec() - _over_at_ms < RESTART_DELAY_MS:
		return
	var confirm := event.is_action_pressed("ui_accept")
	if event is InputEventScreenTouch and event.pressed:
		confirm = true
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		confirm = true
	elif event is InputEventJoypadButton and event.pressed and event.button_index == JOY_BUTTON_A:
		confirm = true
	if confirm:
		get_viewport().set_input_as_handled()
		restart_match()


# Starts a brand new match on the same map: kills back to 0, every flag cleared, player + bots respawned,
# ammo / grenades / weapon / camera zoom back to the start. Settings and touch layout live in
# user://settings.cfg and static GameSettings, so they are kept.
func restart_match() -> void:
	if _restarting:
		return
	_restarting = true
	match_over = false
	player_kills = 0
	bot_kills = 0
	message_label.visible = false
	var scene := get_tree().current_scene
	if sess:
		MatchSession.restart_pending = true       # the reloaded scene starts this same match straight away
	elif scene != null:
		MapRegistry.restart_map_id = str(scene.get_meta("active_map_id", ""))
	# a touch button that was mid-tap when the scene is replaced would otherwise stay pressed
	Input.action_release("pickup")
	Input.action_release("dual_wield")
	get_tree().paused = false
	get_tree().reload_current_scene()


# ======================= network match =======================
# The arena controller calls this when a LAN match starts. From then on the host's scores are shown here.
func enter_net_mode() -> void:
	net_mode = true
	match_over = false
	score_label.add_theme_font_size_override("font_size", 21)
	if _feed_label == null:
		_feed_label = Label.new()
		_feed_label.set_anchors_preset(Control.PRESET_TOP_RIGHT)
		_feed_label.grow_horizontal = Control.GROW_DIRECTION_BEGIN
		_feed_label.position = Vector2(-20, 70)
		_feed_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		_feed_label.add_theme_font_size_override("font_size", 16)
		_feed_label.add_theme_color_override("font_color", UITheme.ON_SURFACE)
		_feed_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.65))
		_feed_label.add_theme_constant_override("outline_size", 4)
		_feed_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(_feed_label)
	if not Net.game.scores_changed.is_connected(_update_net_score):
		Net.game.scores_changed.connect(_update_net_score)
		Net.game.kill_feed.connect(_on_net_feed)
	_update_net_score()


func _update_net_score() -> void:
	if not net_mode:
		return
	var rows: Array = []
	for id in Net.game.scores:
		rows.append([Net.name_of(id), int(Net.game.scores[id]["kills"]), int(Net.game.scores[id]["deaths"])])
	rows.sort_custom(func(a, b) -> bool: return a[1] > b[1])
	var parts: PackedStringArray = []
	for r in rows:
		parts.append("%s %d" % [r[0], r[1]])
	var clock := ""
	if Net.game.time_limit > 0.0:
		var t := int(ceil(Net.game.time_left))
		clock = "     %d:%02d" % [t / 60, t % 60]
	score_label.text = "%s     (first to %d)%s" % ["  -  ".join(parts), Net.game.kill_limit, clock]


func _on_net_feed(text: String) -> void:
	_feed.append([text, Time.get_ticks_msec() + 5000])
	while _feed.size() > 5:
		_feed.pop_front()
	_refresh_feed()


func _refresh_feed() -> void:
	var now := Time.get_ticks_msec()
	_feed = _feed.filter(func(e) -> bool: return e[1] > now)
	var lines: PackedStringArray = []
	for e in _feed:
		lines.append(e[0])
	if _feed_label != null:
		_feed_label.text = "\n".join(lines)


var _clock_shown := -1


func _process(_delta: float) -> void:
	if sess:
		_session_tick(_delta)
		return
	if net_mode and Net.game.time_limit > 0.0:
		var t := int(ceil(Net.game.time_left))
		if t != _clock_shown:
			_clock_shown = t
			_update_net_score()
	if net_mode and not _feed.is_empty():
		_refresh_feed()


# =========================================================================================== configured offline match
# Scoring rules (explicit, per mode):
#   SURVIVAL   score = 100 per bot kill + 20 x streak bonus (streak - 1, max 5) + 5 per 10 s survived.
#              You have `lives` lives. Out of lives = DEFEAT. Reaching the time limit alive = VICTORY.
#              Kill limit (if set) = VICTORY. Survival time = seconds you were alive.
#   DEATHMATCH free-for-all: every fighter's kills count (bots can kill bots). Score = 100 per kill.
#   CUSTOM     same rules as Deathmatch (it is a Deathmatch with your own settings).
#   TRAINING   nothing ends the match and nothing is saved to records (unless you set a time / kill limit yourself).
# Ending: first to the kill limit, or when time runs out the most kills wins (a tie for first is a draw).
# With bot respawn OFF, the match also ends once every bot is down (you win).
func _begin_session() -> void:
	_cfg = MatchSession.cfg
	MatchSession.on_player_out_cb = _on_player_out
	score_label.add_theme_font_size_override("font_size", 20)


func _record_mode() -> String:
	# an experimental modifier means this is NOT a normal Survival / Deathmatch result
	var m := _cfg.mode
	if (m == "survival" or m == "deathmatch"):
		for id in MatchConfig.MODIFIERS:
			if _cfg.is_mod(id):
				return "custom"
	return m


func _is_player(n: Node) -> bool:
	return n != null and n.is_in_group("player")


func _session_died(victim: Node, killer: Node) -> void:
	if match_over:
		return
	if _is_player(victim):
		deaths += 1
		streak = 0
		if _cfg.mode == "survival":
			MatchSession.lives_left = maxi(MatchSession.lives_left - 1, 0)
	elif victim.is_in_group("bot") and killer != null and killer != victim:
		if _is_player(killer):
			kills += 1
			streak += 1
			best_streak = maxi(best_streak, streak)
			_streak_bonus_total += 20 * mini(streak - 1, 5)
		elif killer.is_in_group("bot"):
			bot_scores[killer.get_instance_id()] = int(bot_scores.get(killer.get_instance_id(), 0)) + 1
	if _is_player(victim) and killer != null and killer != victim and killer.is_in_group("bot"):
		bot_scores[killer.get_instance_id()] = int(bot_scores.get(killer.get_instance_id(), 0)) + 1
	_update_session_score()
	_check_session_end()


func _on_player_out(_player: Node) -> void:
	_player_out = true
	if _cfg.mode == "survival":
		_check_session_end()
	else:
		message_label.text = "ELIMINATED\nRespawn is off. The match goes on.\nOpen MENU to restart or quit."
		message_label.visible = true
		message_label.add_theme_font_size_override("font_size", 28)


func _top_bot() -> int:
	var best := 0
	for k in bot_scores:
		best = maxi(best, int(bot_scores[k]))
	return best


func score() -> int:
	var s := kills * 100
	if _cfg.mode == "survival":
		s += _streak_bonus_total + int(alive_time / 10.0) * 5
	return s


var _streak_bonus_total := 0


func _session_tick(delta: float) -> void:
	if match_over or get_tree().paused:
		return
	elapsed += delta
	var player := get_tree().get_first_node_in_group("player")
	if player != null and not bool(player.get("is_dead")):
		alive_time += delta
	_score_refresh -= delta
	if _score_refresh <= 0.0:
		_score_refresh = 0.25
		_update_session_score()
		_check_session_end()


var _score_refresh := 0.0


func _time_left() -> float:
	return -1.0 if _cfg.duration_min <= 0 else maxf(float(_cfg.duration_min) * 60.0 - elapsed, 0.0)


func _clock_text(seconds: float) -> String:
	var t := int(ceil(seconds))
	return "%d:%02d" % [t / 60, t % 60]


func _update_session_score() -> void:
	var parts: PackedStringArray = []
	match _cfg.mode:
		"survival":
			parts.append("SCORE %d" % score())
			parts.append("KILLS %d" % kills)
			parts.append("STREAK %d" % streak)
			parts.append("LIVES %d" % MatchSession.lives_left)
		"training":
			parts.append("TRAINING")
			parts.append("KILLS %d" % kills)
		_:
			parts.append("YOU %d" % kills)
			parts.append("BEST BOT %d" % _top_bot())
	if _cfg.kill_limit > 0:
		parts.append("FIRST TO %d" % _cfg.kill_limit)
	var left := _time_left()
	parts.append(_clock_text(left) if left >= 0.0 else _clock_text(elapsed))
	score_label.text = "   ".join(parts)


func _all_bots_down() -> bool:
	if _cfg.bot_respawn or _cfg.bot_count <= 0:
		return false
	var bots := get_tree().get_nodes_in_group("bot")
	if bots.is_empty():
		return false
	for b in bots:
		if bool(b.get("dead")) == false:
			return false
	return true


func _check_session_end() -> void:
	if match_over or not sess:
		return
	var limit := _cfg.kill_limit
	if _cfg.mode == "survival":
		if MatchSession.lives_left <= 0 and _player_out:
			_end_session("DEFEAT", false)
			return
		if limit > 0 and kills >= limit:
			_end_session("VICTORY", true)
			return
		var left := _time_left()
		if left == 0.0:
			_end_session("VICTORY", true)
			return
		if _all_bots_down():
			_end_session("VICTORY", true)
		return
	if limit > 0:
		if kills >= limit:
			_end_session("VICTORY", true)
			return
		if _top_bot() >= limit:
			_end_session("DEFEAT", false)
			return
	if _time_left() == 0.0:
		var bot_best := _top_bot()
		if kills > bot_best:
			_end_session("VICTORY", true)
		elif kills < bot_best:
			_end_session("DEFEAT", false)
		else:
			_end_session("DRAW", false)
		return
	if _all_bots_down():
		_end_session("VICTORY", true)


func _end_session(title: String, won: bool) -> void:
	match_over = true
	_over_at_ms = Time.get_ticks_msec()
	for t in get_tree().get_nodes_in_group("touch_controls"):
		t.call("apply_settings")
	var final_score := score()
	var mode := _record_mode()
	var broken: Array = MatchStore.record_match({
		"mode": mode, "map_id": _cfg.map_id, "difficulty": _cfg.bot_difficulty, "kills": kills, "deaths": deaths,
		"best_streak": best_streak, "score": final_score,
		"time": alive_time if _cfg.mode == "survival" else elapsed, "won": won})
	var lines: PackedStringArray = []
	lines.append("Kills %d   Deaths %d   Best streak %d" % [kills, deaths, best_streak])
	if MatchSession.shots > 0:
		lines.append("Accuracy %d%%   (bullets only)" % roundi(MatchSession.accuracy() * 100.0))
	lines.append("Score %d" % final_score)
	lines.append("Match time %s" % _clock_text(elapsed))
	if _cfg.mode == "survival":
		lines.append("Survived %s" % _clock_text(alive_time))
	if not broken.is_empty():
		lines.append("NEW PERSONAL BEST: " + ", ".join(broken))
	elif mode == "training":
		lines.append("Training results are not saved.")
	_show_end_panel(title, "\n".join(lines))
	get_tree().paused = true


func _show_end_panel(title: String, body: String) -> void:
	message_label.visible = false
	if _end_panel != null:
		_end_panel.queue_free()
	var root := CenterContainer.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(root)
	_end_panel = root
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UITheme.panel_box(24, 20))
	panel.custom_minimum_size = Vector2(380, 0)
	root.add_child(panel)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	panel.add_child(col)
	var t := Label.new()
	t.text = title
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.add_theme_font_size_override("font_size", 38)
	t.add_theme_font_override("font", UITheme.font(true))
	t.add_theme_color_override("font_color", UITheme.PRIMARY if title == "VICTORY" else (UITheme.ERROR if title == "DEFEAT" else UITheme.ON_SURFACE))
	col.add_child(t)
	var b := Label.new()
	b.text = body
	b.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	b.add_theme_font_size_override("font_size", 16)
	b.add_theme_color_override("font_color", UITheme.ON_VARIANT)
	col.add_child(b)
	var again := Button.new()
	again.text = "PLAY AGAIN"
	again.custom_minimum_size = Vector2(0, 54)
	UITheme.style_button(again, "primary")
	again.pressed.connect(restart_match)
	col.add_child(again)
	var menu := Button.new()
	menu.text = "MAIN MENU"
	menu.custom_minimum_size = Vector2(0, 54)
	UITheme.style_button(menu, "tonal")
	menu.pressed.connect(go_to_main_menu)
	col.add_child(menu)
	UITheme.pop_in(panel)


# Leaves the match for good: the config is dropped, so nothing experimental can leak into the next one.
func go_to_main_menu() -> void:
	if _restarting:
		return
	_restarting = true
	MatchSession.end_session()
	get_tree().paused = false
	Input.action_release("pickup")
	Input.action_release("dual_wield")
	get_tree().reload_current_scene()
