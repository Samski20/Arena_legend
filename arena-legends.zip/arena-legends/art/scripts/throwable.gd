class_name Throwable
extends CharacterBody2D
## A thrown bomb: flies in an arc, bounces off the map, blinks, then goes off.
## Created by player.gd, which calls setup() right before adding it to the scene.

var data: ThrowableData
var thrower: Node = null
var gravity := 900.0

var _fuse := 2.0
var _age := 0.0
var _exploded := false
var _stuck := false          # mines: has landed
var _stuck_time := 0.0
var _scan := 0.0
var net_visual := false      # network match: cosmetic copy on a client; only the host's copy explodes and hurts
var net_id := 0               # network id shared by the host's bomb and the clients' copies (0 = offline / rocket warhead)


func setup(d: ThrowableData, who: Node, start_velocity: Vector2) -> void:
	data = d
	thrower = who
	velocity = start_velocity
	_fuse = d.fuse_time


func _ready() -> void:
	add_to_group("throwable")          # lets future counters (EMP field, deflector...) find bombs
	collision_layer = 0                # nothing (bullets included) collides *with* the bomb
	collision_mask = 0xFFFFFFFF        # but the bomb bounces off everything solid
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	var shape := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 6.0
	shape.shape = circle
	add_child(shape)
	if thrower is PhysicsBody2D:
		add_collision_exception_with(thrower)    # doesn't bounce off the person who threw it
	if Net.match_active():
		for p in get_tree().get_nodes_in_group("player"):     # network: bombs fly through every player, the same on every peer
			if p is PhysicsBody2D:
				add_collision_exception_with(p)


func _physics_process(delta: float) -> void:
	if _exploded:
		return
	_age += delta
	if global_position.y > 6000.0:
		queue_free()                               # fell off a floorless map
		return
	if data.is_mine:
		_mine_step(delta)
		return
	_fuse -= delta

	velocity.y += gravity * delta
	var hit := move_and_collide(velocity * delta)
	if hit:
		if data.explode_on_impact and _age > 0.05:
			if net_visual:
				velocity = Vector2.ZERO          # contact bomb copy: waits for the host's explosion event
				return
			_explode()
			return
		var n := hit.get_normal()
		velocity = velocity.bounce(n) * data.bounciness
		if n.y < -0.7:                       # landed on a floor: scrub sideways speed
			velocity.x *= 0.82
			if absf(velocity.y) < 60.0:
				velocity.y = 0.0

	rotation += velocity.x * 0.02 * delta
	queue_redraw()
	if _fuse <= 0.0 and not net_visual:
		_explode()


func _draw() -> void:
	if data == null:
		return
	if data.icon != null:
		draw_texture_rect(data.icon, Rect2(-13, -17, 26, 26), false)    # the smooth 64x64 bomb art
	else:
		var ink := Color(0.07, 0.08, 0.13)
		draw_circle(Vector2.ZERO, 8.0, ink)
		draw_circle(Vector2.ZERO, 6.5, data.color.darkened(0.4))
		draw_circle(Vector2(-2, -2), 3.0, data.color.lightened(0.3))
		draw_rect(Rect2(-2, -11, 4, 4), ink)                  # little cap on top
	if data.is_mine:
		if _stuck and _stuck_time >= data.arm_time:
			if int(_age * 3.0) % 2 == 0:
				draw_circle(Vector2(0, -3), 2.5, Color(1, 0.15, 0.1, 0.95))      # armed: slow red blink
		elif _stuck:
			draw_circle(Vector2(0, -3), 2.5, Color(1, 0.85, 0.2, 0.9))           # arming: steady yellow
		return
	if _fuse < 0.8 and int(_age * 14.0) % 2 == 0:             # blinks faster-looking near the end
		draw_circle(Vector2.ZERO, 6.5, Color(1, 1, 1, 0.55))


func _explode() -> void:
	if _exploded:
		return
	_exploded = true
	if net_visual:
		queue_free()                           # cosmetic copy: the host's explosion event draws the blast
		return
	if data.damage > 0 or data.knockback > 0.0:
		_apply_blast()                         # pure zone bombs skip the instant blast

	if data.leaves_zone:
		if data.zone_effect == "portal":
			_portal_departure()
		_make_zone(global_position)

	var fx := BlastFX.new()
	fx.setup(data.radius, data.color, data.explosion_style)
	fx.shake_scale = data.shake
	get_tree().current_scene.add_child(fx)
	fx.global_position = global_position
	if Net.match_active() and Net.is_host():
		Net.game.host_explosion(net_id, global_position, data.radius, data.color, data.explosion_style, data.shake)
	queue_free()


func _make_zone(at: Vector2) -> void:
	var zone := ThrowableZone.new()
	zone.setup(data, thrower)
	get_tree().current_scene.add_child(zone)
	zone.global_position = at
	if Net.match_active() and Net.is_host():
		Net.game.host_zone_created(zone, data)


func _exit_tree() -> void:
	# a host bomb that vanished without exploding (EMP, fizzled mine, fell out of the world): drop the clients' copies
	if net_id != 0 and not _exploded and not net_visual and Net.match_active() and Net.is_host():
		Net.game.host_net_gone(net_id)


# ---------------- trap mine ----------------
func _mine_step(delta: float) -> void:
	if not _stuck:
		velocity.y += gravity * delta
		var hit := move_and_collide(velocity * delta)
		if hit:
			_stuck = true                          # sticks to whatever it hits
			velocity = Vector2.ZERO
			rotation = hit.get_normal().angle() + PI / 2.0       # stands up off the surface
		queue_redraw()
		return

	_stuck_time += delta
	queue_redraw()
	if net_visual:
		return                                     # cosmetic mine: the host decides when it goes off
	if _stuck_time >= data.mine_life:
		queue_free()                               # fizzles out
		return
	if _stuck_time < data.arm_time:
		return
	_scan -= delta
	if _scan > 0.0:
		return
	_scan = 0.08
	var circle := CircleShape2D.new()
	circle.radius = data.trigger_radius
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = circle
	query.transform = Transform2D(0.0, global_position)
	query.collision_mask = 0xFFFFFFFF
	query.collide_with_bodies = true
	query.collide_with_areas = false
	for hit in get_world_2d().direct_space_state.intersect_shape(query, 16):
		var body: Object = hit.collider
		if body == null or not body.has_method("take_damage"):
			continue
		if ("is_dead" in body and bool(body.get("is_dead"))) or ("dead" in body and bool(body.get("dead"))):
			continue                               # corpses don't set it off
		_explode()
		return


# ---------------- portal ----------------
# The thrower steps out of one portal and into another where the bomb landed.
func _portal_departure() -> void:
	if not is_instance_valid(thrower) or not (thrower is Node2D):
		return
	if ("is_dead" in thrower and bool(thrower.get("is_dead"))) or ("dead" in thrower and bool(thrower.get("dead"))):
		return
	var who := thrower as Node2D
	_make_zone(who.global_position + Vector2(0, 22))                       # portal opens at your feet
	var dest := global_position + Vector2(0, -22)
	if who.has_method("net_teleport"):
		who.net_teleport(dest)                                             # a remote player: the host tells its owner where to go
	else:
		who.global_position = dest
		if "velocity" in who:
			who.set("velocity", Vector2.ZERO)


func _is_dead(body: Object) -> bool:
	return ("is_dead" in body and bool(body.get("is_dead"))) or ("dead" in body and bool(body.get("dead")))


# Damages + launches everything with take_damage() inside the radius (players, bots, targets).
var skip_bodies: Array = []        # bodies this blast must not hurt again (a rocket's direct-hit target)


func _apply_blast() -> void:
	var space := get_world_2d().direct_space_state
	var circle := CircleShape2D.new()
	circle.radius = data.radius
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = circle
	query.transform = Transform2D(0.0, global_position)
	query.collision_mask = 0xFFFFFFFF
	query.collide_with_bodies = true
	query.collide_with_areas = false

	var seen := {}
	for hit in space.intersect_shape(query, 32):
		var body: Object = hit.collider
		if body == null or seen.has(body):
			continue
		if not (body is Node2D) or not body.has_method("take_damage"):
			continue
		seen[body] = true
		if skip_bodies.has(body):
			continue                                                   # already hit directly by this rocket

		var target_pos: Vector2 = (body as Node2D).global_position
		if body.has_method("blast_center"):
			target_pos = body.blast_center()                           # the middle of the body, not the feet
		var offset: Vector2 = target_pos - global_position
		var dist := offset.length()
		var falloff := clampf(1.0 - dist / data.radius, 0.0, 1.0)     # 1 at the center, 0 at the edge
		var strength := lerpf(data.knockback_min, 1.0, falloff)        # never fully zero inside the blast
		var dir := offset.normalized() if dist > 1.0 else Vector2.UP    # away from the blast
		dir = (dir + Vector2(0, -data.knockback_up_bias)).normalized() # pop people slightly upward

		# Cover is directional: only a crouching target whose shield FACES the blast is protected.
		var covered := false
		var is_shield_body: bool = body.has_method("is_shielding_toward")
		if is_shield_body:
			covered = body.is_shielding_toward(global_position)

		var dmg := maxi(1, roundi(data.damage * strength * MatchSession.damage_mult_for(thrower)))
		var push: Vector2 = dir * minf(data.knockback * strength, data.knockback_cap) * MatchSession.explosion_mult()    # smooth, capped, then scaled by the Increased Explosion Force modifier
		if covered:
			dmg = maxi(1, roundi(dmg * data.crouch_blast_mult))        # shield soaks part of it
			push *= 0.3
		elif data.lethal_radius > 0.0 and dist <= data.lethal_radius:
			dmg = 9999                                                 # kill zone, nothing in the way

		if body != thrower and "last_attacker" in body:
			body.last_attacker = thrower if is_instance_valid(thrower) else null     # kill credit
		if is_shield_body:
			body.take_damage(dmg, push, true)                          # we already did the shield math
		else:
			body.take_damage(dmg, push)

		# Stun: closer = longer, capped, shorter when shielded or when it's your own bomb.
		if data.stun_time > 0.0 and body.has_method("apply_stun") and not _is_dead(body):
			var stun := data.stun_time * lerpf(data.stun_edge_mult, data.stun_center_mult, falloff)
			if covered:
				stun *= 0.5
			if body == thrower:
				stun *= data.self_stun_mult
			body.apply_stun(minf(stun, data.stun_cap), data.stun_immunity, thrower)
