extends RefCounted
## Central registry for playable Arena Legends maps.
## Add future maps here rather than scattering scene paths across UI/gameplay scripts.

## Set by the match manager just before it restarts the scene, so "play again" stays on the same map.
static var restart_map_id := ""

const MAPS := {
	"abandoned_station": {
		"name": "Abandoned Station",
		"scene": "res://abandoned_station.tscn",
		"description": "A dark industrial station with catwalks, tunnels and reactor rooms."
	},
	"cavern_isles": {
		"name": "Cavern Isles",
		"scene": "res://cavern_isles.tscn",
		"description": "Rocky sky islands with two long tunnels, boulders, stalactites and crate-and-sandbag cover.",
		"oob": true       # has an out-of-bounds zone, so the "Out-of-bounds damage" match rule applies here
	}
}

static func get_map(map_id: String) -> Dictionary:
	return MAPS.get(map_id, {})

static func all_maps() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for map_id in MAPS:
		var entry: Dictionary = MAPS[map_id].duplicate(true)
		entry["id"] = map_id
		result.append(entry)
	return result
