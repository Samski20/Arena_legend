class_name ZoomConfig
extends RefCounted
## One place for every weapon's camera zoom range. Edit the numbers here to balance later.
## Numbers are "view distance" like Mini Militia: LOWER = camera closer, HIGHER = camera farther (sees more).
## Keys are the weapon's display_name (the one in its .tres file).

# BASE_VIEW is the view number of your ORIGINAL camera (Godot zoom 1.0) = 4x. So 2x is twice as close as the
# old camera, and 7x shows far more than it.
# Raise it if everything looks too far away, lower it if everything looks too close.
const BASE_VIEW := 4.0
const STEP := 0.25            # how much one mouse-wheel notch / button tap changes the view number

# name: [min, default, max]
const RANGES := {
	"Desert Eagle": [2.0, 2.5, 3.0],
	"Colt Python":  [2.0, 2.5, 3.0],
	"Glock 18":     [2.0, 2.5, 3.0],      # not in the brief: same as the other pistols
	"Uzi":          [3.0, 3.5, 4.0],
	"MP5":          [3.0, 3.5, 4.0],
	"Thompson":     [3.0, 3.5, 4.0],      # weapon not made yet
	"AK-47":        [2.5, 3.0, 4.0],      # not in the brief: a medium assault rifle view, closer than the M16A4
	"M4A1":         [2.5, 3.0, 4.0],      # not in the brief: same as the AK-47
	"M16A4":        [3.0, 4.0, 5.0],      # weapon not made yet
	"SPAS-12":      [2.0, 2.5, 3.0],      # not in the brief: short range, like the pistols
	"Double Barrel":[2.0, 2.5, 3.0],      # not in the brief: short range, like the pistols
	"M249 SAW":     [3.0, 4.0, 5.0],
	"Barrett M82":  [5.0, 6.0, 7.0],      # not in the brief: same as the SVD Dragunov
	"SVD Dragunov": [5.0, 6.0, 7.0],      # weapon not made yet
	"RPG-7":        [3.0, 4.0, 5.0],      # weapon not made yet
}
const FALLBACK := [2.0, 3.0, 4.0]


static func range_for(w: WeaponData) -> Dictionary:
	var r: Array = RANGES.get(w.display_name if w != null else "", FALLBACK)
	return {"min": float(r[0]), "default": float(r[1]), "max": float(r[2])}


# Zoom rules for one weapon in hand.
static func single_info(w: WeaponData) -> Dictionary:
	var r := range_for(w)
	r["key"] = w.display_name
	return r


# Zoom rules for two guns held together: the gun with the HIGHER maximum decides the limits and the default.
# (Same maximum: that shared maximum, with the lower of the two minimums.)
static func dual_info(a: WeaponData, b: WeaponData) -> Dictionary:
	var ra := range_for(a)
	var rb := range_for(b)
	var hi := ra
	if float(rb["max"]) > float(ra["max"]):
		hi = rb
	var lo := float(hi["min"])
	if is_equal_approx(float(ra["max"]), float(rb["max"])):
		lo = minf(float(ra["min"]), float(rb["min"]))
	var names := PackedStringArray([a.display_name, b.display_name])
	names.sort()
	return {
		"key": "dual:" + "+".join(names),
		"min": lo,
		"max": float(hi["max"]),
		"default": clampf(float(hi["default"]), lo, float(hi["max"])),
	}
