class_name MatchConfig
extends RefCounted
## ONE model for every setting of a single match. Offline setup, saved presets, built-in presets and
## (where it applies) the LAN host screen all read and write this same object. Nothing here is a second
## copy of a gameplay value: MatchSession turns it into real rules when a match starts.

const VERSION := 1
const MapRegistry = preload("res://art/scripts/map_registry.gd")

const MODES := ["survival", "deathmatch", "training", "custom"]
const MODE_NAMES := {"survival": "Survival", "deathmatch": "Deathmatch", "training": "Training", "custom": "Custom Match"}

const DURATIONS := [2, 5, 10, 15, 20, 0]                   # minutes, 0 = no time limit
const KILL_LIMITS := [5, 10, 15, 20, 30, 50, 0]            # 0 = unlimited
const HEALTHS := [50, 100, 150, 200]
const RESPAWN_DELAYS := [0.0, 1.0, 2.0, 3.0, 5.0]
const LIVES := [1, 3, 5]
const RATE_NAMES := ["OFF", "LOW", "NORMAL", "HIGH", "VERY HIGH"]
const WEAPON_MAX := [3, 5, 10, 15, 20, 0]                  # 0 = every spot on the map (capped by the map's own spots)
const THROW_MAX := [2, 4, 6, 8, 12, 0]
const BOT_COUNTS := [0, 1, 2, 3, 4, 5, 6, 8, 10]
const MOBILE_MAX_BOTS := 6                                 # keeps weak phones playable

const WEAPON_MODES := ["all", "none", "custom"]
const THROW_MODES := ["none", "all", "grenades", "explosives", "tactical", "custom"]
const THROW_MODE_NAMES := {"none": "No Throwables", "all": "All Compatible", "grenades": "Grenades Only",
	"explosives": "Explosives Only", "tactical": "Tactical Only", "custom": "Custom Selection"}

const MODIFIERS := {
	"unlimited_ammo": "Unlimited Ammo",
	"infinite_grenades": "Infinite Grenades",
	"infinite_fuel": "Infinite Jetpack Fuel",
	"infinite_health": "Infinite Health",
	"no_reload": "No Weapon Reload",
	"increased_damage": "Increased Damage",
	"low_gravity": "Low Gravity",
	"fast_movement": "Fast Movement",
	"explosion_force": "Increased Explosion Force",
	"no_respawn_delay": "No Respawn Delay",
	"all_weapons": "All Compatible Weapons Available",
	"all_throwables": "All Compatible Throwables Available",
}
const MODIFIER_HINTS := {
	"unlimited_ammo": "Spare ammo never runs out (magazines still empty).",
	"infinite_grenades": "Throwing does not use up your stock.",
	"infinite_fuel": "Jetpack never runs dry. Does NOT stop damage.",
	"infinite_health": "You take no combat damage. Out-of-bounds still hurts and can still kill you.",
	"no_reload": "Reloading is instant.",
	"increased_damage": "Everything YOU shoot, throw or blow up hits 50% harder.",
	"low_gravity": "Gravity is 45% of normal. Jetpack is unchanged.",
	"fast_movement": "Walking and flying speed +30%.",
	"explosion_force": "Every explosion launches people 50% harder.",
	"no_respawn_delay": "You come back instantly. Bots keep their own delay.",
	"all_weapons": "Forces the weapon selection to ALL.",
	"all_throwables": "Forces the throwable selection to ALL compatible.",
}
# UNLIMITED MODE master toggle switches exactly these on (individual ones stay editable afterwards).
const UNLIMITED_GROUP := ["unlimited_ammo", "infinite_grenades", "infinite_fuel", "no_reload"]

# ---- the settings ----
var preset_name := ""                  # name of the preset this was loaded from ("" = none)
var mode := "deathmatch"
var map_id := "abandoned_station"
var duration_min := 5
var kill_limit := 10
var lives := 3                         # Survival only
var start_health := 100
var health_regen := true
var player_respawn := true
var player_respawn_delay := 2.0
var oob_damage := true                 # only has an effect on maps with an out-of-bounds zone
var bot_count := 3
var bot_difficulty := 1
var bot_respawn := true
var bot_respawn_delay := 3.0
var bot_throwables := true             # false = bots never throw, whatever their difficulty
var weapon_rate := 2
var weapon_max := 0
var weapon_mode := "all"
var weapon_ids: Array = []             # used when weapon_mode == "custom"
var throw_rate := 2
var throw_max := 0
var throw_mode := "all"
var throw_ids: Array = []              # used when throw_mode == "custom"
var use_loadouts := false
var loadout: Dictionary = {}           # snapshot of the chosen loadout (see MatchStore.make_loadout)
var unlimited_mode := false
var modifiers: Dictionary = {}         # modifier id -> bool


static func for_mode(m: String) -> MatchConfig:
	var c := MatchConfig.new()
	c.mode = m
	match m:
		"survival":
			c.duration_min = 10
			c.kill_limit = 0
			c.lives = 3
			c.bot_count = 4
			c.bot_difficulty = 1
		"deathmatch":
			c.duration_min = 5
			c.kill_limit = 10
			c.bot_count = 3
		"training":
			c.duration_min = 0
			c.kill_limit = 0
			c.bot_count = 0
			c.player_respawn = true
			c.player_respawn_delay = 1.0
			c.weapon_rate = 3
			c.throw_rate = 3
		"custom":
			c.duration_min = 10
			c.kill_limit = 20
	return c


func is_mod(id: String) -> bool:
	if id in UNLIMITED_GROUP and unlimited_mode:
		return true
	return bool(modifiers.get(id, false))


func set_mod(id: String, on: bool) -> void:
	if unlimited_mode and id in UNLIMITED_GROUP and not on:
		# turning one member off leaves UNLIMITED MODE: the others stay on as individual modifiers
		unlimited_mode = false
		for g in UNLIMITED_GROUP:
			modifiers[g] = true
	modifiers[id] = on


func set_unlimited_mode(on: bool) -> void:
	unlimited_mode = on
	for id in UNLIMITED_GROUP:
		modifiers[id] = on


func max_bots() -> int:
	return MOBILE_MAX_BOTS if UITheme.is_mobile() else 10


# ---- effective selections (the catalogs are the source of truth, nothing is listed twice) ----
func effective_weapon_ids() -> Array:
	var all_ids: Array = WeaponCatalog.PATHS.keys()
	if is_mod("all_weapons") or weapon_mode == "all":
		return all_ids
	if weapon_mode == "none":
		return []
	return all_ids.filter(func(id) -> bool: return weapon_ids.has(id))


func effective_throwable_ids() -> Array:
	var ids: Array = []
	for d in ThrowableCatalog.for_map(map_id):
		ids.append(d.catalog_id)
	if is_mod("all_throwables"):
		return ids
	match throw_mode:
		"none":
			return []
		"all":
			return ids
		"custom":
			return ids.filter(func(id) -> bool: return throw_ids.has(id))
		_:
			return ids.filter(func(id) -> bool: return ThrowableCatalog.mode_contains(throw_mode, id))


# ---- validation: returns a list of {"text": String, "fix": String} problems; empty = OK ----
func validate() -> Array:
	var problems: Array = []
	var info := MapRegistry.get_map(map_id)
	if info.is_empty():
		problems.append({"text": "The map \"%s\" is not available." % map_id, "fix": "map"})
	if not MODES.has(mode):
		problems.append({"text": "Unknown game mode \"%s\"." % mode, "fix": "mode"})
	# custom throwable picks that this map cannot spawn
	if throw_mode == "custom" and not is_mod("all_throwables"):
		for id in throw_ids:
			var d := ThrowableCatalog.get_data(str(id))
			if d == null:
				problems.append({"text": "Throwable \"%s\" no longer exists." % id, "fix": "throwables"})
			elif not ThrowableCatalog.can_spawn_on(d, map_id):
				problems.append({"text": "%s cannot spawn on %s. Pick another map or untick it." % [d.display_name, str(info.get("name", map_id))], "fix": "throwables"})
	if weapon_mode == "custom" and not is_mod("all_weapons"):
		for id in weapon_ids:
			if WeaponCatalog.get_weapon(str(id)) == null:
				problems.append({"text": "Weapon \"%s\" no longer exists." % id, "fix": "weapons"})
	if bot_count > max_bots():
		problems.append({"text": "%d bots is too many for this device (max %d)." % [bot_count, max_bots()], "fix": "bots"})
	if use_loadouts:
		problems.append_array(validate_loadout())
	return problems


func validate_loadout() -> Array:
	var problems: Array = []
	if loadout.is_empty():
		problems.append({"text": "Loadouts are on but none is selected.", "fix": "loadout"})
		return problems
	var nm := str(loadout.get("name", "Loadout"))
	for key in ["primary", "secondary"]:
		var id := str(loadout.get(key, ""))
		if id == "" or WeaponCatalog.get_weapon(id) == null:
			problems.append({"text": "%s: the %s weapon \"%s\" is not available." % [nm, key, id], "fix": "loadout"})
	var p := WeaponCatalog.get_weapon(str(loadout.get("primary", "")))
	var s := WeaponCatalog.get_weapon(str(loadout.get("secondary", "")))
	if p != null and s != null and str(loadout.get("primary")) == str(loadout.get("secondary")):
		problems.append({"text": "%s: primary and secondary are the same weapon." % nm, "fix": "loadout"})
	var info := MapRegistry.get_map(map_id)
	for k in ["t1", "t2"]:
		var tid := str(loadout.get(k, ""))
		if tid == "":
			continue
		var d := ThrowableCatalog.get_data(tid)
		if d == null:
			problems.append({"text": "%s: throwable \"%s\" no longer exists." % [nm, tid], "fix": "loadout"})
		elif not ThrowableCatalog.can_spawn_on(d, map_id):
			problems.append({"text": "%s: %s is not available on %s. Choose another map or change the loadout." % [nm, d.display_name, str(info.get("name", map_id))], "fix": "loadout"})
	return problems


# ---- (de)serialisation: plain dictionaries so saves survive code changes ----
func to_dict() -> Dictionary:
	return {
		"v": VERSION, "name": preset_name, "mode": mode, "map_id": map_id, "duration_min": duration_min,
		"kill_limit": kill_limit, "lives": lives, "start_health": start_health, "health_regen": health_regen,
		"player_respawn": player_respawn, "player_respawn_delay": player_respawn_delay, "oob_damage": oob_damage,
		"bot_count": bot_count, "bot_difficulty": bot_difficulty, "bot_respawn": bot_respawn,
		"bot_respawn_delay": bot_respawn_delay, "bot_throwables": bot_throwables,
		"weapon_rate": weapon_rate, "weapon_max": weapon_max, "weapon_mode": weapon_mode, "weapon_ids": weapon_ids.duplicate(),
		"throw_rate": throw_rate, "throw_max": throw_max, "throw_mode": throw_mode, "throw_ids": throw_ids.duplicate(),
		"use_loadouts": use_loadouts, "loadout": loadout.duplicate(true),
		"unlimited_mode": unlimited_mode, "modifiers": modifiers.duplicate(),
	}


static func from_dict(d: Dictionary) -> MatchConfig:
	var c := MatchConfig.new()
	c.preset_name = str(d.get("name", ""))
	c.mode = str(d.get("mode", c.mode))
	c.map_id = str(d.get("map_id", c.map_id))
	c.duration_min = int(d.get("duration_min", c.duration_min))
	c.kill_limit = int(d.get("kill_limit", c.kill_limit))
	c.lives = int(d.get("lives", c.lives))
	c.start_health = clampi(int(d.get("start_health", c.start_health)), 10, 500)
	c.health_regen = bool(d.get("health_regen", c.health_regen))
	c.player_respawn = bool(d.get("player_respawn", c.player_respawn))
	c.player_respawn_delay = clampf(float(d.get("player_respawn_delay", c.player_respawn_delay)), 0.0, 30.0)
	c.oob_damage = bool(d.get("oob_damage", c.oob_damage))
	c.bot_count = clampi(int(d.get("bot_count", c.bot_count)), 0, 10)
	c.bot_difficulty = clampi(int(d.get("bot_difficulty", c.bot_difficulty)), 0, 3)
	c.bot_respawn = bool(d.get("bot_respawn", c.bot_respawn))
	c.bot_respawn_delay = clampf(float(d.get("bot_respawn_delay", c.bot_respawn_delay)), 0.0, 30.0)
	c.bot_throwables = bool(d.get("bot_throwables", c.bot_throwables))
	c.weapon_rate = clampi(int(d.get("weapon_rate", c.weapon_rate)), 0, 4)
	c.weapon_max = int(d.get("weapon_max", c.weapon_max))
	c.weapon_mode = str(d.get("weapon_mode", c.weapon_mode))
	c.weapon_ids = (d.get("weapon_ids", []) as Array).duplicate() if d.get("weapon_ids", []) is Array else []
	c.throw_rate = clampi(int(d.get("throw_rate", c.throw_rate)), 0, 4)
	c.throw_max = int(d.get("throw_max", c.throw_max))
	c.throw_mode = str(d.get("throw_mode", c.throw_mode))
	c.throw_ids = (d.get("throw_ids", []) as Array).duplicate() if d.get("throw_ids", []) is Array else []
	c.use_loadouts = bool(d.get("use_loadouts", c.use_loadouts))
	c.loadout = (d.get("loadout", {}) as Dictionary).duplicate(true) if d.get("loadout", {}) is Dictionary else {}
	c.unlimited_mode = bool(d.get("unlimited_mode", c.unlimited_mode))
	c.modifiers = (d.get("modifiers", {}) as Dictionary).duplicate() if d.get("modifiers", {}) is Dictionary else {}
	if not WEAPON_MODES.has(c.weapon_mode):
		c.weapon_mode = "all"
	if not THROW_MODES.has(c.throw_mode):
		c.throw_mode = "all"
	return c


func duplicate_config() -> MatchConfig:
	return MatchConfig.from_dict(to_dict())
