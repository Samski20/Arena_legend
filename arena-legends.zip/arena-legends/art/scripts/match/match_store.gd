class_name MatchStore
extends RefCounted
## Everything saved to disk for match setup: saved presets, the five loadout slots and personal records.
## Three small JSON files with a version number, so a game update can still read old saves.
## A broken / unreadable file is moved aside (".bad") instead of crashing or being silently overwritten.

const PRESETS_PATH := "user://match_presets.json"
const LOADOUTS_PATH := "user://match_loadouts.json"
const RECORDS_PATH := "user://match_records.json"
const LAST_PATH := "user://match_last.json"
const LOADOUT_SLOTS := 5
const FORMAT := 1


# ------------------------------------------------------------------ file helpers
static func _read(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return {}
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if parsed is Dictionary:
		return parsed
	# unreadable: keep a copy so nothing the player made is lost, then start clean
	DirAccess.rename_absolute(ProjectSettings.globalize_path(path), ProjectSettings.globalize_path(path) + ".bad")
	push_warning("MatchStore: %s was unreadable and was moved to %s.bad" % [path, path])
	return {}


static func _write(path: String, data: Dictionary) -> bool:
	data["format"] = FORMAT
	var tmp := path + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		push_warning("MatchStore: cannot write %s" % path)
		return false
	f.store_string(JSON.stringify(data, "\t"))
	f.close()
	var abs_tmp := ProjectSettings.globalize_path(tmp)
	var abs_path := ProjectSettings.globalize_path(path)
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(abs_path)
	return DirAccess.rename_absolute(abs_tmp, abs_path) == OK


# ------------------------------------------------------------------ saved match presets
# Stored as an ordered array of config dictionaries (each has a "name").
static func list_presets() -> Array:
	var raw: Variant = _read(PRESETS_PATH).get("presets", [])
	var out: Array = []
	if raw is Array:
		for e in raw:
			if e is Dictionary and str(e.get("name", "")) != "":
				out.append(e)
	return out


static func preset_exists(name: String) -> bool:
	for e in list_presets():
		if str(e["name"]).to_lower() == name.strip_edges().to_lower():
			return true
	return false


# Saves (or updates) a preset by name. Returns "" on success or an error message.
static func save_preset(cfg: MatchConfig, name: String) -> String:
	name = name.strip_edges().left(24)
	if name == "":
		return "Give the preset a name."
	if MatchPresets.is_builtin_name(name):
		return "\"%s\" is a built-in preset name. Pick another." % name
	var d := cfg.to_dict()
	d["name"] = name
	var list := list_presets()
	var replaced := false
	for i in list.size():
		if str(list[i]["name"]).to_lower() == name.to_lower():
			list[i] = d
			replaced = true
	if not replaced:
		list.append(d)
	return "" if _write(PRESETS_PATH, {"presets": list}) else "Could not save to this device."


static func delete_preset(name: String) -> void:
	var list := list_presets().filter(func(e) -> bool: return str(e["name"]).to_lower() != name.to_lower())
	_write(PRESETS_PATH, {"presets": list})


# Returns "" on success or an error message.
static func rename_preset(old_name: String, new_name: String) -> String:
	new_name = new_name.strip_edges().left(24)
	if new_name == "":
		return "Give the preset a name."
	if MatchPresets.is_builtin_name(new_name):
		return "\"%s\" is a built-in preset name." % new_name
	if new_name.to_lower() != old_name.to_lower() and preset_exists(new_name):
		return "A preset called \"%s\" already exists." % new_name
	var list := list_presets()
	for e in list:
		if str(e["name"]).to_lower() == old_name.to_lower():
			e["name"] = new_name
	return "" if _write(PRESETS_PATH, {"presets": list}) else "Could not save to this device."


# ------------------------------------------------------------------ loadouts (5 slots)
static func make_loadout(name: String, primary: String, secondary: String, t1: String, t1_qty: int, t2: String, t2_qty: int) -> Dictionary:
	return {"name": name, "primary": primary, "secondary": secondary, "t1": t1, "t1_qty": t1_qty, "t2": t2, "t2_qty": t2_qty}


# Always returns exactly LOADOUT_SLOTS entries; an empty dictionary = an empty slot.
# First run: the five editable starting loadouts.
static func load_loadouts() -> Array:
	var data := _read(LOADOUTS_PATH)
	var raw: Variant = data.get("slots", null)
	var out: Array = []
	if raw is Array:
		for e in raw:
			out.append(e if e is Dictionary else {})
	else:
		out = MatchPresets.starter_loadouts()
	while out.size() < LOADOUT_SLOTS:
		out.append({})
	return out.slice(0, LOADOUT_SLOTS)


static func save_loadout(slot: int, lo: Dictionary) -> bool:
	if slot < 0 or slot >= LOADOUT_SLOTS:
		return false
	var all := load_loadouts()
	all[slot] = lo
	return _write(LOADOUTS_PATH, {"slots": all})


static func delete_loadout(slot: int) -> bool:
	return save_loadout(slot, {})


# ------------------------------------------------------------------ last used setup (so the screen reopens as you left it)
static func save_last(cfg: MatchConfig) -> void:
	_write(LAST_PATH, {"config": cfg.to_dict()})


static func load_last(mode: String) -> MatchConfig:
	var d: Variant = _read(LAST_PATH).get("config", null)
	if d is Dictionary and str(d.get("mode", "")) == mode:
		return MatchConfig.from_dict(d)
	return MatchConfig.for_mode(mode)


# ------------------------------------------------------------------ personal records
# Key: mode | map | difficulty. Survival, Deathmatch, Training and Custom never share an entry,
# and a different map or bot difficulty has its own entry too.
static func record_key(mode: String, map_id: String, difficulty: int) -> String:
	return "%s|%s|%d" % [mode, map_id, difficulty]


static func _blank_record() -> Dictionary:
	return {"matches": 0, "wins": 0, "losses": 0, "kills": 0, "deaths": 0, "best_score": 0,
		"best_kills": 0, "best_streak": 0, "best_time": 0.0, "total_time": 0.0}


static func all_records() -> Dictionary:
	var r: Variant = _read(RECORDS_PATH).get("records", {})
	return r if r is Dictionary else {}


static func get_record(mode: String, map_id: String, difficulty: int) -> Dictionary:
	var r := _blank_record()
	var saved: Variant = all_records().get(record_key(mode, map_id, difficulty), {})
	if saved is Dictionary:
		for k in r:
			if saved.has(k):
				r[k] = saved[k]
	return r


# Adds one finished match. Returns the list of personal bests that were beaten (for the end screen).
# result: {mode, map_id, difficulty, kills, deaths, best_streak, score, time (s), won (bool)}
static func record_match(result: Dictionary) -> Array:
	var mode := str(result.get("mode", ""))
	if mode == "training":
		return []                                    # practice never touches records
	var key := record_key(mode, str(result.get("map_id", "")), int(result.get("difficulty", 1)))
	var all := all_records()
	var rec := get_record(mode, str(result.get("map_id", "")), int(result.get("difficulty", 1)))
	var broken: Array = []
	rec["matches"] = int(rec["matches"]) + 1
	rec["wins" if bool(result.get("won", false)) else "losses"] = int(rec["wins" if bool(result.get("won", false)) else "losses"]) + 1
	rec["kills"] = int(rec["kills"]) + int(result.get("kills", 0))
	rec["deaths"] = int(rec["deaths"]) + int(result.get("deaths", 0))
	rec["total_time"] = float(rec["total_time"]) + float(result.get("time", 0.0))
	if int(result.get("score", 0)) > int(rec["best_score"]):
		rec["best_score"] = int(result.get("score", 0))
		broken.append("HIGH SCORE")
	if int(result.get("kills", 0)) > int(rec["best_kills"]):
		rec["best_kills"] = int(result.get("kills", 0))
		broken.append("MOST KILLS")
	if int(result.get("best_streak", 0)) > int(rec["best_streak"]):
		rec["best_streak"] = int(result.get("best_streak", 0))
		broken.append("BEST KILL STREAK")
	if mode == "survival" and float(result.get("time", 0.0)) > float(rec["best_time"]):
		rec["best_time"] = float(result.get("time", 0.0))
		broken.append("LONGEST SURVIVAL")
	all[key] = rec
	_write(RECORDS_PATH, {"records": all})
	return broken
