class_name MenuKit
extends RefCounted
## Small builders so every match-setup screen looks like the rest of the v34 UI (green accent, Inter, rounded
## tonal buttons) without repeating styling code.


static func label(text: String, size := 17, color := UITheme.ON_SURFACE, bold := false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if bold:
		l.add_theme_font_override("font", UITheme.font(true))
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


static func hint(parent: Control, text: String, color := UITheme.ON_VARIANT) -> Label:
	var l := label(text, 13, color)
	l.custom_minimum_size = Vector2(240, 0)
	parent.add_child(l)
	return l


static func section(parent: Control, text: String) -> void:
	var l := label(text.to_upper(), 13, UITheme.PRIMARY, true)
	l.custom_minimum_size = Vector2(0, 30)
	l.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	parent.add_child(l)


static func button(text: String, role := "tonal", height := 48.0, size := 17) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(64, height)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("font_size", size)
	UITheme.style_button(b, role)
	focus_ring(b)
	return b


# Visible focus outline so keyboard and controller navigation can see where they are.
static func focus_ring(b: Button) -> void:
	var s := UITheme.box(Color(0, 0, 0, 0), 24, false, 20, 10)
	s.set_border_width_all(3)
	s.border_color = UITheme.FLY
	b.add_theme_stylebox_override("focus", s)


# Row: label on the left, an ON / OFF chip on the right.
static func toggle_row(parent: Control, text: String, value: bool, on_change: Callable, enabled := true) -> Button:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	parent.add_child(row)
	var l := label(text, 17)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.custom_minimum_size = Vector2(110, 0)
	row.add_child(l)
	var b := Button.new()
	b.custom_minimum_size = Vector2(110, 46)
	b.size_flags_horizontal = Control.SIZE_SHRINK_END
	b.add_theme_font_size_override("font_size", 16)
	b.text = "ON" if value else "OFF"
	UITheme.style_toggle(b, value)
	b.disabled = not enabled
	b.pressed.connect(func() -> void: on_change.call(not value))
	row.add_child(b)
	return b


# Row: label, then  <  value  >  . `options` are display strings; `on_change` gets the new index (wraps around).
static func choice_row(parent: Control, text: String, options: Array, index: int, on_change: Callable) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	parent.add_child(row)
	var l := label(text, 17)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.custom_minimum_size = Vector2(100, 0)
	row.add_child(l)
	var n := maxi(options.size(), 1)
	index = clampi(index, 0, n - 1)
	var prev := button("<", "tonal", 46, 18)
	prev.size_flags_horizontal = Control.SIZE_SHRINK_END
	prev.custom_minimum_size = Vector2(48, 46)
	prev.pressed.connect(func() -> void: on_change.call((index - 1 + n) % n))
	row.add_child(prev)
	var v := label(str(options[index]) if not options.is_empty() else "-", 16, UITheme.ON_SURFACE, true)
	v.custom_minimum_size = Vector2(112, 0)
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(v)
	var next := button(">", "tonal", 46, 18)
	next.size_flags_horizontal = Control.SIZE_SHRINK_END
	next.custom_minimum_size = Vector2(48, 46)
	next.pressed.connect(func() -> void: on_change.call((index + 1) % n))
	row.add_child(next)


# A row of mutually exclusive buttons (ALL / NONE / CUSTOM ...). The selected one is the green primary chip.
static func segmented(parent: Control, options: Array, selected: int, on_pick: Callable) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	parent.add_child(row)
	for i in options.size():
		var b := button(str(options[i]), "primary" if i == selected else "tonal", 46, 15)
		b.pressed.connect(func() -> void: on_pick.call(i))
		row.add_child(b)


static func card(parent: Control) -> VBoxContainer:
	var pc := PanelContainer.new()
	pc.add_theme_stylebox_override("panel", UITheme.box(UITheme.SURFACE_2, 18, false, 14, 12))
	pc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(pc)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	pc.add_child(v)
	return v


static func fmt_minutes(m: int) -> String:
	return "No limit" if m <= 0 else "%d min" % m


static func fmt_kills(k: int) -> String:
	return "Unlimited" if k <= 0 else str(k)


static func fmt_seconds(s: float) -> String:
	return "Instant" if s <= 0.0 else ("%.0f s" % s)
