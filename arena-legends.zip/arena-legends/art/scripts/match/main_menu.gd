class_name MainMenu
extends CanvasLayer
## First screen of the game: PLAY GAME / MULTIPLAYER / SETTINGS, then mode select, match setup and records.
## It only collects choices and emits signals; the arena controller does the loading (maps, LAN and settings
## screens are the existing ones).

signal multiplayer_pressed
signal settings_pressed
signal customize_pressed
signal start_match(cfg: MatchConfig)

const BotDifficulty = preload("res://art/scripts/bot_difficulty.gd")
const MapRegistry = preload("res://art/scripts/map_registry.gd")
const LOGO := "res://art/ui/splash.png"

## Drifting soft dots over a dark gradient. ~28 circles, redrawn at ~30 fps and only while visible.
class Ambient extends Control:
	var _dots: Array = []
	var _acc := 0.0

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		for i in 28:
			_dots.append([randf(), randf(), randf_range(0.004, 0.016), randf_range(2.0, 7.0), randf_range(0.05, 0.22)])

	func _process(delta: float) -> void:
		if not is_visible_in_tree():
			return
		for d in _dots:
			d[1] -= d[2] * delta                       # float upward
			d[0] += sin(Time.get_ticks_msec() * 0.0004 + d[3]) * 0.0004
			if d[1] < -0.05:
				d[1] = 1.05
				d[0] = randf()
		_acc += delta
		if _acc >= 0.033:
			_acc = 0.0
			queue_redraw()

	func _draw() -> void:
		var r := Rect2(Vector2.ZERO, size)
		draw_rect(r, UITheme.SURFACE)
		draw_rect(Rect2(0, size.y * 0.55, size.x, size.y * 0.45), Color(0.24, 0.86, 0.52, 0.05))
		for d in _dots:
			draw_circle(Vector2(d[0] * size.x, d[1] * size.y), d[3], Color(0.24, 0.86, 0.52, d[4]))

var _screens := {}
var _setup: MatchSetup
var _records_list: VBoxContainer
var _current := "home"
var _play_btn: Button


func _ready() -> void:
	layer = 104
	process_mode = Node.PROCESS_MODE_ALWAYS
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(root)
	root.add_child(Ambient.new())
	_screens["home"] = _build_home(root)
	_screens["modes"] = _build_modes(root)
	_screens["records"] = _build_records(root)
	_setup = MatchSetup.new()
	_setup.visible = false
	_setup.back_pressed.connect(func() -> void: show_screen("modes"))
	_setup.start_requested.connect(_on_start)
	root.add_child(_setup)
	_screens["setup"] = _setup


func open() -> void:
	visible = true
	show_screen("home")


func close() -> void:
	visible = false


func show_screen(name: String) -> void:
	_current = name
	for k in _screens:
		_screens[k].visible = k == name
	if _screens.has(name):
		UITheme.fade_in(_screens[name], 0.18)
	if name == "home" and _play_btn != null:
		_play_btn.grab_focus.call_deferred()            # keyboard / controller start on PLAY GAME
	elif name == "modes":
		_first_button(_screens["modes"]).grab_focus.call_deferred()
	elif name == "records":
		_records_back.grab_focus.call_deferred()


func _first_button(n: Node) -> Button:
	for c in n.find_children("*", "Button", true, false):
		return c as Button
	return null


func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("ui_cancel") and (_current == "modes" or _current == "records"):
		get_viewport().set_input_as_handled()
		show_screen("home" if _current == "modes" else "modes")


func _centered(parent: Control, width: float) -> VBoxContainer:
	var holder := Control.new()
	holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	holder.visible = false
	parent.add_child(holder)
	var ins := UITheme.safe_insets()
	var m := MarginContainer.new()
	m.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	m.add_theme_constant_override("margin_left", int(16 + ins.x))
	m.add_theme_constant_override("margin_right", int(16 + ins.z))
	m.add_theme_constant_override("margin_top", int(10 + ins.y))
	m.add_theme_constant_override("margin_bottom", int(10 + ins.w))
	holder.add_child(m)
	var c := CenterContainer.new()
	m.add_child(c)
	var col := VBoxContainer.new()
	col.custom_minimum_size = Vector2(width, 0)
	col.add_theme_constant_override("separation", 12)
	c.add_child(col)
	holder.set_meta("col", col)
	return col


func _build_home(parent: Control) -> Control:
	var col := _centered(parent, 380)
	var holder: Control = col.get_parent().get_parent().get_parent()
	if ResourceLoader.exists(LOGO):
		var logo := TextureRect.new()
		logo.texture = load(LOGO)
		logo.custom_minimum_size = Vector2(0, 120)
		logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		logo.mouse_filter = Control.MOUSE_FILTER_IGNORE
		col.add_child(logo)
	var title := MenuKit.label("ARENA LEGENDS", 44, UITheme.ON_SURFACE, true)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(title)
	var tag := MenuKit.label("JETPACK ARENA SHOOTER", 14, UITheme.PRIMARY, true)
	tag.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(tag)
	col.add_child(Control.new())
	_play_btn = MenuKit.button("PLAY GAME", "primary", 66, 22)
	_play_btn.pressed.connect(func() -> void: show_screen("modes"))
	col.add_child(_play_btn)
	var mp := MenuKit.button("MULTIPLAYER", "tonal", 60, 20)
	mp.pressed.connect(func() -> void: multiplayer_pressed.emit())
	col.add_child(mp)
	var cu := MenuKit.button("CUSTOMIZE", "tonal", 60, 20)
	cu.pressed.connect(func() -> void: customize_pressed.emit())
	col.add_child(cu)
	var st := MenuKit.button("SETTINGS", "tonal", 60, 20)
	st.pressed.connect(func() -> void: settings_pressed.emit())
	col.add_child(st)
	var sub := MenuKit.label("Multiplayer: host or join over Wi-Fi or a phone hotspot", 12, UITheme.ON_VARIANT)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(sub)
	return holder


func _build_modes(parent: Control) -> Control:
	var col := _centered(parent, 440)
	var holder: Control = col.get_parent().get_parent().get_parent()
	var t := MenuKit.label("SELECT MODE", 28, UITheme.ON_SURFACE, true)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(t)
	var blurbs := {
		"survival": "Score against bots. Limited lives, kill streaks and personal records.",
		"deathmatch": "Free-for-all against bots. First to the kill limit wins.",
		"training": "Practice movement, jetpack, aim and throwables. No pressure.",
		"custom": "Every rule, map, weapon, throwable and modifier is yours.",
	}
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	col.add_child(grid)
	for m in MatchConfig.MODES:
		var b := MenuKit.button("%s\n%s" % [str(MatchConfig.MODE_NAMES[m]).to_upper(), blurbs[m]], "tonal", 110, 14)
		b.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		b.pressed.connect(_pick_mode.bind(str(m)))
		grid.add_child(b)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	col.add_child(row)
	var rec := MenuKit.button("RECORDS", "tonal", 52, 16)
	rec.pressed.connect(func() -> void:
		_fill_records()
		show_screen("records"))
	row.add_child(rec)
	var back := MenuKit.button("BACK", "tonal", 52, 16)
	back.pressed.connect(func() -> void: show_screen("home"))
	row.add_child(back)
	return holder


func _pick_mode(mode: String) -> void:
	_screens["setup"].visible = true
	_current = "setup"
	for k in _screens:
		_screens[k].visible = k == "setup"
	_setup.open(MatchStore.load_last(mode))


func _on_start(cfg: MatchConfig) -> void:
	MatchStore.save_last(cfg)
	start_match.emit(cfg)


var _records_back: Button


func _build_records(parent: Control) -> Control:
	var holder := Control.new()
	holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	holder.visible = false
	parent.add_child(holder)
	var ins := UITheme.safe_insets()
	var m := MarginContainer.new()
	m.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	m.add_theme_constant_override("margin_left", int(18 + ins.x))
	m.add_theme_constant_override("margin_right", int(18 + ins.z))
	m.add_theme_constant_override("margin_top", int(12 + ins.y))
	m.add_theme_constant_override("margin_bottom", int(12 + ins.w))
	holder.add_child(m)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 8)
	m.add_child(col)
	var head := HBoxContainer.new()
	col.add_child(head)
	_records_back = MenuKit.button("BACK", "tonal", 46, 16)
	_records_back.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_records_back.custom_minimum_size = Vector2(96, 46)
	_records_back.pressed.connect(func() -> void: show_screen("modes"))
	head.add_child(_records_back)
	var t := MenuKit.label("PERSONAL RECORDS", 22, UITheme.ON_SURFACE, true)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	head.add_child(t)
	var sc := MenuScroll.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_child(sc)
	_records_list = VBoxContainer.new()
	_records_list.add_theme_constant_override("separation", 8)
	_records_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(_records_list)
	return holder


func _fill_records() -> void:
	for c in _records_list.get_children():
		_records_list.remove_child(c)
		c.queue_free()
	var all := MatchStore.all_records()
	if all.is_empty():
		MenuKit.hint(_records_list, "No records yet. Finish a Survival, Deathmatch or Custom match to set one. Training is never recorded.")
		return
	var keys := all.keys()
	keys.sort()
	for key in keys:
		var parts := str(key).split("|")
		if parts.size() != 3:
			continue
		var r := MatchStore.get_record(parts[0], parts[1], int(parts[2]))
		var map_name := str(MapRegistry.get_map(parts[1]).get("name", parts[1]))
		var v := MenuKit.card(_records_list)
		v.add_child(MenuKit.label("%s  ·  %s  ·  %s" % [str(MatchConfig.MODE_NAMES.get(parts[0], parts[0])), map_name, BotDifficulty.NAMES[clampi(int(parts[2]), 0, 3)]], 16, UITheme.PRIMARY, true))
		var lines := "Matches %d   Wins %d   Losses %d\nHigh score %d   Most kills %d   Best streak %d\nTotal kills %d   Total deaths %d   Time played %d min" % [
			r["matches"], r["wins"], r["losses"], r["best_score"], r["best_kills"], r["best_streak"], r["kills"], r["deaths"], int(float(r["total_time"]) / 60.0)]
		if parts[0] == "survival":
			lines += "\nLongest survival %d:%02d" % [int(float(r["best_time"])) / 60, int(float(r["best_time"])) % 60]
		v.add_child(MenuKit.label(lines, 14, UITheme.ON_VARIANT))
