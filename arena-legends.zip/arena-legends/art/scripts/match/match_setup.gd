class_name MatchSetup
extends Control
## The match configuration screens (RULES / BOTS / WEAPONS / THROWABLES / LOADOUT / MODIFIERS / PRESETS).
## It edits ONE MatchConfig. Selections live in that object, not in the widgets, so they survive switching pages.
## Nothing here is shown unless the matching gameplay system really uses it.

const MapRegistry = preload("res://art/scripts/map_registry.gd")
const BotDifficulty = preload("res://art/scripts/bot_difficulty.gd")

signal back_pressed
signal start_requested(cfg: MatchConfig)

const PAGES := [["rules", "RULES"], ["bots", "BOTS"], ["weapons", "WEAPONS"], ["throwables", "THROWABLES"],
	["loadout", "LOADOUT"], ["mods", "MODIFIERS"], ["presets", "PRESETS"]]
const SCORING_TEXT := {
	"survival": "SURVIVAL scoring: 100 per bot kill, +20 per streak step (max +100), +5 per 10 s survived. You have a limited number of lives. Out of lives = defeat; reaching the time or kill limit = victory.",
	"deathmatch": "DEATHMATCH: free-for-all, 100 points per kill, bots can also kill each other. First to the kill limit wins; when time runs out the most kills wins.",
	"training": "TRAINING: nothing ends the match unless you set a limit, and results are never saved to records.",
	"custom": "CUSTOM: deathmatch scoring with all your own rules. Saved under its own records.",
}

var cfg: MatchConfig = MatchConfig.new()
var _page := "rules"
var _scroll: MenuScroll
var _list: VBoxContainer
var _tabs: HFlowContainer
var _title: Label
var _start: Button
var _problem_label: Label
var _fix_btn: Button
var _toast: Label
var _toast_t := 0.0
var _overlay: Control
var _edit_slot := -1                      # loadout editor: slot being edited (-1 = list view)
var _draft: Dictionary = {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = UITheme.SURFACE
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(bg)

	var ins := UITheme.safe_insets()
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", int(18 + ins.x))
	margin.add_theme_constant_override("margin_top", int(12 + ins.y))
	margin.add_theme_constant_override("margin_right", int(18 + ins.z))
	margin.add_theme_constant_override("margin_bottom", int(12 + ins.w))
	add_child(margin)

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 8)
	margin.add_child(col)

	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 10)
	col.add_child(head)
	var back := MenuKit.button("BACK", "tonal", 46, 16)
	back.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	back.custom_minimum_size = Vector2(96, 46)
	back.pressed.connect(func() -> void: back_pressed.emit())
	head.add_child(back)
	_title = MenuKit.label("", 22, UITheme.ON_SURFACE, true)
	_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	head.add_child(_title)

	_tabs = HFlowContainer.new()
	_tabs.add_theme_constant_override("h_separation", 6)
	_tabs.add_theme_constant_override("v_separation", 6)
	col.add_child(_tabs)

	_scroll = MenuScroll.new()
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_child(_scroll)
	_list = VBoxContainer.new()
	_list.add_theme_constant_override("separation", 8)
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll.add_child(_list)

	var foot := HBoxContainer.new()
	foot.add_theme_constant_override("separation", 10)
	col.add_child(foot)
	_problem_label = MenuKit.label("", 14, UITheme.ERROR)
	_problem_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_problem_label.custom_minimum_size = Vector2(120, 0)
	foot.add_child(_problem_label)
	_fix_btn = MenuKit.button("FIX", "tonal", 52, 16)
	_fix_btn.size_flags_horizontal = Control.SIZE_SHRINK_END
	_fix_btn.custom_minimum_size = Vector2(80, 52)
	_fix_btn.pressed.connect(_on_fix)
	foot.add_child(_fix_btn)
	_start = MenuKit.button("START MATCH", "primary", 56, 20)
	_start.size_flags_horizontal = Control.SIZE_SHRINK_END
	_start.custom_minimum_size = Vector2(190, 56)
	_start.pressed.connect(func() -> void: start_requested.emit(cfg))
	foot.add_child(_start)

	_toast = MenuKit.label("", 15, UITheme.ON_PRIMARY, true)
	_toast.add_theme_stylebox_override("normal", UITheme.box(UITheme.PRIMARY, 18, false, 16, 8))
	_toast.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_toast.position = Vector2(-120, -120)
	_toast.visible = false
	add_child(_toast)


func _process(delta: float) -> void:
	if _toast_t > 0.0:
		_toast_t -= delta
		if _toast_t <= 0.0:
			_toast.visible = false


func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("ui_cancel") and _overlay == null:
		get_viewport().set_input_as_handled()
		if _edit_slot >= 0:
			_edit_slot = -1
			_rebuild()
		else:
			back_pressed.emit()


func open(config: MatchConfig, page := "rules") -> void:
	cfg = config
	_page = page
	_edit_slot = -1
	visible = true
	_rebuild()
	UITheme.fade_in(self)


func _say(text: String) -> void:
	_toast.text = text
	_toast.visible = true
	_toast_t = 2.2


func _changed() -> void:
	_rebuild.call_deferred()


# ------------------------------------------------------------------ frame: tabs, title, problems
func _rebuild() -> void:
	if _list == null:
		return
	var keep := _scroll.scroll_vertical
	_title.text = str(MatchConfig.MODE_NAMES.get(cfg.mode, cfg.mode)).to_upper()
	if cfg.preset_name != "":
		_title.text += "   ·   " + cfg.preset_name
	for c in _tabs.get_children():
		_tabs.remove_child(c)
		c.queue_free()
	for p in PAGES:
		var b := MenuKit.button(str(p[1]), "primary" if p[0] == _page else "tonal", 40, 14)
		b.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		b.custom_minimum_size = Vector2(98, 40)
		b.pressed.connect(_goto.bind(str(p[0])))
		_tabs.add_child(b)
	for c in _list.get_children():
		_list.remove_child(c)
		c.queue_free()
	match _page:
		"rules": _page_rules()
		"bots": _page_bots()
		"weapons": _page_weapons()
		"throwables": _page_throwables()
		"loadout": _page_loadout()
		"mods": _page_mods()
		"presets": _page_presets()
	_update_footer()
	_restore_scroll.call_deferred(keep)


func _restore_scroll(v: int) -> void:
	if _scroll != null:
		_scroll.scroll_vertical = v


func _goto(page: String) -> void:
	_page = page
	_edit_slot = -1
	_rebuild()
	_scroll.scroll_vertical = 0


var _problems: Array = []


func _update_footer() -> void:
	_problems = cfg.validate()
	_start.disabled = not _problems.is_empty()
	_fix_btn.visible = not _problems.is_empty()
	_problem_label.text = "" if _problems.is_empty() else str(_problems[0]["text"])


func _on_fix() -> void:
	if _problems.is_empty():
		return
	var page := {"map": "rules", "mode": "rules", "throwables": "throwables", "weapons": "weapons", "bots": "bots", "loadout": "loadout"}
	_goto(str(page.get(str(_problems[0]["fix"]), "rules")))


# A red card listing the problems that belong to this page, with the explicit repair actions.
func _problem_card(fix_kind: String) -> void:
	var mine := _problems.filter(func(p) -> bool: return str(p["fix"]) == fix_kind)
	if mine.is_empty():
		return
	var v := MenuKit.card(_list)
	v.add_child(MenuKit.label("NEEDS ATTENTION", 13, UITheme.ERROR, true))
	for p in mine:
		v.add_child(MenuKit.label(str(p["text"]), 15, UITheme.ERROR))
	match fix_kind:
		"map":
			var first := MapRegistry.all_maps()
			if not first.is_empty():
				var b := MenuKit.button("USE %s" % str(first[0]["name"]).to_upper(), "primary", 46, 15)
				b.pressed.connect(func() -> void:
					cfg.map_id = str(first[0]["id"])
					_changed())
				v.add_child(b)
		"throwables", "loadout":
			var other := _compatible_map()
			if other != "":
				var b := MenuKit.button("SWITCH MAP TO %s" % str(MapRegistry.get_map(other).get("name", other)).to_upper(), "tonal", 46, 15)
				b.pressed.connect(func() -> void:
					cfg.map_id = other
					_changed())
				v.add_child(b)
			if fix_kind == "throwables":
				var r := MenuKit.button("REMOVE UNAVAILABLE THROWABLES", "tonal", 46, 15)
				r.pressed.connect(func() -> void:
					cfg.throw_ids = cfg.throw_ids.filter(func(id) -> bool:
						var d := ThrowableCatalog.get_data(str(id))
						return d != null and ThrowableCatalog.can_spawn_on(d, cfg.map_id))
					_changed())
				v.add_child(r)
			else:
				var e := MenuKit.button("EDIT THIS LOADOUT", "tonal", 46, 15)
				e.pressed.connect(func() -> void:
					_edit_slot = int(cfg.loadout.get("slot", 0))
					_draft = cfg.loadout.duplicate(true)
					_changed())
				v.add_child(e)
		"weapons":
			var r2 := MenuKit.button("REMOVE UNAVAILABLE WEAPONS", "tonal", 46, 15)
			r2.pressed.connect(func() -> void:
				cfg.weapon_ids = cfg.weapon_ids.filter(func(id) -> bool: return WeaponCatalog.get_weapon(str(id)) != null)
				_changed())
			v.add_child(r2)
		"bots":
			var r3 := MenuKit.button("SET BOTS TO %d" % cfg.max_bots(), "tonal", 46, 15)
			r3.pressed.connect(func() -> void:
				cfg.bot_count = cfg.max_bots()
				_changed())
			v.add_child(r3)


# First map where every selected throwable / loadout throwable can spawn ("" if none).
func _compatible_map() -> String:
	for m in MapRegistry.all_maps():
		var ok := true
		var ids: Array = []
		if cfg.throw_mode == "custom":
			ids.append_array(cfg.throw_ids)
		if cfg.use_loadouts:
			for k in ["t1", "t2"]:
				if str(cfg.loadout.get(k, "")) != "":
					ids.append(str(cfg.loadout.get(k)))
		for id in ids:
			var d := ThrowableCatalog.get_data(str(id))
			if d == null or not ThrowableCatalog.can_spawn_on(d, str(m["id"])):
				ok = false
		if ok:
			return str(m["id"])
	return ""


# ------------------------------------------------------------------ RULES
func _page_rules() -> void:
	_problem_card("map")
	_problem_card("mode")
	var mode_card := MenuKit.card(_list)
	mode_card.add_child(MenuKit.label(str(SCORING_TEXT.get(cfg.mode, "")), 14, UITheme.ON_VARIANT))

	MenuKit.section(_list, "Map and mode")
	var maps := MapRegistry.all_maps()
	var names: Array = []
	var idx := 0
	for i in maps.size():
		names.append(str(maps[i]["name"]))
		if str(maps[i]["id"]) == cfg.map_id:
			idx = i
	MenuKit.choice_row(_list, "Map", names, idx, func(i: int) -> void:
		cfg.map_id = str(maps[i]["id"])
		_changed())
	var info := MapRegistry.get_map(cfg.map_id)
	if not info.is_empty():
		MenuKit.hint(_list, str(info.get("description", "")))
	var mode_names: Array = []
	for m in MatchConfig.MODES:
		mode_names.append(str(MatchConfig.MODE_NAMES[m]))
	MenuKit.choice_row(_list, "Mode", mode_names, MatchConfig.MODES.find(cfg.mode), func(i: int) -> void:
		cfg.mode = str(MatchConfig.MODES[i])
		_changed())

	MenuKit.section(_list, "Win conditions")
	var dur: Array = []
	for d in MatchConfig.DURATIONS:
		dur.append(MenuKit.fmt_minutes(int(d)))
	MenuKit.choice_row(_list, "Time limit", dur, MatchConfig.DURATIONS.find(cfg.duration_min), func(i: int) -> void:
		cfg.duration_min = int(MatchConfig.DURATIONS[i])
		_changed())
	var kl: Array = []
	for k in MatchConfig.KILL_LIMITS:
		kl.append(MenuKit.fmt_kills(int(k)))
	MenuKit.choice_row(_list, "Kill limit", kl, MatchConfig.KILL_LIMITS.find(cfg.kill_limit), func(i: int) -> void:
		cfg.kill_limit = int(MatchConfig.KILL_LIMITS[i])
		_changed())
	MenuKit.hint(_list, "The match ends when EITHER limit is reached. With both on No limit / Unlimited it runs until you restart or quit. Scoring and records still work without a time limit.")
	if cfg.mode == "survival":
		MenuKit.choice_row(_list, "Lives", MatchConfig.LIVES.map(func(n) -> String: return str(n)), MatchConfig.LIVES.find(cfg.lives), func(i: int) -> void:
			cfg.lives = int(MatchConfig.LIVES[i])
			_changed())

	MenuKit.section(_list, "Player")
	MenuKit.choice_row(_list, "Starting health", MatchConfig.HEALTHS.map(func(n) -> String: return str(n)), MatchConfig.HEALTHS.find(cfg.start_health), func(i: int) -> void:
		cfg.start_health = int(MatchConfig.HEALTHS[i])
		_changed())
	MenuKit.toggle_row(_list, "Health regeneration", cfg.health_regen, func(v: bool) -> void:
		cfg.health_regen = v
		_changed())
	if cfg.mode == "survival":
		MenuKit.hint(_list, "Survival uses lives instead of the respawn switch. Respawn delay below still applies.")
	else:
		MenuKit.toggle_row(_list, "Player respawn", cfg.player_respawn, func(v: bool) -> void:
			cfg.player_respawn = v
			_changed())
		if not cfg.player_respawn:
			MenuKit.hint(_list, "With respawn off you stay down after dying. The match keeps going until its limits are reached; it does not end just because you are out.")
	if cfg.mode == "survival" or cfg.player_respawn:
		MenuKit.choice_row(_list, "Respawn delay", MatchConfig.RESPAWN_DELAYS.map(func(n) -> String: return MenuKit.fmt_seconds(float(n))), MatchConfig.RESPAWN_DELAYS.find(cfg.player_respawn_delay), func(i: int) -> void:
			cfg.player_respawn_delay = float(MatchConfig.RESPAWN_DELAYS[i])
			_changed())
	if bool(info.get("oob", false)):
		MenuKit.toggle_row(_list, "Out-of-bounds damage", cfg.oob_damage, func(v: bool) -> void:
			cfg.oob_damage = v
			_changed())
		MenuKit.hint(_list, "Flying past the edge of this map drains health and finally kills. Turn it off to roam freely.")
	else:
		MenuKit.hint(_list, "%s has no out-of-bounds zone, so there is nothing to switch." % str(info.get("name", "This map")))


# ------------------------------------------------------------------ BOTS
func _page_bots() -> void:
	_problem_card("bots")
	MenuKit.section(_list, "Bots")
	var counts: Array = MatchConfig.BOT_COUNTS.filter(func(n) -> bool: return int(n) <= cfg.max_bots())
	var ci := counts.find(cfg.bot_count)
	if ci < 0:
		ci = counts.size() - 1
	MenuKit.choice_row(_list, "Bot count", counts.map(func(n) -> String: return str(n)), ci, func(i: int) -> void:
		cfg.bot_count = int(counts[i])
		_changed())
	if UITheme.is_mobile():
		MenuKit.hint(_list, "Limited to %d on phones to keep the game smooth." % cfg.max_bots())
	MenuKit.choice_row(_list, "Difficulty", BotDifficulty.NAMES, cfg.bot_difficulty, func(i: int) -> void:
		cfg.bot_difficulty = i
		_changed())
	MenuKit.hint(_list, str(BotDifficulty.DESCRIPTIONS[clampi(cfg.bot_difficulty, 0, 3)]))
	MenuKit.hint(_list, "This only applies to this match. Your saved bot difficulty setting is not changed.")
	MenuKit.section(_list, "Respawning")
	MenuKit.toggle_row(_list, "Bot respawn", cfg.bot_respawn, func(v: bool) -> void:
		cfg.bot_respawn = v
		_changed())
	if cfg.bot_respawn:
		var delays := [1.0, 2.0, 3.0, 5.0, 8.0]
		MenuKit.choice_row(_list, "Bot respawn delay", delays.map(func(n) -> String: return MenuKit.fmt_seconds(float(n))), maxi(delays.find(cfg.bot_respawn_delay), 0), func(i: int) -> void:
			cfg.bot_respawn_delay = float(delays[i])
			_changed())
	else:
		MenuKit.hint(_list, "Defeated bots stay down. When every bot is down you win (Training never ends).")
	MenuKit.section(_list, "Bot equipment")
	MenuKit.toggle_row(_list, "Bots use throwables", cfg.bot_throwables, func(v: bool) -> void:
		cfg.bot_throwables = v
		_changed())
	MenuKit.hint(_list, "Bots keep their normal guns and bombs for their difficulty (Rookie and Normal never carry bombs; Veteran and Legend do).")


# ------------------------------------------------------------------ WEAPONS
func _page_weapons() -> void:
	_problem_card("weapons")
	MenuKit.section(_list, "Weapon pickups")
	MenuKit.choice_row(_list, "Spawn rate", MatchConfig.RATE_NAMES, cfg.weapon_rate, func(i: int) -> void:
		cfg.weapon_rate = i
		_changed())
	MenuKit.choice_row(_list, "Max on the map", MatchConfig.WEAPON_MAX.map(func(n) -> String: return "All spots" if int(n) == 0 else str(n)), MatchConfig.WEAPON_MAX.find(cfg.weapon_max), func(i: int) -> void:
		cfg.weapon_max = int(MatchConfig.WEAPON_MAX[i])
		_changed())
	MenuKit.hint(_list, "Spawn rate is how fast a taken or expired gun comes back. Max is how many can lie on the map at once. A map has a fixed number of weapon spots, so a bigger max just uses them all. Dropped guns and the timed disappearance work as usual.")
	MenuKit.section(_list, "Which weapons can spawn")
	var forced := cfg.is_mod("all_weapons")
	if forced:
		MenuKit.hint(_list, "The \"All Compatible Weapons Available\" modifier forces ALL.", UITheme.WARM)
	MenuKit.segmented(_list, ["ALL", "NONE", "CUSTOM"], MatchConfig.WEAPON_MODES.find(cfg.weapon_mode), _set_weapon_mode)
	var eff := cfg.effective_weapon_ids()
	MenuKit.hint(_list, "%d of %d weapons can spawn. Tap any weapon to pick your own set (it switches to CUSTOM). Your CUSTOM choices are kept while you use ALL or NONE." % [eff.size(), WeaponCatalog.PATHS.size()])
	if cfg.weapon_mode == "none" and not forced:
		MenuKit.hint(_list, "No weapon pickups will spawn. Loadout weapons (if enabled) still work.", UITheme.WARM)
	# grouped by the weapon's own category; new weapons in the catalog show up here by themselves
	var cats := {}
	for id in WeaponCatalog.PATHS:
		var w := WeaponCatalog.get_weapon(str(id))
		if w == null:
			continue
		if not cats.has(w.category):
			cats[w.category] = []
		cats[w.category].append(str(id))
	for cat in cats:
		var row := HBoxContainer.new()
		_list.add_child(row)
		var l := MenuKit.label(str(cat).to_upper(), 13, UITheme.PRIMARY, true)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(l)
		var all_b := MenuKit.button("ALL", "tonal", 36, 13)
		all_b.size_flags_horizontal = Control.SIZE_SHRINK_END
		all_b.custom_minimum_size = Vector2(64, 36)
		all_b.disabled = forced
		all_b.pressed.connect(_set_weapon_category.bind(cats[cat], true))
		row.add_child(all_b)
		var none_b := MenuKit.button("NONE", "tonal", 36, 13)
		none_b.size_flags_horizontal = Control.SIZE_SHRINK_END
		none_b.custom_minimum_size = Vector2(72, 36)
		none_b.disabled = forced
		none_b.pressed.connect(_set_weapon_category.bind(cats[cat], false))
		row.add_child(none_b)
		var grid := GridContainer.new()
		grid.columns = 2
		grid.add_theme_constant_override("h_separation", 6)
		grid.add_theme_constant_override("v_separation", 6)
		grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_list.add_child(grid)
		for id in cats[cat]:
			var w2 := WeaponCatalog.get_weapon(id)
			var on := eff.has(id)
			var b := MenuKit.button(w2.full_name(), "primary" if on else "tonal", 44, 14)
			b.disabled = forced
			b.pressed.connect(_toggle_weapon.bind(id))
			grid.add_child(b)


func _set_weapon_mode(i: int) -> void:
	var m := str(MatchConfig.WEAPON_MODES[i])
	if m == "custom" and cfg.weapon_ids.is_empty() and cfg.weapon_mode == "all":
		cfg.weapon_ids = WeaponCatalog.PATHS.keys()             # start from everything, then deselect what you don't want
	cfg.weapon_mode = m                                         # weapon_ids is kept untouched for ALL / NONE
	_changed()


func _toggle_weapon(id: String) -> void:
	var cur := cfg.effective_weapon_ids()
	if cur.has(id):
		cur.erase(id)
	else:
		cur.append(id)
	cfg.weapon_ids = cur
	cfg.weapon_mode = "custom"
	_changed()


func _set_weapon_category(ids: Array, on: bool) -> void:
	var cur := cfg.effective_weapon_ids()
	for id in ids:
		if on and not cur.has(id):
			cur.append(id)
		elif not on:
			cur.erase(id)
	cfg.weapon_ids = cur
	cfg.weapon_mode = "custom"
	_changed()


# ------------------------------------------------------------------ THROWABLES
func _page_throwables() -> void:
	_problem_card("throwables")
	MenuKit.section(_list, "Throwable pickups")
	MenuKit.choice_row(_list, "Spawn rate", MatchConfig.RATE_NAMES, cfg.throw_rate, func(i: int) -> void:
		cfg.throw_rate = i
		_changed())
	MenuKit.choice_row(_list, "Max on the map", MatchConfig.THROW_MAX.map(func(n) -> String: return "Map default" if int(n) == 0 else str(n)), MatchConfig.THROW_MAX.find(cfg.throw_max), func(i: int) -> void:
		cfg.throw_max = int(MatchConfig.THROW_MAX[i])
		_changed())
	MenuKit.hint(_list, "Spawn rate is how often a new one appears. Max is how many can lie around at once. They are separate.")
	MenuKit.section(_list, "Which throwables can spawn")
	var forced := cfg.is_mod("all_throwables")
	if forced:
		MenuKit.hint(_list, "The \"All Compatible Throwables Available\" modifier forces ALL.", UITheme.WARM)
	var base := ["all", "none", "custom"]
	MenuKit.segmented(_list, ["ALL", "NONE", "CUSTOM"], base.find(cfg.throw_mode), _set_throw_mode)
	var sub := ["grenades", "explosives", "tactical"]
	MenuKit.segmented(_list, ["GRENADES", "EXPLOSIVES", "TACTICAL"], sub.find(cfg.throw_mode), _set_throw_mode_sub)
	MenuKit.hint(_list, "GRENADES = the standard grenade only. EXPLOSIVES = blasts and damage zones (Grenade, Knockback Bomb, Trap Mine, Incendiary, Toxic). TACTICAL = utility with no direct damage (Smoke, Decoy, EMP, Gravity, Flight Disruptor, Cryo, Portal). Tap a throwable to override any of these.")
	var eff := cfg.effective_throwable_ids()
	var info := MapRegistry.get_map(cfg.map_id)
	var map_name := str(info.get("name", cfg.map_id))
	MenuKit.hint(_list, "%d throwable types can spawn on %s with this selection." % [eff.size(), map_name])
	if eff.is_empty() and not forced:
		MenuKit.hint(_list, "No throwable pickups will spawn.", UITheme.WARM)
	for cat in ["explosive", "hazard", "tactical"]:
		MenuKit.section(_list, str(ThrowableCatalog.CATEGORY_NAMES[cat]))
		var grid := GridContainer.new()
		grid.columns = 2
		grid.add_theme_constant_override("h_separation", 6)
		grid.add_theme_constant_override("v_separation", 6)
		grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_list.add_child(grid)
		for id in ThrowableCatalog.IDS:
			if ThrowableCatalog.category_of(id) != cat:
				continue
			var d := ThrowableCatalog.get_data(id)
			if d == null:
				continue
			var compatible := ThrowableCatalog.can_spawn_on(d, cfg.map_id)
			var on := eff.has(id) if compatible else (cfg.throw_mode == "custom" and cfg.throw_ids.has(id))
			var text := d.display_name if compatible else "%s (not on %s)" % [d.display_name, map_name]
			var b := MenuKit.button(text, "primary" if on else "tonal", 44, 13)
			b.disabled = forced or not compatible
			b.pressed.connect(_toggle_throwable.bind(id))
			grid.add_child(b)


func _set_throw_mode(i: int) -> void:
	var m := str(["all", "none", "custom"][i])
	if m == "custom" and cfg.throw_ids.is_empty() and cfg.throw_mode == "all":
		cfg.throw_ids = cfg.effective_throwable_ids()
	cfg.throw_mode = m
	_changed()


func _set_throw_mode_sub(i: int) -> void:
	cfg.throw_mode = str(["grenades", "explosives", "tactical"][i])
	_changed()


func _toggle_throwable(id: String) -> void:
	var cur := cfg.effective_throwable_ids()
	if cur.has(id):
		cur.erase(id)
	else:
		cur.append(id)
	cfg.throw_ids = cur
	cfg.throw_mode = "custom"
	_changed()


# ------------------------------------------------------------------ LOADOUT
func _loadout_summary(lo: Dictionary) -> String:
	var parts: PackedStringArray = []
	for k in ["primary", "secondary"]:
		var w := WeaponCatalog.get_weapon(str(lo.get(k, "")))
		parts.append(w.full_name() if w != null else "?")
	for k in ["t1", "t2"]:
		var t := ThrowableCatalog.get_data(str(lo.get(k, "")))
		if t != null:
			parts.append("%s x%d" % [t.display_name, int(lo.get(k + "_qty", 1))])
	return "  /  ".join(parts)


func _page_loadout() -> void:
	if _edit_slot >= 0:
		_page_loadout_edit()
		return
	_problem_card("loadout")
	MenuKit.section(_list, "Loadouts")
	MenuKit.toggle_row(_list, "Use loadouts", cfg.use_loadouts, func(v: bool) -> void:
		cfg.use_loadouts = v
		if v and cfg.loadout.is_empty():
			var first := MatchStore.load_loadouts()
			for i in first.size():
				if not (first[i] as Dictionary).is_empty():
					cfg.loadout = (first[i] as Dictionary).duplicate(true)
					cfg.loadout["slot"] = i
					break
		_changed())
	MenuKit.hint(_list, "OFF: you start with the normal equipment. ON: you start with the loadout you pick here. Either way you can still collect guns and throwables from the map (unless you turned those pickups off). Bots keep their own equipment.")
	if not cfg.use_loadouts:
		return
	var slots := MatchStore.load_loadouts()
	var selected := int(cfg.loadout.get("slot", -1))
	for i in slots.size():
		var lo: Dictionary = slots[i]
		var v := MenuKit.card(_list)
		if lo.is_empty():
			v.add_child(MenuKit.label("Slot %d   -   empty" % (i + 1), 16, UITheme.ON_VARIANT, true))
			var create := MenuKit.button("CREATE", "tonal", 44, 15)
			create.pressed.connect(_edit_loadout.bind(i, true))
			v.add_child(create)
			continue
		v.add_child(MenuKit.label("%d.  %s" % [i + 1, str(lo.get("name", "Loadout"))], 17, UITheme.ON_SURFACE, true))
		v.add_child(MenuKit.label(_loadout_summary(lo), 14, UITheme.ON_VARIANT))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 6)
		v.add_child(row)
		var sel := MenuKit.button("SELECTED" if i == selected else "SELECT", "primary" if i == selected else "tonal", 42, 14)
		sel.pressed.connect(_select_loadout.bind(i))
		row.add_child(sel)
		var edit := MenuKit.button("EDIT", "tonal", 42, 14)
		edit.pressed.connect(_edit_loadout.bind(i, false))
		row.add_child(edit)
		var del := MenuKit.button("DELETE", "danger", 42, 14)
		del.pressed.connect(_delete_loadout.bind(i))
		row.add_child(del)


func _select_loadout(slot: int) -> void:
	var lo: Dictionary = MatchStore.load_loadouts()[slot]
	cfg.loadout = lo.duplicate(true)
	cfg.loadout["slot"] = slot
	_changed()


func _edit_loadout(slot: int, create: bool) -> void:
	_edit_slot = slot
	if create:
		_draft = MatchStore.make_loadout("Loadout %d" % (slot + 1), "ak47", "glock", "grenade", 2, "", 0)
	else:
		_draft = (MatchStore.load_loadouts()[slot] as Dictionary).duplicate(true)
	_changed()


func _delete_loadout(slot: int) -> void:
	var nm := str((MatchStore.load_loadouts()[slot] as Dictionary).get("name", "this loadout"))
	_confirm("Delete \"%s\"?" % nm, func() -> void:
		MatchStore.delete_loadout(slot)
		if int(cfg.loadout.get("slot", -1)) == slot:
			cfg.loadout = {}                                   # the selected one is gone: nothing is substituted silently
		_changed())


func _page_loadout_edit() -> void:
	MenuKit.section(_list, "Edit loadout %d" % (_edit_slot + 1))
	var name_row := HBoxContainer.new()
	_list.add_child(name_row)
	var nl := MenuKit.label("Name", 17)
	nl.custom_minimum_size = Vector2(90, 0)
	name_row.add_child(nl)
	var le := LineEdit.new()
	le.text = str(_draft.get("name", ""))
	le.max_length = 20
	le.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	le.custom_minimum_size = Vector2(160, 46)
	le.text_changed.connect(func(t: String) -> void: _draft["name"] = t)
	name_row.add_child(le)

	var wids: Array = WeaponCatalog.PATHS.keys()
	var wnames: Array = wids.map(func(id) -> String: return WeaponCatalog.get_weapon(str(id)).full_name())
	MenuKit.choice_row(_list, "Primary", wnames, maxi(wids.find(str(_draft.get("primary", ""))), 0), func(i: int) -> void:
		_draft["primary"] = str(wids[i])
		_changed())
	MenuKit.choice_row(_list, "Secondary", wnames, maxi(wids.find(str(_draft.get("secondary", ""))), 0), func(i: int) -> void:
		_draft["secondary"] = str(wids[i])
		_changed())
	if str(_draft.get("primary", "")) == str(_draft.get("secondary", "")):
		MenuKit.hint(_list, "Primary and secondary must be different weapons.", UITheme.ERROR)
	var p := WeaponCatalog.get_weapon(str(_draft.get("primary", "")))
	if p != null and p.one_handed:
		MenuKit.hint(_list, "%s is one-handed: press the dual-wield key in a match to use it with another one-handed gun." % p.full_name())

	var tids: Array = [""]
	tids.append_array(ThrowableCatalog.IDS)
	var tnames: Array = tids.map(func(id) -> String:
		if str(id) == "":
			return "None"
		var d := ThrowableCatalog.get_data(str(id))
		return d.display_name if d != null else str(id))
	var map_name := str(MapRegistry.get_map(cfg.map_id).get("name", cfg.map_id))
	for k in ["t1", "t2"]:
		var slot_label := "Throwable 1" if k == "t1" else "Throwable 2"
		MenuKit.choice_row(_list, slot_label, tnames, maxi(tids.find(str(_draft.get(k, ""))), 0), func(i: int) -> void:
			_draft[k] = str(tids[i])
			if str(tids[i]) != "" and int(_draft.get(k + "_qty", 0)) <= 0:
				_draft[k + "_qty"] = 1
			_changed())
		var d2 := ThrowableCatalog.get_data(str(_draft.get(k, "")))
		if d2 != null:
			var maxq := maxi(d2.max_count, 1)
			var qopts: Array = []
			for q in range(1, maxq + 1):
				qopts.append(str(q))
			MenuKit.choice_row(_list, "   Quantity", qopts, clampi(int(_draft.get(k + "_qty", 1)) - 1, 0, maxq - 1), func(i: int) -> void:
				_draft[k + "_qty"] = i + 1
				_changed())
			if not ThrowableCatalog.can_spawn_on(d2, cfg.map_id):
				MenuKit.hint(_list, "%s is not available on %s. You can still save it, but you will need another map or throwable to start." % [d2.display_name, map_name], UITheme.WARM)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	_list.add_child(row)
	var save := MenuKit.button("SAVE", "primary", 50, 17)
	save.pressed.connect(_save_draft)
	row.add_child(save)
	var cancel := MenuKit.button("CANCEL", "tonal", 50, 17)
	cancel.pressed.connect(func() -> void:
		_edit_slot = -1
		_changed())
	row.add_child(cancel)


func _save_draft() -> void:
	var nm := str(_draft.get("name", "")).strip_edges()
	if nm == "":
		_say("Give the loadout a name.")
		return
	if str(_draft.get("primary", "")) == str(_draft.get("secondary", "")):
		_say("Pick two different weapons.")
		return
	_draft["name"] = nm
	_draft.erase("slot")
	if not MatchStore.save_loadout(_edit_slot, _draft):
		_say("Could not save to this device.")
		return
	if int(cfg.loadout.get("slot", -1)) == _edit_slot:        # keep the selected copy in step with the edit
		cfg.loadout = _draft.duplicate(true)
		cfg.loadout["slot"] = _edit_slot
	_edit_slot = -1
	_say("Loadout saved")
	_changed()


# ------------------------------------------------------------------ MODIFIERS
func _page_mods() -> void:
	var warn := MenuKit.card(_list)
	warn.add_child(MenuKit.label("CUSTOM / EXPERIMENTAL RULES", 13, UITheme.WARM, true))
	warn.add_child(MenuKit.label("These only affect the match you start from this screen and never carry into another one. Any modifier moves the result to the Custom records, so it can't replace a normal Survival or Deathmatch record.", 14, UITheme.ON_VARIANT))
	MenuKit.section(_list, "Master switch")
	MenuKit.toggle_row(_list, "UNLIMITED MODE", cfg.unlimited_mode, func(v: bool) -> void:
		cfg.set_unlimited_mode(v)
		_changed())
	MenuKit.hint(_list, "Turns on Unlimited Ammo, Infinite Grenades, Infinite Jetpack Fuel and No Weapon Reload together. Infinite Health is NOT included. You can still switch each one off on its own.")
	MenuKit.section(_list, "Individual modifiers")
	for id in MatchConfig.MODIFIERS:
		MenuKit.toggle_row(_list, str(MatchConfig.MODIFIERS[id]), cfg.is_mod(id), func(v: bool) -> void:
			cfg.set_mod(id, v)
			_changed())
		MenuKit.hint(_list, str(MatchConfig.MODIFIER_HINTS.get(id, "")))


# ------------------------------------------------------------------ PRESETS
func _preset_blurb(c: MatchConfig) -> String:
	return "%s  ·  %s  ·  %s bots (%s)" % [MenuKit.fmt_minutes(c.duration_min), ("%s kills" % MenuKit.fmt_kills(c.kill_limit)),
		c.bot_count, BotDifficulty.NAMES[clampi(c.bot_difficulty, 0, 3)]]


func _page_presets() -> void:
	MenuKit.section(_list, "Your presets")
	var save := MenuKit.button("SAVE CURRENT SETTINGS AS NEW PRESET", "primary", 50, 15)
	save.pressed.connect(func() -> void:
		_prompt_name("Name this preset", "", func(nm: String) -> String:
			if MatchStore.preset_exists(nm):
				return "A preset with that name exists. Use UPDATE on it instead."
			var err := MatchStore.save_preset(cfg, nm)
			if err == "":
				cfg.preset_name = nm.strip_edges().left(24)
				_say("Preset saved")
			return err))
	_list.add_child(save)
	var saved := MatchStore.list_presets()
	if saved.is_empty():
		MenuKit.hint(_list, "No saved presets yet.")
	for e in saved:
		var nm := str(e["name"])
		var v := MenuKit.card(_list)
		v.add_child(MenuKit.label(nm, 17, UITheme.ON_SURFACE, true))
		v.add_child(MenuKit.label(_preset_blurb(MatchConfig.from_dict(e)), 13, UITheme.ON_VARIANT))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 6)
		v.add_child(row)
		var load_b := MenuKit.button("LOAD", "primary", 42, 14)
		load_b.pressed.connect(_load_saved.bind(e))
		row.add_child(load_b)
		var upd := MenuKit.button("UPDATE", "tonal", 42, 14)
		upd.pressed.connect(_update_preset.bind(nm))
		row.add_child(upd)
		var ren := MenuKit.button("RENAME", "tonal", 42, 14)
		ren.pressed.connect(_rename_preset.bind(nm))
		row.add_child(ren)
		var del := MenuKit.button("DELETE", "danger", 42, 14)
		del.pressed.connect(_delete_preset.bind(nm))
		row.add_child(del)
	MenuKit.section(_list, "Built-in presets")
	MenuKit.hint(_list, "Starting points. Load one, then change anything you like before you start.")
	for nm in MatchPresets.NAMES:
		var bc := MatchPresets.get_builtin(str(nm))
		var v2 := MenuKit.card(_list)
		v2.add_child(MenuKit.label(str(nm), 17, UITheme.ON_SURFACE, true))
		v2.add_child(MenuKit.label(_preset_blurb(bc), 13, UITheme.ON_VARIANT))
		var b := MenuKit.button("LOAD", "tonal", 42, 14)
		b.pressed.connect(_load_builtin.bind(str(nm)))
		v2.add_child(b)


func _load_saved(d: Dictionary) -> void:
	cfg = MatchConfig.from_dict(d)                       # only the setup changes; nothing is saved, nothing starts
	var probs := cfg.validate()
	_say("Loaded %s" % cfg.preset_name if probs.is_empty() else "Loaded with %d problem(s) to fix" % probs.size())
	if not probs.is_empty():
		_goto(str({"map": "rules", "mode": "rules", "throwables": "throwables", "weapons": "weapons", "bots": "bots", "loadout": "loadout"}.get(str(probs[0]["fix"]), "rules")))
	else:
		_changed()


func _load_builtin(nm: String) -> void:
	cfg = MatchPresets.get_builtin(nm)
	var probs := cfg.validate()
	_say("Loaded %s" % nm if probs.is_empty() else "%s: %s" % [nm, str(probs[0]["text"])])
	if probs.is_empty():
		_changed()
	else:
		_goto("throwables" if str(probs[0]["fix"]) == "throwables" else "rules")


func _update_preset(nm: String) -> void:
	_confirm("Overwrite \"%s\" with the current settings?" % nm, func() -> void:
		var err := MatchStore.save_preset(cfg, nm)
		_say("Preset updated" if err == "" else err)
		_changed())


func _rename_preset(nm: String) -> void:
	_prompt_name("Rename preset", nm, func(new_name: String) -> String:
		var err := MatchStore.rename_preset(nm, new_name)
		if err == "":
			if cfg.preset_name.to_lower() == nm.to_lower():
				cfg.preset_name = new_name.strip_edges().left(24)
			_say("Renamed")
		return err)


func _delete_preset(nm: String) -> void:
	_confirm("Delete preset \"%s\"?" % nm, func() -> void:
		MatchStore.delete_preset(nm)
		if cfg.preset_name.to_lower() == nm.to_lower():
			cfg.preset_name = ""
		_changed())


# ------------------------------------------------------------------ modal prompts
func _close_overlay() -> void:
	if _overlay != null:
		_overlay.queue_free()
		_overlay = null


func _modal(width := 360.0) -> VBoxContainer:
	_close_overlay()
	var root := ColorRect.new()
	root.color = Color(0, 0, 0, 0.6)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(root)
	_overlay = root
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UITheme.panel_box(22, 18))
	panel.custom_minimum_size = Vector2(width, 0)
	center.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	panel.add_child(v)
	UITheme.pop_in(panel)
	return v


func _confirm(text: String, on_yes: Callable) -> void:
	var v := _modal()
	v.add_child(MenuKit.label(text, 18, UITheme.ON_SURFACE, true))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	v.add_child(row)
	var yes := MenuKit.button("YES", "danger", 48, 16)
	yes.pressed.connect(func() -> void:
		_close_overlay()
		on_yes.call())
	row.add_child(yes)
	var no := MenuKit.button("CANCEL", "tonal", 48, 16)
	no.pressed.connect(_close_overlay)
	row.add_child(no)


# on_ok(name) returns "" to accept or an error message to show (the prompt stays open).
func _prompt_name(title: String, initial: String, on_ok: Callable) -> void:
	var v := _modal()
	v.add_child(MenuKit.label(title, 18, UITheme.ON_SURFACE, true))
	var le := LineEdit.new()
	le.text = initial
	le.max_length = 24
	le.placeholder_text = "Preset name"
	le.custom_minimum_size = Vector2(0, 48)
	v.add_child(le)
	var err := MenuKit.label("", 14, UITheme.ERROR)
	v.add_child(err)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	v.add_child(row)
	var ok := MenuKit.button("OK", "primary", 48, 16)
	var submit := func() -> void:
		var msg: String = on_ok.call(le.text)
		if msg == "":
			_close_overlay()
			_changed()
		else:
			err.text = msg
	ok.pressed.connect(submit)
	le.text_submitted.connect(func(_t: String) -> void: submit.call())
	row.add_child(ok)
	var cancel := MenuKit.button("CANCEL", "tonal", 48, 16)
	cancel.pressed.connect(_close_overlay)
	row.add_child(cancel)
	le.grab_focus.call_deferred()
