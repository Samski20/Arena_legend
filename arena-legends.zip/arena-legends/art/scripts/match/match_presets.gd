class_name MatchPresets
extends RefCounted
## Built-in starting points. They are ordinary MatchConfig objects (not special game modes) and the player can
## change anything after picking one. Saved presets live in MatchStore.

const NAMES := ["Classic", "Quick Match", "Long Battle", "Weapon Frenzy", "Grenade Mayhem", "Portal Chaos",
	"Tactical Combat", "Unlimited Fun", "Sniper Battle", "Heavy Weapons"]


static func is_builtin_name(name: String) -> bool:
	for n in NAMES:
		if str(n).to_lower() == name.strip_edges().to_lower():
			return true
	return false


static func starter_loadouts() -> Array:
	return [
		MatchStore.make_loadout("Assault", "m4a1", "glock", "grenade", 2, "smoke", 1),
		MatchStore.make_loadout("Heavy Weapons", "rpg7", "spas12", "grenade", 2, "knockback", 2),
		MatchStore.make_loadout("Tactical", "mp5", "desert_eagle", "smoke", 2, "decoy", 1),
		MatchStore.make_loadout("Long Range", "svd_dragunov", "colt_python", "grenade", 1, "smoke", 1),
		MatchStore.make_loadout("Close Quarters", "spas12", "uzi", "grenade", 2, "incendiary", 1),
	]


static func get_builtin(name: String) -> MatchConfig:
	var c := MatchConfig.for_mode("deathmatch")
	c.preset_name = name
	match name:
		"Classic":
			pass                                                   # the original game: 3 bots, first to 10, normal spawns
		"Quick Match":
			c.duration_min = 2
			c.kill_limit = 10
			c.bot_difficulty = 1
			c.bot_count = 3
		"Long Battle":
			c.duration_min = 20
			c.kill_limit = 50
			c.bot_count = 5
			c.bot_difficulty = 2
		"Weapon Frenzy":
			c.duration_min = 5
			c.kill_limit = 20
			c.weapon_rate = 4
			c.throw_rate = 1
		"Grenade Mayhem":
			c.duration_min = 5
			c.kill_limit = 20
			c.throw_rate = 4
			c.throw_max = 0
			c.weapon_rate = 1
			c.throw_mode = "explosives"
		"Portal Chaos":
			c.map_id = "abandoned_station"                         # Portal only exists on maps that list it (see ThrowableCatalog)
			c.duration_min = 5
			c.kill_limit = 20
			c.throw_mode = "custom"
			c.throw_ids = ["portal"]
			c.throw_rate = 3
		"Tactical Combat":
			c.duration_min = 10
			c.kill_limit = 20
			c.bot_difficulty = 2
			c.throw_mode = "tactical"
			c.throw_rate = 3
		"Unlimited Fun":
			c.duration_min = 0
			c.kill_limit = 0
			c.set_unlimited_mode(true)
		"Sniper Battle":
			c.duration_min = 10
			c.kill_limit = 15
			c.bot_count = 3
			c.weapon_mode = "custom"
			c.weapon_ids = ["barrett_m82", "svd_dragunov"]
			c.weapon_rate = 3
			c.throw_mode = "none"
			c.throw_rate = 0
		"Heavy Weapons":
			c.duration_min = 10
			c.kill_limit = 15
			c.weapon_mode = "custom"
			c.weapon_ids = ["rpg7", "m249", "spas12", "double_barrel"]
			c.weapon_rate = 3
	c.mode = "deathmatch" if name in ["Classic", "Quick Match", "Long Battle"] else "custom"
	return c
