class_name MenuScroll
extends ScrollContainer
## ScrollContainer that works with a finger. The project turns emulate_mouse_from_touch off and almost every row
## is a button, so Godot's own touch scrolling never starts. Same method as the Settings and LAN menus:
## any finger that lands in the list can drag it, a drag does not also press the button it started on,
## and there is a little momentum after letting go. A plain tap on a text box focuses it (phone keyboard).

const DRAG_THRESHOLD := 12.0
var _touch_id := -1
var _travel := 0.0
var _scrolling := false
var _frac := 0.0
var _inertia := 0.0
var _cancelled: Array = []


func _ready() -> void:
	horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll_deadzone = 100000                  # switch Godot's own (unreliable) touch drag off


func _input(event: InputEvent) -> void:
	if not is_visible_in_tree():
		return
	if event is InputEventScreenTouch:
		var te := event as InputEventScreenTouch
		if te.pressed:
			if _touch_id == -1 and get_global_rect().has_point(te.position):
				_touch_id = te.index
				_travel = 0.0
				_scrolling = false
				_inertia = 0.0
				_frac = 0.0
		elif te.index == _touch_id:
			_touch_id = -1
			if not _scrolling:
				_inertia = 0.0
				_tap_text_fields(te.position)
	elif event is InputEventScreenDrag:
		var de := event as InputEventScreenDrag
		if de.index != _touch_id:
			return
		_travel += absf(de.relative.y)
		if not _scrolling and _travel >= DRAG_THRESHOLD:
			_scrolling = true
			_cancel_pressed_buttons()
		if _scrolling:
			_scroll_by(-de.relative.y)
			_inertia = -de.velocity.y
			get_viewport().set_input_as_handled()


func _tap_text_fields(pos: Vector2) -> void:
	var hit: LineEdit = null
	for n in find_children("*", "LineEdit", true, false):
		var le := n as LineEdit
		if le != null and le.is_visible_in_tree() and le.editable and le.get_global_rect().has_point(pos):
			hit = le
			break
	var focused := get_viewport().gui_get_focus_owner()
	if hit != null:
		hit.grab_focus()
		hit.edit()
	elif focused is LineEdit:
		focused.release_focus()


func _cancel_pressed_buttons() -> void:
	for n in find_children("*", "BaseButton", true, false):
		var b := n as BaseButton
		if b != null and not b.disabled and b.get_draw_mode() == BaseButton.DRAW_PRESSED:
			b.disabled = true                    # disabling a held button cancels the press
			_cancelled.append(b)


func _process(delta: float) -> void:
	if not _cancelled.is_empty():
		for b in _cancelled:
			if is_instance_valid(b):
				b.disabled = false
		_cancelled.clear()
	if _touch_id != -1 or absf(_inertia) < 25.0:
		return
	var before := scroll_vertical
	_scroll_by(_inertia * delta)
	if scroll_vertical == before:
		_inertia = 0.0
	else:
		_inertia *= exp(-5.0 * delta)


func _scroll_by(px: float) -> void:
	_frac += px
	var whole := int(_frac)
	_frac -= float(whole)
	if whole != 0:
		scroll_vertical += whole
