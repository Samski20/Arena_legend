class_name MatchSession
extends RefCounted
## The match that is running right now (offline only) and the one place that turns a MatchConfig into real
## gameplay: it filters the pickup spawners, sets up bots, applies the player's rules and loadout, and answers
## the small rule questions the gameplay scripts ask (MatchSession.mod("infinite_health") ...).
## When `active` is false (menus, LAN matches) every question returns the normal-game answer, so experimental
## rules can never leak into another match.

const SpawnSafety = preload("res://art/scripts/spawn_safety.gd")
const MapRegistry = preload("res://art/scripts/map_registry.gd")
const BotDifficulty = preload("res://art/scripts/bot_difficulty.gd")
## Loaded at runtime on purpose: a preload here made a script cycle (bullet -> MatchSession -> arena -> bot -> bullet).
static func _arena_consts() -> Script:
	return load("res://art/scripts/arena_controller.gd")

static var active := false
static var cfg: MatchConfig = null
## Set by "play again" so the reloaded scene starts the same match straight away instead of showing the menu.
static var restart_pending := false
static var shots := 0
static var hits := 0
static var lives_left := 0
static var _bots_generation := 0

const RATE_RESPAWN_MULT := [0.0, 2.0, 1.0, 0.6, 0.35]       # weapon respawn time x this (OFF is handled separately)
const RATE_INTERVAL_MULT := [0.0, 1.9, 1.0, 0.6, 0.35]      # throwable spawn interval x this
const DAMAGE_MULT := 1.5
const EXPLOSION_MULT := 1.5
const LOW_GRAVITY := 0.45
const FAST_MOVE := 1.3


# ------------------------------------------------------------------ lifecycle
static func begin(config: MatchConfig) -> void:
	cfg = config.duplicate_config()
	active = true
	restart_pending = false
	shots = 0
	hits = 0
	lives_left = cfg.lives if cfg.mode == "survival" else 0
	_apply_static_rules()


static func end_session() -> void:
	active = false
	cfg = null
	restart_pending = false
	ThrowableCatalog.spawn_filter_active = false
	ThrowableCatalog.spawn_filter = []
	BotDifficulty.override_level = -1
	WeaponPickup.max_active_cap = 0


# Rules that live in static state, set BEFORE the map is built so its spawners already obey them.
static func _apply_static_rules() -> void:
	ThrowableCatalog.spawn_filter_active = true
	ThrowableCatalog.spawn_filter = cfg.effective_throwable_ids()
	BotDifficulty.override_level = cfg.bot_difficulty
	WeaponPickup.max_active_cap = cfg.weapon_max


# ------------------------------------------------------------------ rule questions (safe when no match is active)
static func mod(id: String) -> bool:
	return active and cfg != null and cfg.is_mod(id)


static func damage_mult_for(who: Object) -> float:
	# only the human player's damage is boosted
	if active and mod("increased_damage") and who != null and who is Node and (who as Node).is_in_group("player"):
		return DAMAGE_MULT
	return 1.0


static func explosion_mult() -> float:
	return EXPLOSION_MULT if mod("explosion_force") else 1.0


static func player_respawn_delay(default_delay: float) -> float:
	if not active:
		return default_delay
	if mod("no_respawn_delay"):
		return 0.05
	return cfg.player_respawn_delay if cfg.player_respawn_delay > 0.0 else 0.05


static func player_may_respawn() -> bool:
	if not active:
		return true
	if cfg.mode == "survival":
		return lives_left > 0
	return cfg.player_respawn


## The match manager registers here so a player death with no respawn can reach it.
static var on_player_out_cb: Callable = Callable()


static func on_player_out(player: Node) -> void:
	if on_player_out_cb.is_valid():
		on_player_out_cb.call(player)


static func note_shots(n: int) -> void:
	if active:
		shots += n


static func note_hit() -> void:
	if active:
		hits += 1


static func accuracy() -> float:
	return float(hits) / float(shots) if shots > 0 else 0.0


# ------------------------------------------------------------------ applying the config to the live scene
# Called by the arena once the map for this match is loaded and has had two physics frames.
static func apply_to_scene(arena: Node2D) -> void:
	if not active:
		return
	_apply_weapon_pickups(arena)
	_apply_throwable_spawners(arena)
	_apply_out_of_bounds(arena)
	_apply_player(arena)
	if arena.has_method("_apply_local_look"):
		arena.call("_apply_local_look")
	await _rebuild_bots(arena)


static func _apply_weapon_pickups(arena: Node) -> void:
	var pool: Array[WeaponData] = []
	for id in cfg.effective_weapon_ids():
		var w := WeaponCatalog.get_weapon(str(id))
		if w != null:
			pool.append(w)
	var off := cfg.weapon_rate == 0 or pool.is_empty()
	var spots: Array = []
	for n in arena.get_tree().get_nodes_in_group("weapon_pickup"):
		if n is WeaponPickup and not (n as WeaponPickup).is_drop:
			spots.append(n)
	spots.shuffle()
	var allowed := spots.size() if cfg.weapon_max <= 0 else mini(cfg.weapon_max, spots.size())
	var scale: float = RATE_RESPAWN_MULT[clampi(cfg.weapon_rate, 0, 4)]
	for i in spots.size():
		var p: WeaponPickup = spots[i]
		p.configure_match(pool, scale, not off, i >= allowed)


static func _apply_throwable_spawners(arena: Node) -> void:
	for sp in arena.get_tree().get_nodes_in_group("throwable_spawner"):
		if sp is ThrowableSpawner:
			(sp as ThrowableSpawner).configure_match(cfg.throw_rate, RATE_INTERVAL_MULT[clampi(cfg.throw_rate, 0, 4)], cfg.throw_max)


static func _apply_out_of_bounds(arena: Node) -> void:
	for n in arena.find_children("OutOfBounds", "", true, false):
		n.process_mode = Node.PROCESS_MODE_INHERIT if cfg.oob_damage else Node.PROCESS_MODE_DISABLED


static func _apply_player(arena: Node) -> void:
	var player := arena.get_node_or_null("Player")
	if player != null and player.has_method("apply_match_rules"):
		player.call("apply_match_rules", cfg)


# Replaces whatever bots the scene and map made with exactly cfg.bot_count bots.
static func _rebuild_bots(arena: Node2D) -> void:
	_bots_generation += 1
	var gen := _bots_generation
	for b in arena.get_tree().get_nodes_in_group("bot"):
		b.get_parent().remove_child(b)
		b.queue_free()
	var count := mini(cfg.bot_count, cfg.max_bots())
	if count <= 0:
		return
	var map_id := str(arena.get_meta("active_map_id", cfg.map_id))
	var wanted: Array = []
	for p in _arena_consts().get_script_constant_map()["NET_SPAWNS"].get(map_id, []):
		wanted.append(p)
	for p in _arena_consts().get_script_constant_map()["BOT_SPAWNS"].get(map_id, []):
		if not wanted.has(p):
			wanted.append(p)
	if wanted.is_empty():
		wanted.append(_arena_consts().get_script_constant_map()["PLAYER_SPAWNS"].get(map_id, Vector2(250, 2310)))
	wanted.shuffle()
	var bots: Array[Node2D] = []
	for i in count:
		var bot := (load("res://art/scripts/bot.tscn") as PackedScene).instantiate() as Node2D
		bot.position = wanted[i % wanted.size()]
		bot.set("respawn_enabled", cfg.bot_respawn)
		bot.set("respawn_time", cfg.bot_respawn_delay)
		bot.set("throw_enabled", cfg.bot_throwables)
		bot.visible = false
		arena.add_child(bot)
		bot.set_physics_process(false)
		bots.append(bot)
	await arena.get_tree().physics_frame
	await arena.get_tree().physics_frame
	if gen != _bots_generation or not active:
		return
	var taken: Array[Vector2] = []
	var player := arena.get_node_or_null("Player") as Node2D
	if player != null:
		taken.append(player.global_position)
	for b in bots:
		if not is_instance_valid(b):
			continue
		var spot := SpawnSafety.find_safe_spawn(b, b.position, taken, 400.0)
		if b.has_method("place_at"):
			b.call("place_at", spot)
		else:
			b.global_position = spot
		taken.append(spot)
		b.visible = true
		b.set_physics_process(true)
