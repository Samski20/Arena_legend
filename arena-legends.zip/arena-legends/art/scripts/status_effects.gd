class_name StatusEffects
extends Node
## Drop-in status effects for anything that isn't the player (bots, dummies...).
## The zones call StatusEffects.apply_to(body, ...) when a body has no apply_status() of its own,
## and this node is created on that body automatically. Nothing to set up in the editor.
##
##   burn / poison -> damage over time through the body's take_damage()
##   cryo / slow   -> slower. Works on a "speed" or "move_speed" property, and also
##                    on a "status_speed_mult" property if your bot has one (see notes below)
##   smoked        -> body turns almost invisible (and its health bar hides)
##
## Optional hooks a bot can add to react better (none are required):
##   var status_speed_mult := 1.0   # multiply your movement speed by this every frame
##   var smoked := false            # set by this node; bot AI can use it to lose track of the target

const SPEED_PROPS := ["speed", "move_speed", "max_speed"]

var host                      # left untyped on purpose: bots/players have members Node2D doesn't
var _status := {}            # type -> {"t": seconds left, "power": strength, "src": who}
var _dot_accum := {}
var _tinted := false
var _base_speed := {}        # property -> original value, so cold can be undone


static func apply_to(body: Node, type: String, duration: float, power := 1.0, source: Node = null) -> void:
	var comp := body.get_node_or_null("StatusEffects") as StatusEffects
	if comp == null:
		comp = StatusEffects.new()
		comp.name = "StatusEffects"
		body.add_child(comp)
	comp.apply_status(type, duration, power, source)


func _ready() -> void:
	host = get_parent()


func apply_status(type: String, duration: float, power := 1.0, source: Node = null) -> void:
	if _host_dead():
		return
	StatusFX.attach(get_parent())
	if _status.has(type):
		var cur: Dictionary = _status[type]
		cur["t"] = maxf(cur["t"], duration)
		cur["power"] = maxf(cur["power"], power)
		if source != null:
			cur["src"] = source
	else:
		_status[type] = {"t": duration, "power": power, "src": source}


func has_status(type: String) -> bool:
	return _status.has(type)


func clear_statuses() -> void:
	_status.clear()
	_dot_accum.clear()
	_refresh()


func _host_dead() -> bool:
	if not is_instance_valid(host):
		return true
	return ("is_dead" in host and bool(host.get("is_dead"))) or ("dead" in host and bool(host.get("dead")))


func _physics_process(delta: float) -> void:
	if not is_instance_valid(host):
		return
	if _host_dead():
		if not _status.is_empty():
			clear_statuses()             # died: the effects go away
		return

	for type in _status.keys():
		if not _status.has(type):
			continue
		var s: Dictionary = _status[type]
		s["t"] -= delta
		if type == "burn" or type == "poison":
			_dot_accum[type] = float(_dot_accum.get(type, 0.0)) + float(s["power"]) * delta
			if _dot_accum[type] >= 1.0:
				var dmg := int(_dot_accum[type])
				_dot_accum[type] -= dmg
				if is_instance_valid(s["src"]) and "last_attacker" in host:
					host.last_attacker = s["src"]            # kill credit
				if host.has_method("take_damage"):
					host.take_damage(dmg, Vector2.ZERO)
				if _host_dead():
					clear_statuses()
					return
		if s["t"] <= 0.0:
			_status.erase(type)
			_dot_accum.erase(type)
	_refresh()


# Applies the visible/movement side of the current statuses to the host.
func _refresh() -> void:
	if not is_instance_valid(host):
		return

	# slow
	var mult := 1.0
	for type in ["cryo", "slow"]:
		if _status.has(type):
			mult *= 1.0 - clampf(float(_status[type]["power"]), 0.0, 0.9)
	if "status_speed_mult" in host:
		host.set("status_speed_mult", mult)
	for prop in SPEED_PROPS:
		if prop in host:
			if not _base_speed.has(prop):
				_base_speed[prop] = host.get(prop)
			if mult < 1.0 or _base_speed[prop] != host.get(prop):
				host.set(prop, float(_base_speed[prop]) * mult)

	# tint
	var tint := Color(1, 1, 1)
	if _status.has("cryo"):
		tint = Color(0.65, 0.9, 1.3)
	elif _status.has("burn"):
		tint = Color(1.25, 0.8, 0.6) if int(Time.get_ticks_msec() / 120) % 2 == 0 else Color(1.1, 0.7, 0.5)
	elif _status.has("poison"):
		tint = Color(0.7, 1.15, 0.6)
	var smoked := _status.has("smoked")
	tint.a = 0.07 if smoked else 1.0
	var active := not _status.is_empty()
	if active:
		host.modulate = tint
		_tinted = true
	elif _tinted:
		host.modulate = Color(1, 1, 1)         # only reset once, so the bot's own hit flash isn't fought
		_tinted = false
	if "smoked" in host and bool(host.get("smoked")) != smoked:
		host.set("smoked", smoked)
		host.queue_redraw()                    # bots draw their own health bar
	for bar_name in ["HealthBar", "health_bar"]:
		var bar = host.get(bar_name) if bar_name in host else host.get_node_or_null(bar_name)
		if bar is CanvasItem:
			bar.visible = not smoked
