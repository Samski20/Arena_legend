extends RefCounted
## Collision-aware spawn search. Nothing here moves a body: it only answers "is this spot safe?"
## and "where is the nearest safe spot?". Used by bot.gd (every respawn) and arena_controller.gd
## (when a map is chosen).
##
## A spot is SAFE when
##   * it is inside the playable rectangle,
##   * there is walkable ground under it (not a near-vertical face),
##   * the character's capsule (plus a small margin) touches no solid, prop, rock or other fighter,
##   * a box around the body has free room to step and to start the jetpack.
##
## A map can plug in by joining the group "bot_spawn_provider" and offering
##   get_bot_spawn_candidates() -> PackedVector2Array   (points on walkable surfaces)
##   get_playable_rect() -> Rect2
## Maps without a provider still work: the search then spirals around the preferred point.

# Same hitbox as bot.gd (capsule radius 13, height 60, centred 6 px above the node origin).
const BODY_RADIUS := 13.0
const BODY_HEIGHT := 60.0
const BODY_OFFSET := Vector2(0.0, -6.0)
const FOOT_DROP := 24.0                 # node origin -> sole of the feet (-6 + 60 / 2 = 24 below)
const SKIN := 5.0                       # extra clearance around the capsule
const ROOM_HALF_WIDTH := 30.0           # free box left and right of the feet
const ROOM_LIFT := 22.0                 # box starts this far above the ground (lets slopes through)
const ROOM_HEIGHT := 56.0
const RAY_UP := 110.0                   # ray starts this far above the hint point
const RAY_DOWN := 260.0
const MIN_GROUND_NORMAL_Y := 0.62       # normal.y must be at most -0.62 (about 52 degrees)
const COLLIDE_ALL := 0xFFFFFFFF

const WIDE_OPEN := Rect2(-100000.0, -100000.0, 200000.0, 200000.0)


# ------------------------------------------------------------------ basic queries

static func point_is_free(space: PhysicsDirectSpaceState2D, p: Vector2, exclude: Array[RID]) -> bool:
	var q := PhysicsPointQueryParameters2D.new()
	q.position = p
	q.collision_mask = COLLIDE_ALL
	q.collide_with_bodies = true
	q.collide_with_areas = false
	q.exclude = exclude
	return space.intersect_point(q, 1).is_empty()


# Is the body's capsule (grown by SKIN) free when the node origin is at `origin`?
static func body_fits(space: PhysicsDirectSpaceState2D, origin: Vector2, exclude: Array[RID]) -> bool:
	var shape := CapsuleShape2D.new()
	shape.radius = BODY_RADIUS + SKIN
	shape.height = BODY_HEIGHT + SKIN * 2.0
	var q := PhysicsShapeQueryParameters2D.new()
	q.shape = shape
	q.transform = Transform2D(0.0, origin + BODY_OFFSET)
	q.collision_mask = COLLIDE_ALL
	q.collide_with_bodies = true
	q.collide_with_areas = false
	q.exclude = exclude
	return space.intersect_shape(q, 1).is_empty()


# A box above the ground point that must be free: room to take a step and to lift off.
static func has_room(space: PhysicsDirectSpaceState2D, ground: Vector2, exclude: Array[RID]) -> bool:
	var shape := RectangleShape2D.new()
	shape.size = Vector2(ROOM_HALF_WIDTH * 2.0, ROOM_HEIGHT)
	var q := PhysicsShapeQueryParameters2D.new()
	q.shape = shape
	q.transform = Transform2D(0.0, ground + Vector2(0.0, -(ROOM_LIFT + ROOM_HEIGHT * 0.5)))
	q.collision_mask = COLLIDE_ALL
	q.collide_with_bodies = true
	q.collide_with_areas = false
	q.exclude = exclude
	return space.intersect_shape(q, 1).is_empty()


# ------------------------------------------------------------------ one candidate

# Looks straight down from just above `hint` for ground and returns the node-origin position that
# puts the character's feet on it, or Vector2.INF when this column has no safe spot.
static func resolve_column(space: PhysicsDirectSpaceState2D, hint: Vector2, playable: Rect2, exclude: Array[RID]) -> Vector2:
	var from := hint + Vector2(0.0, -RAY_UP)
	if not playable.has_point(from) and not playable.has_point(hint):
		return Vector2.INF
	if not point_is_free(space, from, exclude):
		return Vector2.INF                         # the start of the ray is inside a solid
	var ray := PhysicsRayQueryParameters2D.create(from, from + Vector2(0.0, RAY_DOWN), COLLIDE_ALL, exclude)
	ray.collide_with_areas = false
	ray.hit_from_inside = false
	var hit: Dictionary = space.intersect_ray(ray)
	if hit.is_empty():
		return Vector2.INF
	var normal: Vector2 = hit["normal"]
	if normal.y > -MIN_GROUND_NORMAL_Y:
		return Vector2.INF                         # a wall, an overhang or a too-steep face
	var ground: Vector2 = hit["position"]
	var origin := ground + Vector2(0.0, -(FOOT_DROP + 1.0))
	if not playable.has_point(origin):
		return Vector2.INF
	if not body_fits(space, origin, exclude):
		return Vector2.INF
	if not has_room(space, ground, exclude):
		return Vector2.INF
	return origin


# Public check for any finished position (a body already standing there is excluded by the caller).
static func is_spot_safe(space: PhysicsDirectSpaceState2D, origin: Vector2, playable: Rect2, exclude: Array[RID]) -> bool:
	if not playable.has_point(origin):
		return false
	if not body_fits(space, origin, exclude):
		return false
	var resolved := resolve_column(space, origin + Vector2(0.0, RAY_UP - FOOT_DROP - 4.0), playable, exclude)
	return resolved != Vector2.INF and absf(resolved.y - origin.y) < 40.0


# ------------------------------------------------------------------ searches

# Spirals out from `preferred` (sideways first, then upward) for the nearest safe spot.
static func find_near(space: PhysicsDirectSpaceState2D, preferred: Vector2, playable: Rect2, exclude: Array[RID]) -> Vector2:
	var offsets: Array[float] = [0.0]
	for k in range(1, 15):
		offsets.append(float(k) * 36.0)
		offsets.append(float(-k) * 36.0)
	for lift in [0.0, -90.0, -180.0, 90.0]:
		for dx in offsets:
			var found := resolve_column(space, preferred + Vector2(dx, float(lift)), playable, exclude)
			if found != Vector2.INF:
				return found
	return Vector2.INF


# Picks one safe spot out of `candidates`, preferring spots that are far from everyone in `avoid`.
# At most `max_valid` safe spots are examined, so the cost stays small on phones.
static func pick_from(space: PhysicsDirectSpaceState2D, candidates: PackedVector2Array, avoid: Array[Vector2],
		min_avoid: float, playable: Rect2, exclude: Array[RID], max_valid := 14) -> Vector2:
	if candidates.is_empty():
		return Vector2.INF
	var order: Array[int] = []
	for i in candidates.size():
		order.append(i)
	order.shuffle()
	var best := Vector2.INF
	var best_score := -1.0
	var valid := 0
	for i in order:
		var spot := resolve_column(space, candidates[i], playable, exclude)
		if spot == Vector2.INF:
			continue
		valid += 1
		var nearest := 1.0e9
		for a in avoid:
			nearest = minf(nearest, a.distance_to(spot))
		var score := nearest
		if nearest >= min_avoid:
			return spot                            # good enough: safe AND away from everyone
		if score > best_score:
			best_score = score
			best = spot
		if valid >= max_valid:
			break
	return best


# ------------------------------------------------------------------ one-call entry point

# Returns the node-origin position where `body` should (re)spawn. Order of attempts:
#   1. the preferred point itself (or the closest safe spot around it) when it is far enough from `avoid`,
#   2. any safe point offered by the map's "bot_spawn_provider",
#   3. the closest safe spot around the preferred point,
#   4. the preferred point unchanged (with a warning), so a bad map can never freeze the game.
# Must run while the physics space is up to date: call it from _physics_process, or after an
# `await get_tree().physics_frame`.
static func find_safe_spawn(body: Node2D, preferred: Vector2, avoid: Array[Vector2], min_avoid := 520.0) -> Vector2:
	var tree := body.get_tree()
	var space := body.get_world_2d().direct_space_state
	var exclude: Array[RID] = []
	if body is CollisionObject2D:
		exclude.append((body as CollisionObject2D).get_rid())
	var playable := WIDE_OPEN
	var candidates := PackedVector2Array()
	for n in tree.get_nodes_in_group("bot_spawn_provider"):
		if n.has_method("get_playable_rect"):
			playable = n.call("get_playable_rect")
		if n.has_method("get_bot_spawn_candidates"):
			candidates.append_array(n.call("get_bot_spawn_candidates"))
		break

	var near := find_near(space, preferred, playable, exclude)
	if near != Vector2.INF:
		var far_enough := true
		for a in avoid:
			if a.distance_to(near) < min_avoid:
				far_enough = false
		if far_enough:
			return near
	var picked := pick_from(space, candidates, avoid, min_avoid, playable, exclude)
	if picked != Vector2.INF:
		return picked
	if near != Vector2.INF:
		return near
	push_warning("SpawnSafety: no safe spot found near %s; using it as is." % str(preferred))
	return preferred
