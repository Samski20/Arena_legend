class_name TouchControls
extends Control
## Mini Militia style touch controls. player.gd creates this automatically, so there is
## nothing to add to the scene. It does NOT replace the PC controls: it is just another
## input source that player.gd reads (keyboard + mouse keep working as before).
##
##   LEFT STICK   run left/right. Drag UP to start flying, then steer in ANY direction
##                while you keep dragging. Let go to fall. Drag DOWN on the ground to crouch.
##   RIGHT STICK  Mini Militia style: move the knob INSIDE the small inner circle to aim only.
##                Drag it OUT past the inner circle (into the big ring) and you aim AND shoot, for as long
##                as the same finger stays out there. The finger is tracked by its id, so sliding anywhere
##                never loses it; lifting the finger or dragging back inside the small circle stops firing.
##   ZOOM + / -   camera closer / farther (hold to repeat), limited by the weapon in hand.
##   HOVER        toggles hover (stay in place while flying; the left stick still steers).
##   FLIP         air flip (same as Shift). Flicking the left stick sideways twice also flips.
##   WEAPON BOX   tap to switch weapon.   RELOAD / DUAL / PICK UP buttons.
##   THROW        throws the selected grenade where you aim.
##   GRENADE TYPE tap the small grenade icon to cycle grenade types.
##
## On a phone it turns itself on. On PC press F9 to show it (the mouse then acts as a
## single finger, which is enough to check the layout; keyboard keeps working too).

# ---------- tuning ----------
const BASE_STICK_RADIUS := 80.0       # stick size at 100% (the settings menu scales it)
const BASE_DEADZONE := 0.14
const FIRE_RING := 0.55              # right stick: inside this share of the radius = aim only, past it = shoot
const FIXED_GRAB_FACTOR := 1.9        # fixed sticks: a touch within this many radii of the ring grabs the stick
const TAP_MAX_AGE := 0.30             # a tap that nobody read within this time is dropped
const STICK_SIZE_MIN := 0.6              # per-stick size range in the layout editor (x the global setting)
const STICK_SIZE_MAX := 1.6
const OPACITY_MIN := 0.25             # per-control opacity range in the layout editor
const MARGIN := 60.0                  # keeps controls away from rounded corners / notches

const COL_IDLE := Color(1, 1, 1, 0.22)
const COL_ACTIVE := Color(0.24, 0.86, 0.52, 0.70)       # Android green while a stick is held
const COL_FLY := Color(0.37, 0.94, 1.0, 0.70)
const COL_FIRE := Color(1.0, 0.60, 0.36, 0.72)
const COL_BTN := Color(0.07, 0.08, 0.10, 0.58)
const COL_BTN_ON := Color(0.24, 0.86, 0.52, 0.55)
const COL_EDGE := Color(1, 1, 1, 0.28)

## Emitted when the layout editor is closed with DONE.
signal edit_finished

# Set by player.gd before this node is added to the tree
var player: Node = null

# True while the touch UI is shown and used (static so any script can ask "is this a touch game?")
static var active := false
var enabled := false

# live values (from GameSettings, see apply_settings)
var _sr_g := BASE_STICK_RADIUS        # GLOBAL stick radius from Settings > Stick size (only the buttons' default spots depend on it)
var _sr_l := BASE_STICK_RADIUS        # LEFT (move) stick radius: global setting x this stick's own size
var _sr_r := BASE_STICK_RADIUS        # RIGHT (aim / fire) stick radius: global setting x this stick's own size
var _alpha := 1.0                     # opacity of the control being drawn right now (its own setting)
var _dz := BASE_DEADZONE              # stick dead zone
var _bs := 1.0                        # button scale
var _fixed := true                    # sticks stay at their home spot instead of appearing under the finger
var _labels := true

# layout editor (settings > EDIT LAYOUT): drag any control to where you want it
var edit_mode := false
var _edit_id := ""
var _edit_sel := ""                   # last control touched in the editor (the + / - buttons resize it)
var _edit_index := -1
var _edit_grab := Vector2.ZERO
var _btn_base := {}                   # button id -> default centre (before the saved offset)

# ---------- what player.gd reads every frame ----------
var move_vec := Vector2.ZERO          # left stick, -1..1 (x right, y down), deadzone already removed
var aim_vec := Vector2.RIGHT          # unit vector the player aims along (remembered between touches)
var fire_held := false                # the right stick is dragged out past the inner circle = shooting
var _fire_locked := false             # set when the player dies: no shooting until the finger goes back inside
var aim_strength := 0.0               # how far the right stick is pushed (0..1), used by the camera to look ahead

# ---------- stick state ----------
var _l_id := -1
var _l_base := Vector2.ZERO
var _l_pos := Vector2.ZERO
var _r_id := -1
var _r_base := Vector2.ZERO
var _r_pos := Vector2.ZERO
var _r_vec := Vector2.ZERO

# ---------- buttons ----------
# id -> {"c": center, "r": radius}  or  {"rect": Rect2}
var _btn := {}
var _btn_touch := {}                  # button id -> touch index currently holding it
var _pending := {}                    # action name -> time it was tapped (read once by player.gd)
var _style: StyleBoxFlat
var _font: Font


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_font = UITheme.font(true)
	add_to_group("touch_controls")
	GameSettings.ensure_loaded()
	_read_settings()

	_style = StyleBoxFlat.new()
	_style.bg_color = COL_BTN
	_style.set_corner_radius_all(24)
	_style.set_border_width_all(1)
	_style.border_color = COL_EDGE

	get_viewport().size_changed.connect(_layout)
	_layout()

	# on a phone/tablet the controls are on from the start
	var mobile := OS.has_feature("mobile") or OS.has_feature("web_android") or OS.has_feature("web_ios")
	set_enabled(mobile or TouchControls.active)      # (stays on after the match restarts)


func set_enabled(on: bool) -> void:
	enabled = on
	TouchControls.active = on
	visible = on
	if on:
		# touches must NOT also act as mouse clicks, or every tap would fire the gun
		Input.emulate_mouse_from_touch = false
	else:
		_release_all()
	if player != null and player.has_method("on_touch_mode_changed"):
		player.on_touch_mode_changed(on)


func _read_settings() -> void:
	_sr_g = BASE_STICK_RADIUS * GameSettings.stick_scale
	_sr_l = _sr_g * _stick_size("stick_l")        # each stick reads ITS OWN saved size
	_sr_r = _sr_g * _stick_size("stick_r")
	_dz = GameSettings.deadzone
	_bs = GameSettings.button_scale
	_fixed = GameSettings.fixed_sticks
	_labels = GameSettings.show_labels
	modulate.a = 1.0 if edit_mode else GameSettings.opacity      # global opacity; each control's own opacity is applied when it is drawn


# This stick's own size multiplier (GameSettings.sizes[id]); never shared with the other stick.
func _stick_size(id: String) -> float:
	return clampf(float(GameSettings.sizes.get(id, 1.0)), STICK_SIZE_MIN, STICK_SIZE_MAX)


func _stick_radius(id: String) -> float:
	return _sr_l if id == "stick_l" else _sr_r


# This control's own opacity (GameSettings.opacities[id], 1.0 = no extra fade).
func _opacity_of(id: String) -> float:
	return clampf(float(GameSettings.opacities.get(id, 1.0)), OPACITY_MIN, 1.0)


# The "modulate" the draw helpers use for whatever is drawn next (set once at the start of each control).
func _begin_control(id: String) -> void:
	_alpha = _opacity_of(id)


# The settings menu calls this after every change, so the controls update live.
func apply_settings() -> void:
	_read_settings()
	_release_all()
	_layout()
	queue_redraw()


func left_down() -> bool:
	return _l_id != -1


# ============================================================
# LAYOUT
# ============================================================
func _layout() -> void:
	var vs := get_viewport_rect().size
	var w := vs.x
	var h := vs.y
	_btn.clear()
	var dx := _sr_g - BASE_STICK_RADIUS          # buttons slide outward with the GLOBAL stick size setting (never with one stick's own size)
	var k := _bs
	# --- left side (next to the left stick) ---
	_btn["hover"] = {"c": Vector2(MARGIN + 290.0 + dx, h - 78.0), "r": 42.0 * k}
	_btn["flip"] = {"c": Vector2(MARGIN + 290.0 + dx, h - 78.0 - 94.0 * k), "r": 30.0 * k}
	# --- right side (next to the right stick) ---
	_btn["throw"] = {"c": Vector2(w - MARGIN - 290.0 - dx, h - 84.0), "r": 46.0 * k}
	_btn["throw_type"] = {"c": Vector2(w - MARGIN - 290.0 - dx, h - 84.0 - 98.0 * k), "r": 30.0 * k}
	# camera zoom: top right corner, out of the way of both sticks
	_btn["zoom_in"] = {"c": Vector2(w - MARGIN, 96.0), "r": 28.0 * k}
	_btn["zoom_out"] = {"c": Vector2(w - MARGIN, 96.0 + 68.0 * k), "r": 28.0 * k}
	_btn["weapon"] = {"rect": Rect2(w - MARGIN - 178.0 - (190.0 * (k - 1.0)), h - 366.0 - dx, 190.0 * k, 60.0 * k)}
	_btn["firemode"] = {"c": Vector2(w - MARGIN - 150.0 - (190.0 * (k - 1.0)) , h - 366.0 - dx - 50.0 * k), "r": 32.0 * k}
	_btn["reload"] = {"c": Vector2(w - MARGIN - 262.0 - dx, h - 286.0 - dx), "r": 28.0 * k}
	_btn["pickup"] = {"c": Vector2(w - MARGIN - 6.0, h - 272.0 - dx), "r": 34.0 * k}
	# DUAL WIELD sits right next to PICK UP (both only appear when a gun is within reach)
	_btn["dual"] = {"c": Vector2(w - MARGIN - 6.0 - 84.0 * k, h - 272.0 - dx), "r": 32.0 * k}
	_apply_offsets(vs)


func _home_left_base() -> Vector2:
	var vs := get_viewport_rect().size
	return Vector2(MARGIN + _sr_l + 25.0, vs.y - _sr_l - 70.0)


func _home_right_base() -> Vector2:
	var vs := get_viewport_rect().size
	return Vector2(vs.x - MARGIN - _sr_r - 25.0, vs.y - _sr_r - 70.0)


func _home_left() -> Vector2:
	return _keep_inside(_home_left_base() + _offset("stick_l"), _sr_l + 6.0)


func _home_right() -> Vector2:
	return _keep_inside(_home_right_base() + _offset("stick_r"), _sr_r + 6.0)


func _offset(id: String) -> Vector2:
	return GameSettings.offsets.get(id, Vector2.ZERO)


# keeps a control's centre on screen (with its radius as margin)
func _keep_inside(p: Vector2, margin: float) -> Vector2:
	var vs := get_viewport_rect().size
	return Vector2(clampf(p.x, margin, maxf(vs.x - margin, margin)), clampf(p.y, margin, maxf(vs.y - margin, margin)))


# Moves every button by its saved offset (after _layout has put it on its default spot).
func _apply_offsets(vs: Vector2) -> void:
	_btn_base.clear()
	for id in _btn.keys():
		var b: Dictionary = _btn[id]
		var o := _offset(id)
		var sk: float = clampf(float(GameSettings.sizes.get(id, 1.0)), 0.5, 2.0)
		if b.has("rect"):
			var rect: Rect2 = b["rect"]
			rect = Rect2(rect.get_center() - rect.size * sk * 0.5, rect.size * sk)
			_btn_base[id] = rect.get_center()
			var c := _keep_inside(rect.get_center() + o, minf(rect.size.x, rect.size.y) * 0.5)
			rect.position = c - rect.size * 0.5
			b["rect"] = rect
		else:
			var c0: Vector2 = b["c"]
			b["r"] = float(b["r"]) * sk
			_btn_base[id] = c0
			b["c"] = _keep_inside(c0 + o, float(b["r"]))


# ---------------- layout editor ----------------
func begin_edit() -> void:
	if not enabled:
		set_enabled(true)
		if not (OS.has_feature("mobile") or OS.has_feature("web_android") or OS.has_feature("web_ios")):
			Input.emulate_touch_from_mouse = true      # PC test: the mouse acts as a finger
	_release_all()
	edit_mode = true
	_edit_id = ""
	_edit_sel = ""
	_edit_index = -1
	process_mode = Node.PROCESS_MODE_ALWAYS            # the game is paused behind the menu; the editor must keep running
	modulate.a = 1.0
	_layout()
	queue_redraw()


func end_edit() -> void:
	edit_mode = false
	_edit_id = ""
	process_mode = Node.PROCESS_MODE_INHERIT
	GameSettings.save()
	_read_settings()
	_layout()
	queue_redraw()
	edit_finished.emit()


func _edit_rects() -> Dictionary:
	var vs := get_viewport_rect().size
	var cx := vs.x * 0.5
	return {
		"done": Rect2(cx - 245.0, 14.0, 150.0, 52.0),
		"reset": Rect2(cx - 75.0, 14.0, 150.0, 52.0),
		"mirror": Rect2(cx + 95.0, 14.0, 150.0, 52.0),
		"minus": Rect2(cx - 150.0, vs.y - 74.0, 64.0, 56.0),
		"plus": Rect2(cx + 86.0, vs.y - 74.0, 64.0, 56.0),
		"op_minus": Rect2(cx - 330.0, vs.y - 74.0, 150.0, 56.0),
		"op_plus": Rect2(cx + 180.0, vs.y - 74.0, 150.0, 56.0),
	}


func _edit_element_at(pos: Vector2) -> String:
	var hit := _button_at(pos)
	if hit != "":
		return hit
	if pos.distance_to(_home_right()) <= _sr_r + 14.0:
		return "stick_r"
	if pos.distance_to(_home_left()) <= _sr_l + 14.0:
		return "stick_l"
	return ""


func _elem_center(id: String) -> Vector2:
	if id == "stick_l":
		return _home_left()
	if id == "stick_r":
		return _home_right()
	var b: Dictionary = _btn[id]
	return (b["rect"] as Rect2).get_center() if b.has("rect") else b["c"]


func _elem_default(id: String) -> Vector2:
	if id == "stick_l":
		return _home_left_base()
	if id == "stick_r":
		return _home_right_base()
	return _btn_base.get(id, _elem_center(id))


# Swaps left and right: every control jumps to its mirror position (handy for lefties).
func _mirror_layout() -> void:
	var w := get_viewport_rect().size.x
	var ids: Array = ["stick_l", "stick_r"]
	ids.append_array(_btn.keys())
	var targets := {}
	for id in ids:
		var c := _elem_center(id)
		targets[id] = Vector2(w - c.x, c.y)
	for id in ids:
		var off: Vector2 = (targets[id] as Vector2) - _elem_default(id)
		if off.length() < 3.0:
			GameSettings.offsets.erase(id)
		else:
			GameSettings.offsets[id] = off
	GameSettings.save()
	_layout()


func _resize_selected(delta: float) -> void:
	if _edit_sel == "":
		return
	# Every control (both sticks included) has its OWN entry in GameSettings.sizes; nothing global is touched here.
	var lo := STICK_SIZE_MIN if _edit_sel.begins_with("stick") else 0.5
	var hi := STICK_SIZE_MAX if _edit_sel.begins_with("stick") else 2.0
	var cur: float = float(GameSettings.sizes.get(_edit_sel, 1.0))
	var v := snappedf(clampf(cur + delta, lo, hi), 0.01)
	if absf(v - 1.0) < 0.005:
		GameSettings.sizes.erase(_edit_sel)
	else:
		GameSettings.sizes[_edit_sel] = v
	_read_settings()
	GameSettings.save()
	_layout()


# Changes ONLY the selected control's opacity.
func _adjust_opacity(delta: float) -> void:
	if _edit_sel == "":
		return
	var cur: float = float(GameSettings.opacities.get(_edit_sel, 1.0))
	var v := snappedf(clampf(cur + delta, OPACITY_MIN, 1.0), 0.05)
	if v > 0.995:
		GameSettings.opacities.erase(_edit_sel)
	else:
		GameSettings.opacities[_edit_sel] = v
	GameSettings.save()
	queue_redraw()


func _edit_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var te := event as InputEventScreenTouch
		if te.pressed:
			var rects := _edit_rects()
			if (rects["done"] as Rect2).has_point(te.position):
				end_edit()
				return
			if (rects["reset"] as Rect2).has_point(te.position):
				GameSettings.offsets = {}
				GameSettings.sizes = {}
				GameSettings.opacities = {}
				GameSettings.save()
				_read_settings()
				_layout()
				return
			if (rects["mirror"] as Rect2).has_point(te.position):
				_mirror_layout()
				return
			if (rects["minus"] as Rect2).has_point(te.position):
				_resize_selected(-0.1)
				return
			if (rects["plus"] as Rect2).has_point(te.position):
				_resize_selected(0.1)
				return
			if (rects["op_minus"] as Rect2).has_point(te.position):
				_adjust_opacity(-0.1)
				return
			if (rects["op_plus"] as Rect2).has_point(te.position):
				_adjust_opacity(0.1)
				return
			if _edit_index == -1:
				var id: String = _edit_element_at(te.position)
				if id != "":
					_edit_id = id
					_edit_sel = id
					_edit_index = te.index
					_edit_grab = _elem_center(id) - te.position
		elif te.index == _edit_index:
			_edit_index = -1
			GameSettings.save()
	elif event is InputEventScreenDrag:
		var de := event as InputEventScreenDrag
		if de.index != _edit_index or _edit_id == "":
			return
		var margin: float = (_stick_radius(_edit_id) + 6.0) if _edit_id.begins_with("stick") else 20.0
		var target: Vector2 = _keep_inside(de.position + _edit_grab, margin)
		var off: Vector2 = target - _elem_default(_edit_id)
		if off.length() < 3.0:
			GameSettings.offsets.erase(_edit_id)        # snapped back to the default spot
		else:
			GameSettings.offsets[_edit_id] = off
		_layout()


# ============================================================
# INPUT
# ============================================================
func _input(event: InputEvent) -> void:
	if edit_mode:
		_edit_input(event)
		get_viewport().set_input_as_handled()
		return
	# F9 shows / hides the touch UI on PC
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F9:
		set_enabled(not enabled)
		Input.emulate_touch_from_mouse = enabled
		return

	if event is InputEventScreenTouch:
		if not enabled:
			# a real finger on a device that did not know it was a phone (tablet, touch laptop)
			if event.pressed and not Input.emulate_touch_from_mouse:
				set_enabled(true)
			else:
				return
		if event.pressed:
			_touch_down(event.index, event.position)
		else:
			_touch_up(event.index)
	elif event is InputEventScreenDrag and enabled:
		_touch_move(event.index, event.position)


func _touch_down(index: int, pos: Vector2) -> void:
	# 1) buttons win over the sticks
	var hit := _button_at(pos)
	if hit != "":
		_btn_touch[hit] = index
		_press_button(hit)
		return
	# 2) otherwise the touch goes to whichever stick it is actually ON, judged by that stick's own
	#    position and size (NOT by which half of the screen it is in), so mirrored and moved sticks work.
	var which := _stick_at(pos)
	if which == "stick_l":
		var home := _home_left()
		_l_id = index
		_l_base = home if _fixed else pos
		_l_pos = pos
		move_vec = _stick_value(pos - _l_base, _sr_l)
	elif which == "stick_r":
		var home_r := _home_right()
		_r_id = index
		_r_base = home_r if _fixed else pos
		_r_pos = pos
		_r_vec = _stick_value(pos - _r_base, _sr_r)
		_update_aim_from_right()


# Which FREE stick should a new finger at `pos` grab? "" = none.
#  * Fixed sticks: the finger must be within FIXED_GRAB_FACTOR radii of a stick's ring. If both rings
#    cover the spot (sticks dragged close together) the nearer one, measured in its own radii, wins.
#  * Floating sticks (no visible ring): the finger belongs to the stick whose home spot is nearest.
#    If that stick is already held by another finger the touch is ignored, it does NOT leak to the other stick.
# Screen halves are never used. A stick that already has a finger is skipped, so each stick keeps
# exactly one finger (tracked by its touch index in _touch_move / _touch_up).
func _stick_at(pos: Vector2) -> String:
	var d_l := pos.distance_to(_home_left()) / _sr_l
	var d_r := pos.distance_to(_home_right()) / _sr_r
	if _fixed:
		var best := ""
		var best_d := INF
		if _l_id == -1 and d_l <= FIXED_GRAB_FACTOR:
			best = "stick_l"
			best_d = d_l
		if _r_id == -1 and d_r <= FIXED_GRAB_FACTOR and d_r < best_d:
			best = "stick_r"
		return best
	var nearest := "stick_l" if d_l <= d_r else "stick_r"
	if nearest == "stick_l":
		return "stick_l" if _l_id == -1 else ""
	return "stick_r" if _r_id == -1 else ""


func _touch_up(index: int) -> void:
	if index == _l_id:
		_l_id = -1
		move_vec = Vector2.ZERO
	elif index == _r_id:
		_r_id = -1
		_r_vec = Vector2.ZERO
		aim_strength = 0.0
		fire_held = false                    # the aiming finger lifted: stop shooting
		_fire_locked = false
	for b in _btn_touch.keys():
		if _btn_touch[b] == index:
			_btn_touch.erase(b)


func _touch_move(index: int, pos: Vector2) -> void:
	if index == _l_id:
		_l_pos = pos
		_l_base = _drag_base(_l_base, pos, _sr_l)
		move_vec = _stick_value(pos - _l_base, _sr_l)
	elif index == _r_id:
		_r_pos = pos
		_r_base = _drag_base(_r_base, pos, _sr_r)
		_r_vec = _stick_value(pos - _r_base, _sr_r)
		_update_aim_from_right()


# The stick's center follows the finger when it is dragged past the edge, so reversing
# direction is instant (this is what makes the aim and the flight steering feel so quick).
func _drag_base(base: Vector2, pos: Vector2, radius: float) -> Vector2:
	var off := pos - base
	if _fixed:
		return base                         # a fixed stick never moves
	if off.length() > radius:
		return pos - off.normalized() * radius
	return base


# pixels -> -1..1 with the center deadzone cut out (the value still starts at 0, so it stays smooth)
func _stick_value(off: Vector2, radius: float) -> Vector2:
	var mag := minf(off.length() / radius, 1.0)
	if mag <= _dz:
		return Vector2.ZERO
	var scaled := (mag - _dz) / (1.0 - _dz)
	return off.normalized() * scaled


# Inside the inner circle the stick only aims. Pushed out past it, the same finger also shoots
# (it has to come back a little inside the circle before it stops, so the edge does not flicker).
func _update_aim_from_right() -> void:
	if _r_vec.length() > 0.001:
		aim_vec = _r_vec.normalized()
		aim_strength = minf(_r_vec.length(), 1.0)
	else:
		aim_strength = 0.0
	var pull := (_r_pos - _r_base).length() / _sr_r
	if pull < FIRE_RING - 0.05:
		_fire_locked = false
	if pull > FIRE_RING and not _fire_locked:
		fire_held = true
	elif pull < FIRE_RING - 0.05 or _fire_locked:
		fire_held = false


func _button_at(pos: Vector2) -> String:
	for id in _btn.keys():
		if not _button_visible(id):
			continue
		var b: Dictionary = _btn[id]
		if b.has("rect"):
			if (b["rect"] as Rect2).grow(10.0).has_point(pos):
				return id
		else:
			if pos.distance_to(b["c"]) <= float(b["r"]) + 12.0:     # a little extra room for thumbs
				return id
	return ""


func _button_visible(id: String) -> bool:
	if edit_mode:
		return true
	match id:
		"pickup":
			return player != null and player.pickup_available()     # only while a gun is within reach
		"dual":
			return player != null and player.dual_available()       # only while holding a one-handed gun with another one-handed gun in reach
		"firemode":
			return player != null and player.fire_mode_available()  # only for guns that really have more than one firing mode
	return true


func _press_button(id: String) -> void:
	match id:
		"zoom_in":
			_pending["zoom_in"] = _now()
		"zoom_out":
			_pending["zoom_out"] = _now()
		"hover":
			_pending["jetpack"] = _now()
		"flip":
			_pending["flip"] = _now()
		"throw":
			_pending["throw"] = _now()
		"throw_type":
			_pending["switch_throwable"] = _now()
		"weapon":
			_pending["switch_weapon"] = _now()
		"reload":
			_pending["reload"] = _now()
		"firemode":
			_pending["fire_mode"] = _now()
		"dual":
			_pulse_action("dual_wield")
		"pickup":
			_pulse_action("pickup")


# Weapon pickups listen to the "pickup" and "dual_wield" input actions (the same ones the F and Q keys
# and a controller use), so a button tap just presses that action for a moment.
func _pulse_action(action: String) -> void:
	if not InputMap.has_action(action):
		return
	Input.action_press(action)
	await get_tree().create_timer(0.12).timeout
	Input.action_release(action)


func _now() -> float:
	return Time.get_ticks_msec() / 1000.0


# player.gd calls this: true once for each tap of that button.
func take(action: String) -> bool:
	if not _pending.has(action):
		return false
	var age := _now() - float(_pending[action])
	_pending.erase(action)
	return age <= TAP_MAX_AGE


# True while a finger is holding that button (the camera uses it to repeat ZOOM + / -).
func held(id: String) -> bool:
	return _btn_touch.has(id)


# player.gd calls this when the player dies: stop shooting even though the finger may still be down.
func cancel_fire() -> void:
	fire_held = false
	_fire_locked = _r_id != -1


# Losing focus (a call, the home button) can swallow the "finger lifted" event, so let go of everything.
func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		_release_all()


func _release_all() -> void:
	_l_id = -1
	_r_id = -1
	move_vec = Vector2.ZERO
	_r_vec = Vector2.ZERO
	aim_strength = 0.0
	fire_held = false
	_btn_touch.clear()
	_pending.clear()


func _process(_delta: float) -> void:
	if not enabled:
		return
	# (aim_vec is written ONLY by the aim stick: it used to be overwritten here with the run direction, which made
	# the character turn around whenever the move stick was pushed the other way)
	queue_redraw()


# ============================================================
# DRAWING
# ============================================================
func _draw() -> void:
	if not enabled:
		return
	if edit_mode:
		draw_rect(Rect2(Vector2.ZERO, get_viewport_rect().size), Color(0, 0, 0, 0.35))
	_draw_stick(_l_id != -1, _l_base if _l_id != -1 else _home_left(), _l_pos, true)
	_draw_stick(_r_id != -1, _r_base if _r_id != -1 else _home_right(), _r_pos, false)

	_draw_round("hover", "HOVER", player != null and player.jetpack_toggled)
	_draw_round("flip", "FLIP", false)
	_draw_zoom()
	_draw_round("reload", "RELOAD", player != null and player.reloading)
	if _button_visible("firemode"):
		_draw_firemode()
	if _button_visible("dual"):
		_draw_dual()
	if _button_visible("pickup"):
		_draw_pickup()
	_draw_weapon_box()
	_draw_throw()
	if edit_mode:
		_alpha = 1.0                       # the editor's own rings / buttons are never faded
		_draw_edit_overlay()


func _draw_edit_overlay() -> void:
	var ids: Array = ["stick_l", "stick_r"]
	ids.append_array(_btn.keys())
	for id in ids:
		var c := _elem_center(id)
		var r := _stick_radius(id) + 10.0 if String(id).begins_with("stick") else 0.0
		if r == 0.0:
			var b: Dictionary = _btn[id]
			r = (maxf((b["rect"] as Rect2).size.x * 0.5, 30.0) + 8.0) if b.has("rect") else float(b["r"]) + 8.0
		var sel: bool = (id == _edit_sel)
		_darc(c, r, 0.0, TAU, 40, Color(1.0, 0.85, 0.3, 0.95 if sel else 0.55), 4.0 if sel else 2.0, true)
	var rects := _edit_rects()
	for key in rects:
		var rect: Rect2 = rects[key]
		var bg := Color(0.45, 0.3, 0.2, 0.9)
		var label := "RESET"
		match key:
			"done":
				bg = Color(0.2, 0.55, 0.3, 0.9)
				label = "DONE"
			"mirror":
				bg = Color(0.25, 0.35, 0.55, 0.9)
				label = "MIRROR"
			"minus":
				bg = Color(0.2, 0.25, 0.3, 0.9)
				label = "-"
			"plus":
				bg = Color(0.2, 0.25, 0.3, 0.9)
				label = "+"
			"op_minus":
				bg = Color(0.3, 0.25, 0.4, 0.9)
				label = "OPACITY -"
			"op_plus":
				bg = Color(0.3, 0.25, 0.4, 0.9)
				label = "OPACITY +"
		_style.bg_color = bg
		_dstyle(rect)
		_text(rect.get_center() + Vector2(0, 7), label, 24 if key == "minus" or key == "plus" else (15 if key.begins_with("op_") else 18), Color.WHITE, true)
	var sel_text := "Tap a control to select it, then use - / + to resize and OPACITY - / + to fade it"
	if _edit_sel != "":
		var pct: float = float(GameSettings.sizes.get(_edit_sel, 1.0))      # this control's OWN size
		var op: float = _opacity_of(_edit_sel)                              # and its OWN opacity
		sel_text = "%s   size %d%%   opacity %d%%" % [_edit_sel.replace("_", " ").to_upper(), roundi(pct * 100.0), roundi(op * 100.0)]
	_text(Vector2(get_viewport_rect().size.x * 0.5, get_viewport_rect().size.y - 38.0), sel_text, 16, Color(1, 1, 0.7, 1), true)
	_text(Vector2(get_viewport_rect().size.x * 0.5, 96.0), "Drag any control to move it", 18, Color(1, 1, 1, 0.9), true)
	_style.bg_color = COL_BTN


func _draw_stick(down: bool, base: Vector2, pos: Vector2, is_left: bool) -> void:
	_begin_control("stick_l" if is_left else "stick_r")
	var sr := _sr_l if is_left else _sr_r                  # THIS stick's radius
	var knob_r := 34.0 * sr / BASE_STICK_RADIUS            # knob scales with its own stick only
	var ring := COL_ACTIVE if down else COL_IDLE
	if is_left and down and player != null and player.get("_touch_flying") == true:
		ring = COL_FLY
	elif (not is_left) and down and fire_held:
		ring = COL_FIRE
	_dcircle(base, sr + 6.0, Color(ring.r, ring.g, ring.b, 0.12 if down else 0.07))
	_darc(base, sr + 6.0, 0.0, TAU, 48, ring, 2.0, true)
	if not is_left:
		# inner circle: stay inside to aim, drag out past it to shoot
		_darc(base, sr * FIRE_RING, 0.0, TAU, 40, Color(1.0, 0.7, 0.4, 0.75 if down else 0.45), 2.5, true)

	var knob := base
	if down:
		knob = base + (pos - base).limit_length(sr)
	if down:
		_dcircle(knob, knob_r + 12.0, Color(ring.r, ring.g, ring.b, 0.14))      # soft glow while held
	_dcircle(knob + Vector2(0, 4), knob_r + 1.0, Color(0, 0, 0, 0.28))           # drop shadow
	_dcircle(knob, knob_r, Color(ring.r, ring.g, ring.b, 0.62 if down else 0.30))
	_dcircle(knob + Vector2(-knob_r * 0.28, -knob_r * 0.32), knob_r * 0.42, Color(1, 1, 1, 0.14))   # highlight
	_darc(knob, knob_r, 0.0, TAU, 32, Color(1, 1, 1, 0.5 if down else 0.28), 1.5, true)

	if not down and _labels:
		var txt := "RUN / FLY" if is_left else "AIM / FIRE"
		_text(base + Vector2(0, sr + 26.0), txt, 13, Color(1, 1, 1, 0.45), true)
		if is_left:
			# up arrow: "drag up to fly"
			var a := base + Vector2(0, -sr - 22.0)
			_dpoly(PackedVector2Array([a + Vector2(0, -9), a + Vector2(10, 7), a + Vector2(-10, 7)]), Color(1, 1, 1, 0.35))


func _draw_round(id: String, label: String, lit: bool) -> void:
	_begin_control(id)
	var b: Dictionary = _btn[id]
	var c: Vector2 = b["c"]
	var r: float = b["r"]
	var fill := COL_BTN_ON if lit else COL_BTN
	if _btn_touch.has(id):
		fill = Color(1, 1, 1, 0.40)
		r *= 0.93                                  # press-down feel
	_shadow(c, r)
	_dcircle(c, r, fill)
	_darc(c, r, 0.0, TAU, 40, COL_EDGE, 1.5, true)
	_text(c + Vector2(0, 5), label, 12 if r < 36.0 else 14, Color(1, 1, 1, 0.95), true)


func _draw_zoom() -> void:
	_draw_round("zoom_in", "ZOOM +", false)
	_draw_round("zoom_out", "ZOOM -", false)
	var cz: Node = player.get_node_or_null("CameraZoom") if player != null else null
	_begin_control("zoom_in")
	if cz != null:
		var top: Dictionary = _btn["zoom_in"]
		var tc: Vector2 = top["c"]
		_text(tc + Vector2(0, -float(top["r"]) - 8.0), "VIEW %sx" % String.num(cz.view_value(), 2), 12, Color(0.8, 1, 0.95, 0.9), true)


# FIRE MODE: shows the selected mode (SEMI / BURST / AUTO) in big letters; tap to switch. It dims while you are
# shooting, because the game ignores mode changes while the trigger is held.
func _draw_firemode() -> void:
	_begin_control("firemode")
	var b: Dictionary = _btn["firemode"]
	var c: Vector2 = b["c"]
	var r: float = b["r"]
	var busy: bool = player != null and not edit_mode and player.fire_held_now()
	var fill := Color(0.95, 0.72, 0.2, 0.28) if busy else Color(0.95, 0.72, 0.2, 0.55)
	if edit_mode:
		fill = COL_BTN
	if _btn_touch.has("firemode"):
		fill = Color(1, 1, 1, 0.45)
	_shadow(c, r)
	_dcircle(c, r, fill)
	_darc(c, r, 0.0, TAU, 40, Color(1, 0.85, 0.4, 0.95) if not edit_mode else COL_EDGE, 2.5, true)
	var label: String = "MODE" if edit_mode or player == null else player.fire_mode_text()
	_text(c + Vector2(0, -2), label, 13, Color(1, 1, 1, 0.98), true)
	_text(c + Vector2(0, 13), "FIRE", 10, Color(1, 1, 1, 0.7), true)


func _draw_dual() -> void:
	_begin_control("dual")
	var b: Dictionary = _btn["dual"]
	var c: Vector2 = b["c"]
	var r: float = b["r"]
	var pulse := 0.5 + 0.5 * sin(_now() * 8.0)
	var fill := Color(0.30, 0.62, 0.95, 0.55 + 0.2 * pulse)
	if edit_mode:
		fill = COL_BTN
	if _btn_touch.has("dual"):
		fill = Color(1, 1, 1, 0.45)
	_shadow(c, r)
	_dcircle(c, r, fill)
	_darc(c, r, 0.0, TAU, 40, Color(0.6, 0.85, 1.0, 0.95) if not edit_mode else COL_EDGE, 2.5, true)
	_text(c + Vector2(0, -2), "DUAL", 12, Color(1, 1, 1, 0.95), true)
	_text(c + Vector2(0, 13), "WIELD", 12, Color(1, 1, 1, 0.95), true)


func _draw_pickup() -> void:
	_begin_control("pickup")
	var b: Dictionary = _btn["pickup"]
	var c: Vector2 = b["c"]
	var r: float = b["r"]
	var near := not edit_mode            # it is only drawn while a gun is within reach
	var pulse := 0.5 + 0.5 * sin(_now() * 8.0)
	var fill := COL_BTN
	if near:
		fill = Color(0.95, 0.54, 0.18, 0.55 + 0.25 * pulse)
	if _btn_touch.has("pickup"):
		fill = Color(1, 1, 1, 0.45)
	_shadow(c, r)
	_dcircle(c, r, fill)
	_darc(c, r, 0.0, TAU, 40, COL_EDGE if not near else Color(1, 0.8, 0.4, 0.95), 2.5, true)
	_text(c + Vector2(0, -2), "PICK", 13, Color(1, 1, 1, 0.95), true)
	_text(c + Vector2(0, 14), "UP", 13, Color(1, 1, 1, 0.95), true)


func _draw_weapon_box() -> void:
	_begin_control("weapon")
	var rect: Rect2 = (_btn["weapon"] as Dictionary)["rect"]
	_style.bg_color = Color(1, 1, 1, 0.30) if _btn_touch.has("weapon") else COL_BTN
	_dstyle(rect)
	if player == null or player.weapon == null:
		return
	var w: WeaponData = player.weapon
	if player.dual and player.off_weapon != null:
		# dual wielding: both guns, each with its own ammo, stacked
		_draw_gun_icon(w, Rect2(rect.position.x + 8.0, rect.position.y + 4.0, 84.0, rect.size.y * 0.5 - 5.0))
		_draw_gun_icon(player.off_weapon, Rect2(rect.position.x + 8.0, rect.position.y + rect.size.y * 0.5 + 1.0, 84.0, rect.size.y * 0.5 - 5.0))
		_text(Vector2(rect.position.x + 140.0, rect.position.y + 23.0), _hand_ammo(player.ammo, player.reserve, player.reloading), 14, Color(1, 1, 1, 0.95), true)
		_text(Vector2(rect.position.x + 140.0, rect.position.y + 47.0), _hand_ammo(player.off_ammo, player.off_reserve, player.off_reloading), 14, Color(1, 1, 1, 0.95), true)
		return
	_draw_gun_icon(w, Rect2(rect.position.x + 8.0, rect.position.y + 7.0, 84.0, rect.size.y - 14.0))
	var ammo_txt := "%d / %d" % [player.ammo, player.reserve]
	var col := Color(1, 1, 1, 0.95)
	if player.reloading:
		ammo_txt = "RELOAD"
		col = Color(1.0, 0.8, 0.4, 1.0)
	elif player.ammo == 0 and player.reserve == 0:
		ammo_txt = "NO AMMO"
		col = Color(1.0, 0.4, 0.4, 1.0)
	_text(Vector2(rect.position.x + 140.0, rect.position.y + 28.0), ammo_txt, 16, col, true)
	var sub := "TAP: SWAP" if player.weapons.size() >= 2 else w.display_name.to_upper()
	_text(Vector2(rect.position.x + 140.0, rect.position.y + 48.0), sub, 11, Color(1, 1, 1, 0.6), true)


# Draws a gun picture scaled to fit a box, keeping its proportions.
func _draw_gun_icon(w: WeaponData, box: Rect2) -> void:
	if w == null or w.texture == null:
		return
	var tex_size := w.texture.get_size()
	var s := minf(box.size.x / tex_size.x, box.size.y / tex_size.y)
	var sz := tex_size * s
	var tl := Vector2(box.position.x + (box.size.x - sz.x) * 0.5, box.position.y + (box.size.y - sz.y) * 0.5)
	_dtex(w.texture, Rect2(tl, sz), false)


func _hand_ammo(a: int, r: int, is_reloading: bool) -> String:
	if is_reloading:
		return "RELOAD"
	if a == 0 and r == 0:
		return "NO AMMO"
	return "%d / %d" % [a, r]


func _draw_throw() -> void:
	var t: ThrowableData = player.current_throwable() if player != null else null
	var count := 0
	if t != null:
		count = int(player._throw_counts.get(t, 0))

	# big THROW button
	_begin_control("throw")
	var b: Dictionary = _btn["throw"]
	var c: Vector2 = b["c"]
	var r: float = b["r"]
	var fill := Color(0.75, 0.2, 0.15, 0.55) if count > 0 else COL_BTN
	if _btn_touch.has("throw"):
		fill = Color(1, 1, 1, 0.45)
	_shadow(c, r)
	_dcircle(c, r, fill)
	_darc(c, r, 0.0, TAU, 40, COL_EDGE, 2.0, true)
	if t != null and t.icon != null:
		var isz := 40.0
		_dtex(t.icon, Rect2(c - Vector2(isz * 0.5, isz * 0.5 + 6.0), Vector2(isz, isz)), false, Color(1, 1, 1, 1.0 if count > 0 else 0.4))
	_text(c + Vector2(0, 28), "THROW x%d" % count, 12, Color(1, 1, 1, 0.95), true)

	_begin_control("throw_type")
	# grenade selector: tap the grenade icon to change type (dim when there is nothing to switch to)
	var s: Dictionary = _btn["throw_type"]
	var sc: Vector2 = s["c"]
	var sr: float = s["r"]
	var can_switch: bool = player != null and player.throwable_loadout.size() >= 2
	var sf := Color(1, 1, 1, 0.45) if _btn_touch.has("throw_type") else COL_BTN
	_shadow(sc, sr)
	_dcircle(sc, sr, sf)
	_darc(sc, sr, 0.0, TAU, 32, COL_EDGE, 2.0, true)
	if t != null and t.icon != null:
		_dtex(t.icon, Rect2(sc - Vector2(15, 15), Vector2(30, 30)), false, Color(1, 1, 1, 1.0 if can_switch else 0.55))
	if can_switch:
		# circular "change" arrow around the icon
		_darc(sc, sr + 5.0, -0.4, 4.2, 24, Color(1, 1, 1, 0.6), 2.0, true)
		var tip := sc + Vector2(cos(4.2), sin(4.2)) * (sr + 5.0)
		_dpoly(PackedVector2Array([tip + Vector2(-6, -2), tip + Vector2(6, -3), tip + Vector2(0, 7)]), Color(1, 1, 1, 0.7))


func _text(pos: Vector2, text: String, size: int, color: Color, centered := false) -> void:
	var width := 300.0
	var p := pos
	var align := HORIZONTAL_ALIGNMENT_LEFT
	if centered:
		p = pos - Vector2(width * 0.5, 0.0)
		align = HORIZONTAL_ALIGNMENT_CENTER
	draw_string_outline(_font, p, text, align, width, size, 4, Color(0, 0, 0, 0.55 * _alpha))
	draw_string(_font, p, text, align, width, size, _fade(color))


# ---- draw helpers: the same draw_* calls, faded by the opacity of the control being drawn (_alpha) ----
func _fade(c: Color) -> Color:
	return Color(c.r, c.g, c.b, c.a * _alpha)


func _shadow(center: Vector2, radius: float) -> void:
	_dcircle(center + Vector2(0, 4), radius + 1.0, Color(0, 0, 0, 0.26))


func _dcircle(center: Vector2, radius: float, color: Color) -> void:
	draw_circle(center, radius, _fade(color))


func _darc(center: Vector2, radius: float, start: float, end: float, points: int, color: Color, width: float, aa: bool) -> void:
	draw_arc(center, radius, start, end, points, _fade(color), width, aa)


func _dpoly(points: PackedVector2Array, color: Color) -> void:
	draw_colored_polygon(points, _fade(color))


func _dtex(tex: Texture2D, rect: Rect2, tile: bool, mod := Color(1, 1, 1, 1)) -> void:
	draw_texture_rect(tex, rect, tile, _fade(mod))


func _dstyle(rect: Rect2) -> void:
	var bg := _style.bg_color
	var bd := _style.border_color
	_style.bg_color = _fade(bg)
	_style.border_color = _fade(bd)
	draw_style_box(_style, rect)
	_style.bg_color = bg
	_style.border_color = bd
