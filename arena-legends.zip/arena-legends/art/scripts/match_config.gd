class_name MatchConfig
extends RefCounted
## Central match configuration used by offline modes and (where applicable) LAN host settings.
## One source of truth so UI, spawners, match manager and bots all read the same values.

const MapRegistry = preload("res://art/scripts/map_registry.gd")

# ---- game mode ----
enum Mode { SURVIVAL, DEATHMATCH, TRAINING, CUSTOM }
var mode: Mode = Mode.DEATHMATCH

# ---- map ----
var map_id: String = "abandoned_station"

# ---- victory conditions ----
## Seconds. 0 = no time limit.
var duration_sec: int = 300
## 0 = unlimited kills.
var kill_limit: int = 10

# ---- player ----
var player_start_health: float = 100.0
var player_respawn: bool = true
var player_respawn_delay: float = 3.0
var health_regen: bool = false
var out_of_bounds_damage: bool = true

# ---- bots ----
var bot_count: int = 3
var bot_difficulty: int = 1          # 0 Rookie .. 3 Legend (matches GameSettings / BotDifficulty)
var bot_respawn: bool = true
var bot_respawn_delay: float = 3.0

# ---- weapons ----
## 0 = off, 1 = low, 2 = normal, 3 = high, 4 = very high
var weapon_spawn_rate: int = 2
var max_weapon_pickups: int = 10
## Empty array = ALL weapons. Explicit list of catalog ids when custom.
var allowed_weapons: PackedStringArray = PackedStringArray()
var weapons_all: bool = true
var weapons_none: bool = false

# ---- throwables ----
## 0 = off, 1 = low, 2 = normal, 3 = high, 4 = very high
var throwable_spawn_rate: int = 2
var max_throwable_pickups: int = 6
var allowed_throwables: PackedStringArray = PackedStringArray()
var throwables_all: bool = true
var throwables_none: bool = false
## Category shortcuts: "grenades", "explosives", "tactical", "" = custom/all
var throwable_category: String = ""

# ---- loadouts ----
var use_loadouts: bool = false
var selected_loadout_id: String = ""

# ---- gameplay modifiers (experimental) ----
var mod_unlimited_ammo: bool = false
var mod_infinite_grenades: bool = false
var mod_infinite_jetpack: bool = false
var mod_infinite_health: bool = false
var mod_no_reload: bool = false
var mod_increased_damage: bool = false
var mod_low_gravity: bool = false
var mod_fast_movement: bool = false
var mod_increased_explosion: bool = false
var mod_no_respawn_delay: bool = false
var mod_all_weapons: bool = false
var mod_all_throwables: bool = false

# ---- helpers ----
const DURATION_OPTIONS := [120, 300, 600, 900, 1200, 0]   # 2,5,10,15,20 min, unlimited
const DURATION_LABELS := ["2 min", "5 min", "10 min", "15 min", "20 min", "No limit"]
const KILL_OPTIONS := [5, 10, 15, 20, 30, 50, 0]
const KILL_LABELS := ["5", "10", "15", "20", "30", "50", "Unlimited"]
const RATE_LABELS := ["Off", "Low", "Normal", "High", "Very High"]
const BOT_COUNT_OPTIONS := [0, 1, 2, 3, 4, 5, 6, 8, 10]
const MAX_PICKUP_OPTIONS := [3, 5, 10, 15, 20, 99]

static func mode_name(m: Mode) -> String:
	match m:
		Mode.SURVIVAL: return "Survival"
		Mode.DEATHMATCH: return "Deathmatch"
		Mode.TRAINING: return "Training"
		Mode.CUSTOM: return "Custom Match"
	return "Custom"


func duplicate_config() -> MatchConfig:
	var c := MatchConfig.new()
	c.mode = mode
	c.map_id = map_id
	c.duration_sec = duration_sec
	c.kill_limit = kill_limit
	c.player_start_health = player_start_health
	c.player_respawn = player_respawn
	c.player_respawn_delay = player_respawn_delay
	c.health_regen = health_regen
	c.out_of_bounds_damage = out_of_bounds_damage
	c.bot_count = bot_count
	c.bot_difficulty = bot_difficulty
	c.bot_respawn = bot_respawn
	c.bot_respawn_delay = bot_respawn_delay
	c.weapon_spawn_rate = weapon_spawn_rate
	c.max_weapon_pickups = max_weapon_pickups
	c.allowed_weapons = allowed_weapons.duplicate()
	c.weapons_all = weapons_all
	c.weapons_none = weapons_none
	c.throwable_spawn_rate = throwable_spawn_rate
	c.max_throwable_pickups = max_throwable_pickups
	c.allowed_throwables = allowed_throwables.duplicate()
	c.throwables_all = throwables_all
	c.throwables_none = throwables_none
	c.throwable_category = throwable_category
	c.use_loadouts = use_loadouts
	c.selected_loadout_id = selected_loadout_id
	c.mod_unlimited_ammo = mod_unlimited_ammo
	c.mod_infinite_grenades = mod_infinite_grenades
	c.mod_infinite_jetpack = mod_infinite_jetpack
	c.mod_infinite_health = mod_infinite_health
	c.mod_no_reload = mod_no_reload
	c.mod_increased_damage = mod_increased_damage
	c.mod_low_gravity = mod_low_gravity
	c.mod_fast_movement = mod_fast_movement
	c.mod_increased_explosion = mod_increased_explosion
	c.mod_no_respawn_delay = mod_no_respawn_delay
	c.mod_all_weapons = mod_all_weapons
	c.mod_all_throwables = mod_all_throwables
	return c


func to_dict() -> Dictionary:
	return {
		"mode": int(mode),
		"map_id": map_id,
		"duration_sec": duration_sec,
		"kill_limit": kill_limit,
		"player_start_health": player_start_health,
		"player_respawn": player_respawn,
		"player_respawn_delay": player_respawn_delay,
		"health_regen": health_regen,
		"out_of_bounds_damage": out_of_bounds_damage,
		"bot_count": bot_count,
		"bot_difficulty": bot_difficulty,
		"bot_respawn": bot_respawn,
		"bot_respawn_delay": bot_respawn_delay,
		"weapon_spawn_rate": weapon_spawn_rate,
		"max_weapon_pickups": max_weapon_pickups,
		"allowed_weapons": Array(allowed_weapons),
		"weapons_all": weapons_all,
		"weapons_none": weapons_none,
		"throwable_spawn_rate": throwable_spawn_rate,
		"max_throwable_pickups": max_throwable_pickups,
		"allowed_throwables": Array(allowed_throwables),
		"throwables_all": throwables_all,
		"throwables_none": throwables_none,
		"throwable_category": throwable_category,
		"use_loadouts": use_loadouts,
		"selected_loadout_id": selected_loadout_id,
		"mod_unlimited_ammo": mod_unlimited_ammo,
		"mod_infinite_grenades": mod_infinite_grenades,
		"mod_infinite_jetpack": mod_infinite_jetpack,
		"mod_infinite_health": mod_infinite_health,
		"mod_no_reload": mod_no_reload,
		"mod_increased_damage": mod_increased_damage,
		"mod_low_gravity": mod_low_gravity,
		"mod_fast_movement": mod_fast_movement,
		"mod_increased_explosion": mod_increased_explosion,
		"mod_no_respawn_delay": mod_no_respawn_delay,
		"mod_all_weapons": mod_all_weapons,
		"mod_all_throwables": mod_all_throwables,
	}


static func from_dict(d: Dictionary) -> MatchConfig:
	var c := MatchConfig.new()
	if d.is_empty():
		return c
	c.mode = int(d.get("mode", Mode.DEATHMATCH)) as Mode
	c.map_id = str(d.get("map_id", "abandoned_station"))
	c.duration_sec = int(d.get("duration_sec", 300))
	c.kill_limit = int(d.get("kill_limit", 10))
	c.player_start_health = float(d.get("player_start_health", 100.0))
	c.player_respawn = bool(d.get("player_respawn", true))
	c.player_respawn_delay = float(d.get("player_respawn_delay", 3.0))
	c.health_regen = bool(d.get("health_regen", false))
	c.out_of_bounds_damage = bool(d.get("out_of_bounds_damage", true))
	c.bot_count = clampi(int(d.get("bot_count", 3)), 0, 10)
	c.bot_difficulty = clampi(int(d.get("bot_difficulty", 1)), 0, 3)
	c.bot_respawn = bool(d.get("bot_respawn", true))
	c.bot_respawn_delay = float(d.get("bot_respawn_delay", 3.0))
	c.weapon_spawn_rate = clampi(int(d.get("weapon_spawn_rate", 2)), 0, 4)
	c.max_weapon_pickups = int(d.get("max_weapon_pickups", 10))
	var aw: Array = d.get("allowed_weapons", [])
	c.allowed_weapons = PackedStringArray(aw)
	c.weapons_all = bool(d.get("weapons_all", true))
	c.weapons_none = bool(d.get("weapons_none", false))
	c.throwable_spawn_rate = clampi(int(d.get("throwable_spawn_rate", 2)), 0, 4)
	c.max_throwable_pickups = int(d.get("max_throwable_pickups", 6))
	var at: Array = d.get("allowed_throwables", [])
	c.allowed_throwables = PackedStringArray(at)
	c.throwables_all = bool(d.get("throwables_all", true))
	c.throwables_none = bool(d.get("throwables_none", false))
	c.throwable_category = str(d.get("throwable_category", ""))
	c.use_loadouts = bool(d.get("use_loadouts", false))
	c.selected_loadout_id = str(d.get("selected_loadout_id", ""))
	c.mod_unlimited_ammo = bool(d.get("mod_unlimited_ammo", false))
	c.mod_infinite_grenades = bool(d.get("mod_infinite_grenades", false))
	c.mod_infinite_jetpack = bool(d.get("mod_infinite_jetpack", false))
	c.mod_infinite_health = bool(d.get("mod_infinite_health", false))
	c.mod_no_reload = bool(d.get("mod_no_reload", false))
	c.mod_increased_damage = bool(d.get("mod_increased_damage", false))
	c.mod_low_gravity = bool(d.get("mod_low_gravity", false))
	c.mod_fast_movement = bool(d.get("mod_fast_movement", false))
	c.mod_increased_explosion = bool(d.get("mod_increased_explosion", false))
	c.mod_no_respawn_delay = bool(d.get("mod_no_respawn_delay", false))
	c.mod_all_weapons = bool(d.get("mod_all_weapons", false))
	c.mod_all_throwables = bool(d.get("mod_all_throwables", false))
	return c


## Returns weapon ids that should actually be allowed to spawn given current flags.
func effective_weapon_ids() -> PackedStringArray:
	if weapons_none and not mod_all_weapons:
		return PackedStringArray()
	if weapons_all or mod_all_weapons or allowed_weapons.is_empty():
		var all_ids: PackedStringArray = PackedStringArray()
		for id in WeaponCatalog.PATHS:
			all_ids.append(id)
		return all_ids
	return allowed_weapons


## Returns throwable ids allowed on the chosen map given current flags.
func effective_throwable_ids() -> PackedStringArray:
	if throwables_none and not mod_all_throwables:
		return PackedStringArray()
	var map_pool: Array[ThrowableData] = ThrowableCatalog.for_map(map_id)
	if throwables_all or mod_all_throwables or (allowed_throwables.is_empty() and throwable_category == ""):
		var ids: PackedStringArray = PackedStringArray()
		for d in map_pool:
			ids.append(d.catalog_id)
		return ids
	if throwable_category != "":
		return _throwables_in_category(throwable_category, map_pool)
	var out: PackedStringArray = PackedStringArray()
	for id in allowed_throwables:
		for d in map_pool:
			if d.catalog_id == id:
				out.append(id)
				break
	return out


func _throwables_in_category(cat: String, pool: Array[ThrowableData]) -> PackedStringArray:
	# Categories based on actual gameplay function
	var grenades := ["grenade", "knockback", "incendiary", "toxic", "cryo"]
	var explosives := ["grenade", "knockback", "incendiary", "gravity", "trap_mine"]
	var tactical := ["smoke", "decoy", "emp", "flight_disruption", "portal", "toxic", "cryo"]
	var list: Array
	match cat:
		"grenades": list = grenades
		"explosives": list = explosives
		"tactical": list = tactical
		_: list = []
	var out: PackedStringArray = PackedStringArray()
	for d in pool:
		if list.has(d.catalog_id):
			out.append(d.catalog_id)
	return out


## Interval multiplier / absolute values for spawn rates (0 = off).
func weapon_interval() -> float:
	match weapon_spawn_rate:
		0: return 99999.0
		1: return 18.0
		2: return 9.0
		3: return 5.0
		4: return 2.5
	return 9.0


func throwable_interval() -> float:
	match throwable_spawn_rate:
		0: return 99999.0
		1: return 14.0
		2: return 7.0
		3: return 4.0
		4: return 2.0
	return 7.0


func validate() -> PackedStringArray:
	var errors: PackedStringArray = PackedStringArray()
	if MapRegistry.get_map(map_id).is_empty():
		errors.append("Unknown map: %s" % map_id)
	if bot_count < 0 or bot_count > 10:
		errors.append("Bot count out of range")
	if use_loadouts and selected_loadout_id != "":
		var ld := LoadoutStore.get_loadout(selected_loadout_id)
		if ld.is_empty():
			errors.append("Selected loadout not found")
		else:
			# check map-compatible throwables
			for tid in [ld.get("throwable1", ""), ld.get("throwable2", "")]:
				if tid == "":
					continue
				var td := ThrowableCatalog.get_data(tid)
				if td != null and not ThrowableCatalog.can_spawn_on(td, map_id):
					errors.append("Loadout throwable '%s' is not available on %s" % [tid, map_id])
	return errors


## Built-in starting presets.
static func builtin_presets() -> Array[Dictionary]:
	var list: Array[Dictionary] = []
	# Classic
	var c := MatchConfig.new()
	c.mode = Mode.DEATHMATCH
	c.duration_sec = 300
	c.kill_limit = 10
	c.bot_count = 3
	c.bot_difficulty = 1
	list.append({"id": "classic", "name": "Classic", "config": c})
	# Quick Match
	c = MatchConfig.new()
	c.mode = Mode.DEATHMATCH
	c.duration_sec = 120
	c.kill_limit = 10
	c.bot_count = 3
	c.bot_difficulty = 1
	list.append({"id": "quick", "name": "Quick Match", "config": c})
	# Long Battle
	c = MatchConfig.new()
	c.mode = Mode.DEATHMATCH
	c.duration_sec = 900
	c.kill_limit = 30
	c.bot_count = 5
	c.bot_difficulty = 2
	list.append({"id": "long", "name": "Long Battle", "config": c})
	# Weapon Frenzy
	c = MatchConfig.new()
	c.mode = Mode.DEATHMATCH
	c.duration_sec = 300
	c.kill_limit = 20
	c.weapon_spawn_rate = 4
	c.throwable_spawn_rate = 1
	c.bot_count = 4
	list.append({"id": "frenzy", "name": "Weapon Frenzy", "config": c})
	# Grenade Mayhem
	c = MatchConfig.new()
	c.mode = Mode.DEATHMATCH
	c.duration_sec = 300
	c.kill_limit = 15
	c.throwable_spawn_rate = 4
	c.throwable_category = "grenades"
	c.throwables_all = false
	c.weapon_spawn_rate = 1
	c.bot_count = 4
	list.append({"id": "grenade", "name": "Grenade Mayhem", "config": c})
	# Portal Chaos
	c = MatchConfig.new()
	c.mode = Mode.DEATHMATCH
	c.duration_sec = 300
	c.kill_limit = 15
	c.map_id = "abandoned_station"
	c.throwables_all = false
	c.throwables_none = false
	c.allowed_throwables = PackedStringArray(["portal"])
	c.throwable_spawn_rate = 3
	c.bot_count = 3
	list.append({"id": "portal", "name": "Portal Chaos", "config": c})
	# Tactical Combat
	c = MatchConfig.new()
	c.mode = Mode.DEATHMATCH
	c.duration_sec = 600
	c.kill_limit = 20
	c.throwable_category = "tactical"
	c.throwables_all = false
	c.bot_difficulty = 2
	c.bot_count = 4
	list.append({"id": "tactical", "name": "Tactical Combat", "config": c})
	# Unlimited Fun
	c = MatchConfig.new()
	c.mode = Mode.CUSTOM
	c.duration_sec = 0
	c.kill_limit = 0
	c.mod_unlimited_ammo = true
	c.mod_infinite_jetpack = true
	c.mod_infinite_grenades = true
	c.bot_count = 5
	list.append({"id": "unlimited", "name": "Unlimited Fun", "config": c})
	# Sniper Battle
	c = MatchConfig.new()
	c.mode = Mode.DEATHMATCH
	c.duration_sec = 600
	c.kill_limit = 15
	c.weapons_all = false
	c.allowed_weapons = PackedStringArray(["barrett_m82", "svd_dragunov"])
	c.weapon_spawn_rate = 3
	c.throwable_spawn_rate = 1
	c.bot_count = 4
	c.bot_difficulty = 2
	list.append({"id": "sniper", "name": "Sniper Battle", "config": c})
	# Heavy Weapons
	c = MatchConfig.new()
	c.mode = Mode.DEATHMATCH
	c.duration_sec = 300
	c.kill_limit = 15
	c.weapons_all = false
	c.allowed_weapons = PackedStringArray(["m249", "rpg7", "spas12", "double_barrel"])
	c.weapon_spawn_rate = 3
	c.bot_count = 4
	list.append({"id": "heavy", "name": "Heavy Weapons", "config": c})
	return list
