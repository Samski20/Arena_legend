extends Node
## Attached as a child of a player CharacterBody2D when multiplayer is active.
## Handles authority, input routing, state replication, and combat RPCs.
## Host is authority for damage / death / pickups; movement is interpolated for remotes.

class_name NetPlayer

const SYNC_RATE := 20.0  # Hz for movement state
const INTERP_BUFFER := 0.1

var player: CharacterBody2D = null
var peer_id: int = 1
var is_local: bool = true
var is_authority: bool = true  # host or offline

var _sync_accum: float = 0.0
var _target_pos: Vector2 = Vector2.ZERO
var _target_vel: Vector2 = Vector2.ZERO
var _target_facing: float = 1.0
var _remote_jet: bool = false
var _has_target: bool = false

# Last known remote state for interpolation
var _from_pos: Vector2 = Vector2.ZERO
var _from_vel: Vector2 = Vector2.ZERO
var _interp_t: float = 0.0
var _interp_dur: float = 1.0 / SYNC_RATE


func setup(p: CharacterBody2D, id: int, local: bool) -> void:
	player = p
	peer_id = id
	is_local = local
	is_authority = multiplayer.is_server() if multiplayer.has_multiplayer_peer() else true
	name = "NetPlayer_%d" % id
	# Only local player processes input; remotes are driven by network
	if not is_local:
		player.set_physics_process(true)  # still run physics for interpolation
		# Disable local input helpers if present
		if player.has_method("on_touch_mode_changed"):
			pass
	_target_pos = player.global_position
	_from_pos = player.global_position


func _physics_process(delta: float) -> void:
	if player == null or not is_instance_valid(player):
		return
	if player.get("is_dead"):
		return

	if is_local:
		_sync_accum += delta
		if _sync_accum >= 1.0 / SYNC_RATE:
			_sync_accum = 0.0
			_send_state()
	else:
		# Interpolate remote player
		if _has_target:
			_interp_t += delta
			var t := clampf(_interp_t / _interp_dur, 0.0, 1.0)
			# Smoothstep
			t = t * t * (3.0 - 2.0 * t)
			player.global_position = _from_pos.lerp(_target_pos, t)
			player.velocity = _from_vel.lerp(_target_vel, t)
			# Facing
			if player.has_node("Visuals"):
				var vis = player.get_node("Visuals")
				if vis.has_method("set_facing"):
					vis.set_facing(_target_facing)
				elif "scale" in vis:
					vis.scale.x = absf(vis.scale.x) * signf(_target_facing) if _target_facing != 0 else vis.scale.x
			if "jetpack_active" in player:
				player.jetpack_active = _remote_jet


func _send_state() -> void:
	if not multiplayer.has_multiplayer_peer():
		return
	var facing := 1.0
	if player.has_node("Visuals"):
		var vis = player.get_node("Visuals")
		if "scale" in vis:
			facing = signf(vis.scale.x)
	var jet := bool(player.get("jetpack_active")) if "jetpack_active" in player else false
	var fuel := float(player.get("fuel")) if "fuel" in player else 100.0
	var hp := int(player.get("health")) if "health" in player else 100
	_replicate_state.rpc(player.global_position, player.velocity, facing, jet, fuel, hp)


@rpc("any_peer", "unreliable_ordered")
func _replicate_state(pos: Vector2, vel: Vector2, facing: float, jet: bool, fuel: float, hp: int) -> void:
	var sender := multiplayer.get_remote_sender_id()
	# Only accept state from the owning peer (or host correcting)
	if sender != peer_id and not multiplayer.is_server():
		return
	if is_local:
		return  # never overwrite local player with network
	_from_pos = player.global_position
	_from_vel = player.velocity
	_target_pos = pos
	_target_vel = vel
	_target_facing = facing
	_remote_jet = jet
	_interp_t = 0.0
	_has_target = true
	if "fuel" in player:
		player.fuel = fuel
	if "health" in player and multiplayer.is_server():
		# Host may keep authoritative health; clients show replicated
		pass
	elif "health" in player:
		player.health = hp
		if player.has_node("HealthBar"):
			player.get_node("HealthBar").value = hp


# ---------------------------------------------------------------------------
# COMBAT: clients request, host validates
# ---------------------------------------------------------------------------
func request_shoot(dir: Vector2, muzzle_pos: Vector2, weapon_id: String = "") -> void:
	if is_local:
		if multiplayer.has_multiplayer_peer() and not multiplayer.is_server():
			_rpc_request_shoot.rpc_id(1, dir, muzzle_pos, weapon_id)
		else:
			# Host or offline: fire immediately and replicate
			_do_shoot(dir, muzzle_pos, weapon_id)
			if multiplayer.has_multiplayer_peer():
				_rpc_show_shot.rpc(dir, muzzle_pos, weapon_id)


@rpc("any_peer", "reliable")
func _rpc_request_shoot(dir: Vector2, muzzle_pos: Vector2, weapon_id: String) -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	if sender != peer_id:
		return
	_do_shoot(dir, muzzle_pos, weapon_id)
	_rpc_show_shot.rpc(dir, muzzle_pos, weapon_id)


@rpc("authority", "call_local", "unreliable")
func _rpc_show_shot(dir: Vector2, muzzle_pos: Vector2, weapon_id: String) -> void:
	# Visual only on non-firing peers (firing peer already spawned locally if host)
	if is_local and multiplayer.is_server():
		return
	_do_shoot(dir, muzzle_pos, weapon_id)


func _do_shoot(dir: Vector2, muzzle_pos: Vector2, _weapon_id: String) -> void:
	if player == null or not player.has_method("shoot"):
		return
	# Use existing shoot path; for remote we may need a visual-only path
	if is_local or multiplayer.is_server():
		player.shoot(dir)
	else:
		# Remote visual: spawn a bullet without damage authority on client
		if player.get("bullet_scene"):
			var bullet = player.bullet_scene.instantiate()
			bullet.global_position = muzzle_pos
			if bullet.has_method("setup") and player.get("weapon"):
				bullet.setup(player.weapon, dir, player)
				# Mark as remote so damage is not applied twice
				if "is_remote" in bullet:
					bullet.is_remote = true
			player.get_tree().current_scene.add_child(bullet)


func request_damage(amount: int, hit_dir: Vector2, attacker_peer: int) -> void:
	if multiplayer.has_multiplayer_peer() and not multiplayer.is_server():
		_rpc_request_damage.rpc_id(1, amount, hit_dir, attacker_peer)
	else:
		_apply_damage(amount, hit_dir, attacker_peer)


@rpc("any_peer", "reliable")
func _rpc_request_damage(amount: int, hit_dir: Vector2, attacker_peer: int) -> void:
	if not multiplayer.is_server():
		return
	_apply_damage(amount, hit_dir, attacker_peer)
	_rpc_apply_damage.rpc(amount, hit_dir, attacker_peer)


@rpc("authority", "call_local", "reliable")
func _rpc_apply_damage(amount: int, hit_dir: Vector2, attacker_peer: int) -> void:
	_apply_damage(amount, hit_dir, attacker_peer)


func _apply_damage(amount: int, hit_dir: Vector2, attacker_peer: int) -> void:
	if player == null or not player.has_method("take_damage"):
		return
	# Resolve attacker node if possible
	if attacker_peer > 0 and player.get_tree():
		for n in player.get_tree().get_nodes_in_group("player"):
			if n.has_node("NetPlayer") and n.get_node("NetPlayer").peer_id == attacker_peer:
				player.last_attacker = n
				break
	player.take_damage(amount, hit_dir)


func request_die() -> void:
	if multiplayer.has_multiplayer_peer() and not multiplayer.is_server():
		_rpc_request_die.rpc_id(1)
	else:
		if player and player.has_method("die"):
			player.die()


@rpc("any_peer", "reliable")
func _rpc_request_die() -> void:
	if not multiplayer.is_server():
		return
	if player and player.has_method("die"):
		player.die()
	_rpc_die.rpc()


@rpc("authority", "call_local", "reliable")
func _rpc_die() -> void:
	if player and player.has_method("die") and not player.get("is_dead"):
		player.die()
