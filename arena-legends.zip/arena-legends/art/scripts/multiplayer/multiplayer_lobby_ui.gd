extends CanvasLayer
## Clean LAN multiplayer lobby UI for Arena Legends (mobile-friendly).
## Host / Join / Lobby screens. Driven by LANMultiplayer instance.

signal back_pressed
signal request_host(port: int, max_players: int, map_id: String, match_time: int)
signal request_join(ip: String, port: int)
signal request_start_match
signal request_leave

const LANScript = preload("res://art/scripts/multiplayer/lan_multiplayer.gd")

var lan: Node = null  # LANMultiplayer instance
var _screen: String = "main"  # main | host | join | lobby
var _root: Control
var _status_label: Label
var _player_list: VBoxContainer
var _ip_edit: LineEdit
var _port_edit: LineEdit
var _name_edit: LineEdit
var _map_option: OptionButton
var _max_option: OptionButton
var _time_option: OptionButton
var _host_info: Label
var _discovered_list: VBoxContainer
var _start_btn: Button
var _map_ids: Array[String] = []
## Display labels for match time options (seconds stored in _time_secs)
var _time_secs: Array[int] = [0, 180, 300, 600, 900]


func _ready() -> void:
	layer = 110
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build_ui()
	visible = false


func bind(lan_node: Node) -> void:
	lan = lan_node
	if lan.has_signal("status_changed"):
		lan.status_changed.connect(_on_status)
	if lan.has_signal("lobby_updated"):
		lan.lobby_updated.connect(_refresh_lobby)
	if lan.has_signal("connected_to_host"):
		lan.connected_to_host.connect(func(): _show_screen("lobby"))
	if lan.has_signal("connection_failed"):
		lan.connection_failed.connect(func(_r): _show_screen("join"))
	if lan.has_signal("match_starting"):
		lan.match_starting.connect(func(_m): visible = false)
	if lan.has_signal("host_started"):
		lan.host_started.connect(func(_ip, _p): _show_screen("lobby"))


func open() -> void:
	visible = true
	_show_screen("main")
	if lan:
		lan.start_client_discovery()
	_refresh_all()


func close() -> void:
	visible = false
	if lan:
		lan.stop_client_discovery()


func _on_status(msg: String) -> void:
	if _status_label:
		_status_label.text = msg


func _show_screen(name: String) -> void:
	_screen = name
	for c in _root.get_children():
		if c is PanelContainer:
			c.visible = (c.name == "Panel_" + name)
	_refresh_all()


func _refresh_all() -> void:
	_refresh_lobby()
	if _screen == "join":
		_refresh_discovered()


func _refresh_lobby() -> void:
	if lan == null or _player_list == null:
		return
	for c in _player_list.get_children():
		c.queue_free()
	for pid in lan.players:
		var info: Dictionary = lan.players[pid]
		var row := HBoxContainer.new()
		# Color swatch
		var swatch := ColorRect.new()
		swatch.custom_minimum_size = Vector2(18, 18)
		swatch.color = lan.get_player_color(int(pid)) if lan.has_method("get_player_color") else Color.WHITE
		row.add_child(swatch)
		var lbl := Label.new()
		var host_tag := " (HOST)" if int(pid) == 1 else ""
		lbl.text = "  %s%s" % [info.get("name", "Player"), host_tag]
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		lbl.add_theme_font_size_override("font_size", 18)
		lbl.add_theme_color_override("font_color", Color("eaf7ff"))
		row.add_child(lbl)
		var st := Label.new()
		st.text = "Connected"
		st.add_theme_font_size_override("font_size", 14)
		st.add_theme_color_override("font_color", Color("7dcea0"))
		row.add_child(st)
		_player_list.add_child(row)
	var time_txt := "No limit"
	if lan.match_time_sec > 0:
		time_txt = "%d:%02d" % [lan.match_time_sec / 60, lan.match_time_sec % 60]
	if _host_info and lan.is_host:
		_host_info.text = "Room: %s\nIP: %s   Port: %d\nMap: %s   Time: %s\nPlayers: %d/%d" % [
			lan.room_name, lan.local_ip, lan.port, lan.map_id, time_txt,
			lan.players.size(), lan.max_players
		]
	elif _host_info:
		_host_info.text = "Connected to room %s\nMap: %s   Time: %s" % [lan.room_name, lan.map_id, time_txt]
	if _start_btn:
		_start_btn.visible = lan != null and lan.is_host
		_start_btn.disabled = lan == null or lan.players.size() < 1


func _refresh_discovered() -> void:
	if _discovered_list == null or lan == null:
		return
	for c in _discovered_list.get_children():
		c.queue_free()
	if lan.discovered_hosts.is_empty():
		var empty := Label.new()
		empty.text = "Scanning LAN... (or enter IP below)"
		empty.add_theme_color_override("font_color", Color("9bc4d8"))
		_discovered_list.add_child(empty)
		return
	for h in lan.discovered_hosts:
		var btn := Button.new()
		btn.text = "%s  —  %s:%d  (%d/%d)  [%s]" % [
			h.get("room", "?"), h.get("ip", ""), h.get("port", 7777),
			h.get("players", 0), h.get("max", 4), h.get("map", "")
		]
		btn.custom_minimum_size = Vector2(0, 44)
		btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		btn.add_theme_font_size_override("font_size", 15)
		btn.add_theme_stylebox_override("normal", _btn_style(Color("253b4b")))
		btn.add_theme_stylebox_override("hover", _btn_style(Color("31586b")))
		var ip: String = h.get("ip", "")
		var port: int = int(h.get("port", 7777))
		btn.pressed.connect(func():
			_ip_edit.text = ip
			_port_edit.text = str(port)
			_on_join_pressed()
		)
		_discovered_list.add_child(btn)


func _build_ui() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0.035, 0.055, 0.075, 0.88)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_root)

	_build_main_panel()
	_build_host_panel()
	_build_join_panel()
	_build_lobby_panel()

	_status_label = Label.new()
	_status_label.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	_status_label.offset_top = -48
	_status_label.offset_bottom = -12
	_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status_label.add_theme_font_size_override("font_size", 15)
	_status_label.add_theme_color_override("font_color", Color("9bc4d8"))
	add_child(_status_label)


func _panel_base(name: String) -> PanelContainer:
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.add_child(center)
	var panel := PanelContainer.new()
	panel.name = "Panel_" + name
	panel.custom_minimum_size = Vector2(460, 0)
	panel.add_theme_stylebox_override("panel", _panel_style())
	center.add_child(panel)
	panel.visible = false
	return panel


func _build_main_panel() -> void:
	var panel := _panel_base("main")
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 14)
	panel.add_child(col)

	_add_title(col, "LAN MULTIPLAYER")
	_add_sub(col, "Same Wi-Fi only  ·  No internet required")

	var host_btn := _make_btn("HOST GAME", Color("2f5a3c"))
	host_btn.pressed.connect(func(): _show_screen("host"))
	col.add_child(host_btn)

	var join_btn := _make_btn("JOIN GAME", Color("2f4f6b"))
	join_btn.pressed.connect(func():
		_show_screen("join")
		if lan:
			lan.start_client_discovery()
	)
	col.add_child(join_btn)

	var back := _make_btn("BACK", Color("3a3a3a"))
	back.pressed.connect(func():
		close()
		back_pressed.emit()
	)
	col.add_child(back)


func _build_host_panel() -> void:
	var panel := _panel_base("host")
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 12)
	panel.add_child(col)

	_add_title(col, "HOST A MATCH")
	_add_sub(col, "You will be the match authority")

	var name_row := HBoxContainer.new()
	name_row.add_child(_lbl("Your name"))
	_name_edit = LineEdit.new()
	_name_edit.text = "Player"
	_name_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_name_edit.custom_minimum_size.y = 40
	name_row.add_child(_name_edit)
	col.add_child(name_row)

	var map_row := HBoxContainer.new()
	map_row.add_child(_lbl("Map"))
	_map_option = OptionButton.new()
	_map_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_map_option.custom_minimum_size.y = 40
	_map_ids.clear()
	const MapRegistry = preload("res://art/scripts/map_registry.gd")
	for m in MapRegistry.all_maps():
		_map_ids.append(m["id"])
		_map_option.add_item(m["name"])
	map_row.add_child(_map_option)
	col.add_child(map_row)

	var max_row := HBoxContainer.new()
	max_row.add_child(_lbl("Max players"))
	_max_option = OptionButton.new()
	_max_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for n in [2, 3, 4, 5, 6]:
		_max_option.add_item(str(n))
	_max_option.select(2)  # 4
	max_row.add_child(_max_option)
	col.add_child(max_row)

	var time_row := HBoxContainer.new()
	time_row.add_child(_lbl("Match time"))
	_time_option = OptionButton.new()
	_time_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_time_option.custom_minimum_size.y = 40
	_time_secs = [0, 180, 300, 600, 900]
	for label in ["No limit", "3 min", "5 min", "10 min", "15 min"]:
		_time_option.add_item(label)
	_time_option.select(2)  # 5 min default
	time_row.add_child(_time_option)
	col.add_child(time_row)

	var port_row := HBoxContainer.new()
	port_row.add_child(_lbl("Port"))
	var port_edit := LineEdit.new()
	port_edit.name = "HostPort"
	port_edit.text = str(LANScript.DEFAULT_PORT)
	port_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	port_edit.custom_minimum_size.y = 40
	port_row.add_child(port_edit)
	col.add_child(port_row)

	var go := _make_btn("CREATE LOBBY", Color("2f5a3c"))
	go.pressed.connect(func():
		if lan:
			lan.player_name = _name_edit.text
		var port := int(port_edit.text) if port_edit.text.is_valid_int() else LANScript.DEFAULT_PORT
		var max_p := int(_max_option.get_item_text(_max_option.selected))
		var mid := _map_ids[_map_option.selected] if _map_option.selected >= 0 else "abandoned_station"
		var tsec := _time_secs[_time_option.selected] if _time_option.selected >= 0 else 300
		request_host.emit(port, max_p, mid, tsec)
	)
	col.add_child(go)

	var back := _make_btn("BACK", Color("3a3a3a"))
	back.pressed.connect(func(): _show_screen("main"))
	col.add_child(back)


func _build_join_panel() -> void:
	var panel := _panel_base("join")
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	panel.add_child(col)

	_add_title(col, "JOIN A MATCH")
	_add_sub(col, "Discovered hosts on this Wi-Fi")

	_discovered_list = VBoxContainer.new()
	_discovered_list.add_theme_constant_override("separation", 6)
	col.add_child(_discovered_list)

	var sep := HSeparator.new()
	col.add_child(sep)

	var name_row := HBoxContainer.new()
	name_row.add_child(_lbl("Your name"))
	var join_name := LineEdit.new()
	join_name.name = "JoinName"
	join_name.text = "Player"
	join_name.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	join_name.custom_minimum_size.y = 40
	name_row.add_child(join_name)
	col.add_child(name_row)

	var ip_row := HBoxContainer.new()
	ip_row.add_child(_lbl("Host IP"))
	_ip_edit = LineEdit.new()
	_ip_edit.placeholder_text = "192.168.x.x"
	_ip_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_ip_edit.custom_minimum_size.y = 40
	ip_row.add_child(_ip_edit)
	col.add_child(ip_row)

	var port_row := HBoxContainer.new()
	port_row.add_child(_lbl("Port"))
	_port_edit = LineEdit.new()
	_port_edit.text = str(LANScript.DEFAULT_PORT)
	_port_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_port_edit.custom_minimum_size.y = 40
	port_row.add_child(_port_edit)
	col.add_child(port_row)

	var go := _make_btn("CONNECT", Color("2f4f6b"))
	go.pressed.connect(_on_join_pressed)
	col.add_child(go)

	var back := _make_btn("BACK", Color("3a3a3a"))
	back.pressed.connect(func(): _show_screen("main"))
	col.add_child(back)


func _on_join_pressed() -> void:
	var name_edit := _root.find_child("JoinName", true, false) as LineEdit
	if lan and name_edit:
		lan.player_name = name_edit.text
	var ip := _ip_edit.text.strip_edges()
	var port := int(_port_edit.text) if _port_edit.text.is_valid_int() else LANScript.DEFAULT_PORT
	if ip.is_empty():
		if _status_label:
			_status_label.text = "Enter the host IP address."
		return
	request_join.emit(ip, port)


func _build_lobby_panel() -> void:
	var panel := _panel_base("lobby")
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 12)
	panel.add_child(col)

	_add_title(col, "LOBBY")
	_host_info = Label.new()
	_host_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_host_info.add_theme_font_size_override("font_size", 15)
	_host_info.add_theme_color_override("font_color", Color("9bc4d8"))
	_host_info.autowrap_mode = TextServer.AUTOWRAP_WORD
	col.add_child(_host_info)

	var list_title := Label.new()
	list_title.text = "PLAYERS"
	list_title.add_theme_font_size_override("font_size", 14)
	list_title.add_theme_color_override("font_color", Color("7a9aab"))
	col.add_child(list_title)

	_player_list = VBoxContainer.new()
	_player_list.add_theme_constant_override("separation", 6)
	col.add_child(_player_list)

	_start_btn = _make_btn("START MATCH", Color("2f5a3c"))
	_start_btn.pressed.connect(func(): request_start_match.emit())
	col.add_child(_start_btn)

	var leave := _make_btn("LEAVE", Color("7a2f2f"))
	leave.pressed.connect(func():
		request_leave.emit()
		_show_screen("main")
	)
	col.add_child(leave)


# --- style helpers ---
func _add_title(col: VBoxContainer, t: String) -> void:
	var heading := Label.new()
	heading.text = t
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	heading.add_theme_font_size_override("font_size", 28)
	heading.add_theme_color_override("font_color", Color("eaf7ff"))
	col.add_child(heading)


func _add_sub(col: VBoxContainer, t: String) -> void:
	var sub := Label.new()
	sub.text = t
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_font_size_override("font_size", 14)
	sub.add_theme_color_override("font_color", Color("9bc4d8"))
	col.add_child(sub)
	col.add_child(HSeparator.new())


func _lbl(t: String) -> Label:
	var l := Label.new()
	l.text = t
	l.custom_minimum_size.x = 110
	l.add_theme_font_size_override("font_size", 15)
	l.add_theme_color_override("font_color", Color("c5dce8"))
	return l


func _make_btn(text: String, tint: Color) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 52)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("font_size", 18)
	b.add_theme_color_override("font_color", Color("f4fbff"))
	b.add_theme_stylebox_override("normal", _btn_style(tint))
	b.add_theme_stylebox_override("hover", _btn_style(tint.lightened(0.12)))
	b.add_theme_stylebox_override("pressed", _btn_style(tint.lightened(0.22)))
	return b


func _panel_style() -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = Color("0f1a22")
	s.set_border_width_all(2)
	s.border_color = Color("2a4a5c")
	s.set_corner_radius_all(12)
	s.set_content_margin_all(20)
	return s


func _btn_style(c: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(8)
	s.set_content_margin_all(10)
	return s
