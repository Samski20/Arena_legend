extends Node
## LAN Multiplayer Manager for Arena Legends (host-authoritative, ENet, no internet).
## Add as an autoload named "LAN" or instantiate under the root scene.
##
## Architecture:
##   Host (server) is the authority for spawning, damage, pickups, match state.
##   Clients send inputs / action requests; host validates and replicates results.
##   Movement is interpolated on remote peers; local player is client-side predicted.

class_name LANMultiplayer

signal host_started(ip: String, port: int)
signal join_started
signal connected_to_host
signal connection_failed(reason: String)
signal peer_connected(peer_id: int)
signal peer_disconnected(peer_id: int)
signal lobby_updated
signal match_starting(map_id: String)
signal match_ended
signal status_changed(msg: String)

const DEFAULT_PORT := 7777
const MAX_PLAYERS_DEFAULT := 4
const BROADCAST_PORT := 7778
const DISCOVERY_INTERVAL := 1.5
const ROOM_NAME_PREFIX := "AL-"
## Match length in seconds. 0 = unlimited (first to kill limit only).
const DEFAULT_MATCH_TIME := 300
## Distinct uniform colors so players are easy to tell apart in-match.
const PLAYER_COLORS: Array[Color] = [
	Color("3a7bd5"),  # blue
	Color("d64545"),  # red
	Color("2ecc71"),  # green
	Color("f39c12"),  # orange
	Color("9b59b6"),  # purple
	Color("1abc9c"),  # teal
	Color("e91e63"),  # pink
	Color("f1c40f"),  # yellow
]

enum State { IDLE, HOSTING_LOBBY, JOINING, IN_LOBBY, IN_MATCH, DISCONNECTING }

var state: State = State.IDLE
var port: int = DEFAULT_PORT
var max_players: int = MAX_PLAYERS_DEFAULT
var map_id: String = "abandoned_station"
var room_name: String = ""
var player_name: String = "Player"
var local_ip: String = ""
var is_host: bool = false
## Match duration in seconds (host-controlled). 0 = no time limit.
var match_time_sec: int = DEFAULT_MATCH_TIME
var peer: ENetMultiplayerPeer = null
var players: Dictionary = {}  # peer_id -> {name, ready, color_idx}
var discovered_hosts: Array[Dictionary] = []  # {ip, port, room, players, map}
## Runtime scores: peer_id -> kills
var scores: Dictionary = {}

var _discovery_udp: PacketPeerUDP = null
var _discovery_timer: float = 0.0
var _status: String = ""

# Match runtime
var _player_scene: PackedScene = null
var _spawned_players: Dictionary = {}  # peer_id -> Node


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	_detect_local_ip()
	_player_scene = load("res://player.tscn") if ResourceLoader.exists("res://player.tscn") else null
	# Fallback: player is embedded in test_arena; we will spawn copies of the existing player node later.


func _process(delta: float) -> void:
	if state == State.HOSTING_LOBBY or state == State.IN_LOBBY:
		_discovery_timer -= delta
		if _discovery_timer <= 0.0 and is_host:
			_discovery_timer = DISCOVERY_INTERVAL
			_broadcast_presence()
	if state == State.JOINING or state == State.IDLE:
		_poll_discovery()


func _detect_local_ip() -> void:
	local_ip = "127.0.0.1"
	var addrs := IP.get_local_addresses()
	for a in addrs:
		if a.begins_with("192.168.") or a.begins_with("10.") or a.begins_with("172."):
			# Prefer non-link-local
			if not a.begins_with("169."):
				local_ip = a
				return
	# Fallback any IPv4 that is not loopback
	for a in addrs:
		if a.count(".") == 3 and a != "127.0.0.1":
			local_ip = a
			return


func get_status() -> String:
	return _status


func set_status(msg: String) -> void:
	_status = msg
	status_changed.emit(msg)


# ---------------------------------------------------------------------------
# HOST
# ---------------------------------------------------------------------------
func host_game(p_port: int = DEFAULT_PORT, p_max: int = MAX_PLAYERS_DEFAULT, p_map: String = "abandoned_station") -> bool:
	if state != State.IDLE and state != State.DISCONNECTING:
		set_status("Already in a session.")
		return false
	close_session()
	port = p_port
	max_players = clampi(p_max, 2, 8)
	map_id = p_map
	room_name = ROOM_NAME_PREFIX + str(randi() % 9000 + 1000)
	peer = ENetMultiplayerPeer.new()
	var err := peer.create_server(port, max_players)
	if err != OK:
		set_status("Failed to create server (port %d in use?): %s" % [port, error_string(err)])
		peer = null
		connection_failed.emit(_status)
		return false
	multiplayer.multiplayer_peer = peer
	is_host = true
	state = State.HOSTING_LOBBY
	players.clear()
	players[1] = _make_player_entry(player_name)
	_start_discovery_listener()
	_discovery_timer = 0.0
	set_status("Hosting on %s:%d  |  Room: %s" % [local_ip, port, room_name])
	host_started.emit(local_ip, port)
	lobby_updated.emit()
	return true


# ---------------------------------------------------------------------------
# JOIN
# ---------------------------------------------------------------------------
func join_game(ip: String, p_port: int = DEFAULT_PORT) -> bool:
	if state != State.IDLE and state != State.DISCONNECTING:
		set_status("Already in a session.")
		return false
	close_session()
	port = p_port
	peer = ENetMultiplayerPeer.new()
	var err := peer.create_client(ip.strip_edges(), port)
	if err != OK:
		set_status("Could not start client: %s" % error_string(err))
		peer = null
		connection_failed.emit(_status)
		return false
	multiplayer.multiplayer_peer = peer
	is_host = false
	state = State.JOINING
	set_status("Connecting to %s:%d ..." % [ip, port])
	join_started.emit()
	return true


func close_session() -> void:
	state = State.DISCONNECTING
	_stop_discovery()
	if peer != null:
		peer.close()
		peer = null
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer = null
	players.clear()
	scores.clear()
	_spawned_players.clear()
	is_host = false
	state = State.IDLE
	set_status("")
	match_ended.emit()


# ---------------------------------------------------------------------------
# LOBBY
# ---------------------------------------------------------------------------
func set_player_name(n: String) -> void:
	player_name = n.strip_edges()
	if player_name.is_empty():
		player_name = "Player"
	if multiplayer.has_multiplayer_peer() and multiplayer.get_unique_id() in players:
		players[multiplayer.get_unique_id()]["name"] = player_name
		if is_host:
			_push_lobby()
		else:
			_request_name_change.rpc_id(1, player_name)
		lobby_updated.emit()


func set_map(id: String) -> void:
	if not is_host:
		return
	map_id = id
	_push_lobby()
	lobby_updated.emit()


func set_max_players(n: int) -> void:
	if not is_host:
		return
	max_players = clampi(n, 2, 8)
	_push_lobby()
	lobby_updated.emit()


func set_match_time(sec: int) -> void:
	if not is_host:
		return
	# 0 = unlimited; otherwise clamp to sensible range (1–30 min)
	if sec <= 0:
		match_time_sec = 0
	else:
		match_time_sec = clampi(sec, 60, 1800)
	_push_lobby()
	lobby_updated.emit()


func host_start_match() -> void:
	if not is_host or state != State.HOSTING_LOBBY and state != State.IN_LOBBY:
		return
	if players.size() < 1:
		set_status("Need at least one player.")
		return
	state = State.IN_MATCH
	scores.clear()
	for pid in players:
		scores[pid] = 0
	_begin_match.rpc(map_id, match_time_sec)


@rpc("authority", "call_local", "reliable")
func _begin_match(p_map: String, p_time: int = DEFAULT_MATCH_TIME) -> void:
	map_id = p_map
	match_time_sec = p_time
	state = State.IN_MATCH
	scores.clear()
	for pid in players:
		scores[pid] = 0
	set_status("Starting match on %s (%s)..." % [map_id, _time_label(match_time_sec)])
	match_starting.emit(map_id)


func _push_lobby() -> void:
	if is_host and multiplayer.has_multiplayer_peer():
		_sync_lobby.rpc(players, map_id, max_players, room_name, match_time_sec)


@rpc("any_peer", "reliable")
func _request_name_change(n: String) -> void:
	if not is_host:
		return
	var id := multiplayer.get_remote_sender_id()
	if id in players:
		players[id]["name"] = n.strip_edges() if not n.strip_edges().is_empty() else "Player"
		_push_lobby()
		lobby_updated.emit()


@rpc("authority", "call_local", "reliable")
func _sync_lobby(p_players: Dictionary, p_map: String, p_max: int, p_room: String, p_time: int = DEFAULT_MATCH_TIME) -> void:
	players = p_players
	map_id = p_map
	max_players = p_max
	room_name = p_room
	match_time_sec = p_time
	lobby_updated.emit()


func _make_player_entry(n: String) -> Dictionary:
	var used: Array = []
	for pid in players:
		used.append(int(players[pid].get("color_idx", 0)))
	var idx := 0
	while idx in used and idx < PLAYER_COLORS.size():
		idx += 1
	if idx >= PLAYER_COLORS.size():
		idx = players.size() % PLAYER_COLORS.size()
	return {
		"name": n,
		"ready": false,
		"color_idx": idx
	}


func get_player_color(peer_id: int) -> Color:
	var info: Dictionary = players.get(peer_id, {})
	var idx: int = int(info.get("color_idx", 0)) % PLAYER_COLORS.size()
	return PLAYER_COLORS[idx]


func get_player_name(peer_id: int) -> String:
	var info: Dictionary = players.get(peer_id, {})
	return str(info.get("name", "Player %d" % peer_id))


func record_kill(killer_peer: int, victim_peer: int) -> void:
	if not is_host:
		return
	if killer_peer in scores:
		scores[killer_peer] = int(scores[killer_peer]) + 1
	else:
		scores[killer_peer] = 1
	_sync_scores.rpc(scores, killer_peer, victim_peer)


@rpc("authority", "call_local", "reliable")
func _sync_scores(p_scores: Dictionary, killer_peer: int, victim_peer: int) -> void:
	scores = p_scores
	# Notify match UI via group
	get_tree().call_group("mp_match_ui", "on_kill_event", killer_peer, victim_peer, scores)


func _time_label(sec: int) -> String:
	if sec <= 0:
		return "No time limit"
	var m := sec / 60
	var s := sec % 60
	return "%d:%02d" % [m, s]


# ---------------------------------------------------------------------------
# PEER CALLBACKS
# ---------------------------------------------------------------------------
func _on_peer_connected(id: int) -> void:
	if is_host:
		if players.size() >= max_players:
			# Kick excess
			peer.disconnect_peer(id)
			return
		players[id] = _make_player_entry("Player %d" % id)
		_push_lobby()
		lobby_updated.emit()
		peer_connected.emit(id)
		set_status("Player joined (id %d). %d/%d" % [id, players.size(), max_players])


func _on_peer_disconnected(id: int) -> void:
	players.erase(id)
	if _spawned_players.has(id):
		var n: Node = _spawned_players[id]
		if is_instance_valid(n):
			n.queue_free()
		_spawned_players.erase(id)
	if is_host:
		_push_lobby()
	lobby_updated.emit()
	peer_disconnected.emit(id)
	set_status("Player %d left. %d remaining." % [id, players.size()])


func _on_connected_to_server() -> void:
	state = State.IN_LOBBY
	var my_id := multiplayer.get_unique_id()
	players[my_id] = _make_player_entry(player_name)
	_request_name_change.rpc_id(1, player_name)
	set_status("Connected to host.")
	connected_to_host.emit()
	lobby_updated.emit()


func _on_connection_failed() -> void:
	set_status("Connection failed. Check IP, port, Wi-Fi, and firewall.")
	connection_failed.emit(_status)
	close_session()


func _on_server_disconnected() -> void:
	set_status("Host disconnected. Returning to menu.")
	close_session()


# ---------------------------------------------------------------------------
# LAN DISCOVERY (UDP broadcast)
# ---------------------------------------------------------------------------
func _start_discovery_listener() -> void:
	_stop_discovery()
	_discovery_udp = PacketPeerUDP.new()
	# Bind to discovery port so we can also receive (for clients)
	var err := _discovery_udp.bind(BROADCAST_PORT)
	if err != OK:
		# Still allow broadcast even if bind fails on some platforms
		_discovery_udp = PacketPeerUDP.new()
	_discovery_udp.set_broadcast_enabled(true)


func _stop_discovery() -> void:
	if _discovery_udp != null:
		_discovery_udp.close()
		_discovery_udp = null
	discovered_hosts.clear()


func _broadcast_presence() -> void:
	if _discovery_udp == null:
		return
	var payload := JSON.stringify({
		"game": "ArenaLegends",
		"room": room_name,
		"port": port,
		"players": players.size(),
		"max": max_players,
		"map": map_id,
		"ip": local_ip
	})
	var bytes := payload.to_utf8_buffer()
	# Broadcast to common LAN broadcast addresses
	for bcast in ["255.255.255.255", "192.168.0.255", "192.168.1.255", "10.0.0.255"]:
		_discovery_udp.set_dest_address(bcast, BROADCAST_PORT)
		_discovery_udp.put_packet(bytes)


func start_client_discovery() -> void:
	_start_discovery_listener()
	discovered_hosts.clear()


func stop_client_discovery() -> void:
	_stop_discovery()


func _poll_discovery() -> void:
	if _discovery_udp == null:
		return
	while _discovery_udp.get_available_packet_count() > 0:
		var pkt := _discovery_udp.get_packet()
		var from_ip := _discovery_udp.get_packet_ip()
		var txt := pkt.get_string_from_utf8()
		var data = JSON.parse_string(txt)
		if typeof(data) != TYPE_DICTIONARY:
			continue
		if data.get("game", "") != "ArenaLegends":
			continue
		var entry := {
			"ip": data.get("ip", from_ip),
			"port": int(data.get("port", DEFAULT_PORT)),
			"room": str(data.get("room", "")),
			"players": int(data.get("players", 0)),
			"max": int(data.get("max", 4)),
			"map": str(data.get("map", ""))
		}
		# Upsert
		var found := false
		for i in discovered_hosts.size():
			if discovered_hosts[i]["ip"] == entry["ip"] and discovered_hosts[i]["port"] == entry["port"]:
				discovered_hosts[i] = entry
				found = true
				break
		if not found:
			discovered_hosts.append(entry)
		lobby_updated.emit()


# ---------------------------------------------------------------------------
# MATCH SPAWN HELPERS (called by arena after map load)
# ---------------------------------------------------------------------------
func register_local_player(node: Node) -> void:
	var id := multiplayer.get_unique_id() if multiplayer.has_multiplayer_peer() else 1
	_spawned_players[id] = node
	if node.has_method("setup_multiplayer"):
		node.setup_multiplayer(id, true)


func get_spawn_points(scene: Node) -> Array[Vector2]:
	var pts: Array[Vector2] = []
	# Prefer named SpawnPoint / group
	for n in scene.find_children("*", "Marker2D", true, false):
		if n.name.begins_with("Spawn") or n.is_in_group("spawn_point"):
			pts.append(n.global_position)
	var sp := scene.get_node_or_null("SpawnPoint")
	if sp and pts.is_empty():
		pts.append(sp.global_position)
	# Fallback known positions from arena_controller
	if pts.is_empty():
		match map_id:
			"cavern_isles":
				pts = [Vector2(364, 1782), Vector2(4830, 1725), Vector2(2740, 1272), Vector2(1420, 2070)]
			_:
				pts = [Vector2(1200, 1440), Vector2(400, 1440), Vector2(2800, 1440), Vector2(960, 920)]
	return pts


func is_multiplayer_active() -> bool:
	return state == State.IN_MATCH or state == State.IN_LOBBY or state == State.HOSTING_LOBBY


func is_authority() -> bool:
	return is_host or not multiplayer.has_multiplayer_peer()
