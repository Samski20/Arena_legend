extends CharacterBody2D
## Enemy bot. Attach this to an empty CharacterBody2D and save it as bot.tscn.
## It builds its own hitbox and character, using the same rig as the player
## with enemy colors.

signal died(victim, killer)

const SpawnSafety = preload("res://art/scripts/spawn_safety.gd")
const BotDifficulty = preload("res://art/scripts/bot_difficulty.gd")
const CROUCH_SPEED_MULT := 0.5           # same as the player's crouch walk
const BLOCK_DAMAGE_MULT := 0.2           # a shielded hit does 20% damage (same as the player)

@export var max_health := 60
@export var move_speed := 150.0
@export var preferred_range := 380.0     # tries to stay about this far from you
@export var shoot_range := 700.0
@export var fire_interval := 0.7         # seconds between shots
@export var aim_error := 0.12            # radians of random aim error (bigger = worse aim)
@export var gravity := 900.0
@export var jump_force := 450.0
@export var respawn_time := 3.0
var respawn_enabled := true          # match setup: false = a defeated bot stays down
var throw_enabled := true            # match setup: false = this bot never carries or throws bombs
@export var bullet_scene: PackedScene
@export var weapon: WeaponData

# jetpack
@export var max_fuel := 100.0
@export var fuel_burn_rate := 30.0
@export var fuel_regen_rate := 25.0

var health := 60
var fuel := 100.0
var dead := false
@export var regen_delay := 5.0       # bots heal too, but slower than you
@export var regen_rate := 6.0
var _time_since_hit := 0.0
var _regen_accum := 0.0
var last_attacker: Node = null           # who hit us last (set by the bullet)
var target = null                        # the player (found automatically)
var visuals: PlayerRig
var col: CollisionShape2D
var start_position := Vector2.ZERO
var _fire_timer := 0.0
var _strafe_dir := 1.0
var _strafe_timer := 0.0
var _jetting := false
var _last_seen := Vector2.ZERO           # where the target was when it vanished into smoke
var _searching := false
var _status := {}                        # type -> {"t": seconds left, "power": strength, "src": who}
var _dot_accum := {}
var _base_move_speed := 150.0
var smoked := false                      # set by StatusEffects while inside smoke

# ---- difficulty (see bot_difficulty.gd) ----
var _diff := {}                          # the active difficulty row
var _export_health := 60
var _export_speed := 150.0
var _export_interval := 0.7
var _export_aim := 0.12
var _export_pref := 380.0
var _export_range := 700.0
var _default_weapon: WeaponData
# ---- shield (crouch) ----
var crouching := false
var blocking := false
var aim_dir := Vector2.RIGHT             # where the shield points
var _block_t := 0.0                      # seconds left behind the shield
var _block_cd := 0.0                     # seconds until it may go up again (so it is never permanently covered)
# ---- throwables carried (one entry per bomb) ----
var _throwables: Array = []
var _throw_cd := 3.0


func _ready() -> void:
	add_to_group("bot")
	floor_snap_length = 14.0          # stick to slopes instead of skipping down them
	floor_max_angle = deg_to_rad(72.0)   # every slope is walkable; only near-vertical faces act as walls
	floor_stop_on_slope = true
	floor_constant_speed = true
	start_position = global_position
	health = max_health
	_base_move_speed = move_speed
	_export_health = max_health
	_export_speed = move_speed
	_export_interval = fire_interval
	_export_aim = aim_error
	_export_pref = preferred_range
	_export_range = shoot_range

	# hitbox
	col = CollisionShape2D.new()
	var shape := CapsuleShape2D.new()
	shape.radius = 13.0
	shape.height = 60.0
	col.shape = shape
	col.position = Vector2(0, -6)
	add_child(col)

	# character (same rig as the player, enemy colors)
	visuals = PlayerRig.new()
	visuals.scale = Vector2(0.45, 0.45)
	add_child(visuals)
	visuals.apply_loadout({
		"armor": Color("c44545"),
		"trim": Color("2b2b3a"),
		"visor": Color("ffb347"),
		"jetpack": Color("5a5f70"),
		"scarf": Color("2b2b3a"),
	})
	if weapon == null:
		weapon = load("res://art/scripts/rifle.tres")
	_default_weapon = weapon
	visuals.equip_weapon(weapon)

	if bullet_scene == null:
		bullet_scene = preload("res://bullet.tscn")

	target = get_tree().current_scene.get_node_or_null("Player")
	_fire_timer = randf_range(0.5, fire_interval)
	GameSettings.ensure_loaded()
	apply_difficulty.call_deferred()          # deferred: the arena sets the active map id after its children are ready


# ---------- difficulty ----------
# Called at start-up, when the player changes BOT DIFFICULTY in the menu, and after a map change.
func apply_difficulty() -> void:
	if _default_weapon == null:
		return
	_diff = BotDifficulty.profile()
	max_health = maxi(1, roundi(_export_health * float(_diff["hp"])))
	health = max_health
	_base_move_speed = _export_speed * float(_diff["speed"])
	_roll_loadout()
	queue_redraw()


# Picks this life's gun and throwables.
func _roll_loadout() -> void:
	if _diff.is_empty():
		_diff = BotDifficulty.profile()
	var guns := int(_diff["guns"])
	var w: WeaponData = BotDifficulty.pick_weapon(guns)
	weapon = w if w != null else _default_weapon
	visuals.equip_weapon(weapon)
	_apply_weapon_style(guns > 0)
	_throwables.clear()
	var map_id := str(get_tree().current_scene.get_meta("active_map_id", "abandoned_station"))
	for i in (int(_diff["carry"]) if throw_enabled else 0):
		var t: ThrowableData = BotDifficulty.pick_throwable(map_id)
		if t != null:
			_throwables.append(t)
	var cd: Array = _diff["throw_cd"]
	_throw_cd = randf_range(1.5, float(cd[0]))


# Aim, fire speed and fighting distance. With a random gun the bot fights the way that gun wants
# (shotgun = close, sniper = far, SMG / pistol = mid-close).
func _apply_weapon_style(per_gun: bool) -> void:
	var interval := _export_interval
	var pref := _export_pref
	var rng := _export_range
	if per_gun and weapon != null:
		var gap := weapon.shot_gap(weapon.default_mode())
		interval = maxf(clampf(gap * 3.0, 0.25, 1.2), gap)
		match weapon.category:
			"Shotgun":
				pref = 170.0
				rng = 520.0
			"Sniper Rifle":
				pref = 720.0
				rng = 1500.0
			"Launcher":
				pref = 480.0
				rng = 950.0
			"SMG", "Pistol":
				pref = 270.0
				rng = 720.0
			"Machine Gun":
				pref = 450.0
				rng = 900.0
	fire_interval = interval * float(_diff["fire"])
	aim_error = _export_aim * float(_diff["aim"])
	preferred_range = pref
	shoot_range = rng


func _physics_process(delta: float) -> void:
	_tick_statuses(delta)
	if dead:
		return
	# health regeneration
	_time_since_hit += delta
	if _time_since_hit >= regen_delay and health < max_health:
		_regen_accum += regen_rate * delta
		if _regen_accum >= 1.0:
			var gain := int(_regen_accum)
			_regen_accum -= gain
			health = mini(health + gain, max_health)
			queue_redraw()

	if target == null or not is_instance_valid(target):
		target = get_tree().current_scene.get_node_or_null("Player")

	# a decoy hologram draws the bot's attention away from the real player
	var focus = target                    # untyped on purpose: the player has methods Node2D doesn't
	var decoy := _nearest_decoy()
	if decoy != null:
		focus = decoy
	var aim_off := Vector2(0, -30) if decoy != null else Vector2(0, -8)
	var target_alive: bool = focus != null and focus.get("is_dead") != true
	var aim_point: Vector2 = global_position + Vector2(100, -10)
	var dist := 99999.0
	var dx := 0.0

	if target_alive:
		aim_point = focus.global_position + aim_off
		dist = global_position.distance_to(focus.global_position)
		dx = focus.global_position.x - global_position.x

	# smoke blocks line of sight: a smoked player can't be seen, so the bot goes to where
	# it last saw them and stops shooting
	var can_see: bool = target_alive and not (focus.has_method("has_status") and focus.has_status("smoked")) and not _hidden_in_bush(focus)
	if can_see:
		_last_seen = focus.global_position
		_searching = true
	elif not target_alive:
		_searching = false
	elif _searching:
		aim_point = _last_seen + Vector2(0, -8)
		dist = global_position.distance_to(_last_seen)
		dx = _last_seen.x - global_position.x
		if absf(dx) < 40.0:
			_searching = false                 # reached the spot, nobody there: gives up

	# ----- horizontal movement -----
	var want := 0.0
	if not can_see and _searching:
		want = signf(dx)                       # walk to the last known position
	elif can_see:
		var toward := signf(dx)
		if dist > preferred_range + 60.0:
			want = toward
		elif dist < preferred_range - 80.0:
			want = -toward
		else:
			_strafe_timer -= delta
			if _strafe_timer <= 0.0:
				_strafe_timer = randf_range(1.0, 2.5)
				_strafe_dir = [-1.0, 0.0, 1.0].pick_random()
			want = _strafe_dir
	var stunned := is_stunned()
	var player_above: bool = can_see and focus.global_position.y < global_position.y - 150.0
	aim_dir = (aim_point - visuals.aim_pivot.global_position).normalized()
	_update_block(delta, can_see, dist, stunned, player_above)
	if stunned:
		velocity.x = move_toward(velocity.x, 0.0, (1500.0 if is_on_floor() else 140.0) * delta)     # no steering: the blast's push carries it
	else:
		velocity.x = move_toward(velocity.x, want * _base_move_speed * _speed_mult() * (CROUCH_SPEED_MULT if crouching else 1.0), 900.0 * delta)

	# ----- jetpack: fly up when the player is well above -----
	var want_up: bool = can_see and focus.global_position.y < global_position.y - 150.0
	if fuel <= 0.0 or _status.has("emp") or _status.has("noflight") or stunned:
		_jetting = false          # empty tank, EMP / flight disruptor, or stunned
	elif want_up:
		_jetting = true
	else:
		_jetting = false

	if _jetting:
		fuel = maxf(fuel - fuel_burn_rate * delta, 0.0)
		velocity.y = move_toward(velocity.y, -280.0, 1100.0 * delta)
	else:
		if not is_on_floor() or (stunned and velocity.y < -1.0):
			velocity.y += gravity * delta
		else:
			velocity.y = 0.0
			fuel = minf(fuel + fuel_regen_rate * delta, max_fuel)
			# hop over obstacles
			if is_on_wall() and want != 0.0 and not stunned and not crouching:
				velocity.y = -jump_force

	move_and_slide()

	# ----- throwing bombs (VETERAN / LEGEND) -----
	_throw_cd -= delta
	if _throw_cd <= 0.0 and not _throwables.is_empty() and not stunned and not _status.has("emp"):
		_try_throw(can_see, dist, aim_point)

	# ----- shooting -----
	_fire_timer -= delta
	if can_see and dist < shoot_range and _fire_timer <= 0.0 and not stunned:
		_fire_timer = fire_interval * randf_range(0.8, 1.3)
		_shoot(aim_point)

	visuals.update_visuals(velocity, aim_point, _jetting, is_on_floor(), delta, crouching, blocking)


# ---------- shield: crouch behind it ----------
# The bot ducks behind its shield when it gets hit, when a bomb is coming, and now and then on its own.
# It never stays up for long (a cooldown follows every block), and it can still shoot while crouched.
func _update_block(delta: float, can_see: bool, dist: float, stunned: bool, player_above: bool) -> void:
	var want := false
	if bool(_diff.get("shield", false)) and can_see and is_on_floor() and not stunned and not player_above and dist < shoot_range:
		_block_t -= delta
		_block_cd -= delta
		if _block_t > 0.0:
			want = true
		elif _block_cd <= 0.0 and (_time_since_hit < 0.4 or _bomb_incoming() or randf() < 0.7 * delta):
			_block_t = randf_range(0.7, 1.5)
			_block_cd = _block_t + randf_range(0.6, 1.4)
			want = true
	else:
		_block_t = 0.0
	if want != crouching:
		_set_crouch(want)


func _set_crouch(on: bool) -> void:
	crouching = on
	blocking = on
	if col != null:
		# shrink the hitbox to 70% height, keeping the feet on the ground (same as the player)
		col.scale.y = 0.7 if on else 1.0
		col.position.y = (-6.0 + 60.0 * 0.5 * 0.3) if on else -6.0


func _bomb_incoming() -> bool:
	for n in get_tree().get_nodes_in_group("throwable"):
		var b := n as Node2D
		if b != null and b.get("thrower") != self and global_position.distance_to(b.global_position) < 300.0:
			return true
	return false


# True if we're blocking AND the shot came from inside the shield's arc.
func _shield_covers(hit_direction: Vector2) -> bool:
	if not blocking:
		return false
	var from_dir := Vector2.ZERO                  # direction from us toward the attacker
	if hit_direction != Vector2.ZERO:
		from_dir = -hit_direction.normalized()
	elif is_instance_valid(last_attacker) and last_attacker is Node2D:
		from_dir = ((last_attacker as Node2D).global_position - visuals.aim_pivot.global_position).normalized()
	else:
		return false
	return absf(aim_dir.angle_to(from_dir)) <= PlayerRig.SHIELD_HALF_ANGLE


# Used by explosions (throwable.gd): is our shield pointing toward the blast?
func is_shielding_toward(world_point: Vector2) -> bool:
	if not blocking or dead:
		return false
	var to_point: Vector2 = world_point - visuals.aim_pivot.global_position
	if to_point.length() < 1.0:
		return true
	return absf(aim_dir.angle_to(to_point.normalized())) <= PlayerRig.SHIELD_HALF_ANGLE


# ---------- throwing ----------
func _try_throw(can_see: bool, dist: float, aim_point: Vector2) -> void:
	var cd: Array = _diff["throw_cd"]
	var hurt := health < int(max_health * 0.45)
	var pick := -1
	var at_feet := false
	if hurt:                                                    # low on health: smoke to break line of sight
		for i in _throwables.size():
			if _throwables[i].catalog_id == "smoke":
				pick = i
				at_feet = true
				break
	if pick < 0 and can_see and dist > 170.0 and dist < 650.0:   # never closer than the blast radius
		var offensive: Array = []
		for i in _throwables.size():
			if _throwables[i].catalog_id != "smoke":
				offensive.append(i)
		if not offensive.is_empty():
			pick = offensive.pick_random()
	if pick < 0:
		_throw_cd = 0.6                                         # nothing worth throwing right now: look again soon
		return
	var t: ThrowableData = _throwables[pick]
	_throwables.remove_at(pick)
	var origin: Vector2 = visuals.aim_pivot.global_position
	var vel: Vector2
	if at_feet:
		vel = Vector2(randf_range(-50.0, 50.0), -160.0)
	else:
		vel = BotDifficulty.throw_velocity(origin, aim_point + Vector2(0, 14), t.throw_speed, 900.0, aim_error * 0.6)
	var bomb := Throwable.new()
	bomb.setup(t, self, vel + velocity * 0.5)
	get_tree().current_scene.add_child(bomb)
	bomb.global_position = origin + vel.normalized() * 22.0
	_throw_cd = randf_range(float(cd[0]), float(cd[1]))


# A player hiding in a bush can't be seen from far away (see bush_cover.gd); close up they give themselves away.
func _hidden_in_bush(f: Node) -> bool:
	if f == null or not f.has_meta("bush_concealed") or not bool(f.get_meta("bush_concealed")):
		return false
	return global_position.distance_to((f as Node2D).global_position) > 170.0


func _nearest_decoy() -> Node2D:
	var best: Node2D = null
	var best_d := 700.0                        # bots only notice decoys within this range
	for d in get_tree().get_nodes_in_group("decoy"):
		var n := d as Node2D
		if n == null:
			continue
		var dd := global_position.distance_to(n.global_position)
		if dd < best_d:
			best_d = dd
			best = n
	return best


func _shoot(aim_point: Vector2) -> void:
	var base_dir: Vector2 = (aim_point - visuals.muzzle.global_position).normalized()
	GunAudio.shoot(self, weapon, -5.0)
	if weapon.projectile_kind == "rocket":
		var err := randf_range(-aim_error, aim_error) * (3.0 if _status.has("emp") else 1.0)
		Rocket.launch(weapon, visuals.muzzle.global_position, base_dir.rotated(err), self, get_tree())
		visuals.fire_effects(0)
		return
	# one bullet per pellet, so shotgun bots fire a spread like the player does
	for i in weapon.pellets:
		var spread := deg_to_rad(randf_range(-weapon.spread_degrees, weapon.spread_degrees))
		var dir := base_dir.rotated(randf_range(-aim_error, aim_error) * (3.0 if _status.has("emp") else 1.0) + spread)
		var bullet = bullet_scene.instantiate()
		bullet.global_position = visuals.muzzle.global_position
		bullet.setup(weapon, dir, self)
		get_tree().current_scene.add_child(bullet)
	visuals.fire_effects(0)            # muzzle flash, recoil kick, spent casing


# Where to respawn: the safest spot SpawnSafety can find, preferably far from the player and the other bot.
func _find_respawn_position() -> Vector2:
	var avoid: Array[Vector2] = []
	if target != null and is_instance_valid(target) and target is Node2D:
		avoid.append((target as Node2D).global_position)
	for other in get_tree().get_nodes_in_group("bot"):
		if other != self and other is Node2D and other.get("dead") != true:
			avoid.append((other as Node2D).global_position)
	return SpawnSafety.find_safe_spawn(self, start_position, avoid)


# Called by the arena controller after it has moved the bot onto a new map.
func place_at(pos: Vector2) -> void:
	start_position = pos
	global_position = pos
	velocity = Vector2.ZERO


# ---------- health bar over the head ----------
func _draw() -> void:
	if smoked or (has_meta("bush_concealed") and bool(get_meta("bush_concealed"))):
		return
	var w := 44.0
	var p := clampf(float(health) / float(max_health), 0.0, 1.0)
	draw_rect(Rect2(-w / 2.0, -56.0, w, 6.0), Color(0, 0, 0, 0.6))
	draw_rect(Rect2(-w / 2.0 + 1.0, -55.0, (w - 2.0) * p, 4.0), Color(0.9, 0.25, 0.25))


# ---------- status effects (called by throwable zones) ----------
func apply_status(type: String, duration: float, power := 1.0, source: Node = null) -> void:
	if dead:
		return
	StatusFX.attach(self)
	if _status.has(type):
		var cur: Dictionary = _status[type]
		cur["t"] = maxf(cur["t"], duration)
		cur["power"] = maxf(cur["power"], power)
		if source != null:
			cur["src"] = source
	else:
		_status[type] = {"t": duration, "power": power, "src": source}


func has_status(type: String) -> bool:
	return _status.has(type)


func clear_statuses() -> void:
	_status.clear()
	_dot_accum.clear()
	smoked = false
	if visuals:
		visuals.modulate = Color(1, 1, 1)
	queue_redraw()


func _speed_mult() -> float:
	var m := 1.0
	for type in ["cryo", "slow"]:
		if _status.has(type):
			m *= 1.0 - clampf(float(_status[type]["power"]), 0.0, 0.9)
	return m


# Where blasts aim: the middle of the body, not the feet.
func blast_center() -> Vector2:
	return global_position + Vector2(0, -12)


# ---------- stun (knockback bomb) ----------
var _stun_immune := 0.0
var _stun_immunity_len := 1.0


func is_stunned() -> bool:
	return _status.has("stun")


# Same rules as the player: no stacking, short immunity after it ends.
func apply_stun(duration: float, immunity := 1.0, source: Node = null) -> void:
	if dead or duration <= 0.0:
		return
	if _status.has("stun"):
		_status["stun"]["t"] = maxf(float(_status["stun"]["t"]), duration)
		return
	if _stun_immune > 0.0:
		return
	_stun_immunity_len = immunity
	apply_status("stun", duration, 1.0, source)


func _tick_statuses(delta: float) -> void:
	_stun_immune = maxf(0.0, _stun_immune - delta)
	if dead or _status.is_empty():
		if smoked and not dead:
			clear_statuses()
		return
	for type in _status.keys():
		if not _status.has(type):
			continue
		var s: Dictionary = _status[type]
		s["t"] -= delta
		if type == "burn" or type == "poison":
			_dot_accum[type] = float(_dot_accum.get(type, 0.0)) + float(s["power"]) * delta
			if _dot_accum[type] >= 1.0:
				var dmg := int(_dot_accum[type])
				_dot_accum[type] -= dmg
				if is_instance_valid(s["src"]):
					last_attacker = s["src"]          # kill credit
				take_damage(dmg, Vector2.ZERO, true)          # burn / poison ignore the shield
				if dead:
					clear_statuses()
					return
		if s["t"] <= 0.0:
			_status.erase(type)
			_dot_accum.erase(type)
			if type == "stun":
				_stun_immune = _stun_immunity_len

	if _status.is_empty():
		clear_statuses()
		return
	var tint := Color(1, 1, 1)
	if _status.has("cryo"):
		tint = Color(0.65, 0.9, 1.3)
	elif _status.has("burn"):
		tint = Color(1.25, 0.8, 0.6) if int(Time.get_ticks_msec() / 120) % 2 == 0 else Color(1.1, 0.7, 0.5)
	elif _status.has("poison"):
		tint = Color(0.7, 1.15, 0.6)
	elif _status.has("stun"):
		tint = Color(1.4, 1.4, 0.8) if int(Time.get_ticks_msec() / 70) % 2 == 0 else Color(1.0, 1.0, 1.0)
	var now_smoked := _status.has("smoked")
	tint.a = 0.07 if now_smoked else 1.0
	visuals.modulate = tint
	if now_smoked != smoked:
		smoked = now_smoked
		queue_redraw()                           # hides/shows the health bar


# ---------- taking damage / dying ----------
func take_damage(amount, hit_direction := Vector2.ZERO, ignore_shield := false) -> void:
	if dead:
		return

	_time_since_hit = 0.0
	# Shield: only hits from the side it faces are reduced
	if not ignore_shield and _shield_covers(hit_direction):
		amount = maxi(1, roundi(amount * BLOCK_DAMAGE_MULT))
		hit_direction *= 0.3
		visuals.shield_hit()
	health -= amount
	health = maxi(health, 0)
	queue_redraw()

	if hit_direction != Vector2.ZERO:
		velocity += hit_direction

	if health > 0:
		modulate = Color(1, 0.4, 0.4)
		await get_tree().create_timer(0.1).timeout
		if not dead:
			modulate = Color(1, 1, 1)
	else:
		die()


func die() -> void:
	if dead:
		return
	dead = true
	clear_statuses()
	_set_crouch(false)
	_block_t = 0.0
	died.emit(self, last_attacker)
	_drop_loot()                      # the gun it held + any bombs it had left fall to the floor
	set_physics_process(false)
	col.set_deferred("disabled", true)

	var tween := create_tween()
	tween.tween_property(self, "modulate:a", 0.0, 0.3)
	await tween.finished
	visible = false

	if not respawn_enabled:
		return                            # stays defeated (dead = true, no AI); the match manager notices
	await get_tree().create_timer(maxf(respawn_time, 0.05)).timeout

	# Respawn on a spot that is checked first: walkable ground, nothing solid around the body, inside
	# the map and away from the player. start_position is only the preferred area (and the fallback).
	await get_tree().physics_frame            # make sure the physics space is up to date before querying it
	global_position = _find_respawn_position()
	health = max_health
	fuel = max_fuel
	velocity = Vector2.ZERO
	modulate = Color(1, 1, 1, 1)
	visible = true
	col.set_deferred("disabled", false)
	dead = false
	_roll_loadout()                   # new life = new gun and a fresh set of bombs
	queue_redraw()
	set_physics_process(true)


# ---------- loot: killed bots drop what they were carrying ----------
func _drop_loot() -> void:
	var scene := get_tree().current_scene
	if scene == null:
		return
	var w := weapon
	var bombs: Array = _throwables.duplicate()
	_throwables.clear()
	var pos := global_position
	await get_tree().physics_frame            # safe moment to add physics areas / query the world
	if not is_instance_valid(scene):
		return
	if w != null:
		var drop := WeaponPickup.new()
		drop.weapon = w
		drop.is_drop = true
		drop.drop_ammo = maxi(1, roundi(w.magazine_size * randf_range(0.4, 1.0)))
		drop.drop_reserve = roundi(w.reserve_ammo * randf_range(0.3, 0.7))
		drop.ignore_body = self
		scene.add_child(drop)
		drop.global_position = pos + Vector2(0, 6)
	if bombs.is_empty():
		return
	# bombs lie on the ground, so find the floor under the bot first
	var query := PhysicsRayQueryParameters2D.create(pos, pos + Vector2(0, 500))
	query.exclude = [get_rid()]
	var hit := get_world_2d().direct_space_state.intersect_ray(query)
	var floor_pos: Vector2 = hit.position if not hit.is_empty() else pos + Vector2(0, 24)
	var n := bombs.size()
	for i in n:
		var pickup := ThrowablePickup.new()
		pickup.data = bombs[i]
		pickup.lifetime = 30.0
		scene.add_child(pickup)
		pickup.global_position = floor_pos + Vector2((i - (n - 1) * 0.5) * 30.0, 0.0)
