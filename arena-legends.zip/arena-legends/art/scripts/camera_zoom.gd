class_name CameraZoom
extends Node
## Weapon-specific camera zoom + comfortable aim framing. Replaces ScopeZoom.
##
## Zoom numbers are "view distance": LOWER = camera closer, HIGHER = camera farther (see zoom_config.gd).
##  - Each weapon has its own min / default / max, and remembers its own last zoom during the match.
##  - Dual wielding uses the higher-maximum gun's range, and remembers a zoom per gun PAIR.
##  - Settings > "Start with Maximum Weapon Zoom" makes every equip start at the maximum instead.
##  - PC: mouse wheel, or - / =.   Controller: D-pad down / up.   Touch: the ZOOM buttons (hold to repeat).
## It only sets Camera2D.zoom and Camera2D.offset. Damage, fire rate, bullets, hitboxes are never touched.

const SMOOTH := 8.0                 # zoom change speed
const LOOK_SMOOTH := 5.0            # aim-framing speed (slower = calmer camera)
const LOOK_REACH := 170.0           # how far the view slides toward your aim, in world px at BASE_VIEW
const HOLD_DELAY := 0.35            # holding a zoom button: seconds before it repeats
const HOLD_REPEAT := 0.12

var _player: Node
var _cam: Camera2D
var _key := ""                      # what is equipped: weapon name, or "dual:A+B"
var _last_setting := false
var _min := 2.0
var _max := 3.0
var _view := 4.0                    # wanted view number (lower = closer)
var _zoom := 1.0                    # Godot zoom actually applied (smoothed)
var _look := Vector2.ZERO
var _saved := {}                    # key -> last zoom used with it (this match)
var _inited := false
var _hold := 0.0
var _hold_dir := 0
var _label: Label
var _label_t := 0.0


static func attach(player: Node) -> void:
	if player == null or player.get_node_or_null("CameraZoom") != null:
		return
	var z := CameraZoom.new()
	z.name = "CameraZoom"
	player.add_child(z)


func _ready() -> void:
	_player = get_parent()
	for c in _player.find_children("*", "Camera2D", true, false):
		_cam = c as Camera2D
		break
	if _cam == null:
		push_warning("CameraZoom: the player has no Camera2D, zoom is off.")
		set_process(false)
		set_process_unhandled_input(false)
		return
	var layer := CanvasLayer.new()
	layer.layer = 5
	add_child(layer)
	_label = Label.new()
	_label.anchor_left = 0.5
	_label.anchor_right = 0.5
	_label.anchor_top = 1.0
	_label.anchor_bottom = 1.0
	_label.offset_left = -100.0
	_label.offset_right = 100.0
	_label.offset_top = -120.0
	_label.offset_bottom = -90.0
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.add_theme_font_size_override("font_size", 18)
	_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	_label.add_theme_constant_override("outline_size", 4)
	_label.modulate = Color(0.7, 1.0, 0.95, 0.0)
	layer.add_child(_label)


# player.gd calls this after every respawn: a new life starts at the starting weapon's default (or maximum) zoom.
func on_respawn() -> void:
	_saved.clear()
	_key = ""


func view_value() -> float:
	return _view


func _unhandled_input(event: InputEvent) -> void:
	var dir := 0
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			dir = -1                       # closer
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			dir = 1                        # farther
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_EQUAL or event.keycode == KEY_KP_ADD:
			dir = -1
		elif event.keycode == KEY_MINUS or event.keycode == KEY_KP_SUBTRACT:
			dir = 1
	elif event is InputEventJoypadButton and event.pressed:
		if event.button_index == JOY_BUTTON_DPAD_UP:
			dir = -1
		elif event.button_index == JOY_BUTTON_DPAD_DOWN:
			dir = 1
	if dir != 0:
		_nudge(dir)
		get_viewport().set_input_as_handled()


func _nudge(dir: int) -> void:
	if _key == "":
		return
	_view = clampf(_view + dir * ZoomConfig.STEP, _min, _max)
	_saved[_key] = _view
	_label_t = 1.3


# What the player is holding right now, as zoom rules: {key, min, default, max}.
func _loadout() -> Dictionary:
	var w = _player.get("weapon")
	if not (w is WeaponData):
		return {}
	var off = _player.get("off_weapon")
	if _player.get("dual") == true and off is WeaponData:
		return ZoomConfig.dual_info(w, off)
	return ZoomConfig.single_info(w)


# A new weapon / pair was equipped (or the setting changed): pick its starting zoom.
func _equip(info: Dictionary) -> void:
	_key = info["key"]
	_min = info["min"]
	_max = info["max"]
	_last_setting = GameSettings.max_weapon_zoom
	if not _saved.has(_key):
		_saved[_key] = clampf(info["default"], _min, _max)      # first time: its default
	if _last_setting:
		_view = _max                                           # the setting wins over the saved zoom
	else:
		_view = clampf(float(_saved[_key]), _min, _max)
	if not _inited:
		_inited = true
		_zoom = ZoomConfig.BASE_VIEW / _view                   # no zoom-in animation on the very first frame
	_label_t = 1.3


func _touch_zoom(delta: float) -> void:
	var t = _player.get("touch")
	if t == null or not TouchControls.active:
		_hold_dir = 0
		return
	if t.take("zoom_in"):
		_nudge(-1)
	if t.take("zoom_out"):
		_nudge(1)
	var dir := 0
	if t.held("zoom_in"):
		dir = -1
	elif t.held("zoom_out"):
		dir = 1
	if dir == 0:
		_hold_dir = 0
		return
	if dir != _hold_dir:
		_hold_dir = dir
		_hold = -HOLD_DELAY
	_hold += delta
	if _hold >= HOLD_REPEAT:
		_hold -= HOLD_REPEAT
		_nudge(dir)


# Where the view slides to: a little way toward where you aim, so you see more in front of you.
func _look_target() -> Vector2:
	if _player.get("is_dead") == true:
		return Vector2.ZERO
	var reach := LOOK_REACH * (_view / ZoomConfig.BASE_VIEW)    # same share of the screen at every zoom
	var t = _player.get("touch")
	if t != null and TouchControls.active:
		return (t.aim_vec as Vector2) * float(t.aim_strength) * reach
	var vp := get_viewport()
	var half := vp.get_visible_rect().size * 0.5
	var n: Vector2 = (vp.get_mouse_position() - half) / half
	var m := n.length()
	if m <= 0.5:
		return Vector2.ZERO                                    # cursor near the middle: no camera push
	var s := (minf(m, 1.0) - 0.5) / 0.5                        # 0 at half way to the edge, 1 at the edge
	return n.normalized() * s * reach


func _process(delta: float) -> void:
	var info := _loadout()
	if info.is_empty():
		return
	if info["key"] != _key or GameSettings.max_weapon_zoom != _last_setting:
		_equip(info)
	_touch_zoom(delta)

	var target := ZoomConfig.BASE_VIEW / _view
	_zoom = lerpf(_zoom, target, 1.0 - exp(-SMOOTH * delta))
	if absf(_zoom - target) < 0.0004:
		_zoom = target
	_look = _look.lerp(_look_target(), 1.0 - exp(-LOOK_SMOOTH * delta))
	if _cam.zoom.x != _zoom:
		_cam.zoom = Vector2(_zoom, _zoom)
	_cam.offset = _look

	if _label != null:
		_label_t = maxf(_label_t - delta, 0.0)
		_label.text = "VIEW  %sx" % String.num(_view, 2)
		_label.modulate.a = clampf(_label_t * 2.0, 0.0, 0.85)
