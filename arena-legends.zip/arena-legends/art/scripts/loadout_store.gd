class_name LoadoutStore
extends RefCounted
## Local loadout save/load. Up to 5 custom loadouts + a few editable presets.

const PATH := "user://loadouts.cfg"
const MAX_CUSTOM := 5

static var _loaded := false
static var _presets: Array[Dictionary] = []   # built-in editable starters
static var _custom: Array[Dictionary] = []    # player-created


static func ensure_loaded() -> void:
	if _loaded:
		return
	_loaded = true
	_presets = _default_presets()
	_custom = []
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	var custom_raw: Variant = cfg.get_value("loadouts", "custom", [])
	if custom_raw is Array:
		for e in custom_raw:
			if e is Dictionary:
				_custom.append(e)
	# restore preset overrides
	var preset_raw: Variant = cfg.get_value("loadouts", "presets", {})
	if preset_raw is Dictionary:
		for i in _presets.size():
			var pid: String = _presets[i]["id"]
			if preset_raw.has(pid):
				_presets[i] = preset_raw[pid]


static func _default_presets() -> Array[Dictionary]:
	return [
		{"id": "assault", "name": "Assault", "primary": "m4a1", "secondary": "glock",
			"throwable1": "grenade", "throwable1_qty": 2, "throwable2": "smoke", "throwable2_qty": 1, "builtin": true},
		{"id": "heavy", "name": "Heavy Weapons", "primary": "m249", "secondary": "rpg7",
			"throwable1": "grenade", "throwable1_qty": 2, "throwable2": "knockback", "throwable2_qty": 1, "builtin": true},
		{"id": "tactical", "name": "Tactical", "primary": "mp5", "secondary": "desert_eagle",
			"throwable1": "smoke", "throwable1_qty": 2, "throwable2": "emp", "throwable2_qty": 1, "builtin": true},
		{"id": "long_range", "name": "Long Range", "primary": "barrett_m82", "secondary": "colt_python",
			"throwable1": "grenade", "throwable1_qty": 1, "throwable2": "decoy", "throwable2_qty": 1, "builtin": true},
		{"id": "cqb", "name": "Close Quarters", "primary": "spas12", "secondary": "uzi",
			"throwable1": "knockback", "throwable1_qty": 2, "throwable2": "incendiary", "throwable2_qty": 1, "builtin": true},
	]


static func all_loadouts() -> Array[Dictionary]:
	ensure_loaded()
	var out: Array[Dictionary] = []
	for p in _presets:
		out.append(p)
	for c in _custom:
		out.append(c)
	return out


static func get_loadout(id: String) -> Dictionary:
	ensure_loaded()
	for p in _presets:
		if p.get("id", "") == id:
			return p
	for c in _custom:
		if c.get("id", "") == id:
			return c
	return {}


static func save_loadout(data: Dictionary) -> String:
	ensure_loaded()
	var id: String = str(data.get("id", ""))
	if id == "":
		id = "custom_%d" % (Time.get_unix_time_from_system() as int)
		data["id"] = id
		data["builtin"] = false
	# update existing or append
	for i in _presets.size():
		if _presets[i].get("id", "") == id:
			_presets[i] = data
			_persist()
			return id
	for i in _custom.size():
		if _custom[i].get("id", "") == id:
			_custom[i] = data
			_persist()
			return id
	if _custom.size() >= MAX_CUSTOM:
		return ""   # full
	_custom.append(data)
	_persist()
	return id


static func delete_loadout(id: String) -> bool:
	ensure_loaded()
	for i in _custom.size():
		if _custom[i].get("id", "") == id:
			_custom.remove_at(i)
			_persist()
			return true
	# builtins cannot be deleted, only reset
	return false


static func _persist() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("loadouts", "custom", _custom)
	var preset_map := {}
	for p in _presets:
		preset_map[p["id"]] = p
	cfg.set_value("loadouts", "presets", preset_map)
	cfg.save(PATH)
