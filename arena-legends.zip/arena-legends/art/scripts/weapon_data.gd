class_name WeaponData
extends Resource
## One of these per weapon. Weapons have their own art and are not recolored
## by the character customization.

# ---- identity + art ----
@export var display_name := "Rifle"        # short name shown in the game: use the real-world name where there is one ("AK-47")
@export var variant := ""                  # what kind of version it is: "Futuristic", "Vintage", "Prototype"... (can stay empty)
@export_enum("Modern", "Futuristic", "Experimental", "Sci-Fi / Energy", "Ancient", "Medieval", "Historical", "Primitive", "Alien", "Special / Event", "Fictional") var era := "Modern"
@export_enum("Assault Rifle", "SMG", "Shotgun", "Sniper Rifle", "Pistol", "Machine Gun", "Launcher", "Energy Weapon", "Bow / Crossbow", "Melee", "Thrown", "Other") var category := "Assault Rifle"
@export_multiline var description := ""
@export var texture: Texture2D
@export var grip := Vector2(28, 18)      # pixel in the texture that the hand holds
@export var muzzle := Vector2(94, 14)    # pixel in the texture where bullets spawn
@export var art_scale := 6.0         # the picture is this many times bigger than its in-game size (smooth, hi-res art). Grip/muzzle numbers stay in in-game pixels
@export var one_handed := false      # tick for pistols/SMGs: can be held in one hand (dual wield)
@export var support_grip := Vector2.ZERO   # pixel where the other hand holds the gun (0,0 = automatic: just ahead of the grip)

# ---- combat stats ----
@export_group("Combat")
@export var damage := 10
@export var fire_rate := 0.12            # seconds between shots
@export var projectile_speed := 900.0
@export var max_range := 900.0           # bullets disappear after this distance
@export var spread_degrees := 2.0        # random aim error per shot
@export var pellets := 1                 # bullets per shot (shotgun = more than 1)
@export var knockback := 80.0
@export var automatic := true           # true = keeps firing while the trigger is held; false = semi-auto (one shot per press)
@export var bullet_color := Color.WHITE   # tints the bullet sprite (per-weapon look)

# ---- firing modes (see FireState + player.gd). Every gun lists the modes it really has ----
@export_group("Firing modes")
@export var fire_modes := PackedStringArray()      # any of "semi", "auto", "burst", "single" (launcher). Empty = old behaviour: "auto" if `automatic`, else "semi"
@export var default_fire_mode := ""   # mode the gun starts in ("" = the first one in the list)
@export var burst_count := 3                        # rounds per burst (burst mode only)
@export var burst_interval := 0.065                 # seconds between rounds INSIDE a burst
@export var burst_pause := 0.28                     # seconds of pause between one burst and the next while the trigger stays held
@export var semi_fire_rate := 0.0                   # minimum seconds between shots in semi / single mode (0 = use fire_rate)
@export_enum("bullet", "rocket") var projectile_kind := "bullet"   # "rocket" = a visible rocket that explodes (RPG-7)
@export var blast_radius := 150.0                   # rocket explosion radius (damage + knockback fall off toward the edge)
@export var sound_style := ""   # firing sound ("" = picked from flash_style)

# ---- ammo ----
@export_group("Ammo")
@export var magazine_size := 30
@export var reload_time := 1.6           # seconds
@export var reserve_ammo := 120          # extra bullets besides the magazine

# ---- scope / zoom (right-click toggles, like Mini Militia) ----
@export_group("Scope")
@export var zoom_steps := PackedFloat32Array()   # camera zoom per click. Below 1 = zoomed OUT (sees farther): 0.5 = twice the view. Above 1 = magnified. Empty = no scope
@export var zoom_look_ahead := 250.0             # how far (pixels) the camera also slides toward your cursor while scoped

# ---- special effect (used by rare weapons later) ----
@export_group("Special")
@export_enum("None", "Freeze", "Slow", "Poison", "Shock", "Pull", "Push", "EMP", "Explode") var special_effect := "None"
@export var special_duration := 0.0      # seconds the effect lasts on the target
@export var special_power := 0.0         # strength (slow %, poison dps, explosion radius...)


# ---- firing effects: muzzle flash, recoil, spent casings (all drawn by PlayerRig.fire_effects) ----
@export_group("Firing effects")
@export_enum("pistol", "smg", "rifle", "mg", "shotgun", "sniper", "magnum") var flash_style := "rifle"   # the shape of the muzzle burst
@export var flash_size := 1.0               # bigger number = bigger flash
@export var flash_bright := 1.0             # above 1 = whiter, hotter core (powerful guns)
@export var recoil_kick := 3.0              # px the gun is shoved back toward the shoulder on every shot
@export var recoil_tilt := 0.10             # radians the muzzle flips up on every shot
@export var recoil_recover := 15.0          # how fast it settles back (higher = snappier, so faster guns jerk in quick small pulses)
@export var casing_eject := true            # spits a spent case out of the ejection port on every shot (false: revolvers, break-action guns, launchers)
@export var casing_on_reload := false       # true = the spent cases stay in the gun and drop out when you reload
@export_enum("pistol", "rifle", "shotgun", "sniper") var casing_kind := "rifle"    # picture of the case
@export var casing_port := Vector2.ZERO     # ejection port: pixel on the gun picture, in in-game px (0,0 = just above the grip)
@export var casing_velocity := Vector2(-70, -230)   # base speed in gun space: +x = forward, -y = up
@export var casing_spread := Vector2(35, 45)        # random +/- added to that speed
@export var casing_spin := 22.0             # how fast it tumbles (radians per second)
@export var casing_gravity := 1500.0        # how fast it falls
@export var casing_scale := 1.0             # size of the case
@export_enum("none", "pistol", "smg", "rifle", "rifle_curved", "box", "sniper_box") var magazine_kind := "none"   # the empty magazine that drops out when you reload ("none": tube / break-action / revolver guns)
@export var magazine_color := Color(0.17, 0.18, 0.2)                 # colour of that magazine
@export var casing_color := Color(0.86, 0.68, 0.28)   # brass (shotgun shells: the colour of the plastic hull)


# Which firing modes this gun has (never empty).
func modes() -> PackedStringArray:
	if not fire_modes.is_empty():
		return fire_modes
	return PackedStringArray(["auto"] if automatic else ["semi"])


func default_mode() -> String:
	var m := modes()
	if default_fire_mode != "" and m.has(default_fire_mode):
		return default_fire_mode
	return m[0]


# Shortest gap between two shots in this mode.
func shot_gap(mode: String) -> float:
	if (mode == "semi" or mode == "single") and semi_fire_rate > 0.0:
		return maxf(semi_fire_rate, 0.03)
	return maxf(fire_rate, 0.03)


static func mode_label(mode: String) -> String:
	return {"semi": "SEMI", "auto": "AUTO", "burst": "BURST", "single": "SINGLE"}.get(mode, mode.to_upper())


# "Futuristic AK-47": the variant in front of the name (or just the name if there is no variant).
func full_name() -> String:
	return display_name if variant == "" else "%s %s" % [variant, display_name]
