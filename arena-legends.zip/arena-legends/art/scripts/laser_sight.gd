class_name LaserSight
extends Node2D
## Red laser sight on the player's gun(s), like Mini Militia: a thin line from the muzzle along your aim that
## stops where it hits the ground, a wall or a fighter, with a small dot at the end.
## Settings > Laser Sight turns it on / off (saved). Pure visual: it never changes bullets, damage or aim.

const MAX_LEN := 900.0
const LINE_COL := Color(1.0, 0.15, 0.1, 0.75)
const DOT_COL := Color(1.0, 0.3, 0.2, 0.95)

var _player: Node
var _hits: Array = []            # [from, to, hit?] per gun, in world space


static func attach(player: Node) -> void:
	if player == null or player.get_node_or_null("LaserSight") != null:
		return
	var l := LaserSight.new()
	l.name = "LaserSight"
	player.add_child(l)


func _ready() -> void:
	_player = get_parent()
	top_level = true                  # drawn in world space, so the player's flips / scale never bend the line
	global_position = Vector2.ZERO
	z_index = 50


func _physics_process(_delta: float) -> void:
	_hits.clear()
	if GameSettings.laser_sight and _player.get("is_dead") != true and _player.get("weapon") != null:
		var vis = _player.get("visuals")
		var dir: Vector2 = _player.get("aim_dir")
		if vis != null and dir.length() > 0.01:
			_add_beam(vis.muzzle.global_position, dir.normalized())
			if _player.get("dual") == true and vis.get("off_muzzle") != null:
				_add_beam(vis.off_muzzle.global_position, dir.normalized())
	queue_redraw()


func _add_beam(from: Vector2, dir: Vector2) -> void:
	var to := from + dir * MAX_LEN
	var q := PhysicsRayQueryParameters2D.create(from, to, (_player as CollisionObject2D).collision_mask)
	q.exclude = [(_player as CollisionObject2D).get_rid()]
	var r := get_world_2d().direct_space_state.intersect_ray(q)
	var hit := not r.is_empty()
	if hit:
		to = r["position"]
	_hits.append([from, to, hit])


func _draw() -> void:
	var cam := get_viewport().get_camera_2d()
	var px := 1.0 / maxf(cam.zoom.x if cam != null else 1.0, 0.1)       # keeps the line the same thickness on screen
	for h in _hits:
		var a: Vector2 = h[0]
		var b: Vector2 = h[1]
		draw_line(a, b, Color(LINE_COL.r, LINE_COL.g, LINE_COL.b, 0.22), 4.0 * px)   # soft glow
		draw_line(a, b, LINE_COL, 1.6 * px)
		if h[2]:
			draw_circle(b, 3.2 * px, DOT_COL)
