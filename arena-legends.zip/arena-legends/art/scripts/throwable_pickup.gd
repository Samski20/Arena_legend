class_name ThrowablePickup
extends Area2D
## A throwable lying on the map. Just walk (or fly) into it to collect it.
## Full on that type? It stays put until you have room.
## Normally created by ThrowableSpawner, but you can also place one by hand:
##   var p := ThrowablePickup.new()
##   p.data = ThrowableCatalog.get_data("emp")
##   add_child(p)

signal collected(pickup)

var data: ThrowableData
@export var grab_height := 34.0      # centre of the pick-up zone above the surface (collision only: the grenade itself lies on the floor)
@export var icon_scale := 0.24       # size of the grenade picture on the map (128px art -> ~22px tall, about a third of a player)
@export var lifetime := 40.0         # untouched pickups fade away after this long (0 = never)

static var _rows_cache := {}         # texture -> Vector2(first solid row, last solid row), so each icon is only measured once

var _sprite: Sprite2D
var _vis_h := 16.0                   # height of the visible grenade (px); its bottom sits at y = 0 (the floor)
var _vis_w := 14.0
var _t := 0.0
var _age := 0.0
var _done := false
var _nearby: Node = null
var _label := ""
var net_id := 0                      # network match id (0 = offline)
var net_role := 0                    # 1 host, 2 client


func _ready() -> void:
	if data == null:
		queue_free()
		return
	monitoring = true
	add_to_group("throwable_pickup")
	z_index = 4
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR

	var shape := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 38.0
	shape.shape = circle
	shape.position = Vector2(0, -grab_height)
	add_child(shape)

	if data.icon != null:
		_sprite = Sprite2D.new()
		_sprite.texture = data.icon
		_sprite.scale = Vector2(icon_scale, icon_scale)
		# the picture has empty margin below the bomb: shift it so the visible bottom touches the floor
		var rows := _solid_rows(data.icon)
		var tex_h := float(data.icon.get_height())
		_sprite.position.y = -((rows.y + 1.0) - tex_h * 0.5) * icon_scale
		_vis_h = (rows.y + 1.0 - rows.x) * icon_scale
		_vis_w = float(data.icon.get_width()) * 0.5 * icon_scale
		add_child(_sprite)

	body_entered.connect(func(b: Node) -> void:
		if b.has_method("add_throwable"):
			_nearby = b)
	body_exited.connect(func(b: Node) -> void:
		if b == _nearby:
			_nearby = null)

	# pop-in
	scale = Vector2(0.2, 0.2)
	create_tween().tween_property(self, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_burst(false)
	queue_redraw()


func _process(delta: float) -> void:
	if _done:
		return
	_t += delta
	_age += delta

	if lifetime > 0.0 and net_role != 2:        # clients wait for the host to remove it
		var left := lifetime - _age
		if left <= 0.0:
			_done = true
			collected.emit(self)
			if net_role == 1:
				Net.game.host_tpickup_removed(self)
			queue_free()
			return
		visible = left > 6.0 or int(left * 6.0) % 2 == 0      # blinks before vanishing

	# someone standing in it with room to carry more? they get it.
	var new_label := ""
	if _nearby != null and is_instance_valid(_nearby):
		var has_room: bool = _nearby.has_method("throwable_room") and _nearby.throwable_room(data)
		if has_room:
			if net_role == 2:
				Net.game.client_tpickup_request(self)       # the host decides if we really get it
			else:
				_collect(_nearby)
				return
		new_label = "%s  (FULL)" % data.display_name.to_upper()
	if new_label != _label:
		_label = new_label
	queue_redraw()        # the glow pulses, so it redraws every frame (it's just a few shapes)


func _draw() -> void:
	if data == null:
		return
	var c := data.color
	var pulse := 0.5 + 0.5 * sin(_t * 4.0)
	var center := Vector2(0, -_vis_h * 0.5)        # middle of the grenade lying on the floor
	var glow_r := clampf(_vis_h * 0.5 + 9.0, 16.0, 26.0)
	# soft contact shadow so it reads as sitting on the surface
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.3))
	draw_circle(Vector2.ZERO, maxf(_vis_w, 8.0) * 0.9, Color(0, 0, 0, 0.3))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	draw_circle(center, glow_r + pulse * 2.0, Color(c.r, c.g, c.b, 0.12 + pulse * 0.06))
	draw_arc(center, glow_r, 0.0, TAU, 36, Color(c.r, c.g, c.b, 0.75), 2.0)
	if data.icon == null:                      # no art yet: a simple colored bomb
		draw_circle(Vector2(0, -8.0), 8.0, Color(0.07, 0.08, 0.13))
		draw_circle(Vector2(0, -8.0), 6.0, c)
	if _label != "":
		var font := ThemeDB.fallback_font
		var pos := Vector2(-80, -_vis_h - 32.0)
		draw_string_outline(font, pos, _label, HORIZONTAL_ALIGNMENT_CENTER, 160.0, 16, 6, Color.BLACK)
		draw_string(font, pos, _label, HORIZONTAL_ALIGNMENT_CENTER, 160.0, 16, Color.WHITE)


func _collect(who: Node) -> void:
	_done = true
	monitoring = false
	who.add_throwable(data, data.pickup_amount)
	if net_role == 1:
		Net.game.host_tpickup_removed(self)
	_burst(true)
	collected.emit(self)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(self, "scale", Vector2(1.6, 1.6), 0.18)
	tw.tween_property(self, "modulate:a", 0.0, 0.18)
	tw.chain().tween_callback(queue_free)


# little sparkle: on spawn (soft) and on pickup (bigger)
func _burst(big: bool) -> void:
	var p := CPUParticles2D.new()
	p.position = Vector2(0, -_vis_h * 0.5)
	p.emitting = true
	p.one_shot = true
	p.explosiveness = 1.0
	p.amount = 18 if big else 8
	p.lifetime = 0.5
	p.direction = Vector2(0, -1)
	p.spread = 180.0
	p.initial_velocity_min = 60.0
	p.initial_velocity_max = 170.0 if big else 90.0
	p.gravity = Vector2.ZERO
	p.scale_amount_min = 2.0
	p.scale_amount_max = 4.0
	var g := Gradient.new()
	g.colors = PackedColorArray([Color(data.color.r, data.color.g, data.color.b, 0.9), Color(data.color.r, data.color.g, data.color.b, 0.0)])
	g.offsets = PackedFloat32Array([0.0, 1.0])
	p.color_ramp = g
	var mat := CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	p.material = mat
	if big:
		# the pickup itself disappears right away, so the sparkle lives in the level instead
		p.position = position + Vector2(0, -_vis_h * 0.5)      # same space as this pickup's parent
		get_parent().add_child(p)
		get_tree().create_timer(1.0).timeout.connect(p.queue_free)
	else:
		add_child(p)


# First and last row of the picture that is clearly visible (alpha > 0.35), in texture pixels.
func _solid_rows(tex: Texture2D) -> Vector2:
	if _rows_cache.has(tex):
		return _rows_cache[tex]
	var result := Vector2(0, tex.get_height() - 1)
	var img := tex.get_image()
	if img != null and not img.is_empty():
		var top := -1
		var bottom := -1
		for y in img.get_height():
			for x in img.get_width():
				if img.get_pixel(x, y).a > 0.35:
					if top < 0:
						top = y
					bottom = y
					break
		if top >= 0:
			result = Vector2(top, bottom)
	_rows_cache[tex] = result
	return result


# ======================= network match =======================
# HOST: a validated client request took it (the client adds the bombs to itself when the host's grant arrives).
func net_take() -> void:
	if _done:
		return
	_done = true
	monitoring = false
	_burst(true)
	collected.emit(self)
	Net.game.host_tpickup_removed(self)
	queue_free()


# CLIENT: the host removed it (someone took it or it timed out).
func net_remove() -> void:
	if _done:
		return
	_done = true
	monitoring = false
	_burst(true)
	queue_free()
