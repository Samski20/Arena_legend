class_name DamageNumber
extends Label
## Floating damage number that pops over whatever you hit (it doubles as the hit marker). Bigger and warmer on a kill.

static func spawn(parent: Node, world_pos: Vector2, amount: int, killed := false) -> void:
	if parent == null or amount <= 0:
		return
	var l := DamageNumber.new()
	l.text = "%d" % amount
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.z_index = 200
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.custom_minimum_size = Vector2(120, 0)
	l.add_theme_font_override("font", UITheme.font(true))
	l.add_theme_font_size_override("font_size", 34 if killed else 24)
	l.add_theme_color_override("font_color", Color("ff6b5e") if killed else Color("ffffff"))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	l.add_theme_constant_override("outline_size", 7)
	parent.add_child(l)
	l.global_position = world_pos + Vector2(randf_range(-14.0, 14.0) - 60.0, -46.0)
	l.pivot_offset = Vector2(60, 16)
	l.scale = Vector2(1.5, 1.5)
	var t := l.create_tween()
	t.set_parallel(true)
	t.set_ease(Tween.EASE_OUT)
	t.set_trans(Tween.TRANS_CUBIC)
	t.tween_property(l, "scale", Vector2.ONE, 0.16)
	t.tween_property(l, "global_position:y", l.global_position.y - 54.0, 0.75)
	t.tween_property(l, "modulate:a", 0.0, 0.35).set_delay(0.4)
	t.chain().tween_callback(l.queue_free)
