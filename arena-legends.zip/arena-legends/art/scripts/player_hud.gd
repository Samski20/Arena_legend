class_name PlayerHUD
extends CanvasLayer
## Self-building HUD: health meter, jetpack fuel meter, and icons for the gun in
## your hands plus the one you're carrying. player.gd creates it automatically,
## so there is nothing to add to the scene.

const HP_COLOR := UITheme.PRIMARY
const HP_LOW_COLOR := Color("ff5a5f")
const FUEL_COLOR := UITheme.FLY
const FUEL_LOW_COLOR := UITheme.WARM
const ACCENT := UITheme.PRIMARY
const PANEL_BG := Color(1, 1, 1, 0.07)
const EDGE := Color(1, 1, 1, 0.10)

var _hp_bar: ProgressBar
var _hp_label: Label
var _hp_fill: StyleBoxFlat
var _fuel_bar: ProgressBar
var _fuel_label: Label
var _fuel_fill: StyleBoxFlat

var _main_panel: PanelContainer
var _main_icon: TextureRect
var _main_style: StyleBoxFlat
var _alt_panel: PanelContainer
var _alt_icon: TextureRect
var _alt_style: StyleBoxFlat
var _hint: Label
var _throw_panel: PanelContainer
var _slot_row: HBoxContainer
var _touch := false          # touch HUD: controls show guns + grenades
var _throw_icon: ThrowIcon
var _throw_label: Label
var _haze: ColorRect
var _haze_target := 0.0
var _flash: TextureRect                  # red screen-edge flash when you are hit (and a slow pulse on low health)
var _flash_a := 0.0
var _pulse_t := 0.0

var _hp := 100.0
var _hp_max := 100.0
var _fuel := 100.0
var _fuel_max := 100.0
var _hp_shown := 100.0
var _fuel_shown := 100.0


func _ready() -> void:
	layer = 5
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	_haze = ColorRect.new()                  # screen haze while standing in smoke
	_haze.set_anchors_preset(Control.PRESET_FULL_RECT)
	_haze.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_haze.color = Color(0.62, 0.65, 0.72, 0.0)
	root.add_child(_haze)

	_flash = TextureRect.new()
	_flash.texture = UITheme.radial_edge(Color(1.0, 0.18, 0.2, 0.8), 0.5)
	_flash.set_anchors_preset(Control.PRESET_FULL_RECT)
	_flash.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_flash.stretch_mode = TextureRect.STRETCH_SCALE
	_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_flash.modulate.a = 0.0
	root.add_child(_flash)

	# one soft glass card holds the meters (Material-style, no outlines)
	var inset := UITheme.safe_insets()
	var card := PanelContainer.new()
	card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.position = Vector2(16.0 + inset.x, 68.0 + inset.y)       # sits under the MENU button
	card.add_theme_stylebox_override("panel", UITheme.glass_box(22, 12, 0.5))
	root.add_child(card)
	var box := VBoxContainer.new()
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_theme_constant_override("separation", 8)
	card.add_child(box)

	var hp := _make_bar(box, "HEALTH", HP_COLOR)
	_hp_bar = hp[0]; _hp_label = hp[1]; _hp_fill = hp[2]
	var fuel := _make_bar(box, "JETPACK", FUEL_COLOR)
	_fuel_bar = fuel[0]; _fuel_label = fuel[1]; _fuel_fill = fuel[2]

	var row := HBoxContainer.new()
	_slot_row = row
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 8)
	box.add_child(row)

	var main := _make_slot(row, Vector2(116, 40))
	_main_panel = main[0]; _main_icon = main[1]; _main_style = main[2]
	var alt := _make_slot(row, Vector2(80, 28))
	_alt_panel = alt[0]; _alt_icon = alt[1]; _alt_style = alt[2]

	_hint = Label.new()
	_hint.add_theme_font_size_override("font_size", 12)
	_hint.add_theme_color_override("font_color", UITheme.ON_VARIANT)
	_hint.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(_hint)

	# throwable slot (its own row, under the guns)
	_throw_panel = PanelContainer.new()
	_throw_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var tsb := StyleBoxFlat.new()
	tsb.bg_color = PANEL_BG
	tsb.set_corner_radius_all(14)
	tsb.set_border_width_all(1)
	tsb.border_color = EDGE
	tsb.set_content_margin_all(5)
	_throw_panel.add_theme_stylebox_override("panel", tsb)
	var trow := HBoxContainer.new()
	trow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	trow.add_theme_constant_override("separation", 8)
	_throw_panel.add_child(trow)
	_throw_icon = ThrowIcon.new()
	_throw_icon.custom_minimum_size = Vector2(32, 32)
	_throw_icon.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	trow.add_child(_throw_icon)
	_throw_label = Label.new()
	_throw_label.add_theme_font_size_override("font_size", 13)
	_throw_label.add_theme_color_override("font_color", UITheme.ON_SURFACE)
	_throw_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	trow.add_child(_throw_label)
	box.add_child(_throw_panel)

	set_weapons(null, null, false)
	set_throwable(null, 0)
	_refresh_bars()


func _process(delta: float) -> void:
	# bars glide to their new value instead of snapping
	var k := 1.0 - exp(-12.0 * delta)
	_hp_shown = lerpf(_hp_shown, _hp, k)
	_fuel_shown = lerpf(_fuel_shown, _fuel, k)
	_refresh_bars()
	_haze.color.a = lerpf(_haze.color.a, _haze_target, 1.0 - exp(-6.0 * delta))
	# damage flash fades out; low health adds a slow heartbeat glow at the screen edges
	_flash_a = maxf(_flash_a - delta * 2.2, 0.0)
	var low := _hp > 0.0 and _hp / _hp_max < 0.3
	var pulse := 0.0
	if low:
		_pulse_t += delta * 3.2
		pulse = 0.14 + 0.12 * (0.5 + 0.5 * sin(_pulse_t))
	_flash.modulate.a = maxf(_flash_a, pulse)


# ---------- called by player.gd ----------
# On touch devices the weapon / grenade icons live on touch buttons, so only meters stay here.
func set_touch_mode(on: bool) -> void:
	_touch = on
	if _slot_row != null:
		_slot_row.visible = not on
	if _throw_panel != null:
		_throw_panel.visible = not on and _throw_icon != null and _throw_icon.texture != null


## Red flash at the screen edges. `fraction` = damage as a share of max health (a big hit flashes harder).
func flash_damage(fraction: float) -> void:
	_flash_a = clampf(0.28 + fraction * 1.0, 0.28, 0.7)


func set_smoke(on: bool) -> void:
	_haze_target = 0.55 if on else 0.0


func set_stats(health: float, max_health: float, fuel: float, max_fuel: float) -> void:
	_hp = health
	_hp_max = maxf(max_health, 1.0)
	_fuel = fuel
	_fuel_max = maxf(max_fuel, 1.0)


# main = gun in your hands, alt = the other gun you carry (null if none).
# While dual wielding, both are in your hands and both slots light up.
func set_weapons(main: WeaponData, alt: WeaponData, is_dual: bool) -> void:
	if _main_icon == null:
		return
	_main_icon.texture = main.texture if main else null
	_alt_icon.texture = alt.texture if alt else null

	_main_style.border_color = ACCENT
	_alt_style.border_color = ACCENT if is_dual else EDGE
	_alt_panel.modulate.a = 0.0 if alt == null else (1.0 if is_dual else 0.6)
	_alt_panel.visible = alt != null
	if is_dual:
		_hint.text = "DUAL WIELD"
	elif alt != null:
		_hint.text = "" if _touch else "E: swap"
	else:
		_hint.text = ""


# The bomb currently selected for the throwable slot (null hides the slot).
func set_throwable(data: ThrowableData, count: int) -> void:
	if _throw_label == null:
		return
	if data == null:
		_throw_panel.visible = false
		return
	_throw_panel.visible = not _touch
	_throw_icon.color = data.color
	_throw_icon.texture = data.icon
	_throw_icon.queue_redraw()
	_throw_label.text = "G: %s x%d" % [data.display_name.to_upper(), count]
	_throw_panel.modulate.a = 1.0 if count > 0 else 0.45


# ---------- building blocks ----------
func _refresh_bars() -> void:
	if _hp_bar == null:
		return
	_hp_bar.max_value = _hp_max
	_hp_bar.value = _hp_shown
	_hp_label.text = "%d" % ceili(_hp)
	_hp_fill.bg_color = HP_LOW_COLOR if _hp_shown / _hp_max < 0.3 else HP_COLOR

	_fuel_bar.max_value = _fuel_max
	_fuel_bar.value = _fuel_shown
	_fuel_label.text = "%d" % ceili(_fuel)
	_fuel_fill.bg_color = FUEL_LOW_COLOR if _fuel_shown / _fuel_max < 0.2 else FUEL_COLOR


func _make_bar(parent: Control, title: String, color: Color) -> Array:
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 8)
	parent.add_child(row)

	var name_label := Label.new()
	name_label.text = title
	name_label.custom_minimum_size = Vector2(62, 0)
	name_label.add_theme_font_size_override("font_size", 11)
	name_label.add_theme_color_override("font_color", UITheme.ON_VARIANT)
	row.add_child(name_label)

	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(190, 16)
	bar.show_percentage = false
	bar.min_value = 0.0
	bar.max_value = 100.0
	bar.value = 100.0
	var bg := StyleBoxFlat.new()
	bg.bg_color = PANEL_BG
	bg.set_corner_radius_all(8)
	var fill := StyleBoxFlat.new()
	fill.bg_color = color
	fill.set_corner_radius_all(8)
	bar.add_theme_stylebox_override("background", bg)
	bar.add_theme_stylebox_override("fill", fill)
	row.add_child(bar)

	var value_label := Label.new()
	value_label.set_anchors_preset(Control.PRESET_FULL_RECT)
	value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	value_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	value_label.add_theme_font_size_override("font_size", 10)
	value_label.add_theme_font_override("font", UITheme.font(true))
	value_label.add_theme_color_override("font_color", Color.WHITE)
	value_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.55))
	value_label.add_theme_constant_override("outline_size", 3)
	value_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.add_child(value_label)
	return [bar, value_label, fill]


func _make_slot(parent: Control, icon_size: Vector2) -> Array:
	var panel := PanelContainer.new()
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = PANEL_BG
	sb.set_corner_radius_all(14)
	sb.set_border_width_all(1)
	sb.border_color = EDGE
	sb.set_content_margin_all(5)
	panel.add_theme_stylebox_override("panel", sb)

	var icon := TextureRect.new()
	icon.custom_minimum_size = icon_size
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(icon)
	parent.add_child(panel)
	return [panel, icon, sb]


# little round bomb icon for the throwable slot
class ThrowIcon extends Control:
	var color := Color.WHITE
	var texture: Texture2D

	func _draw() -> void:
		if texture != null:                 # real bomb art
			draw_texture_rect(texture, Rect2(Vector2.ZERO, size), false)
			return
		var c := size * 0.5
		var ink := Color(0.07, 0.08, 0.13)
		draw_circle(c + Vector2(0, 2), 11.0, ink)
		draw_circle(c + Vector2(0, 2), 9.0, color.darkened(0.4))
		draw_circle(c + Vector2(-3, -1), 3.5, color.lightened(0.3))
		draw_rect(Rect2(c.x - 3, c.y - 11, 6, 5), ink)
