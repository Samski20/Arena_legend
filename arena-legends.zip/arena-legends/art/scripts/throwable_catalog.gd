class_name ThrowableCatalog
extends RefCounted
## ONE place that decides which throwables exist, how common they are, and
## which maps they can spawn on.
##
## To make a throwable map-exclusive, change its "maps" list below.
##   maps = []                       -> spawns on every map
##   maps = ["abandoned_station"]    -> only on that map
##   maps = ["abandoned_station", "ice_base"]  -> on both
## A map id is whatever you type in the map's "map_id" field.
##
## IMPORTANT: every throwable is built ONCE and shared (get_data), so the player's
## ammo counts and the pickups always talk about the very same object.

const IDS := [
	"grenade", "knockback", "smoke", "decoy", "incendiary",
	"emp", "toxic", "gravity", "trap_mine", "flight_disruption",
	"cryo", "portal",
]

const ENTRIES := {
	# ---- everywhere ----
	"grenade":           {"maps": [], "weight": 10.0, "category": "explosive"},
	"knockback":         {"maps": [], "weight": 7.0, "category": "explosive"},
	"smoke":             {"maps": [], "weight": 6.0, "category": "tactical"},
	"decoy":             {"maps": [], "weight": 4.0, "category": "tactical"},
	"incendiary":        {"maps": [], "weight": 5.0, "category": "hazard"},
	# ---- Tactical map pool: Abandoned Station ----
	"emp":               {"maps": ["abandoned_station"], "weight": 4.0, "category": "tactical"},
	"toxic":             {"maps": ["abandoned_station"], "weight": 5.0, "category": "hazard"},
	"gravity":           {"maps": ["abandoned_station"], "weight": 3.0, "category": "tactical"},
	"trap_mine":         {"maps": ["abandoned_station"], "weight": 4.0, "category": "explosive"},
	"flight_disruption": {"maps": ["abandoned_station"], "weight": 3.0, "category": "tactical"},
	# ---- spawn on Abandoned Station now, and on their own future maps too ----
	"cryo":              {"maps": ["abandoned_station", "future_ice_map"], "weight": 5.0, "category": "tactical"},
	"portal":            {"maps": ["abandoned_station", "future_portal_map"], "weight": 3.0, "category": "tactical"},
}


## Categories (by what the throwable really does):
##   explosive = a burst blast that damages / launches (Grenade, Knockback Bomb, Trap Mine)
##   hazard    = leaves a damaging zone (Incendiary, Toxic)
##   tactical  = utility / control, no direct damage (Smoke, Decoy, EMP, Gravity, Flight Disruptor, Cryo, Portal)
## Menu modes: GRENADES = the standard Grenade only, EXPLOSIVES = explosive + hazard, TACTICAL = tactical.
const CATEGORY_NAMES := {"explosive": "Explosive", "hazard": "Hazard", "tactical": "Tactical"}

## Match setup restricts what PICKUPS can spawn. Empty + inactive = no restriction (LAN and default play).
static var spawn_filter_active := false
static var spawn_filter: Array = []

static func category_of(id: String) -> String:
	return str(ENTRIES.get(id, {}).get("category", "tactical"))


static func mode_contains(mode: String, id: String) -> bool:
	match mode:
		"grenades": return id == "grenade"
		"explosives": return category_of(id) in ["explosive", "hazard"]
		"tactical": return category_of(id) == "tactical"
	return true


# What PICKUPS may spawn on this map. Bots keep using for_map() so their equipment is unchanged.
static func spawn_pool(map_id: String) -> Array[ThrowableData]:
	var out: Array[ThrowableData] = []
	for d in for_map(map_id):
		if not spawn_filter_active or spawn_filter.has(d.catalog_id):
			out.append(d)
	return out

static var _cache := {}


static func get_data(id: String) -> ThrowableData:
	if _cache.has(id):
		return _cache[id]
	var d: ThrowableData = null
	match id:
		"grenade": d = ThrowableData.make_grenade()
		"knockback": d = ThrowableData.make_knockback_bomb()
		"smoke": d = ThrowableData.make_smoke()
		"decoy": d = ThrowableData.make_decoy()
		"incendiary": d = ThrowableData.make_incendiary()
		"emp": d = ThrowableData.make_emp()
		"toxic": d = ThrowableData.make_toxic()
		"gravity": d = ThrowableData.make_gravity()
		"trap_mine": d = ThrowableData.make_trap_mine()
		"flight_disruption": d = ThrowableData.make_flight_disruption()
		"cryo": d = ThrowableData.make_cryo()
		"portal": d = ThrowableData.make_portal()
	if d == null:
		push_warning("ThrowableCatalog: unknown throwable id '%s'" % id)
		return null
	var entry: Dictionary = ENTRIES.get(id, {"maps": [], "weight": 5.0})
	d.catalog_id = id
	d.allowed_maps = PackedStringArray(entry["maps"])
	d.spawn_weight = float(entry["weight"])
	_cache[id] = d
	return d


static func can_spawn_on(d: ThrowableData, map_id: String) -> bool:
	return d.allowed_maps.is_empty() or d.allowed_maps.has(map_id)


# Every throwable that is allowed on this map.
static func for_map(map_id: String) -> Array[ThrowableData]:
	var out: Array[ThrowableData] = []
	for id in IDS:
		var d := get_data(id)
		if d != null and can_spawn_on(d, map_id):
			out.append(d)
	return out


# Weighted random pick. `avoid` lets the spawner skip types that are already lying around.
static func pick_random(map_id: String, avoid: Array = []) -> ThrowableData:
	var pool := spawn_pool(map_id)
	var choices: Array[ThrowableData] = []
	for d in pool:
		if not avoid.has(d):
			choices.append(d)
	if choices.is_empty():
		choices = pool                      # everything is taken: allow repeats
	if choices.is_empty():
		return null
	var total := 0.0
	for d in choices:
		total += maxf(d.spawn_weight, 0.01)
	var roll := randf() * total
	for d in choices:
		roll -= maxf(d.spawn_weight, 0.01)
		if roll <= 0.0:
			return d
	return choices.back()
