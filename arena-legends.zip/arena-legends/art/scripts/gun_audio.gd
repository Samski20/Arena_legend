class_name GunAudio
extends RefCounted
## Gun sounds, made in code (no audio files needed). Every weapon has a sound_style; each style is a short
## burst of low thump + filtered noise + a sharp crack, so a pistol, an SMG, a rifle, a machine gun, a shotgun,
## a sniper and the RPG all sound different. Each shooter owns a small pool of players, so automatic fire never
## stacks into an unbearably loud wall of sound (the oldest shot is cut when the pool is full).

const RATE := 22050
const POOL_SIZE := 4

# style -> [length s, thump Hz, thump decay, thump amp, noise amp, noise decay, noise smoothing(0-1, higher = brighter), crack amp, volume dB]
const STYLES := {
	"pistol":   [0.16, 150.0, 30.0, 0.60, 0.80, 36.0, 0.55, 0.55, -9.0],
	"magnum":   [0.30, 95.0, 14.0, 0.95, 0.85, 17.0, 0.40, 0.70, -5.0],
	"revolver": [0.34, 80.0, 12.0, 1.00, 0.80, 14.0, 0.35, 0.75, -4.0],
	"smg":      [0.11, 190.0, 40.0, 0.50, 0.75, 46.0, 0.65, 0.55, -11.0],
	"thompson": [0.15, 120.0, 26.0, 0.80, 0.70, 30.0, 0.40, 0.45, -9.0],
	"rifle":    [0.20, 130.0, 22.0, 0.75, 0.80, 26.0, 0.50, 0.65, -8.0],
	"dmr":      [0.32, 90.0, 13.0, 0.95, 0.80, 16.0, 0.42, 0.80, -5.0],
	"mg":       [0.17, 110.0, 24.0, 0.85, 0.75, 29.0, 0.45, 0.55, -9.0],
	"shotgun":  [0.30, 85.0, 12.0, 0.95, 0.95, 15.0, 0.38, 0.50, -4.0],
	"sniper":   [0.50, 65.0, 8.0, 1.00, 0.85, 10.0, 0.36, 0.90, -3.0],
	"rocket":   [0.45, 70.0, 7.0, 0.85, 0.95, 8.0, 0.30, 0.10, -4.0],
	"boom":     [0.90, 48.0, 4.2, 1.00, 0.95, 5.0, 0.22, 0.0, -2.0],
}
const FLASH_TO_SOUND := {"pistol": "pistol", "smg": "smg", "rifle": "rifle", "mg": "mg", "shotgun": "shotgun", "sniper": "sniper", "magnum": "magnum"}

static var _cache := {}


static func style_of(w: WeaponData) -> String:
	if w.sound_style != "":
		return w.sound_style
	return FLASH_TO_SOUND.get(w.flash_style, "rifle")


static func _make(style: String, variant: int) -> AudioStreamWAV:
	var key := "%s_%d" % [style, variant]
	if _cache.has(key):
		return _cache[key]
	var p: Array = STYLES.get(style, STYLES["rifle"])
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(key)
	var n := int(float(RATE) * float(p[0]))
	var bytes := PackedByteArray()
	bytes.resize(n * 2)
	var lp := 0.0
	var f0: float = float(p[1]) * (1.0 + 0.07 * float(variant))
	for i in n:
		var t := float(i) / float(RATE)
		var attack := minf(1.0, t / 0.0015)
		var thump := sin(TAU * f0 * t * (1.0 - 0.35 * minf(t * 6.0, 1.0))) * exp(-t * float(p[2])) * float(p[3])
		lp = lerpf(lp, rng.randf() * 2.0 - 1.0, float(p[6]))
		var noise := lp * exp(-t * float(p[5])) * float(p[4])
		var crack := (rng.randf() * 2.0 - 1.0) * exp(-t * 220.0) * float(p[7])
		var v := clampf((thump + noise + crack) * attack, -1.0, 1.0)
		bytes.encode_s16(i * 2, int(v * 28000.0))
	var s := AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = RATE
	s.stereo = false
	s.data = bytes
	_cache[key] = s
	return s


# One shot from `shooter`'s gun. Call once per shot (a shotgun blast or one round of a burst = one sound).
static func shoot(shooter: Node2D, w: WeaponData, quiet_db := 0.0) -> void:
	if shooter == null or w == null or not is_instance_valid(shooter):
		return
	var style := style_of(w)
	var pool: Node2D = shooter.get_node_or_null("GunAudioPool")
	if pool == null:
		pool = Node2D.new()
		pool.name = "GunAudioPool"
		pool.set_meta("next", 0)
		for i in POOL_SIZE:
			var a := AudioStreamPlayer2D.new()
			a.max_distance = 1500.0
			a.attenuation = 1.5
			pool.add_child(a)
		shooter.add_child(pool)
	var idx: int = int(pool.get_meta("next"))
	var chosen: AudioStreamPlayer2D = null
	for i in POOL_SIZE:                                  # a free player if there is one, else cut the oldest
		var cand := pool.get_child((idx + i) % POOL_SIZE) as AudioStreamPlayer2D
		if not cand.playing:
			chosen = cand
			idx = (idx + i + 1) % POOL_SIZE
			break
	if chosen == null:
		chosen = pool.get_child(idx) as AudioStreamPlayer2D
		idx = (idx + 1) % POOL_SIZE
	pool.set_meta("next", idx)
	var p: Array = STYLES.get(style, STYLES["rifle"])
	chosen.stream = _make(style, randi() % 3)
	chosen.volume_db = float(p[8]) + quiet_db
	chosen.pitch_scale = randf_range(0.95, 1.06)
	chosen.play()


# A rocket explosion at a world position (a one-off player that frees itself).
static func boom_at(tree: SceneTree, pos: Vector2) -> void:
	if tree == null or tree.current_scene == null:
		return
	var a := AudioStreamPlayer2D.new()
	a.stream = _make("boom", randi() % 3)
	a.volume_db = float(STYLES["boom"][8])
	a.max_distance = 2200.0
	a.attenuation = 1.2
	a.finished.connect(a.queue_free)
	tree.current_scene.add_child(a)
	a.global_position = pos
	a.play()
