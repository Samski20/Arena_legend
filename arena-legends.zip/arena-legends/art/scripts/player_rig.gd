class_name PlayerRig
extends Node2D
## Smooth, customizable 2D character rig (Mini Militia style), 3/4 view soldier.
## Put the PNGs in res://art/player/ and keep this script on the Node2D called "Visuals".
## The rig origin is the hips; the feet are about 47px below it.

const ART := "res://art/player/"
# Arms are held OUT in front of the body, like Mini Militia: each gun is placed so the hand(s) reach it with the
# arm nearly straight. How far out depends on the gun: a gun held with two hands keeps its FRONT hand near full
# reach and lets the rear hand sit a bit closer; a one-handed gun in a dual wield is held at full stretch.
const REACH_GOAL := 47.0              # the front hand's distance from the shoulder (arm length is 48)
const HAND_MIN := 26.0                # never closer than this (long guns keep their stock near the shoulder)
const HAND_MAX := 42.0                # never farther than this for the rear/main hand
const ART_SCALE := 2.0            # the body art is drawn 2x bigger than its in-game size (smoother, more detail)
const UPPER_ARM := 24.0           # shoulder -> elbow (BodySlots.UPPER_ARM)
const FOREARM := 24.0             # elbow -> hand (BodySlots.FOREARM)
const HEAD_Y := -58.0            # the head sits low enough that its neck runs into the shoulders
const HEAD_ART := 2.5            # the head picture is a bit smaller than the rest (so the head is in proportion)
const JP_ART := 2.35             # jetpack picture scale
const MAX_ARM_STRETCH := 1.2      # an arm may stretch this much if a hand target is out of reach
const SHIELD_HALF_ANGLE := 0.95   # shield covers this many radians either side of your aim (player.gd uses it too)

# Ground contact events (GroundContact turns these into dust, sound, camera thump).
signal footstep(boot: Node2D, power: float)   # a boot just planted; power ~0.4 crouch-walk .. 1.2 sprint
signal landed(strength: float)                # touched down after a fall; ~0.2 small drop .. 1.0+ hard landing

# Customization: each key tints every sprite in that group (a "_dark" group is the far-side limb).
# "beard" is on/off. The look below is the default "Sentinel" set.
var loadout := {
	"skin":    Color("e8bc9c"),
	"hair":    Color("3a2a22"),
	"helmet":  Color("58667a"),
	"accent":  Color("46546a"),
	"visor":   Color("b8f0ff"),
	"uniform": Color("2f3a4c"),
	"pants":   Color("2f3a4c"),
	"vest":    Color("5d6c82"),
	"gear":    Color("232a36"),
	"leather": Color("7d5a3a"),
	"glove":   Color("262c38"),
	"boots":   Color("3c4350"),
	"jetpack": Color("5d6c82"),
	"glow":    Color("4fd8ff"),
	"beard":   false,
}

var rig: Node2D
var torso: Node2D
var head: Node2D
var aim_pivot: Node2D
var jetpack: Node2D             # the pack on the back (tilts when flying)
var front_boot: Node2D
var back_boot: Node2D
var pad_near: Node2D
var pad_far: Node2D
var straps: Node2D
var waist: Node2D
var _jfx: JetpackFx              # the pack's pictures, flames, exhaust and ignition animation
var _jp_id := "standard"
var _glow: Array[Sprite2D] = []
var hip_throwable: Node2D       # the equipped grenade, clipped to the belt like in Mini Militia
var _hip_sprite: Sprite2D
var weapon_sprite: Sprite2D     # holds whatever weapon is equipped (not tinted)
var off_pivot: Node2D            # second arm: holds the front of the gun, or a second gun while dual wielding
var _main_arm := {}              # {upper, fore, hand}: two-bone arm that holds the grip
var _off_arm := {}               # same for the second arm (holds the front of the gun / second gun)
var off_weapon_sprite: Sprite2D
var off_muzzle: Marker2D
var shield: Node2D             # energy shield shown while blocking
var muzzle: Marker2D            # spawn bullets at muzzle.global_position
var front_thigh: Node2D
var front_shin: Node2D
var back_thigh: Node2D
var back_shin: Node2D
var flames: Array[Sprite2D] = []
var _tinted: Array = []         # [sprite, group]
var _flags := {}                # appearance flag name -> [sprites / nodes] shown or hidden together (apply_appearance)
var preview := false            # the customisation menu draws a rig with no ground, shadow or dust
var _cosm_chest: Sprite2D
var _hl := {}                   # head layer name -> Sprite2D (skin, eyes, brows, hair, facial hair, headgear ... see _build_head)
var _head_state := {}           # the head parameters last applied (Appearance.resolve()["head"])
var _hair_sway: Node2D          # hair that hangs behind the head swings from here
var _hair_rot := 0.0
var _anat_mat: Material         # hue shader of the equipped creature cosmetic (null = none): used for its baked head pieces
var _ovs := {}                  # body slot name -> [overlay sprites]: clothes cut to a creature's own limbs
var _cape_node: Node2D
var _tex_cache := {}
var _exists_cache := {}
var _gm := []                   # garment layers (see _gm_make): {slot, owner, dark, layers{m,a,b,c,g,d}}
var _neck_patch: Sprite2D       # bare skin over the head/torso junction (creatures draw their own neck in the torso picture)
var collar_node: Node2D         # neckline pieces drawn over the base of the neck (above the head)
var _slots := {}                # body slot name -> [sprites]: the parts a full-anatomy cosmetic redraws (torso, thigh, hand ...)
var _body_sprites: Array = []   # every sprite _spr made while building (used to find decoration layers)
var _fx: CosmeticFx             # the cosmetic's own flight / movement presentation (wings, cape, levitation) or null
var _lean_mult := 1.0
var _hue_mat: ShaderMaterial
const COSM_ART := "res://art/cosmetics/"
const OUTFIT_ART := "res://art/outfits/"
# Clothing is drawn as separate pieces on top of the bare body. One piece = one picture per layer: m (main colour),
# a / b / c (camouflage or trim colours), g (glowing lines), d (details that keep their own colours: straps, buckles ...).
const GM_LAYERS := ["m", "a", "b", "c", "g", "d"]
# body slot -> which kinds of clothing have a piece on it (drawing order = list order)
const GM_OWNERS := {"torso": ["top", "armor"], "upper_arm": ["top"], "forearm": ["top", "gloves"], "hand": ["gloves"],
	"waist": ["bottom"], "thigh": ["bottom"], "shin": ["bottom", "boots"], "foot": ["boots"]}
var _t := 0.0

# ---- air acrobatics ----
const ROLL_PIVOT := Vector2(0, -24)         # the body turns around the middle of the torso
# Equipped grenade: it hangs from the belt buckle on the back side of the belt (matches the reference art).
const HIP_THROW_POS := Vector2(-8.3, -4.3)  # the buckle it hangs from (rig space, facing right)
const HIP_THROW_SPRITE_POS := Vector2(-0.5, 11.3)   # centre of the grenade picture, measured from that buckle
const HIP_THROW_SCALE := 0.21               # the 128px grenade picture shrinks to about 20px
var _flip_t := 0.0                    # time left in the current flip
var _flip_total := 0.55
var _flip_dir := 1.0
var _tilt := 0.0                      # smooth lean while flying
var _crouch_y := 0.0

# ---- jetpack flight animation (visual only; reads velocity/jetting/on_floor, never changes them) ----
const FLY_LEAN_MAX := 0.34          # torso lean (radians) at full sideways flight speed
const FLY_SPEED_REF := 360.0        # sideways speed that counts as "fast" (matches player jet_move_speed)
const FLY_ACC_REF := 1400.0         # acceleration that counts as a hard direction change (matches jet_accel)
const THRUST_ACC_REF := 1100.0      # vertical acceleration that counts as full thrust (matches thrust_power)
const LAND_TIME := 0.13             # how long the landing squash is held before it eases out
var _fly_blend := 0.0               # 0 = not in powered flight, 1 = fully in the flight pose (smooth)
var _fly_t := 0.0                   # animation clock for the wobbles (advances with delta, frame-rate independent)
var _prev_v := Vector2.ZERO
var _have_prev_v := false
var _prev_jet := false
var _lag := 0.0                     # legs lagging behind a change of direction (spring, radians)
var _lag_v := 0.0
var _kick := 0.0                    # tiny body bump from the thrust (spring, pixels; negative = up)
var _kick_v := 0.0
var _kick_cd := 0.0
var _air_time := 0.0
var _air_vy := 0.0
var _land_t := 0.0
var _land_s := 0.0
var _step_sign := 0.0                # sign of cos(walk phase): flips twice per stride = one footstep each
var _foot_k := 0.7                  # how flat the boots try to stay (less in the air so feet dangle)
var _jp_rot := 0.0

# ---- support hand (second hand on the gun) ----
const OFF_GUN_POS := Vector2(38.0, 12.0)  # dual wield: where the off-hand gun's grip sits (from the off shoulder): out in front and clearly lower than the main gun, so both guns show
# Held guns are drawn bigger than the raw art so everyone can tell what you are carrying: short guns (pistols)
# grow the most, long guns the least. Tune GUN_VIEW_MIN / GUN_VIEW_MAX / GUN_BOOST to taste.
const GUN_BOOST := 1.5                    # every held gun is drawn at least this much bigger ...
const GUN_VIEW_MIN := 52.0                # ... and never shorter than this many in-game px ...
const GUN_VIEW_MAX := 108.0                # ... nor longer than this (long rifles / snipers stay manageable)


# How much bigger than its art size this gun is drawn in the hand. Grip, muzzle, support hand and casing
# positions are all scaled by it, so bullets still leave the barrel and the hands still hold the gun.
func gun_scale(data: WeaponData) -> float:
	if data == null or data.texture == null:
		return 1.0
	var len_px := float(data.texture.get_width()) / data.art_scale
	return clampf(len_px * GUN_BOOST, GUN_VIEW_MIN, maxf(GUN_VIEW_MAX, len_px)) / len_px


const SUPPORT_OFFSET := Vector2(16, 6)   # default hold spot (when a weapon sets no Support Grip): ahead of the grip, under the barrel
const SUPPORT_MAX_STRETCH := 1.9         # how far the arm may stretch to reach
const SUPPORT_REACH := 23.0              # the hand sits this far along the arm art
const DRAW_TIME := 0.16                   # seconds for a gun to swing from the back into the hand
var _draw_t := 0.0
var _has_main := false                   # a main weapon is equipped
var _support := false                    # the second hand is holding the gun (not dual wielding)
var _support_local := Vector2.ZERO
var _hand_dist := 34.0               # how far the main hand holds the gun from the shoulder (set per gun in _place_main)


func _ready() -> void:
	_build()
	_find_decor()
	apply_loadout(loadout)
	# a rig nobody customised (bots, old code) keeps exactly the stock "Sentinel" layers
	var stock := Appearance.resolve(Appearance.default_for("male"))
	stock["head"]["hair"] = "none"
	stock["show"]["glow_lines"] = true
	stock["show"]["forearm_trim"] = true
	_apply_flags(stock)
	apply_garments(stock.get("garments", {}))
	_apply_head(stock["head"])
	if not preview:
		GroundContact.attach(self)       # shadow, dust, footstep sounds (see ground_contact.gd)


# ---------- building the rig ----------
func _node(parent: Node, pos: Vector2, z := 0) -> Node2D:
	var n := Node2D.new()
	n.position = pos
	n.z_index = z
	parent.add_child(n)
	return n


func _spr(parent: Node, file: String, pivot: Vector2, group := "", art := ART_SCALE) -> Sprite2D:
	var s := Sprite2D.new()
	s.texture = load(ART + file)
	s.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS    # smooth, not pixelated
	s.centered = false
	s.offset = -pivot * art                 # pivot is given in in-game pixels, the picture is `art` times bigger
	s.scale = Vector2.ONE / art
	parent.add_child(s)
	_body_sprites.append(s)
	if group != "":
		_tinted.append([s, group])
	return s


# Marks a sprite as the picture of a body slot, so an anatomy cosmetic can swap it for its own drawing.
func _slot(slot: String, s: Sprite2D, dark := false) -> Sprite2D:
	if not _slots.has(slot):
		_slots[slot] = []
	_slots[slot].append(s)
	s.set_meta("orig_tex", s.texture)
	s.set_meta("orig_size", s.texture.get_size())
	s.set_meta("base_scale", s.scale)
	s.set_meta("base_offset", s.offset)
	s.set_meta("dark", dark)
	return s


# A clothing overlay for a creature body: same place and size as the slot picture `like`, hidden until a creature
# cosmetic that can wear clothes is equipped (its pictures are ov_<slot>.png in the cosmetic's folder).
func _ov(slot: String, like: Sprite2D, group: String) -> Sprite2D:
	var s := Sprite2D.new()
	s.texture = like.texture
	s.texture_filter = like.texture_filter
	s.centered = false
	s.offset = like.offset
	s.scale = like.scale
	s.set_meta("orig_tex", like.texture)
	s.set_meta("orig_size", like.texture.get_size())
	s.set_meta("base_scale", like.scale)
	s.set_meta("base_offset", like.offset)
	s.visible = false
	like.get_parent().add_child(s)
	_body_sprites.append(s)
	_tinted.append([s, group])
	if not _ovs.has(slot):
		_ovs[slot] = []
	_ovs[slot].append(s)
	_reg("ov_" + slot, s)
	return s


# Puts a picture on a slot sprite. Creature art is drawn at 2x the human parts' resolution, so the sprite is scaled to match.
func _set_slot_tex(sp: Sprite2D, tex: Texture2D) -> void:
	var ref: Vector2 = sp.get_meta("orig_size", tex.get_size())
	var k := float(tex.get_width()) / maxf(1.0, ref.x)
	sp.texture = tex
	sp.scale = (sp.get_meta("base_scale", Vector2.ONE) as Vector2) / k
	sp.offset = (sp.get_meta("base_offset", Vector2.ZERO) as Vector2) * k


# Creates the (hidden) clothing layers for one body slot picture. They share its place, size and drawing order.
func _gm_make(slot: String, like: Sprite2D, dark: bool) -> void:
	for owner in GM_OWNERS[slot]:
		var entry := {"slot": slot, "owner": owner, "dark": dark, "layers": {}}
		for layer in GM_LAYERS:
			var sp := Sprite2D.new()
			sp.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
			sp.centered = false
			sp.visible = false
			sp.set_meta("orig_size", like.texture.get_size())
			sp.set_meta("base_scale", like.scale)
			sp.set_meta("base_offset", like.offset)
			sp.offset = like.offset
			sp.scale = like.scale
			like.get_parent().add_child(sp)
			entry["layers"][layer] = sp
		_gm.append(entry)


func _res_exists(path: String) -> bool:
	if not _exists_cache.has(path):
		_exists_cache[path] = ResourceLoader.exists(path)
	return _exists_cache[path]


## g = Appearance.resolve()["garments"]: {kind: {id, pal[4 colours], glow}}. Kinds without an id (or without a picture for a
## slot, e.g. a tank top has no sleeves) leave the bare body showing.
var _gstate := {}
var _team_pal := {}                # kind -> palette: bots and old scripts recolour the clothes through apply_loadout(armor / trim)


func apply_garments(g: Dictionary) -> void:
	_gstate = g
	for e in _gm:
		var spec: Dictionary = g.get(e["owner"], {})
		var id := str(spec.get("id", ""))
		for layer in GM_LAYERS:
			var sp: Sprite2D = e["layers"][layer]
			var path := "%s%s_%s/%s_%s.png" % [OUTFIT_ART, e["owner"], id, e["slot"], layer]
			if id != "" and _res_exists(path):
				_set_slot_tex(sp, _tex_path(path))
				sp.visible = true
			else:
				sp.visible = false
	_recolor_garments()


func _recolor_garments() -> void:
	for e in _gm:
		var spec: Dictionary = _gstate.get(e["owner"], {})
		var pal: Array = _team_pal.get(e["owner"], spec.get("pal", []))
		for layer in GM_LAYERS:
			var sp: Sprite2D = e["layers"][layer]
			if not sp.visible:
				continue
			var c := Color.WHITE
			var li := GM_LAYERS.find(layer)
			if layer == "g":
				c = loadout.get("glow", spec.get("glow", Color("4fd8ff")))
			elif layer != "d" and li < pal.size():
				c = pal[li]
			if e["dark"]:
				c = c.darkened(0.3)
			sp.modulate = c


# pv = the pivot in the same units the sprites were drawn in (art scale 2); it is converted for other scales
func _part(parent: Node, file: String, pv: Vector2, group := "", art := ART_SCALE, alpha := 1.0) -> Sprite2D:
	var s := _spr(parent, file, pv * (ART_SCALE / art), group, art)
	if alpha < 1.0:
		s.modulate.a = alpha
	return s


# Everything the human build draws that is not a body slot and not tied to another flag (joints, shines, trims, glow
# strips, underwear ...). A full-anatomy cosmetic hides all of it: those layers belong to the human body only.
func _find_decor() -> void:
	var tagged := {}
	for k in _flags:
		for n in _flags[k]:
			tagged[n] = true
	for k in _slots:
		for n in _slots[k]:
			tagged[n] = true
	_flags["decor"] = []
	for sp in _body_sprites:
		if not tagged.has(sp) and is_instance_valid(sp) and not _is_in_jetpack(sp):
			_flags["decor"].append(sp)


func _is_in_jetpack(n: Node) -> bool:
	return jetpack != null and jetpack.is_ancestor_of(n)


# Remember a sprite under an appearance flag (see apply_appearance).
func _reg(key: String, node: Node) -> Node:
	if not _flags.has(key):
		_flags[key] = []
	_flags[key].append(node)
	return node


# A body-slot picture (art/body/<slot>.png): its canvas and joint pivot come from BodySlots, shared with every garment / cosmetic.
func _body_spr(parent: Node, slot: String, group := "", file := "") -> Sprite2D:
	var d: Dictionary = BodySlots.DATA[slot]
	var s := Sprite2D.new()
	s.texture = _tex_path("res://art/body/%s.png" % (file if file != "" else slot))
	s.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	s.centered = false
	s.offset = -(d["pivot"] as Vector2) * BodySlots.PPU
	s.scale = Vector2.ONE / BodySlots.PPU
	parent.add_child(s)
	_body_sprites.append(s)
	if group != "":
		_tinted.append([s, group])
	return s


## One leg: thigh -> shin -> foot. Every segment ends in a round cap centred on the next joint, so the knee and the ankle
## stay closed at any bend; the child piece (drawn over its parent) has no outline inside the joint disc.
func _leg(x: float, z: int, dark: bool) -> Array:
	var sfx := "_dark" if dark else ""
	var thigh := _node(rig, Vector2(x, 0), z)
	var th_s := _slot("thigh", _body_spr(thigh, "thigh", "pants" + sfx), dark)
	_ov("thigh", th_s, "pants" + sfx)
	_gm_make("thigh", th_s, dark)
	var shin := _node(thigh, Vector2(0, BodySlots.THIGH))
	var sh_s := _slot("shin", _body_spr(shin, "shin", "shin_pants" + sfx), dark)
	_ov("shin", sh_s, "shin_pants" + sfx)
	_gm_make("shin", sh_s, dark)
	var knee := _node(shin, Vector2(2.4, 0))
	_reg("knee", _part(knee, "knee_pad_base.png", Vector2(14, 14), "knee" + sfx, 3.2))
	if not dark:
		_reg("knee", _part(knee, "knee_pad_shine.png", Vector2(14, 14), "", 3.2, 0.65))
	var boot := _node(shin, Vector2(0, BodySlots.SHIN))
	var ft_s := _slot("foot", _body_spr(boot, "foot", "boots" + sfx), dark)
	_ov("foot", ft_s, "boots" + sfx)
	_gm_make("foot", ft_s, dark)
	return [thigh, shin, boot]


func _shoulder_pad(z: int, pos: Vector2, dark: bool) -> Node2D:
	var sfx := "_dark" if dark else ""
	var pad := _node(rig, pos, z)
	_reg("pads", pad)
	var art := 3.8 if dark else 3.6               # the pad pictures are drawn at 2x
	_part(pad, "shoulder_pad_base.png", Vector2(18, 16), "vest" + sfx, art)
	_part(pad, "shoulder_pad_trim.png", Vector2(18, 16), "gear" + sfx, art)
	if not dark:
		_part(pad, "shoulder_pad_shine.png", Vector2(18, 16), "", art, 0.75)
	return pad


func _build() -> void:
	rig = _node(self, Vector2.ZERO)

	# jetpack, bolted to the back: it tilts in flight, and the flames come out of its two nozzles
	_cape_node = _node(rig, Vector2(-10, -44), -6)       # cape (customisation): hangs behind everything
	_reg("cape", _part(_cape_node, "cape.png", Vector2(60, 4), "cape", 2.0))
	jetpack = _node(rig, Vector2(-19, -42), -4)
	_jfx = JetpackFx.new()
	jetpack.add_child(_jfx)
	_jfx.setup("standard")
	_jfx.retint(loadout)

	# legs: the far leg (darker) is behind, the near leg in front
	var bl := _leg(8, -3, true)
	back_thigh = bl[0]; back_shin = bl[1]; back_boot = bl[2]
	var fl2 := _leg(-1, -2, false)
	front_thigh = fl2[0]; front_shin = fl2[1]; front_boot = fl2[2]

	# far arm is built first so it sits behind the gun; its far shoulder pad hides behind the torso
	_off_arm = _make_arm(1, 6, true)          # in FRONT of the torso (z 1), under the main arm: the free arm is clearly visible
	pad_far = _shoulder_pad(-1, Vector2(18, -41.5), true)

	torso = _node(rig, Vector2(0, -21))
	var to_s := _slot("torso", _body_spr(torso, "torso", "uniform"))
	_ov("torso", to_s, "uniform")
	_gm_make("torso", to_s, false)
	_cosm_chest = _part(torso, "alien_chest.png", Vector2(22, 23), "")
	_cosm_chest.visible = false
	_reg("chest", _cosm_chest)

	# The pelvis is part of the torso now: the bare body is ONE picture (ribcage, abdomen and pelvis) and the legs hang straight
	# from it, so there is no separate waist piece to drift or leave a seam. This node only carries the trousers (it rides on
	# the torso, drawn after its clothes) and the own pelvis picture of a creature / hero body (see apply_anatomy).
	waist = _node(torso, Vector2(0, 23), 0)
	var wa_s := _slot("waist", _body_spr(waist, "waist", "pants"))
	_ov("waist", wa_s, "pants")
	_gm_make("waist", wa_s, false)

	straps = _node(rig, Vector2(0, -21), 0)           # jetpack harness: webbing over the shoulder and chest, on top of the clothes
	_body_spr(straps, "torso", "gear", "harness")
	_body_spr(straps, "torso", "", "harness_d")

	# the equipped grenade hangs from the belt buckle (player.gd tells us which one via set_hip_throwable)
	hip_throwable = _node(rig, HIP_THROW_POS, 1)
	hip_throwable.visible = false
	_hip_sprite = Sprite2D.new()
	_hip_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	_hip_sprite.scale = Vector2(HIP_THROW_SCALE, HIP_THROW_SCALE)
	_hip_sprite.position = HIP_THROW_SPRITE_POS
	hip_throwable.add_child(_hip_sprite)

	head = _node(rig, Vector2(7, HEAD_Y), 3)
	_build_head()
	# neckline pieces: drawn after (so over) the head, they hide where the neck meets the shirt
	collar_node = _node(rig, Vector2(0, -21), 3)
	_neck_patch = _body_spr(collar_node, "torso", "skin", "neck")       # skin over the junction of head and torso
	var centry := {"slot": "collar", "owner": "top", "dark": false, "layers": {}}
	for layer in GM_LAYERS:
		var csp := Sprite2D.new()
		csp.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
		csp.centered = false
		csp.visible = false
		csp.set_meta("orig_size", to_s.texture.get_size())
		csp.set_meta("base_scale", to_s.scale)
		csp.set_meta("base_offset", to_s.offset)
		csp.offset = to_s.offset
		csp.scale = to_s.scale
		collar_node.add_child(csp)
		centry["layers"][layer] = csp
	_gm.append(centry)

	pad_near = _shoulder_pad(4, Vector2(8, -38), false)
	_main_arm = _make_arm(2, 6, false)
	aim_pivot = _node(rig, Vector2(8, -38), 5)
	# weapon slot: the hand sits _hand_dist px from the shoulder (worked out per gun); weapons bring their own art
	weapon_sprite = Sprite2D.new()
	weapon_sprite.centered = false
	weapon_sprite.position = Vector2(_hand_dist, 0)
	aim_pivot.add_child(weapon_sprite)
	muzzle = Marker2D.new()
	aim_pivot.add_child(muzzle)
	_make_flash(0, aim_pivot)

	# off hand: second arm + gun, only visible while dual wielding
	off_pivot = _node(rig, Vector2(15, -39.5), 1)
	off_pivot.visible = true                 # you always have two arms, with or without a gun
	off_weapon_sprite = Sprite2D.new()
	off_weapon_sprite.centered = false
	off_weapon_sprite.position = OFF_GUN_POS
	off_pivot.add_child(off_weapon_sprite)
	off_muzzle = Marker2D.new()
	off_pivot.add_child(off_muzzle)
	_make_flash(1, off_pivot)

	shield = Node2D.new()
	shield.visible = false
	shield.draw.connect(_draw_shield)
	aim_pivot.add_child(shield)


# The bare body is drawn at twice the old resolution (art/body/<slot>.png): same size and joints, more detail.
func _hires_body() -> void:
	for slot in _slots:
		var path := "res://art/body/%s.png" % slot
		if not ResourceLoader.exists(path):
			continue
		var tex: Texture2D = _tex_path(path)
		for sp in _slots[slot]:
			sp.set_meta("orig_tex", tex)
			_set_slot_tex(sp, tex)


# ---------- the head: separate, swappable layers (see HeadCatalog / tools/gen_head_parts.py) ----------
const HEAD_PX := 5.0                    # head pictures: picture pixels per in-game pixel


func _head_layer(lname: String, z := 0, parent: Node = null, centered := false) -> Sprite2D:
	var sp := Sprite2D.new()
	sp.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	sp.centered = centered
	sp.scale = Vector2.ONE / HEAD_PX
	if not centered:
		sp.offset = -HeadCatalog.PIVOT_PX
	sp.z_index = z
	sp.visible = false
	(parent if parent != null else head).add_child(sp)
	_hl[lname] = sp
	return sp


func _build_head() -> void:
	# hair that hangs behind the head swings from the back of the skull
	_hair_sway = _node(head, HeadCatalog.to_game(Vector2(36, 44)), -1)
	var hb := _head_layer("hair_back", 0, _hair_sway)
	hb.position = -_hair_sway.position
	var gb := _head_layer("gear_back", -1)
	_head_layer("skin")
	for side in ["near", "far"]:
		for part in ["base", "iris", "top"]:
			_head_layer("eye_%s_%s" % [side, part], 0, null, true)
	_head_layer("brow_near", 0, null, true)
	_head_layer("brow_far", 0, null, true)
	_head_layer("facial", 1)       # z 1 over the head (3) = 4: ABOVE the collar / neck patch (3), so a beard that reaches the neck is no longer painted over by skin
	_head_layer("hair")
	var hg := _head_layer("hair_glow")
	var add := CanvasItemMaterial.new()
	add.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	hg.material = add
	for l in ["gear_base", "gear_trim", "gear_lens", "gear_shine", "gear_det"]:
		_head_layer(l)


func _head_tex(path: String) -> Texture2D:
	if not ResourceLoader.exists(path):
		return null
	return _tex_path(path)


func _set_head_layer(lname: String, path: String, on: bool) -> void:
	var sp: Sprite2D = _hl[lname]
	var t: Texture2D = _head_tex(path) if on else null
	sp.texture = t
	sp.visible = t != null


## Draws a head from Appearance.resolve()["head"]: shape, eyes, brows, hair, facial hair, headgear. Every picture is
## the one generated for THIS head shape, so nothing has to be stretched to fit.
func _apply_head(h: Dictionary) -> void:
	if h.is_empty() or _hl.is_empty():
		return
	_head_state = h.duplicate()
	var shape := str(h.get("shape", "round"))
	var dir := HeadCatalog.shape_dir(shape)
	var species: bool = bool(h.get("species", false))
	var gear_id := str(h.get("gear", "none"))
	var gear: Dictionary = HeadCatalog.GEAR.get(gear_id, HeadCatalog.GEAR["none"])
	var hides: Array = gear.get("hides", [])
	var hair_id := str(h.get("hair", "none"))
	var hair_mode := str(gear.get("hair", "keep"))
	var mat: Material = _anat_mat if species else null
	_set_head_layer("skin", dir + "skin.png", true)
	# eyes sit on this head's own eye anchors
	var style := str(h.get("eyes", "round"))
	var eyes_on := not hides.has("eyes")
	for side in ["near", "far"]:
		var pos := HeadCatalog.to_game(HeadCatalog.anchor(shape, "eye_" + side))
		for part in ["base", "iris", "top"]:
			var lname: String = "eye_%s_%s" % [side, part]
			_set_head_layer(lname, "%seyes/%s_%s_%s.png" % [HeadCatalog.DIR, style, side, part], eyes_on)
			(_hl[lname] as Sprite2D).position = pos
		var brow := str(h.get("brows", "none"))
		var bl: String = "brow_" + side
		_set_head_layer(bl, "%sbrows/%s_%s.png" % [HeadCatalog.DIR, brow, side], eyes_on and brow != "none" and not species)
		(_hl[bl] as Sprite2D).position = HeadCatalog.to_game(HeadCatalog.anchor(shape, "eye_" + side) + Vector2(0, -8))
	var facial := str(h.get("facial", "none"))
	_set_head_layer("facial", "%sfacial_%s.png" % [dir, facial], facial != "none" and not hides.has("facial"))
	_set_head_layer("hair", "%shair_%s.png" % [dir, hair_id], hair_id != "none" and hair_mode == "keep")
	_set_head_layer("hair_back", "%shairb_%s.png" % [dir, hair_id], hair_id != "none" and hair_mode != "all")
	_set_head_layer("hair_glow", "%shairg_%s.png" % [dir, hair_id], hair_id != "none" and hair_mode == "keep")
	for layer in ["base", "trim", "lens", "shine", "back", "det"]:
		var lname: String = "gear_" + layer
		_set_head_layer(lname, "%sgear_%s_%s.png" % [dir, gear_id, layer], gear_id != "none" and (gear.get("layers", []) as Array).has(layer))
	for lname in ["skin", "hair", "hair_back", "hair_glow", "facial"]:
		(_hl[lname] as Sprite2D).material = mat if (species and lname != "hair_glow") else (_hl[lname].material if lname == "hair_glow" else null)
	_tint_head()


func _tint_head() -> void:
	if _hl.is_empty() or _head_state.is_empty():
		return
	var species: bool = bool(_head_state.get("species", false))
	var gear: Dictionary = HeadCatalog.GEAR.get(str(_head_state.get("gear", "none")), HeadCatalog.GEAR["none"])
	var hair_c: Color = loadout.get("hair", Color("3a2a22"))
	var skin_c: Color = loadout.get("cosm_skin", Color.WHITE) if species else loadout.get("skin", Color("e8bc9c"))
	var baked_hair: bool = species
	(_hl["skin"] as Sprite2D).modulate = skin_c
	for side in ["near", "far"]:
		(_hl["eye_%s_iris" % side] as Sprite2D).modulate = loadout.get("eye", Color("5aa8e6"))
		(_hl["brow_" + side] as Sprite2D).modulate = hair_c
	(_hl["facial"] as Sprite2D).modulate = Color.WHITE if baked_hair else hair_c
	(_hl["hair"] as Sprite2D).modulate = Color.WHITE if baked_hair else hair_c
	(_hl["hair_back"] as Sprite2D).modulate = Color.WHITE if baked_hair else hair_c
	var glow_c: Color = _head_state.get("species_glow", loadout.get("glow", Color("4fd8ff"))) if species else loadout.get("glow", Color("4fd8ff"))
	(_hl["hair_glow"] as Sprite2D).modulate = glow_c
	var main_c: Color = loadout.get("helmet", Color("58667a"))
	var trim_c: Color = loadout.get("accent", Color("46546a"))
	if bool(gear.get("gold", false)):
		main_c = Color("e8b94a")
		trim_c = Color("e8b94a")
	(_hl["gear_base"] as Sprite2D).modulate = main_c
	(_hl["gear_back"] as Sprite2D).modulate = main_c
	(_hl["gear_trim"] as Sprite2D).modulate = trim_c
	var lens_c: Color = loadout.get("visor", Color("b8f0ff"))
	if bool(gear.get("dark_lens", false)):
		lens_c = Color.WHITE
	elif bool(gear.get("glow_lens", false)):
		lens_c = loadout.get("cosm_over", Color("ff8a4d"))
	elif bool(gear.get("gold", false)):
		lens_c = loadout.get("eye", Color("5aa8e6"))
	(_hl["gear_lens"] as Sprite2D).modulate = lens_c
	(_hl["gear_shine"] as Sprite2D).modulate = Color.WHITE
	(_hl["gear_det"] as Sprite2D).modulate = Color.WHITE


# Shows the equipped grenade on the hip (pass null to hide it, e.g. when you have none left).
func set_hip_throwable(tex: Texture2D) -> void:
	if hip_throwable == null:
		return
	hip_throwable.visible = tex != null
	if tex != null:
		_hip_sprite.texture = tex


# A two-bone arm (upper arm + forearm) with a glove. The bones are placed by _solve_arm() so the
# glove always lands exactly on the gun's grip, with a natural bend at the elbow.
func _make_arm(z: int, hand_z: int, dark: bool) -> Dictionary:
	var sfx := "_dark" if dark else ""
	var upper := _node(rig, Vector2.ZERO, z)
	var ua_s := _slot("upper_arm", _body_spr(upper, "upper_arm", "sleeve_up" + sfx), dark)
	_ov("upper_arm", ua_s, "sleeve_up" + sfx)
	_gm_make("upper_arm", ua_s, dark)
	var fore := _node(upper, Vector2(BodySlots.UPPER_ARM, 0))
	var fa_s := _slot("forearm", _body_spr(fore, "forearm", "sleeve_fore" + sfx), dark)
	_ov("forearm", fa_s, "sleeve_fore" + sfx)
	_gm_make("forearm", fa_s, dark)
	var hand := _node(rig, Vector2.ZERO, hand_z)      # the glove sits on top of the gun
	var ha_s := _slot("hand", _body_spr(hand, "hand", "glove" + sfx), dark)
	_ov("hand", ha_s, "glove" + sfx)
	_gm_make("hand", ha_s, dark)
	return {"upper": upper, "fore": fore, "hand": hand}


# ---------- customization ----------
const GROUP_FALLBACK := {"jnt_leg": "gear", "jnt_arm": "gear", "sleeve_up": "uniform", "sleeve_fore": "uniform", "shin_pants": "pants", "knee": "vest",
	"under": "pants", "under_top": "uniform", "cape": "uniform", "cosm_skin": "skin", "cosm_over": "glow"}


func apply_loadout(new_loadout: Dictionary) -> void:
	var nl := new_loadout.duplicate()
	# older scripts (like bot.gd) still send the old group names; turn them into the new ones
	if nl.has("armor"):
		var a: Color = nl["armor"]
		nl["helmet"] = nl.get("helmet", a)
		nl["vest"] = nl.get("vest", a)
		nl["uniform"] = nl.get("uniform", a.darkened(0.35))
		nl["pants"] = nl.get("pants", a.darkened(0.45))
		nl.erase("armor")
	if nl.has("trim"):
		var tr: Color = nl["trim"]
		nl["accent"] = nl.get("accent", tr)
		nl["gear"] = nl.get("gear", tr)
		nl["glove"] = nl.get("glove", tr)
		nl["boots"] = nl.get("boots", tr.lightened(0.1))
		nl.erase("trim")
	nl.erase("scarf")
	if new_loadout.has("armor"):                  # bots / old scripts: dress the clothes in the team colour
		var tc: Color = new_loadout["armor"]
		_team_pal["top"] = [tc.darkened(0.45), tc.darkened(0.15), tc.darkened(0.65), tc]
		_team_pal["bottom"] = [tc.darkened(0.6), tc.darkened(0.35), tc.darkened(0.75), tc.darkened(0.2)]
		_team_pal["armor"] = [tc, tc.darkened(0.25), tc.lightened(0.2), tc.darkened(0.45)]
	for k in nl:
		loadout[k] = nl[k]
	if _jfx != null:
		_jfx.retint(loadout)
	for e in _tinted:
		if (e[0] as Node).has_meta("baked"):
			continue                                           # an anatomy cosmetic's own painted picture: no recolouring
		var g: String = e[1]
		var gk := g.trim_suffix("_dark")
		# groups added by the customisation system fall back to the old ones, so bots and old looks are unchanged
		var c: Color = loadout.get(gk, loadout.get(GROUP_FALLBACK.get(gk, gk), Color.WHITE))
		if g.ends_with("_dark"):
			c = c.darkened(0.3)          # the far-side limbs are a bit darker
		e[0].modulate = c
	_tint_head()
	_recolor_garments()
	if shield:
		shield.queue_redraw()


# ---------- appearance (customisation menu, saved look, cosmetics, LAN) ----------
var _appearance_applied := false


func _tex(file: String) -> Texture2D:
	if not _tex_cache.has(file):
		_tex_cache[file] = load(ART + file)
	return _tex_cache[file]


## params come from Appearance.resolve(). Purely visual: no collision, speed, jetpack or weapon value is touched here.
func apply_appearance(params: Dictionary) -> void:
	if params.is_empty() or rig == null:
		return
	_appearance_applied = true
	apply_loadout(params.get("colors", {}))
	_apply_flags(params)
	var an: Dictionary = params.get("anatomy", {})
	_set_torso_art(bool(params.get("female", false)))
	apply_anatomy(an)
	apply_garments({} if str(an.get("folder", "")) != "" else params.get("garments", {}))
	_apply_head(params.get("head", {}))


# The bare torso picture differs between the two avatars (same silhouette, different forms).
func _set_torso_art(female: bool) -> void:
	var tex: Texture2D = _tex_path("res://art/body/torso_f.png" if female else "res://art/body/torso.png")
	for sp in _slots.get("torso", []):
		sp.set_meta("orig_tex", tex)
		if not sp.has_meta("baked"):
			_set_slot_tex(sp, tex)


# Swaps the whole pack (pictures, flames, particles) for another design.
func _set_jetpack(id: String) -> void:
	if id == "slim":
		id = "future"
	if id == "none" or not JetpackDefs.DATA.has(id):
		if id == "none":
			jetpack.visible = false
			return
		id = "standard"
	if id != _jp_id or _jfx == null:
		if _jfx != null:
			_jfx.queue_free()
		_jfx = JetpackFx.new()
		jetpack.add_child(_jfx)
		_jfx.setup(id)
		_jp_id = id
	_jfx.retint(loadout)


# Shows / hides the layers, swaps pictures, sets proportions. (Colours are separate: see apply_loadout.)
func _apply_flags(params: Dictionary) -> void:
	var show: Dictionary = params.get("show", {})
	for key in _flags:
		var on: bool = bool(show.get(key, not key.begins_with("ov_")))
		if key.begins_with("jp_"):
			continue
		for n in _flags[key]:
			if is_instance_valid(n):
				n.visible = on
	var cosm: Dictionary = params.get("cosm", {})
	for pair in [["chest", _cosm_chest]]:
		var file := str(cosm.get(pair[0], ""))
		if file != "" and ResourceLoader.exists(ART + file):
			pair[1].texture = _tex(file)
		elif file == "":
			pair[1].visible = false
	var jp: Dictionary = params.get("jp", {})
	var tex := str(jp.get("tex", "standard"))
	_set_jetpack(tex)
	var sc := float(jp.get("scale", 1.0))
	jetpack.scale = Vector2.ONE
	jetpack.visible = tex != "none"          # wings / cape / levitation cosmetics have no pack at all
	straps.visible = tex != "none"
	var body: Dictionary = params.get("body", {})
	torso.scale = Vector2(float(body.get("torso_x", 1.0)), 1.0)
	collar_node.scale = torso.scale
	waist.scale = Vector2(float(body.get("hip_x", 1.0)) / maxf(0.01, torso.scale.x), 1.0)       # child of the torso: keep the hips' own width
	var hs := float(body.get("head", 1.0))
	head.scale = Vector2(hs, hs)
	for g in _glow:
		if is_instance_valid(g):
			g.visible = bool(show.get("glow_lines", false))


const HUE_SHADER := """
shader_type canvas_item;
uniform float hue = 0.0;
void fragment() {
	vec4 c = texture(TEXTURE, UV);
	float a = hue * 6.2831853; float cs = cos(a); float sn = sin(a);
	mat3 m = mat3(
		vec3(0.299 + 0.701 * cs + 0.168 * sn, 0.299 - 0.299 * cs - 0.328 * sn, 0.299 - 0.300 * cs + 1.250 * sn),
		vec3(0.587 - 0.587 * cs + 0.330 * sn, 0.587 + 0.413 * cs + 0.035 * sn, 0.587 - 0.588 * cs - 1.050 * sn),
		vec3(0.114 - 0.114 * cs - 0.497 * sn, 0.114 - 0.114 * cs + 0.292 * sn, 0.114 + 0.886 * cs - 0.203 * sn));
	COLOR = vec4(clamp(m * c.rgb, 0.0, 1.0), c.a) * COLOR;
}
"""


## A full-character cosmetic with its OWN anatomy: its pictures replace the human body slots (same canvas sizes and
## joints, so bones, weapon sockets and hit-boxes are untouched), human decoration is hidden by the show flags, and an
## optional CosmeticFx drives its flight look. Empty dictionary = back to the human body.
func apply_anatomy(an: Dictionary) -> void:
	for slot in _slots:
		for sp in _slots[slot]:
			if is_instance_valid(sp) and sp.has_meta("orig_tex"):
				_set_slot_tex(sp, sp.get_meta("orig_tex"))
				sp.remove_meta("baked")
				sp.material = null
				sp.modulate = Color.WHITE
	for slot in _ovs:
		for sp in _ovs[slot]:
			if is_instance_valid(sp):
				_set_slot_tex(sp, sp.get_meta("orig_tex"))
				sp.material = null
	if _fx != null:
		_fx.queue_free()
		_fx = null
	_lean_mult = 1.0
	_anat_mat = null
	var folder := str(an.get("folder", ""))
	# trousers sit OVER the torso picture when the pelvis is part of it (human body, insectoid, lumen); a hero body keeps its own pelvis picture BEHIND its torso
	waist.z_index = 0 if (folder == "" or bool(an.get("merged_pelvis", false))) else -1
	if _neck_patch != null:
		_neck_patch.visible = folder == "" or bool(an.get("neck_patch", true))
	if folder == "":
		apply_loadout(loadout)                   # recolour the human parts again
		return
	if _hue_mat == null:
		var sh := Shader.new()
		sh.code = HUE_SHADER
		_hue_mat = ShaderMaterial.new()
		_hue_mat.shader = sh
	var mat: ShaderMaterial = _hue_mat.duplicate()
	mat.set_shader_parameter("hue", float(an.get("hue", 0.0)))
	var use_mat: Material = mat if absf(float(an.get("hue", 0.0))) > 0.001 else null
	_anat_mat = use_mat
	for slot in an.get("slots", []):
		var path := "%s%s/%s.png" % [COSM_ART, folder, slot]
		if not ResourceLoader.exists(path):
			continue
		var tex: Texture2D = _tex_path(path)
		for sp in _slots.get(slot, []):
			_set_slot_tex(sp, tex)
			sp.set_meta("baked", true)
			sp.material = use_mat
			sp.modulate = Color(0.74, 0.74, 0.8) if bool(sp.get_meta("dark", false)) else Color.WHITE
	if bool(an.get("overlays", false)):
		for slot in _ovs:
			var opath := "%s%s/ov_%s.png" % [COSM_ART, folder, slot]
			if not ResourceLoader.exists(opath):
				continue
			var otex: Texture2D = _tex_path(opath)
			for sp in _ovs[slot]:
				_set_slot_tex(sp, otex)
	_lean_mult = float(an.get("lean", 1.0))
	var kind := str(an.get("fx", ""))
	if kind != "":
		_fx = CosmeticFx.create(kind)
		if _fx != null:
			rig.add_child(_fx)
			_fx.setup(self, folder, use_mat, an.get("fx_cfg", {}))


func _tex_path(path: String) -> Texture2D:
	if not _tex_cache.has(path):
		_tex_cache[path] = load(path)
	return _tex_cache[path]


# ---------- weapons (independent of the character look) ----------
func equip_weapon(data: WeaponData, from_back := false) -> void:
	if data == null:
		push_warning("PlayerRig: no weapon assigned")
		return
	if data.texture == null:
		push_warning("PlayerRig: weapon '%s' has no Texture assigned" % data.display_name)
	weapon_sprite.texture = data.texture
	weapon_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS    # smooth, not pixelated
	weapon_sprite.scale = Vector2.ONE * gun_scale(data) / data.art_scale     # hi-res picture drawn a bit bigger than its art size, so it is easy to see
	weapon_sprite.visible = true
	weapon_sprite.offset = -data.grip * data.art_scale     # grip pixel sits in the hand
	_has_main = true
	_fx_data[0] = data
	_place_main()
	_recoil[0] = 0.0
	if _fx_flash[0] != null:
		(_fx_flash[0] as MuzzleFlash).hide_now()               # no flash carries over from the previous gun
	if off_weapon_sprite.texture == null:
		_support = true
		off_pivot.visible = true
	if from_back and torso != null:
		_draw_t = DRAW_TIME            # the gun swings from the back into the hand (see _update_draw)


# Works out how far out the main hand holds the gun, then places the muzzle and the support hand to match.
func _place_main() -> void:
	var data: WeaponData = _fx_data[0]
	if data == null:
		return
	var hold: Vector2 = data.support_grip if data.support_grip != Vector2.ZERO else data.grip + SUPPORT_OFFSET
	if _fx_data[1] != null:
		_hand_dist = HAND_MAX                                   # dual wield: arm stretched out
	else:
		_hand_dist = clampf(REACH_GOAL - (hold.x - data.grip.x) * gun_scale(data), HAND_MIN, HAND_MAX)   # front hand at full reach
	muzzle.position = Vector2(_hand_dist, 0) + (data.muzzle - data.grip) * gun_scale(data)
	_support_local = Vector2(_hand_dist, 0) + (hold - data.grip) * gun_scale(data)


func equip_off_hand(data: WeaponData) -> void:
	if data == null:
		return
	off_weapon_sprite.texture = data.texture
	off_weapon_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	off_weapon_sprite.scale = Vector2.ONE * gun_scale(data) / data.art_scale
	off_weapon_sprite.offset = -data.grip * data.art_scale
	off_muzzle.position = OFF_GUN_POS + (data.muzzle - data.grip) * gun_scale(data)
	_fx_data[1] = data
	_recoil[1] = 0.0
	if _fx_flash[1] != null:
		(_fx_flash[1] as MuzzleFlash).hide_now()
	_place_main()
	_support = false
	off_pivot.visible = true


func unequip_off_hand() -> void:
	off_weapon_sprite.texture = null
	_fx_data[1] = null
	if _fx_flash[1] != null:
		(_fx_flash[1] as MuzzleFlash).hide_now()
	_place_main()
	_support = _has_main                 # back to holding the one gun with both hands
	off_pivot.visible = true             # (no gun in the main hand: the free arm just mirrors the aim)


func unequip_weapon() -> void:
	weapon_sprite.texture = null
	_fx_data[0] = null
	if _fx_flash[0] != null:
		(_fx_flash[0] as MuzzleFlash).hide_now()
	_has_main = false
	if off_weapon_sprite.texture == null:
		_support = false
		off_pivot.visible = true          # hands are empty but both arms stay


# ---------- air flip ----------
# dir: +1 = clockwise (flip to the right), -1 = counter-clockwise. player.gd calls this.
func start_flip(dir: float, duration := 0.55) -> void:
	_flip_dir = signf(dir) if dir != 0.0 else 1.0
	_flip_total = maxf(duration, 0.1)
	_flip_t = _flip_total


func is_flipping() -> bool:
	return _flip_t > 0.0


# ---------- animation (call every physics frame) ----------
func update_visuals(velocity: Vector2, aim_target: Vector2, jetting: bool, on_floor: bool, delta: float, crouching := false, blocking := false) -> void:
	var left: bool = aim_target.x < global_position.x
	rig.scale.x = -1.0 if left else 1.0
	var k := 1.0 - exp(-18.0 * delta)
	var sx := rig.scale.x                                           # -1 when facing left

	# ----- flight animation state (all smoothed, all frame-rate independent) -----
	var dt := clampf(delta, 0.001, 0.05)
	var powered := jetting and not on_floor
	_fly_blend = lerpf(_fly_blend, 1.0 if powered else 0.0, 1.0 - exp(-(7.0 if powered else 5.0) * delta))
	_fly_t += delta
	if not _have_prev_v:
		_prev_v = velocity
		_have_prev_v = true
	var acc := ((velocity - _prev_v) / dt).limit_length(4000.0)      # how hard the velocity is changing
	_prev_v = velocity
	var speed_n := clampf(absf(velocity.x) / FLY_SPEED_REF, 0.0, 1.0)
	var fwd_n := clampf(velocity.x * sx / FLY_SPEED_REF, -1.0, 1.0)  # + = moving the way the body faces

	# legs lag behind direction changes, then settle (a small under-damped spring)
	var lag_target := clampf(acc.x * sx / FLY_ACC_REF, -1.5, 1.5) * 0.16 * _fly_blend
	_lag_v += ((lag_target - _lag) * 120.0 - _lag_v * 10.0) * dt
	_lag = clampf(_lag + _lag_v * dt, -0.4, 0.4)

	# thrust bump: a quick little shove when the jetpack fires, plus a tiny push while thrust accelerates you up
	_kick_cd = maxf(0.0, _kick_cd - delta)
	if jetting and not _prev_jet and _flip_t <= 0.0 and _kick_cd <= 0.0:
		_kick_v -= 75.0
		_kick_cd = 0.18
	_prev_jet = jetting
	var kick_target := clampf(acc.y / THRUST_ACC_REF, -1.0, 1.0) * 0.9 * _fly_blend
	_kick_v += ((kick_target - _kick) * 260.0 - _kick_v * 14.0) * dt
	_kick = clampf(_kick + _kick_v * dt, -4.0, 4.0)

	# landing: a short squash after coming down from a real fall/flight (not from floor jitter)
	if on_floor:
		if _air_time > 0.15 and not jetting:
			_land_t = LAND_TIME
			_land_s = clampf(_air_vy / 650.0, 0.35, 1.0)
			landed.emit(clampf(_air_vy / 700.0, 0.0, 1.5))
		_air_time = 0.0
		_air_vy = 0.0
	else:
		_air_time += delta
		_air_vy = maxf(_air_vy, velocity.y)
	_land_t = maxf(0.0, _land_t - delta)
	var lw := _land_s if (_land_t > 0.0 and not crouching) else 0.0

	# ----- body roll: lean into the flight direction, or a full flip -----
	var lean := 0.0
	if jetting:
		lean = clampf(velocity.x / FLY_SPEED_REF, -1.0, 1.0) * FLY_LEAN_MAX * _lean_mult + clampf(velocity.y / 500.0, -1.0, 1.0) * 0.05 * signf(velocity.x)
		if not on_floor:
			lean += sin(_fly_t * 1.4) * 0.03 * (1.0 - speed_n)     # a calm sway while hovering
	elif not on_floor:
		lean = clampf(velocity.x / 600.0, -1.0, 1.0) * 0.2          # drifting through the air
	_tilt = lerpf(_tilt, lean, 1.0 - exp(-(7.0 if jetting else 9.0) * delta))
	var roll := _tilt
	if _flip_t > 0.0:
		_flip_t = maxf(0.0, _flip_t - delta)
		var p := 1.0 - _flip_t / _flip_total
		roll += _flip_dir * (p * p * (3.0 - 2.0 * p)) * TAU          # smooth start and stop, ends exactly on a full turn
	_crouch_y = lerpf(_crouch_y, 16.0 if crouching else 11.0 * lw, k)       # a landing now really drops the body
	rig.rotation = roll
	rig.position = Vector2(0, _crouch_y) + ROLL_PIVOT - ROLL_PIVOT.rotated(roll)    # keeps the torso in place while turning

	# aim: angle is computed in the rig's (possibly mirrored AND rolled) space
	var d: Vector2 = (aim_target - aim_pivot.global_position).rotated(-roll)
	aim_pivot.rotation = Vector2(-d.x, d.y).angle() if left else d.angle()

	var moving: bool = absf(velocity.x) > 10.0 and on_floor
	var ft := 0.0; var fs := 0.0; var bt := 0.0; var bs := 0.0; var bob := 0.0

	if _flip_t > 0.0:
		ft = 1.0; fs = 1.7; bt = 0.6; bs = 1.4          # knees tucked in mid-flip
	elif jetting and not on_floor:
		# loose dangling legs: each leg has its own wobble speeds, so they never move in sync.
		# Moving faster makes them trail a little more and wobble a little more; _lag adds the
		# momentum swing after a change of direction.
		var amp := lerpf(0.045, 0.10, speed_n)
		var w := _fly_t
		ft = 0.08 + 0.20 * fwd_n + _lag + sin(w * 3.1) * amp + sin(w * 5.3 + 1.3) * amp * 0.35
		fs = 0.45 + 0.18 * absf(fwd_n) + _lag * 0.6 + _kick * 0.08 + sin(w * 3.7 + 0.8) * amp * 1.5
		bt = -0.10 + 0.14 * fwd_n + _lag * 0.8 + sin(w * 2.6 + 1.9) * amp + sin(w * 4.6 + 0.4) * amp * 0.35
		bs = 0.62 + 0.15 * absf(fwd_n) + _lag * 0.5 + _kick * 0.08 + sin(w * 3.2 + 2.5) * amp * 1.5
		fs = maxf(fs, 0.05); bs = maxf(bs, 0.05)       # knees never bend backwards
		bob = sin(w * 2.4) * lerpf(1.4, 0.7, speed_n)  # tiny body bob (calmer when moving fast)
	elif not on_floor:
		# falling: legs stay a little loose instead of rigid
		var w2 := _fly_t
		ft = 0.25 + _lag + sin(w2 * 3.4) * 0.04
		fs = 0.5 + sin(w2 * 4.0 + 0.9) * 0.06
		bt = -0.2 + _lag * 0.8 + sin(w2 * 2.9 + 1.7) * 0.04
		bs = 0.7 + sin(w2 * 3.6 + 2.2) * 0.06
	elif crouching and moving:
		# crouch-walk: stay low with the knees bent, take short shuffling steps.
		# Each leg swings a little around the squat pose, and lifts its foot (more knee bend)
		# as it comes forward, then straightens slightly as it pushes back.
		var c_backwards := (velocity.x > 0.0) == left
		var c_cycle := clampf(absf(velocity.x) / 90.0, 0.6, 1.4) * 8.0
		_t += delta * c_cycle * (-1.0 if c_backwards else 1.0)
		ft = -1.1 + sin(_t) * 0.42
		fs = 1.85 + maxf(0.0, -cos(_t)) * 0.75 - maxf(0.0, cos(_t)) * 0.2
		bt = -0.95 + sin(_t + PI) * 0.42
		bs = 1.7 + maxf(0.0, -cos(_t + PI)) * 0.75 - maxf(0.0, cos(_t + PI)) * 0.2
		bob = -absf(sin(_t)) * 1.5
	elif crouching:
		ft = -1.2; fs = 2.0; bt = -0.95; bs = 1.8
	elif moving:
		var backwards := (velocity.x > 0.0) == left   # walking away from where we aim
		var cycle := clampf(absf(velocity.x) / 160.0, 0.5, 1.6) * 9.0
		_t += delta * cycle * (-1.0 if backwards else 1.0)
		ft = sin(_t) * 0.65
		fs = maxf(0.0, -cos(_t)) * 0.95
		bt = sin(_t + PI) * 0.65
		bs = maxf(0.0, -cos(_t + PI)) * 0.95
		bob = -absf(sin(_t)) * 3.0
	else:
		bob = sin(Time.get_ticks_msec() / 1000.0 * 2.0) * 1.5

	# footsteps: the front / back leg alternate planting as the walk cycle passes the middle of each stride
	if moving:
		var cs := signf(cos(_t))
		if cs != 0.0 and _step_sign != 0.0 and cs != _step_sign:
			var planted: Node2D = front_boot if front_boot.global_position.y > back_boot.global_position.y else back_boot
			footstep.emit(planted, 0.4 if crouching else clampf(0.55 + speed_n * 0.6, 0.0, 1.2))
		if cs != 0.0:
			_step_sign = cs
	else:
		_step_sign = 0.0

	if lw > 0.0:
		# landing: bend toward the crouch pose a little (the body drops by _crouch_y at the same time)
		ft = lerpf(ft, -1.2, 0.40 * lw); fs = lerpf(fs, 2.0, 0.40 * lw)
		bt = lerpf(bt, -0.95, 0.40 * lw); bs = lerpf(bs, 1.8, 0.40 * lw)
		bob += 1.2 * lw
	bob += _kick                                      # thrust bump: moves the whole upper body together

	# legs ease more slowly in the air, so leaving/entering flight never snaps
	var kl := 1.0 - exp(-(10.0 if not on_floor else 18.0) * delta)
	front_thigh.rotation = lerp_angle(front_thigh.rotation, ft, kl)
	front_shin.rotation = lerp_angle(front_shin.rotation, fs, kl)
	back_thigh.rotation = lerp_angle(back_thigh.rotation, bt, kl)
	back_shin.rotation = lerp_angle(back_shin.rotation, bs, kl)

	# boots stay roughly flat on the ground; in the air they hang loose and dangle a little
	_foot_k = lerpf(_foot_k, 0.45 if not on_floor else 0.7, 1.0 - exp(-12.0 * delta))
	var dangle := 1.0 - clampf((_foot_k - 0.45) / 0.25, 0.0, 1.0)
	front_boot.rotation = clampf(-(front_thigh.rotation + front_shin.rotation) * _foot_k + sin(_fly_t * 3.3 + 0.5) * 0.07 * dangle, -0.9, 0.9)
	back_boot.rotation = clampf(-(back_thigh.rotation + back_shin.rotation) * _foot_k + sin(_fly_t * 2.9 + 2.0) * 0.07 * dangle, -0.9, 0.9)

	# arms: both shoulders (and the gun, which is attached to the shoulder) drift together by a
	# pixel or so, so the hands stay on the grips. They swing back when you accelerate and sway gently in flight.
	var arm_off := Vector2(-_lag * 5.0, sin(_fly_t * 2.1 + 0.7) * 0.7 * _fly_blend - _kick * 0.35)

	torso.position.y = -21.0 + bob
	collar_node.position.y = -21.0 + bob
	head.position.y = HEAD_Y + bob * 1.3
	aim_pivot.position = Vector2(8, -38.0 + bob) + arm_off
	off_pivot.position = Vector2(15, -39.5 + bob) + arm_off
	# hair that hangs behind the head swings a little: trails when running or flying, lifts when rising, settles when still
	var hair_target := clampf(-fwd_n * 0.22 - clampf(velocity.y / 700.0, -1.0, 1.0) * 0.12 * (1.0 if not on_floor else 0.3) + (sin(_t * 2.0) * 0.05 if moving else 0.0), -0.45, 0.45)
	hair_target += sin(_fly_t * 2.3) * 0.03 * (0.4 + _fly_blend)
	_hair_rot = lerpf(_hair_rot, hair_target, 1.0 - exp(-9.0 * delta))
	if _hair_sway != null:
		_hair_sway.rotation = _hair_rot
	straps.position.y = -21.0 + bob
	straps.scale = torso.scale
	# the grenade on the hip swings back a little when you run or fly forward
	var fwd := velocity.x * (-1.0 if left else 1.0)
	var swing := clampf(fwd / 700.0, -0.4, 0.4)
	hip_throwable.position = HIP_THROW_POS + Vector2(0, bob)       # the belt is part of the torso art, so it bobs with the torso
	hip_throwable.rotation = lerp_angle(hip_throwable.rotation, swing + sin(Time.get_ticks_msec() * 0.012) * 0.04 * absf(swing), 1.0 - exp(-10.0 * delta))
	pad_near.position = Vector2(8, -38.0 + bob) + arm_off
	pad_far.position = Vector2(18, -41.5 + bob) + arm_off
	pad_near.rotation = aim_pivot.rotation * 0.4
	pad_far.rotation = aim_pivot.rotation * 0.4
	_update_draw(delta)
	_update_recoil(delta)
	_update_arms()
	_update_carry(velocity, bob, delta)

	# the jetpack stays on the back, leaning a bit more than the body while flying
	var jp_target := 0.0
	if jetting and not on_floor:
		jp_target = 0.02 + clampf(absf(velocity.x) / 360.0, 0.0, 1.0) * 0.03
	elif not on_floor:
		jp_target = 0.0
	_jp_rot = lerp_angle(_jp_rot, jp_target, 1.0 - exp(-8.0 * delta))
	var vib := _fly_blend                                  # very subtle engine vibration while thrusting
	jetpack.rotation = _jp_rot + sin(_fly_t * 47.0) * 0.012 * vib
	jetpack.position = Vector2(-19.0 + (1.0 - torso.scale.x) * 21.8 + sin(_fly_t * 58.0) * 0.3 * vib, -42.0 + bob)
	var pulse := 0.8 + sin(Time.get_ticks_msec() * 0.004) * 0.2          # the armour's glow lines breathe
	for g in _glow:
		g.modulate.a = pulse

	if _jfx != null and jetpack.visible:
		_jfx.update(delta, velocity, jetting, on_floor)
	if _fx != null:
		_fx.update(delta, velocity, jetting, on_floor)

	shield.visible = blocking
	if blocking:
		shield.modulate.a = 0.85 + sin(Time.get_ticks_msec() * 0.012) * 0.15


# While a gun is being drawn from the back, slides it from where it hung to the hand. Visual only.
func _update_draw(delta: float) -> void:
	if _draw_t <= 0.0 or weapon_sprite == null:
		return
	_draw_t = maxf(0.0, _draw_t - delta)
	var e := 1.0 - _draw_t / DRAW_TIME
	e = e * e * (3.0 - 2.0 * e)                                    # ease in and out
	var rest := Vector2(_hand_dist, 0)
	var start: Vector2 = (torso.position + _back_pos - aim_pivot.position).rotated(-aim_pivot.rotation)
	weapon_sprite.position = start.lerp(rest, e)
	weapon_sprite.rotation = lerp_angle(_back_rot - aim_pivot.rotation, 0.0, e)
	if _draw_t <= 0.0:
		weapon_sprite.position = rest
		weapon_sprite.rotation = 0.0


# ---------- arms ----------
# Both arms are two-bone arms. Each hand goes to a fixed spot on the gun, so the gun is held by
# BOTH hands at every aim angle (the way Mini Militia does it):
#   - near hand: the grip (_hand_dist along the aim)
#   - far hand:  the support grip on the front of the gun (while dual wielding it holds its own gun)
# The elbows bend on their own to make the hands reach, and the gloves are drawn on top of the gun.
func _update_arms() -> void:
	var aim := aim_pivot.rotation
	var shoulder: Vector2 = aim_pivot.position
	_solve_arm(_main_arm, shoulder, shoulder + Vector2(_hand_dist - float(_recoil_px[0]) * 0.8, 0).rotated(aim), aim)

	_off_arm["upper"].visible = off_pivot.visible
	_off_arm["hand"].visible = off_pivot.visible
	if not off_pivot.visible:
		return
	off_pivot.rotation = aim                    # (a second gun in this hand aims the same way)
	var off_shoulder: Vector2 = off_pivot.position
	var target: Vector2 = off_shoulder + (OFF_GUN_POS - Vector2(float(_recoil_px[1]) * 0.8, 0)).rotated(aim)   # the hand sits on the off-hand gun's grip (and rides its recoil)
	if _support:
		target = aim_pivot.position + (_support_local - Vector2(float(_recoil_px[0]) * 0.8, 0)).rotated(aim)     # the spot on the gun
	_solve_arm(_off_arm, off_shoulder, target, aim)


# Places the upper arm, forearm and glove so the glove ends on `hand_pos` (all in rig space).
func _solve_arm(arm: Dictionary, shoulder: Vector2, hand_pos: Vector2, hand_rot: float) -> void:
	var upper: Node2D = arm["upper"]
	var fore: Node2D = arm["fore"]
	var glove: Node2D = arm["hand"]
	var to_hand := hand_pos - shoulder
	var dist := maxf(to_hand.length(), 0.001)
	var dir := to_hand / dist
	var reach := UPPER_ARM + FOREARM

	var stretch := 1.0
	var bend := 0.0                              # angle at the shoulder between the aim line and the upper arm
	if dist >= reach * 0.995:
		stretch = minf(dist / (reach * 0.995), MAX_ARM_STRETCH)      # too far: straighten and stretch a little
	else:
		var d := maxf(dist, 4.0)
		var c := (UPPER_ARM * UPPER_ARM + d * d - FOREARM * FOREARM) / (2.0 * UPPER_ARM * d)
		bend = acos(clampf(c, -1.0, 1.0))        # law of cosines: the elbow ends up on the lower side

	upper.position = shoulder
	upper.scale = Vector2(stretch, stretch)
	upper.rotation = dir.angle() + bend
	var elbow := shoulder + Vector2.from_angle(upper.rotation) * UPPER_ARM * stretch
	var wrist := shoulder + dir * minf(dist, reach * stretch)
	fore.rotation = angle_difference(upper.rotation, (wrist - elbow).angle())
	glove.position = wrist if dist > reach * stretch else hand_pos
	glove.rotation = hand_rot


# ---------- shield ----------
func _draw_shield() -> void:
	var c: Color = loadout["visor"]
	var arc := PackedVector2Array()
	for i in range(21):
		var a := lerpf(-SHIELD_HALF_ANGLE, SHIELD_HALF_ANGLE, i / 20.0)
		arc.append(Vector2(10, 0) + Vector2(cos(a), sin(a)) * 64.0)
	var fill := PackedVector2Array([Vector2(10, 0)])
	fill.append_array(arc)
	shield.draw_colored_polygon(fill, Color(c.r, c.g, c.b, 0.18))
	shield.draw_polyline(arc, Color(c.r, c.g, c.b, 0.95), 3.0, true)


func shield_hit() -> void:
	shield.modulate = Color(2.5, 2.5, 2.5, 1.0)
	var tw := create_tween()
	tw.tween_property(shield, "modulate", Color(1, 1, 1, 1), 0.15)

# ============================================================
# FIRING EFFECTS: muzzle flash, recoil, spent casings (hand 0 = main, 1 = off hand)
# The player and the bots call fire_effects() once per shot. Nothing here changes gameplay.
# ============================================================
var _fx_data: Array = [null, null]          # WeaponData in each hand
var _fx_anchor: Array = [null, null]        # Node2D that sits exactly on the barrel tip and tilts with the gun
var _fx_flash: Array = [null, null]         # MuzzleFlash on that anchor
var _recoil: Array = [0.0, 0.0]             # 1 = just fired, falls back to 0
var _recoil_px: Array = [0.0, 0.0]          # how far back the gun is right now (px), so the hand can follow


func _make_flash(hand: int, pivot: Node2D) -> void:
	var anchor := Node2D.new()
	pivot.add_child(anchor)
	var flash := MuzzleFlash.new()
	anchor.add_child(flash)
	_fx_anchor[hand] = anchor
	_fx_flash[hand] = flash


# One shot was fired from this hand: flash at the barrel tip, kick the gun, spit out a case.
func fire_effects(hand: int) -> void:
	var data: WeaponData = _fx_data[hand]
	if data == null or (_fx_flash[hand] == null):
		return
	_recoil[hand] = 1.0
	(_fx_flash[hand] as MuzzleFlash).fire(data.flash_style, data.flash_size, data.flash_bright)
	if data.casing_eject:
		_eject_casing(hand, data, Vector2.ZERO)


# Revolvers and break-action guns keep their spent cases until you reload: `count` of them drop out now.
func eject_reload_casings(hand: int, count: int) -> void:
	var data: WeaponData = _fx_data[hand]
	if data == null or not data.casing_on_reload:
		return
	for i in mini(count, 6):
		_eject_casing(hand, data, Vector2(randf_range(-6.0, 6.0), randf_range(-1.0, 3.0)))


# Reload: the empty magazine drops out of the gun (guns with magazine_kind "none" have nothing to drop).
func drop_magazine(hand: int) -> void:
	var data: WeaponData = _fx_data[hand]
	if data == null or data.magazine_kind == "none":
		return
	var spr: Sprite2D = weapon_sprite if hand == 0 else off_weapon_sprite
	var pivot: Node2D = aim_pivot if hand == 0 else off_pivot
	var field := CasingField.of(self)
	if field == null or spr.texture == null:
		return
	var local: Vector2 = spr.position + (Vector2(4.0, 6.0) * gun_scale(data)).rotated(spr.rotation)   # the magazine well, just ahead of the grip
	var gt: Transform2D = pivot.global_transform
	var k := absf(gt.get_scale().x)
	var v := gt.basis_xform(Vector2(randf_range(-40.0, 40.0), randf_range(30.0, 110.0)))
	field.drop_mag(pivot.to_global(local), v, data.magazine_kind, data.magazine_color, 1500.0 * k, gun_scale(data) * k)


func _eject_casing(hand: int, data: WeaponData, jitter: Vector2) -> void:
	var spr: Sprite2D = weapon_sprite if hand == 0 else off_weapon_sprite
	var pivot: Node2D = aim_pivot if hand == 0 else off_pivot
	var field := CasingField.of(self)
	if field == null or spr.texture == null:
		return
	var port: Vector2 = data.casing_port if data.casing_port != Vector2.ZERO else data.grip + Vector2(6, -5)
	var local: Vector2 = spr.position + ((port - data.grip) * gun_scale(data) + jitter).rotated(spr.rotation)     # in the pivot's space
	var sp: Vector2 = data.casing_spread
	var v := Vector2(data.casing_velocity.x + randf_range(-sp.x, sp.x), data.casing_velocity.y + randf_range(-sp.y, sp.y)).rotated(spr.rotation)
	var gt: Transform2D = pivot.global_transform
	var k := absf(gt.get_scale().x)                                  # the whole rig can be scaled (bots are smaller)
	field.eject(pivot.to_global(local), gt.basis_xform(v), data.casing_kind, data.casing_color, data.casing_spin, data.casing_gravity * k, data.casing_scale * k)


# Every frame: eases the recoil back out and keeps the flash anchor on the barrel tip.
func _update_recoil(delta: float) -> void:
	for h in 2:
		var data: WeaponData = _fx_data[h]
		var spr: Sprite2D = weapon_sprite if h == 0 else off_weapon_sprite
		if data == null or spr.texture == null:
			_recoil_px[h] = 0.0
			continue
		var r: float = _recoil[h]
		if r > 0.002:
			r *= exp(-data.recoil_recover * delta)
		else:
			r = 0.0
		_recoil[h] = r
		_recoil_px[h] = data.recoil_kick * r
		if h == 0 and _draw_t > 0.0:
			continue                                    # drawing the gun from the back owns the sprite for now
		var base := Vector2(_hand_dist, 0) if h == 0 else OFF_GUN_POS
		spr.position = base + Vector2(-_recoil_px[h], 0)          # kicks back toward the shoulder ...
		spr.rotation = -data.recoil_tilt * r                      # ... and the muzzle flips up (negative = up)
		var anchor: Node2D = _fx_anchor[h]
		anchor.position = spr.position + ((data.muzzle - data.grip) * gun_scale(data)).rotated(spr.rotation)
		anchor.rotation = spr.rotation


# ============================================================
# SECONDARY WEAPON DISPLAY (carried gun)
# The stored gun is slung on the body on a real two-point sling: both ends of the strap
# are fixed to the gun, loop over the shoulder and cross the chest to the opposite hip, so the
# gun visibly hangs from the body. It sits on a spring, so it bounces, lags and swings with
# your movement. EVERY stored gun is shown (pistols included), sized and angled to suit it,
# whether it is one-handed or two-handed, and also while you dual wield.
# Positions are in the parent's space (facing right); the rig mirrors when you turn left.
# ============================================================

# --- slung gun (back) ---
# Where the stored gun hangs, picked from how long the gun is (in-game px). Each layout is
# (where the MIDDLE of the gun sits relative to the torso, rotation in degrees, scale). Anchoring the middle
# keeps every gun poking out past the jetpack, so it reads clearly instead of hiding behind the body.
const BACK_SMALL := [Vector2(-28, -6), -100.0, 1.0]       # pistols, revolvers, micro SMGs (up to ~42 px long)
const BACK_MEDIUM := [Vector2(-28, -24), -110.0, 0.92]    # SMGs (up to ~58 px)
const BACK_LARGE := [Vector2(-30, -30), -112.0, 0.85]     # rifles, shotguns, machine guns, snipers
const BACK_MAX_LEN := 64.0                                # nothing is drawn longer than this on the back (px)
const BACK_Z := -3                        # in front of the jetpack, behind the torso
const BACK_SHADE := Color(0.88, 0.88, 0.94)   # slightly darker: it sits in the body's shadow
var _sling_gun_a := Vector2(22, 14)       # sling mount on the gun (in-game px from the picture's corner): stock end
var _sling_gun_b := Vector2(62, 14)       # ... barrel end (both are worked out from each gun's size in set_secondary)
const SLING_A_VIA := Vector2(-12, -12)    # sling route on the torso (behind the body)
const SLING_A_END := Vector2(-9, -24)     # over the shoulder
const SLING_B_VIA := Vector2(-2, 14)
const SLING_B_END := Vector2(10, 16)      # opposite hip
const CHEST_STRAP := [Vector2(-9, -24), Vector2(0, -5), Vector2(10, 16)]   # across the chest
const BUCKLE_POS := Vector2(0, -5)
const SPRING_K := 220.0                   # how stiffly the slung gun springs back (higher = stiffer)
const SPRING_DAMP := 16.0                 # how fast the wobble dies out (higher = less wobble)
const SWAY_KICK := 0.0035                 # how strongly sudden speed changes shove the gun

const STRAP_COLOR := Color(0.14, 0.15, 0.18)
const BUCKLE_COLOR := Color(0.8, 0.59, 0.24)

var _secondary_sprite: Sprite2D
var _back_rot := 0.0                  # rest rotation of the stored gun (set per gun in set_secondary)
var _back_pos := Vector2.ZERO         # rest position of the stored gun's grip, relative to the torso
var _secondary_art := 1.0              # art_scale of the carried gun (its picture is this many times bigger)
var _strap: Line2D                 # chest strap (in front of the torso)
var _sling_a: Line2D               # sling parts behind the torso, tied to the gun
var _sling_b: Line2D
var _buckle: Polygon2D
var _secondary_grip := Vector2.ZERO
var _carry_sway := 0.0
var _sway_vel := 0.0
var _prev_vel := Vector2.ZERO


func _make_line(width: float, color: Color, z: int) -> Line2D:
	var l := Line2D.new()
	l.width = width
	l.default_color = color
	l.z_index = z
	l.begin_cap_mode = Line2D.LINE_CAP_ROUND
	l.end_cap_mode = Line2D.LINE_CAP_ROUND
	l.joint_mode = Line2D.LINE_JOINT_ROUND
	l.visible = false
	return l


func _build_secondary() -> void:
	_secondary_sprite = Sprite2D.new()
	_secondary_sprite.name = "SecondarySprite"
	_secondary_sprite.centered = false
	_secondary_sprite.visible = false

	_sling_a = _make_line(2.4, STRAP_COLOR, BACK_Z)
	_sling_a.name = "SlingA"
	_sling_b = _make_line(2.4, STRAP_COLOR, BACK_Z)
	_sling_b.name = "SlingB"
	_strap = _make_line(3.4, STRAP_COLOR, 1)
	_strap.name = "CarryStrap"
	_strap.points = PackedVector2Array(CHEST_STRAP)
	_buckle = Polygon2D.new()
	_buckle.name = "CarryBuckle"
	_buckle.polygon = PackedVector2Array([Vector2(-2.5, -2), Vector2(2.5, -2), Vector2(2.5, 2), Vector2(-2.5, 2)])
	_buckle.color = BUCKLE_COLOR
	_buckle.position = BUCKLE_POS
	_buckle.z_index = 2
	_buckle.visible = false
	for n in [_sling_a, _sling_b, _strap, _buckle]:
		torso.add_child(n)


# Shows the carried (not held) gun. Only TWO-HANDED guns are shown, slung across the back.
# One-handed guns, or no gun at all, show nothing on the body.
func set_secondary(data: WeaponData) -> void:
	if _secondary_sprite == null:
		_build_secondary()

	if data == null or data.texture == null:
		_secondary_sprite.visible = false
		_secondary_sprite.texture = null
		for n in [_strap, _sling_a, _sling_b, _buckle]:
			n.visible = false
		return

	if _secondary_sprite.get_parent() != torso:
		if _secondary_sprite.get_parent() != null:
			_secondary_sprite.get_parent().remove_child(_secondary_sprite)
		torso.add_child(_secondary_sprite)
	# the sling is drawn after the gun so it lies over it
	for n in [_sling_a, _sling_b]:
		torso.move_child(n, -1)

	_secondary_grip = data.grip
	_secondary_art = data.art_scale
	var gun_len := float(data.texture.get_width()) / data.art_scale
	_sling_gun_a = Vector2(gun_len * 0.24, data.grip.y + 1.0)
	_sling_gun_b = Vector2(gun_len * 0.70, data.muzzle.y + 3.0)
	_secondary_sprite.texture = data.texture
	_secondary_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	_secondary_sprite.offset = -data.grip * _secondary_art     # the grip pixel is the pivot for position and rotation
	_carry_sway = 0.0
	_sway_vel = 0.0
	_prev_vel = Vector2.ZERO
	var layout: Array = BACK_SMALL if gun_len <= 42.0 else (BACK_MEDIUM if gun_len <= 58.0 else BACK_LARGE)
	var back_scale: float = minf(float(layout[2]), BACK_MAX_LEN / gun_len)
	_back_rot = deg_to_rad(float(layout[1]))
	var mid := Vector2(gun_len * 0.5, float(data.texture.get_height()) / data.art_scale * 0.5)   # middle of the picture
	_back_pos = (layout[0] as Vector2) - ((mid - data.grip) * back_scale).rotated(_back_rot)   # grip position that puts the middle there
	_secondary_sprite.position = _back_pos
	_secondary_sprite.rotation = _back_rot
	_secondary_sprite.scale = Vector2.ONE * back_scale / _secondary_art
	_secondary_sprite.z_index = BACK_Z
	_secondary_sprite.self_modulate = BACK_SHADE

	for n in [_strap, _sling_a, _sling_b, _buckle]:
		n.visible = true
	_update_sling()
	_secondary_sprite.visible = true


# Draws the parts of the sling that are tied to the gun, following it as it moves.
func _update_sling() -> void:
	var a: Vector2 = _secondary_sprite.transform * ((_sling_gun_a - _secondary_grip) * _secondary_art)
	var b: Vector2 = _secondary_sprite.transform * ((_sling_gun_b - _secondary_grip) * _secondary_art)
	_sling_a.points = PackedVector2Array([a, SLING_A_VIA, SLING_A_END])
	_sling_b.points = PackedVector2Array([b, SLING_B_VIA, SLING_B_END])


# Makes the carried gun move like it has weight. Called from update_visuals.
# A spring, so it bounces with your steps, lags behind when you speed up, droops when
# you jump and wobbles a little before settling.
func _update_carry(velocity: Vector2, bob: float, delta: float) -> void:
	if _secondary_sprite == null or not _secondary_sprite.visible:
		return
	var dt := clampf(delta, 0.0001, 0.05)

	var kick := (velocity - _prev_vel).limit_length(800.0)      # sudden speed change this frame
	_prev_vel = velocity
	var forward := velocity.x * rig.scale.x                      # + = moving the way you face
	_sway_vel += kick.y * SWAY_KICK - kick.x * rig.scale.x * SWAY_KICK
	var target := -clampf(velocity.y / 900.0, -1.0, 1.0) * 0.12 \
		- clampf(forward / 400.0, -1.0, 1.0) * 0.08 \
		+ bob * 0.03
	_sway_vel += ((target - _carry_sway) * SPRING_K - _sway_vel * SPRING_DAMP) * dt
	_carry_sway = clampf(_carry_sway + _sway_vel * dt, -0.4, 0.4)
	_secondary_sprite.rotation = _back_rot + _carry_sway
	_update_sling()
