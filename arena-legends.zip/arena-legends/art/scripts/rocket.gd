class_name Rocket
extends Area2D
## The RPG-7 rocket: a visible projectile that flies straight, leaves a smoke trail, and explodes on the first
## thing it touches (or at the end of its range). The explosion reuses the grenade code (Throwable), so it
## gives the same area damage, knockback falloff, crouch-shield rules, camera shake and blast effects.

var direction := Vector2.RIGHT
var speed := 650.0
var max_range := 1600.0
var shooter: Node = null
var data: WeaponData
var net_visual := false          # network match: cosmetic copy on a client (the blast arrives from the host)
var net_id := 0

var _travelled := 0.0
var _age := 0.0
var _done := false
var _trail: Array[Vector2] = []

const TRAIL_POINTS := 9


# One call launches a rocket (used by the player and by bots).
static func launch(w: WeaponData, pos: Vector2, dir: Vector2, who: Node, tree: SceneTree) -> Rocket:
	var r := Rocket.new()
	r.data = w
	r.direction = dir.normalized()
	r.speed = w.projectile_speed
	r.max_range = w.max_range
	r.shooter = who
	r.rotation = r.direction.angle()
	tree.current_scene.add_child(r)
	r.global_position = pos
	return r


func _ready() -> void:
	z_index = 4
	if Net.match_active():
		collision_mask |= 2
	var shape := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 5.0
	shape.shape = circle
	add_child(shape)
	body_entered.connect(_on_body_entered)
	add_to_group("rocket")


func _physics_process(delta: float) -> void:
	if _done:
		return
	_age += delta
	var accel := minf(1.0, 0.35 + _age * 2.2)          # leaves the tube slowly, then the motor kicks in
	var step := direction * speed * accel * delta
	global_position += step
	_travelled += step.length()
	_trail.append(global_position)
	if _trail.size() > TRAIL_POINTS:
		_trail.pop_front()
	queue_redraw()
	if _travelled >= max_range:
		_explode()


func _on_body_entered(body: Node) -> void:
	if _done or body == shooter:
		return
	var victim: Node = null
	if body.has_method("take_damage") and not (("is_dead" in body and bool(body.get("is_dead"))) or ("dead" in body and bool(body.get("dead")))):
		victim = body                             # a player, bot or LAN puppet: this is a DIRECT hit
	_explode(victim)


# direct = the fighter the rocket flew into (or null when it hit the map / ran out of range).
func _explode(direct: Node = null) -> void:
	if _done:
		return
	_done = true
	if net_visual:
		queue_free()                      # the host's explosion event draws the blast for everybody
		return
	if net_id != 0 and Net.match_active() and Net.is_host():
		Net.game.host_net_gone(net_id)     # remove the cosmetic rockets on the clients
	var d := ThrowableData.make_grenade()
	d.damage = data.damage if data != null else 90
	d.radius = data.blast_radius if data != null else 150.0
	d.knockback = data.knockback if data != null else 500.0
	d.lethal_radius = 0.0
	d.knockback_cap = 1200.0
	var bomb := Throwable.new()
	bomb.setup(d, shooter, Vector2.ZERO)
	if direct != null and is_instance_valid(direct):
		# Direct hit = instant kill, ahead of any body-part multiplier. The blast skips this target so the
		# same rocket can never damage it twice; everybody else in the radius still takes distance-based damage.
		if "last_attacker" in direct:
			direct.last_attacker = shooter if is_instance_valid(shooter) else null    # kill credit
		bomb.skip_bodies.append(direct)
		direct.take_damage(9999, direction * (data.knockback if data != null else 500.0), true)
	get_tree().current_scene.add_child(bomb)
	bomb.global_position = global_position
	bomb._explode()
	GunAudio.boom_at(get_tree(), global_position)
	queue_free()


func _draw() -> void:
	# smoke trail (fading, in local space)
	var n := _trail.size()
	for i in n:
		var t := float(i + 1) / float(maxi(n, 1))
		var p := to_local(_trail[i])
		draw_circle(p, 1.5 + 3.2 * t, Color(0.78, 0.78, 0.8, 0.10 + 0.22 * t))
	# exhaust flame
	var fl := 7.0 + randf() * 5.0
	draw_colored_polygon(PackedVector2Array([Vector2(-7, -2.4), Vector2(-7 - fl, 0), Vector2(-7, 2.4)]), Color(1.0, 0.55, 0.15, 0.9))
	draw_colored_polygon(PackedVector2Array([Vector2(-7, -1.2), Vector2(-7 - fl * 0.55, 0), Vector2(-7, 1.2)]), Color(1.0, 0.95, 0.65, 0.95))
	# fins
	draw_colored_polygon(PackedVector2Array([Vector2(-7, -2), Vector2(-10, -6), Vector2(-3, -2)]), Color(0.16, 0.18, 0.2))
	draw_colored_polygon(PackedVector2Array([Vector2(-7, 2), Vector2(-10, 6), Vector2(-3, 2)]), Color(0.16, 0.18, 0.2))
	# body + warhead
	draw_rect(Rect2(-7, -2.6, 12, 5.2), Color(0.34, 0.4, 0.28))
	draw_colored_polygon(PackedVector2Array([Vector2(5, -3.6), Vector2(11, -2), Vector2(14, 0), Vector2(11, 2), Vector2(5, 3.6)]), Color(0.52, 0.56, 0.4))
	draw_rect(Rect2(3, -2.8, 1.6, 5.6), Color(0.85, 0.7, 0.25))
	draw_line(Vector2(-6, -2.6), Vector2(4, -2.6), Color(1, 1, 1, 0.35), 1.0)
