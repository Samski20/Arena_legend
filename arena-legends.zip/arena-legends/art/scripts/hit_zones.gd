class_name HitZones
extends RefCounted
## Head / torso / legs damage zones for bullets. The zones are slices of the body's REAL collision capsule
## (the one the player, bots and LAN puppets already use), read at the moment of the hit, so they follow
## walking, crouching, jetpack flight, falling and landing with no extra nodes to keep in sync.
## Zone is picked from the bullet's height inside that capsule: top 25% = head, next 40% = torso, rest = legs.
## Rockets and explosions do NOT use these (a direct rocket hit always kills; blasts use distance falloff).

const HEAD := "head"
const TORSO := "torso"
const LEGS := "legs"

const MULT := {"head": 2.0, "torso": 1.0, "legs": 0.6}     # torso = the baseline damage of the weapon
const HEAD_END := 0.25
const TORSO_END := 0.65


# Which zone a point (world position) hits on this body.
static func zone_at(body: Node, point: Vector2) -> String:
	var top := 0.0
	var h := 0.0
	for c in body.get_children():
		var cs := c as CollisionShape2D
		if cs == null or cs.shape == null or cs.disabled:
			continue
		if cs.shape is CapsuleShape2D:
			h = (cs.shape as CapsuleShape2D).height * absf(cs.global_scale.y)
		elif cs.shape is RectangleShape2D:
			h = (cs.shape as RectangleShape2D).size.y * absf(cs.global_scale.y)
		else:
			continue
		top = cs.global_position.y - h * 0.5
		break
	if h <= 0.0:
		return TORSO                                   # unknown shape: baseline damage, never a surprise
	var f := clampf((point.y - top) / h, 0.0, 1.0)
	if f < HEAD_END:
		return HEAD
	if f < TORSO_END:
		return TORSO
	return LEGS


static func mult(zone: String) -> float:
	return float(MULT.get(zone, 1.0))
