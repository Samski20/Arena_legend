class_name LevitateFx
extends CosmeticFx
## Organic alien propulsion: no pack, no flames. A luminous ring pulses under the feet, bioenergy motes rise from it,
## two glow-orbs circle the head, and the whole thing brightens and speeds up while the jetpack is active.
## Landing sends the ring outward. All additive sprites + two tiny emitters.

var _halo: Sprite2D
var _orbs: Array = []
var _motes_idle: CPUParticles2D
var _motes_fly: CPUParticles2D
var _energy := 0.0
var _spin := 0.0
var _pulse_boost := 0.0
var _col := Color(0.4, 0.95, 1.0)


func _build() -> void:
	_col = cfg.get("glow", _col)
	_halo = _sprite(self, "halo.png", Vector2(60, 20), 0.5, true)
	_halo.position = Vector2(0, 5)
	_halo.z_index = -3
	for i in 2:
		var o := _sprite(self, "orb.png", Vector2(12, 12), 0.5, true)
		o.z_index = 6
		_orbs.append(o)
	_motes_idle = _puff(self, 5, 1.4, Color(_col.r, _col.g, _col.b, 0.6), 10.0, 40.0, Vector2(0, -1), 1.4)
	_motes_fly = _puff(self, 9, 0.9, Color(_col.r, _col.g, _col.b, 0.9), 28.0, 70.0, Vector2(0, 1), 1.8, Vector2(0, 30))
	_motes_idle.position = Vector2(0, 2)
	_motes_fly.position = Vector2(0, 2)
	_motes_idle.emitting = true


func _tick(delta: float, vel: Vector2, jetting: bool, on_floor: bool) -> void:
	_energy = move_toward(_energy, 1.0 if jetting else 0.0, delta * 3.0)
	_pulse_boost = move_toward(_pulse_boost, 0.0, delta * 2.5)
	var pulse := 0.6 + 0.25 * sin(_t * (2.2 + 4.0 * _energy))
	_halo.modulate.a = clampf((0.45 + 0.4 * _energy) * pulse + _pulse_boost * 0.5, 0.0, 1.0)
	_halo.scale = Vector2(0.5, 0.5) * (1.0 + 0.25 * _energy + _pulse_boost * 0.9)
	_halo.position.y = 5.0 + (1.0 - _energy) * 0.0
	_spin += delta * (1.4 + 3.4 * _energy)
	var head_pos := rig.head.position + Vector2(0, -10)
	for i in _orbs.size():
		var a := _spin + i * PI
		(_orbs[i] as Sprite2D).position = head_pos + Vector2(cos(a) * 24.0, sin(a) * 9.0 - 4.0)
		(_orbs[i] as Sprite2D).z_index = 6 if sin(a) > 0.0 else -6
		(_orbs[i] as Sprite2D).modulate.a = 0.55 + 0.35 * _energy
	_motes_idle.emitting = not jetting
	_motes_fly.emitting = jetting


func _on_landed(strength: float) -> void:
	_pulse_boost = clampf(0.5 + strength, 0.5, 1.5)                  # the ring flares outward on touch-down
