class_name AppearanceStore
extends RefCounted
## Local save for the look: user://appearance.json. Holds the base appearance, the equipped cosmetic and the
## owned cosmetic ids as plain ids (no art). Missing / damaged / old files fall back to safe defaults.
## There is no account or payment: unlock(id) is the single hook rewards or achievements can call later.

const PATH := "user://appearance.json"
const FORMAT := 1

static var app: Dictionary = {}
static var equipped := ""
static var variant := 0                 # colour variant of the equipped cosmetic
static var owned: Array = []
static var _loaded := false


static func load_all() -> void:
	_loaded = true
	app = Appearance.default_for("male")
	equipped = ""
	variant = 0
	owned = _default_owned()
	if not FileAccess.file_exists(PATH):
		return
	var f := FileAccess.open(PATH, FileAccess.READ)
	if f == null:
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if not (parsed is Dictionary):
		DirAccess.rename_absolute(ProjectSettings.globalize_path(PATH), ProjectSettings.globalize_path(PATH) + ".bad")
		return
	app = Appearance.sanitize(parsed.get("app", {}))
	var own: Variant = parsed.get("owned", null)
	if own is Array:
		owned = []
		for id in own:
			if CosmeticCatalog.DEFS.has(str(id)) and not owned.has(str(id)):
				owned.append(str(id))
	for id in _default_owned():                          # newly added free cosmetics reach old saves
		if not owned.has(id):
			owned.append(id)
	var eq := str(parsed.get("equipped", ""))
	equipped = eq if owned.has(eq) and CosmeticCatalog.DEFS.has(eq) else ""    # removed / not owned -> normal look
	var nv: int = (CosmeticCatalog.get_def(equipped).get("variants", []) as Array).size()
	variant = clampi(int(parsed.get("variant", 0)), 0, maxi(nv - 1, 0))


static func _default_owned() -> Array:
	var out: Array = []
	for id in CosmeticCatalog.all():
		if bool(CosmeticCatalog.get_def(id).get("owned_default", false)):
			out.append(id)
	return out


static func ensure() -> void:
	if not _loaded:
		load_all()


static func save_all() -> bool:
	ensure()
	var tmp := PATH + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return false
	f.store_string(JSON.stringify({"format": FORMAT, "app": app, "equipped": equipped, "variant": variant, "owned": owned}, "\t"))
	f.close()
	if FileAccess.file_exists(PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(PATH))
	return DirAccess.rename_absolute(ProjectSettings.globalize_path(tmp), ProjectSettings.globalize_path(PATH)) == OK


static func is_owned(id: String) -> bool:
	ensure()
	return owned.has(id)


static func unlock(id: String) -> void:
	ensure()
	if CosmeticCatalog.DEFS.has(id) and not owned.has(id):
		owned.append(id)
		save_all()


static func rig_params() -> Dictionary:
	ensure()
	return Appearance.resolve(app, equipped, variant)


static func net_code() -> String:
	ensure()
	return Appearance.encode(app, equipped, variant)
