class_name HeadParts
extends RefCounted
## Every head-related choice (shape, eyes, hair, facial hair, headgear) with the SPECIES it fits.
## Species: "human", "saurian" (the armoured lizard-alien), "insect", "lumen". A part that does not fit the
## current species is shown greyed out ("doesn't fit ...") instead of being drawn badly.
## Shapes also carry their own attachment anchors (HeadAnchors) so eyes, hair, beards and hats sit on THAT head.

const SPECIES_NAMES := {"human": "a human head", "saurian": "a saurian head", "insect": "an insectoid head", "lumen": "a Lumen head"}

# id -> {name, species, file (under art/player/ unless it starts with res://), baked}
const SHAPES := {
	"round": {"name": "Round", "species": "human", "file": "heads/head_round.png"},
	"oval": {"name": "Oval", "species": "human", "file": "heads/head_oval.png"},
	"square": {"name": "Square", "species": "human", "file": "heads/head_square.png"},
	"angular": {"name": "Angular", "species": "human", "file": "heads/head_angular.png"},
	"long": {"name": "Long Face", "species": "human", "file": "heads/head_long.png"},
	"broad": {"name": "Broad Face", "species": "human", "file": "heads/head_broad.png"},
	"narrow": {"name": "Narrow Face", "species": "human", "file": "heads/head_narrow.png"},
	"strong_jaw": {"name": "Strong Jaw", "species": "human", "file": "heads/head_strong_jaw.png"},
	"sau_smooth": {"name": "Saurian Smooth", "species": "saurian", "file": "res://art/cosmetics/saurian/head_smooth.png", "baked": true},
	"sau_crest": {"name": "Saurian Crested", "species": "saurian", "file": "res://art/cosmetics/saurian/head_crest.png", "baked": true},
	"insect": {"name": "Insectoid", "species": "insect", "file": "res://art/cosmetics/insectoid/head.png", "baked": true, "eyes_baked": true},
	"lumen": {"name": "Lumen", "species": "lumen", "file": "res://art/cosmetics/lumen/head.png", "baked": true, "eyes_baked": true},
}
# eye styles: human ones are 3 layers (white / iris / lids) in art/player/eyes; species ones are baked sets
const EYES := {
	"round": {"name": "Round", "species": "human"}, "narrow": {"name": "Narrow", "species": "human"},
	"almond": {"name": "Almond", "species": "human"}, "angular": {"name": "Angular", "species": "human"},
	"heavy": {"name": "Heavy-lidded", "species": "human"}, "large": {"name": "Large Expressive", "species": "human"},
	"small": {"name": "Small", "species": "human"}, "cyber": {"name": "Futuristic Visor", "species": "human"},
	"amber_slit": {"name": "Amber Slit", "species": "saurian", "dir": "res://art/cosmetics/saurian/"},
	"black_oval": {"name": "Black Oval", "species": "saurian", "dir": "res://art/cosmetics/saurian/"},
	"glow_green": {"name": "Glowing Green", "species": "saurian", "dir": "res://art/cosmetics/saurian/"},
}
const HAIR := {
	"none": {"name": "Bald", "species": "any"}, "crop": {"name": "Short Crop", "species": "human"}, "fade": {"name": "Fade", "species": "human"},
	"afro": {"name": "Afro", "species": "human"}, "braids": {"name": "Braids", "species": "human", "flows": true},
	"dreads": {"name": "Dreadlocks", "species": "human", "flows": true}, "long": {"name": "Long Flowing", "species": "human", "flows": true},
	"curly": {"name": "Curly", "species": "human"}, "wavy": {"name": "Wavy", "species": "human", "flows": true},
	"spiky": {"name": "Spiky", "species": "human"}, "pony": {"name": "Ponytail", "species": "human", "flows": true},
	"mohawk": {"name": "Mohawk", "species": "human"}, "future": {"name": "Swept Blade", "species": "human", "flows": true},
}
const FACIAL := {
	"none": {"name": "Clean", "species": "any"}, "stubble": {"name": "Stubble", "species": "human"}, "short_beard": {"name": "Short Beard", "species": "human"},
	"full_beard": {"name": "Full Beard", "species": "human"}, "goatee": {"name": "Goatee", "species": "human"},
	"mustache": {"name": "Mustache", "species": "human"}, "mustache_beard": {"name": "Mustache + Beard", "species": "human"},
	"long_beard": {"name": "Long Beard", "species": "human"},
}
# headgear -> the rig layers it switches on. Fits human + saurian heads (through their anchors); insect / lumen heads take none.
const HEADGEAR := {
	"none": {"name": "None", "species": "any", "show": []},
	"helmet": {"name": "Combat Helmet", "species": "fitted", "show": ["helmet"]},
	"tactical": {"name": "Visor Helmet", "species": "fitted", "show": ["helmet", "faceshield"]},
	"mask": {"name": "Face Mask", "species": "fitted", "show": ["mask"]},
	"goggles": {"name": "Goggles", "species": "fitted", "show": ["goggles"]},
	"cap": {"name": "Cap", "species": "fitted", "show": ["cap"]},
	"beanie": {"name": "Beanie", "species": "fitted", "show": ["beanie"]},
	"cowl": {"name": "Hero Cowl", "species": "fitted", "show": ["cowl"]},
}
const FITTED_SPECIES := ["human", "saurian"]


static func shape_species(shape_id: String) -> String:
	return str(SHAPES.get(shape_id, {}).get("species", "human"))


# Does this option fit a character of `species`? ("any" fits all, "fitted" = human + saurian)
static func fits(option: Dictionary, species: String) -> bool:
	var s := str(option.get("species", "any"))
	if s == "any":
		return true
	if s == "fitted":
		return FITTED_SPECIES.has(species)
	return s == species


static func default_shape(species: String) -> String:
	match species:
		"saurian": return "sau_smooth"
		"insect": return "insect"
		"lumen": return "lumen"
	return "round"


static func default_eyes(species: String) -> String:
	return "amber_slit" if species == "saurian" else ("round" if species == "human" else "")


static func anchors(shape_id: String) -> Dictionary:
	return HeadAnchors.DATA.get(shape_id, HeadAnchors.DATA.get("round", {}))
