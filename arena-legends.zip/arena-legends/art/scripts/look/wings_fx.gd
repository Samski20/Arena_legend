class_name WingsFx
extends CosmeticFx
## Insectoid flight: two pairs of membrane wings folded along the back on the ground, unfolding and beating while
## the jetpack is active (the wings ARE its jetpack, so the normal jetpack and flames are hidden). Also: an abdomen that lags behind movement, two small mid-limbs that twitch, a motion-blur ghost per wing,
## glowing veins, a few wind glints and a take-off burst. Wing beat rate follows how hard you are flying.

var _open := 0.0                   # 0 folded .. 1 fully unfolded (smooth)
var _phase := 0.0
var _wings: Array = []             # [root, sprite, ghost_a, ghost_b, glow, open_deg, fold_deg, amp_deg, phase_off]
var _abdomen: Node2D
var _mids: Array = []
var _lag := 0.0
var _glints: CPUParticles2D
var _burst: CPUParticles2D
var _glow_col := Color(0.5, 1.0, 0.85)


func _build() -> void:
	_glow_col = cfg.get("glow", _glow_col)
	var back := Node2D.new()
	back.position = Vector2(-12, -45)
	back.z_index = -5
	add_child(back)
	# far wings first (darker, behind), then near wings
	for spec in [["wing_hind.png", 110, 44, -92.0, 118.0, 26.0, 0.9, 0.62, -7], ["wing_fore.png", 150, 60, -128.0, 108.0, 30.0, 0.0, 0.7, -6],
				 ["wing_hind.png", 110, 44, -80.0, 124.0, 26.0, 0.9, 1.0, -5], ["wing_fore.png", 150, 60, -116.0, 112.0, 30.0, 0.0, 1.0, -4]]:
		var root := Node2D.new()
		root.z_index = int(spec[8]) + 5
		back.add_child(root)
		var pv := Vector2(6, float(spec[2]) * 0.5)
		var s := _sprite(root, str(spec[0]), pv, 0.42)
		var shade := float(spec[7])
		s.modulate = Color(shade, shade, shade, 0.92)
		var ga := _sprite(root, str(spec[0]), pv, 0.42)
		var gb := _sprite(root, str(spec[0]), pv, 0.42)
		ga.modulate.a = 0.0
		gb.modulate.a = 0.0
		var gl := _sprite(root, str(spec[0]).replace(".png", "_glow.png"), pv, 0.42, true)
		gl.modulate = Color(_glow_col.r, _glow_col.g, _glow_col.b, 0.5)
		_wings.append({"root": root, "main": s, "ga": ga, "gb": gb, "glow": gl, "open": float(spec[3]), "fold": float(spec[4]), "amp": float(spec[5]), "off": float(spec[6])})
		root.rotation_degrees = float(spec[4])
	# abdomen hangs from the hips
	_abdomen = Node2D.new()
	_abdomen.position = Vector2(-11, -4)
	_abdomen.z_index = -4
	add_child(_abdomen)
	_sprite(_abdomen, "abdomen.png", Vector2(68, 34), 0.34)
	# (the antennae are part of the head picture now - the "Curled / Straight / Feathered Antennae" hairstyles. The old extra
	#  antenna sprites were parented to the head, were never freed with this effect and stayed on EVERY character.)
	# two small extra limbs on the thorax
	for z in [[1, 12.0, -19.0, 70.0], [-1, 6.0, -22.0, 82.0]]:
		var m := Node2D.new()
		m.position = Vector2(float(z[1]), float(z[2]))
		m.z_index = int(z[0])
		m.rotation_degrees = float(z[3])
		add_child(m)
		_sprite(m, "mid_limb.png", Vector2(4, 13), 0.36)
		_mids.append(m)
	_glints = _puff(back, 8, 0.7, Color(_glow_col.r, _glow_col.g, _glow_col.b, 0.8), 40.0, 60.0, Vector2(-1, 0.3), 1.6, Vector2(0, 14))
	_burst = _puff(back, 14, 0.5, Color(1, 1, 1, 0.85), 70.0, 180.0, Vector2(-1, -0.4), 1.8)
	_burst.one_shot = true
	_burst.explosiveness = 1.0


func _tick(delta: float, vel: Vector2, jetting: bool, on_floor: bool) -> void:
	var fs := signf(rig.global_transform.x.x)
	var lv := Vector2(vel.x * fs, vel.y)
	_open = move_toward(_open, 1.0 if jetting else 0.0, delta * (6.5 if jetting else 4.0))
	var effort := clampf(absf(lv.y) / 380.0 + absf(lv.x) / 500.0, 0.0, 1.0)
	var rate := (9.0 + 5.0 * effort) if jetting else 2.0            # beats per second (low enough to read at 60 fps)
	_phase += delta * rate * TAU
	for w in _wings:
		var root: Node2D = w["root"]
		var beat := sin(_phase + float(w["off"])) if _open > 0.3 else sin(_t * 1.3 + float(w["off"])) * 0.05
		var open_deg := lerpf(float(w["fold"]), float(w["open"]), _open)
		root.rotation_degrees = open_deg + beat * float(w["amp"]) * _open
		# squash the wing a touch at the extremes: reads as the membrane flexing
		root.scale = Vector2(1.0, 1.0 - 0.12 * absf(beat) * _open)
		var blur := clampf((_open - 0.6) * 2.5, 0.0, 1.0) * (0.25 + 0.2 * effort)
		(w["ga"] as Sprite2D).rotation_degrees = -float(w["amp"]) * 0.8 * signf(sin(_phase + float(w["off"]) - 0.5))
		(w["gb"] as Sprite2D).rotation_degrees = float(w["amp"]) * 0.8 * signf(sin(_phase + float(w["off"]) + 0.5))
		(w["ga"] as Sprite2D).modulate.a = blur
		(w["gb"] as Sprite2D).modulate.a = blur
		(w["glow"] as Sprite2D).modulate.a = 0.35 + 0.3 * sin(_t * 3.0) + 0.3 * _open
	_lag = lerpf(_lag, clampf(-lv.x * 0.0009 - lv.y * 0.0004, -0.5, 0.5), 1.0 - exp(-7.0 * delta))
	_abdomen.rotation = _lag * 0.9 + sin(_t * 1.6) * 0.04 - 0.08
	for i in _mids.size():
		(_mids[i] as Node2D).rotation_degrees = (70.0 if i == 0 else 82.0) + sin(_t * 3.1 + i * 2.0) * 9.0
	_glints.emitting = jetting and _open > 0.6


func _on_takeoff() -> void:
	if _burst != null:
		_burst.restart()
		_burst.emitting = true


func _on_landed(strength: float) -> void:
	_open = minf(_open, 0.5)                                         # wings snap shut as the feet touch down
