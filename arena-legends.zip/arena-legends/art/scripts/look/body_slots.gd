class_name BodySlots
extends RefCounted
## The body kit: where each body slot's picture sits on its joint. GENERATED from tools/bodykit.py (SLOTS) - keep both in step.
## Every picture that sits on a body slot (bare skin, garments, creature and hero bodies) is drawn on the canvas below,
## 4 picture pixels per in-game pixel, so one rig places them all and parts of different sets always line up.
## size / pivot are in in-game pixels; the pivot is the slot's joint (shoulder, elbow, hip, knee, ankle, wrist ...).

const PPU := 4.0
const DATA := {
	"torso": {"size": Vector2(50, 58), "pivot": Vector2(25, 33)},
	"waist": {"size": Vector2(36, 18), "pivot": Vector2(15, 8)},
	"thigh": {"size": Vector2(17, 33), "pivot": Vector2(8.5, 8)},
	"shin": {"size": Vector2(14, 31), "pivot": Vector2(7, 7)},
	"foot": {"size": Vector2(27, 17), "pivot": Vector2(8, 6)},
	"upper_arm": {"size": Vector2(37, 14), "pivot": Vector2(7, 7)},
	"forearm": {"size": Vector2(35, 12), "pivot": Vector2(6, 6)},
	"hand": {"size": Vector2(14, 14), "pivot": Vector2(7, 7)},
}
# bone lengths (in-game pixels)
const UPPER_ARM := 24.0
const FOREARM := 24.0
const THIGH := 18.5
const SHIN := 19.0
const ANKLE_TO_SOLE := 9.6
