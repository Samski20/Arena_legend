class_name CapeFx
extends CosmeticFx
## Superhero flight: a cloth-like cape (one Polygon2D whose lower points trail behind with a soft spring) and a pair
## of small energy puffs at the boots. There is NO pack: the cape and the body lean carry the flight look. The cape reacts
## to acceleration, direction changes, falling and landing. Visual only.

const ROWS := [0.0, 0.5, 1.0]
var _cape: Polygon2D
var _rest: PackedVector2Array
var _uv: PackedVector2Array
var _lag := Vector2.ZERO
var _lift := 0.0
var _foot_puffs: Array = []
var _col := Color(0.8, 0.92, 1.0)
const TEX_PTS := [Vector2(30, 0), Vector2(18, 40), Vector2(8, 100), Vector2(14, 140), Vector2(86, 140), Vector2(92, 100), Vector2(78, 40), Vector2(66, 0)]
const ROW_OF := [0, 1, 2, 2, 2, 2, 1, 0]


func _build() -> void:
	_col = cfg.get("glow", _col)
	_cape = Polygon2D.new()
	_cape.texture = _tex("cape.png")
	_cape.position = Vector2(3, -44)
	_cape.z_index = -6
	if mat != null:
		_cape.material = mat
	add_child(_cape)
	_rest = PackedVector2Array()
	_uv = PackedVector2Array()
	for p in TEX_PTS:
		_rest.append((p - Vector2(48, 0)) * 0.5 + Vector2(-14, 0))      # hangs behind the shoulders
		_uv.append(p * (float(_cape.texture.get_width()) / 96.0))      # art may be drawn at 2x
	_cape.polygon = _rest
	_cape.uv = _uv
	for boot in [rig.front_boot, rig.back_boot]:
		var p := _puff(boot, 6, 0.45, Color(_col.r, _col.g, _col.b, 0.8), 36.0, 40.0, Vector2(0, 1), 1.6)
		p.position = Vector2(2, 8)
		_foot_puffs.append(p)


func _tick(delta: float, vel: Vector2, jetting: bool, on_floor: bool) -> void:
	var fs := signf(rig.global_transform.x.x)
	var lv := Vector2(vel.x * fs, vel.y)
	# target trail: opposite to the motion, plus a steady streaming-back while flying
	var target := Vector2(-lv.x * 0.07 - (14.0 if jetting else 0.0), -lv.y * 0.045)
	target = target.limit_length(34.0)
	_lag = _lag.lerp(target, 1.0 - exp(-(7.0 if jetting else 5.0) * delta))
	var pts := PackedVector2Array()
	for i in _rest.size():
		var row: float = ROWS[ROW_OF[i]]
		var k := row * row                                           # the hem moves most, the shoulders hardly at all
		var ripple := sin(_t * (11.0 if jetting else 2.5) + row * 3.0 + float(i) * 0.6) * (3.2 if jetting else 0.8) * k
		var p := _rest[i] + _lag * k + Vector2(ripple * 0.4, ripple)
		if row > 0.0:
			p.y = _rest[i].y + _lag.y * k + ripple - absf(_lag.x) * 0.25 * k   # hem rises as it streams out
		pts.append(p)
	_cape.polygon = pts
	for p in _foot_puffs:
		(p as CPUParticles2D).emitting = jetting


func _on_landed(strength: float) -> void:
	_lag.y += 10.0 * clampf(strength, 0.2, 1.5)                      # the cape settles over the landing
