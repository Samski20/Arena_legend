class_name Appearance
extends RefCounted
## The player's customised look as plain ids (never sprites) + the code that turns ids into "rig parameters"
## for PlayerRig.apply_appearance().
##
## MODULAR: every component (head shape, eyes, hair, facial hair, headgear, top, gloves, trousers, boots, flight ...) is a
## separate id. app = the player's own choices. A cosmetic only supplies DEFAULTS for components (CosmeticCatalog
## "defaults"), and the player's per-cosmetic OVERRIDES (app["ov"][cosmetic_id][component]) win over those defaults.
## So equipping an alien and changing only its headgear leaves every other alien component alone, and any component
## can be put back to the cosmetic's default on its own. effective() / source() are the two functions that decide this.
## The same ids travel over LAN (encode / decode) and every client draws them from its own files.

const VERSION := 2
const MAX_CODE_LEN := 1600
const OPTION_KEYS := ["head", "eyes", "brows", "hair", "facial", "headgear", "top", "bottom", "boots", "gloves", "armor", "kneepads", "jetpack", "shoulder", "back"]
const COLOR_KEYS := ["skin", "hair_col", "eye_col", "gear_col", "top_col", "bottom_col", "jp_col"]
const UNDERWEAR := Color("2b3140")            # base coverage colour when nothing is worn over it
# ids that older saves used -> the new ids
# Camouflage / colourway palettes: one per outfit colour swatch -> main, pattern 1, pattern 2, pattern 3
const CAMO := [
	[Color("4a5260"), Color("707a88"), Color("2a2f39"), Color("939ba8")],     # Slate: urban grey
	[Color("4b5a32"), Color("8b7a4c"), Color("2b281b"), Color("6e8044")],     # Olive: woodland
	[Color("a8946a"), Color("cbbb8e"), Color("6c583a"), Color("85704a")],     # Sand: desert
	[Color("23262d"), Color("3b404b"), Color("0f1114"), Color("2c313a")],     # Black: night
	[Color("2a3a62"), Color("4b6cab"), Color("131b33"), Color("38508c")],     # Navy: naval
	[Color("7a3038"), Color("ab5a4e"), Color("381619"), Color("c67c62")],     # Crimson: ember
	[Color("d2dae4"), Color("a6b2c3"), Color("8896ab"), Color("eef3f8")],     # Snow: arctic
	[Color("2c5a3e"), Color("4b8b5b"), Color("15301e"), Color("6ca179")],     # Forest: jungle
]
const MIGRATE := {"hair": {"short": "crop"}, "facial": {"beard": "short"}, "headgear": {"tactical": "visor"}}


static func default_for(avatar := "male") -> Dictionary:
	var f := avatar == "female"
	return {"avatar": avatar, "skin": 1, "head": "oval" if f else "round", "eyes": "almond" if f else "round", "eye_col": 0, "brows": "soft",
		"hair": "pony" if f else "crop", "hair_col": 0, "facial": "none", "headgear": "visor", "gear_col": 0,
		"top": "tactical", "top_col": 0, "bottom": "combat", "bottom_col": 0, "boots": "boots",
		"gloves": "gloves", "armor": "plated", "kneepads": "pads", "jetpack": "standard", "jp_col": 0, "shoulder": "none", "back": "none", "ov": {}}


# ------------------------------------------------------------------ what is allowed where
## The options of one component for a given look + cosmetic: only things that fit the head / body being worn.
## Empty = this component is locked (the cosmetic has its own anatomy for it).
static func options(slot: String, app: Dictionary, cos := "") -> Dictionary:
	var def := CosmeticCatalog.get_def(cos)
	var anat := def.has("anatomy")
	var dressable: bool = bool(def.get("dressable", false))
	var head := effective(app, cos, "head")
	var avatar := str(app.get("avatar", "male"))
	match slot:
		"head":
			var o := {}
			for k in HeadCatalog.HUMAN_SHAPES:
				o[k] = {"name": HeadCatalog.HUMAN_SHAPES[k]}
			var sp := str(def.get("species_head", ""))
			if sp != "":
				o[sp] = {"name": HeadCatalog.head_name(sp), "species": true}
			return o
		"eyes":
			var o := {}
			for k in HeadCatalog.EYES:
				o[k] = {"name": HeadCatalog.EYES[k]}
			return o
		"brows": return HeadCatalog.brow_options(head)
		"hair": return HeadCatalog.hair_options(head)
		"facial":
			var o := HeadCatalog.facial_options(head)
			if not HeadCatalog.is_species(head) and not anat and avatar != "male":
				var keep := {}
				for k in o:
					if k == "none":
						keep[k] = o[k]
				return keep
			return o
		"headgear": return HeadCatalog.gear_options(head)
		"top", "bottom", "boots", "gloves":
			if anat and not dressable:
				return {}
			var t := AppearanceCatalog.table_for(slot)
			return _for_avatar(t, avatar)
		"armor", "kneepads", "shoulder":
			if anat:
				return {}
			return _for_avatar(AppearanceCatalog.table_for(slot), avatar)
		"jetpack":
			var o := {}
			for k in AppearanceCatalog.JETPACKS:
				if bool(AppearanceCatalog.JETPACKS[k].get("anatomy_only", false)) and not anat:
					continue
				o[k] = AppearanceCatalog.JETPACKS[k]
			return o
		"back":
			if anat and effective(app, cos, "jetpack") == "own":
				return {}
			return AppearanceCatalog.table_for("back")
	return {}


static func _for_avatar(t: Dictionary, avatar: String) -> Dictionary:
	var o := {}
	for k in t:
		if AppearanceCatalog.available(t[k], avatar):
			o[k] = t[k]
	return o


## The cosmetic's default for a component, or "" when it has none (the player's own choice shows).
static func cosmetic_default(cos: String, slot: String) -> String:
	if cos == "":
		return ""
	return str(CosmeticCatalog.get_def(cos).get("defaults", {}).get(slot, ""))


static func overrides(app: Dictionary, cos: String) -> Dictionary:
	if cos == "":
		return {}
	var all: Variant = app.get("ov", {})
	if all is Dictionary and (all as Dictionary).get(cos, null) is Dictionary:
		return all[cos]
	return {}


## "custom" (the player changed it on this cosmetic), "default" (the cosmetic supplies it) or "mine" (the player's own look).
static func source(app: Dictionary, cos: String, slot: String) -> String:
	if cos != "" and overrides(app, cos).has(slot):
		return "custom"
	if cosmetic_default(cos, slot) != "":
		return "default"
	return "mine"


## The id a component really has: override, else cosmetic default, else the player's own look - and if that id does not
## fit the current head / body (e.g. an afro on an insect head) the next level down is used instead, never a broken picture.
static func effective(app: Dictionary, cos: String, slot: String) -> String:
	var chain: Array = []
	if cos != "":
		var ov := overrides(app, cos)
		if ov.has(slot):
			chain.append(str(ov[slot]))
		var d := cosmetic_default(cos, slot)
		if d != "":
			chain.append(d)
	chain.append(str(app.get(slot, "")))
	for raw_id in chain:
		var id: String = HeadCatalog.canon(str(raw_id)) if slot == "head" else str(raw_id)
		if slot == "head":
			if HeadCatalog.HUMAN_SHAPES.has(id) or (cos != "" and id == str(CosmeticCatalog.get_def(cos).get("species_head", "")) and id != ""):
				return id
			continue
		if _fits(slot, id, app, cos):
			return id
	return "none" if slot in ["hair", "facial", "headgear", "brows", "armor", "kneepads", "shoulder", "back"] else str(app.get(slot, ""))


static func _fits(slot: String, id: String, app: Dictionary, cos: String) -> bool:
	if id == "":
		return false
	# do not recurse into effective() for the head: a slot is checked against the head the chain would pick
	var head := effective(app, cos, "head")
	var def := CosmeticCatalog.get_def(cos)
	var anat := def.has("anatomy")
	match slot:
		"eyes": return HeadCatalog.EYES.has(id)
		"brows": return HeadCatalog.brow_options(head).has(id)
		"hair": return HeadCatalog.hair_options(head).has(id)
		"facial":
			if not HeadCatalog.facial_options(head).has(id):
				return false
			return HeadCatalog.is_species(head) or anat or id == "none" or str(app.get("avatar", "male")) == "male"
		"headgear": return HeadCatalog.gear_options(head).has(id)
		"top", "bottom", "boots", "gloves":
			if anat and not bool(def.get("dressable", false)):
				return true
			var t := AppearanceCatalog.table_for(slot)
			return t.has(id) and AppearanceCatalog.available(t[id], str(app.get("avatar", "male")))
		"armor", "kneepads", "shoulder":
			return AppearanceCatalog.table_for(slot).has(id)
		"jetpack":
			var jp: Dictionary = AppearanceCatalog.JETPACKS
			return jp.has(id) and (anat or not bool(jp[id].get("anatomy_only", false)))
		"back": return AppearanceCatalog.table_for("back").has(id)
	return false


## Colour choices that a cosmetic may default (so far: eye colour) work like components.
static func effective_color(app: Dictionary, cos: String, key: String) -> int:
	if cos != "":
		var ov := overrides(app, cos)
		if ov.has(key):
			return int(ov[key])
		var dv: Variant = CosmeticCatalog.get_def(cos).get("defaults", {}).get(key, null)
		if dv != null:
			return int(dv)
	return int(app.get(key, 0))


# ------------------------------------------------------------------ sanitising
# Fixes anything missing / unknown / unavailable for the avatar. Never throws, never returns partial data.
static func sanitize(raw: Variant) -> Dictionary:
	var src: Dictionary = raw if raw is Dictionary else {}
	var avatar := str(src.get("avatar", "male"))
	if not AppearanceCatalog.AVATARS.has(avatar):
		avatar = "male"
	var out := default_for(avatar)
	for key in OPTION_KEYS:
		var table := AppearanceCatalog.table_for(key)
		var v := str(src.get(key, out[key]))
		if MIGRATE.has(key) and (MIGRATE[key] as Dictionary).has(v):
			v = MIGRATE[key][v]
		if table.has(v) and AppearanceCatalog.available(table[v], avatar) and not bool(table[v].get("anatomy_only", false)):
			out[key] = v
	for slot in AppearanceCatalog.COLOR_SLOTS:
		var n := AppearanceCatalog.palette_size(str(slot[2]))
		var i := int(src.get(slot[0], out[slot[0]]))
		out[slot[0]] = i if i >= 0 and i < n else 0
	out["ov"] = _sanitize_ov(src.get("ov", {}), out)
	return out


static func _sanitize_ov(raw: Variant, app: Dictionary) -> Dictionary:
	var out := {}
	if not (raw is Dictionary):
		return out
	for cos in raw:
		var cid := str(cos)
		if not CosmeticCatalog.DEFS.has(cid) or not (raw[cos] is Dictionary):
			continue
		var clean := {}
		var tmp := app.duplicate()
		tmp["ov"] = {cid: clean}
		for slot in OPTION_KEYS:                          # head first: later slots are checked against it
			if (raw[cos] as Dictionary).has(slot):
				var id := str(raw[cos][slot])
				if slot == "head":
					id = HeadCatalog.canon(id)
					var sp := str(CosmeticCatalog.get_def(cid).get("species_head", ""))
					if HeadCatalog.HUMAN_SHAPES.has(id) or (sp != "" and id == sp):
						clean[slot] = id
				elif options(slot, tmp, cid).has(id):
					clean[slot] = id
		var dv: Variant = (raw[cos] as Dictionary).get("eye_col", null)
		if dv != null and int(dv) >= 0 and int(dv) < HeadCatalog.EYE_COLORS.size():
			clean["eye_col"] = int(dv)
		if not clean.is_empty():
			out[cid] = clean
	return out


# Keys whose saved choice does not exist for `avatar` (so the menu can say "unavailable, default used").
static func unavailable_for(app: Dictionary, avatar: String) -> Array:
	var bad: Array = []
	for key in OPTION_KEYS:
		var table := AppearanceCatalog.table_for(key)
		var v := str(app.get(key, ""))
		if table.has(v) and not AppearanceCatalog.available(table[v], avatar):
			bad.append(key)
	return bad


# Switching avatar keeps every compatible choice; the others fall back to that avatar's default.
static func with_avatar(app: Dictionary, avatar: String) -> Dictionary:
	var n := app.duplicate(true)
	n["avatar"] = avatar
	return sanitize(n)


# ------------------------------------------------------------------ ids -> rig parameters
static func resolve(app_in: Dictionary, cosmetic_id := "", variant := 0) -> Dictionary:
	var app := sanitize(app_in)
	var cos := cosmetic_id if CosmeticCatalog.DEFS.has(cosmetic_id) else ""
	var def := CosmeticCatalog.get_def(cos)
	var anat := def.has("anatomy")
	var female: bool = app["avatar"] == "female"
	var ov := overrides(app, cos)

	# every component, decided by override > cosmetic default > own look
	var c := {}
	for k in OPTION_KEYS:
		c[k] = effective(app, cos, k)
	var skin: Color = AppearanceCatalog.SKIN_TONES[app["skin"]]
	var oc_t: Array = AppearanceCatalog.OUTFIT_COLORS[app["top_col"]]
	var oc_b: Array = AppearanceCatalog.OUTFIT_COLORS[app["bottom_col"]]
	var oc_g: Array = AppearanceCatalog.OUTFIT_COLORS[app["gear_col"]]
	var top: Dictionary = AppearanceCatalog.TOPS.get(c["top"], AppearanceCatalog.TOPS["none"])
	var bot: Dictionary = AppearanceCatalog.BOTTOMS.get(c["bottom"], AppearanceCatalog.BOTTOMS["none"])
	var boots: Dictionary = AppearanceCatalog.BOOTS.get(c["boots"], AppearanceCatalog.BOOTS["boots"])
	var gl: Dictionary = AppearanceCatalog.GLOVES.get(c["gloves"], AppearanceCatalog.GLOVES["none"])
	var jpo: Dictionary = AppearanceCatalog.JETPACKS.get(c["jetpack"], AppearanceCatalog.JETPACKS["standard"])
	var fin: Array = AppearanceCatalog.JETPACK_FINISHES[app["jp_col"]]
	var armor: Dictionary = AppearanceCatalog.ARMOR.get(c["armor"], AppearanceCatalog.ARMOR["none"])
	var sleeves := str(top.get("sleeves", "long"))
	var legs := str(bot.get("legs", "long"))
	var eye_i := effective_color(app, cos, "eye_col")
	var head_id := str(c["head"])
	var species := HeadCatalog.is_species(head_id)

	var colors := {
		"skin": skin, "hair": AppearanceCatalog.HAIR_COLORS[app["hair_col"]], "eye": HeadCatalog.EYE_COLORS[eye_i][1],
		"uniform": skin if top.get("bare", false) else oc_t[1], "vest": oc_t[2], "accent": oc_g[1], "helmet": oc_g[2],
		"sleeve_up": oc_t[1] if sleeves == "long" or sleeves == "short" else skin,
		"sleeve_fore": oc_t[1] if sleeves == "long" else skin,
		"pants": oc_b[1] if legs != "none" else skin,
		"shin_pants": oc_b[1] if legs == "long" else skin,
		"knee": oc_b[2],
		"under": oc_b[1] if legs != "none" else UNDERWEAR,
		"under_top": UNDERWEAR,
		"boots": skin if boots.get("skin", false) else boots.get("color", Color("3c4350")),
		"glove": skin if gl.get("skin", false) else gl.get("color", Color("262c38")),
		"jetpack": fin[1], "glow": fin[2], "cape": Color("1a2030"),
		"cosm_skin": Color.WHITE, "cosm_over": fin[2],
	}
	var show := {
		"cosm_head": false, "cosm_eyes": false, "cosm_over": false, "chest": false, "cape": c["back"] == "cape",
		"bare": top.get("bare", false), "top_band": false,
		"vest": armor.get("vest", false), "pads": armor.get("pads", false) or c["shoulder"] == "pads",
		"knee": c["kneepads"] == "pads", "forearm_trim": gl.get("trim", false),
		"glow_lines": top.get("glow", false) or bot.get("glow", false),
	}
	var cosm := {"head": "", "eyes": "", "over": "", "chest": ""}
	var jp := {"tex": jpo["tex"], "scale": jpo["scale"]}
	var body := {"torso_x": 0.92 if female else 1.0, "hip_x": 1.06 if female else 1.0, "head": 0.97 if female else 1.0}

	# a partial armour set on the human body: each COMPONENT patch is skipped when the player changed any slot of it
	var head_custom := ov.has("headgear")
	if not def.is_empty() and not anat:
		var parts: Dictionary = def.get("parts", {})
		for comp in CosmeticCatalog.COMPONENTS:
			if not parts.has(comp):
				continue
			var slots: Array = CosmeticCatalog.COMPONENT_SLOTS.get(comp, [])
			var touched := false
			for s in slots:
				if ov.has(s):
					touched = true
			if touched:
				continue
			var p: Dictionary = parts[comp]
			for k in p.get("colors", {}):
				colors[k] = p["colors"][k]
			for k in p.get("show", {}):
				show[k] = p["show"][k]
			for k in p.get("cosm", {}):
				cosm[k] = p["cosm"][k]
			for k in p.get("jp", {}):
				jp[k] = p["jp"][k]
		if not head_custom and def.has("head_colors"):
			for k in def["head_colors"]:
				colors[k] = def["head_colors"][k]
		if def.get("parts", {}).has("torso") and not ov.has("top") and not ov.has("armor"):
			show["glow_lines"] = show["glow_lines"] or def["theme"] == "hunter"

	var garments := {}
	if not anat:
		garments = _garments(c, app, oc_t, oc_b, oc_g, colors, def, ov)
		# the bare body under the clothes is just skin; every garment piece carries the clothing itself
		for k in ["uniform", "sleeve_up", "sleeve_fore", "pants", "shin_pants"]:
			colors[k] = skin
		colors["under"] = UNDERWEAR
		show["vest"] = false
		show["glow_lines"] = false
		show["oldbody"] = false
		show["under"] = false
		colors["jnt_leg"] = oc_b[1] if str(bot.get("legs", "long")) != "none" else skin
		colors["jnt_arm"] = oc_t[1] if sleeves != "none" and not top.get("bare", false) else skin
	var anatomy := {}
	if anat:
		# A full-anatomy cosmetic is NOT drawn over the human body: the pictures of the body slots are replaced
		# (PlayerRig.apply_anatomy) and its own flight presentation takes over - unless the player picked a pack.
		var an: Dictionary = def["anatomy"]
		for k in ["vest", "pads", "knee", "forearm_trim", "bare", "top_band", "chest", "glow_lines", "decor", "cosm_eyes", "cosm_over", "under", "oldbody"]:
			show[k] = false
		show["cosm_head"] = false
		colors["cosm_skin"] = Color.WHITE
		var own_flight: bool = str(c["jetpack"]) == "own"
		jp = {"tex": "none", "scale": 1.0} if own_flight else {"tex": jpo["tex"], "scale": jpo["scale"]}
		show["cape"] = (not own_flight) and c["back"] == "cape"
		body = {"torso_x": 1.0, "hip_x": 1.0, "head": 1.0}
		var vars: Array = def.get("variants", [])
		var hue := 0.0
		if variant > 0 and variant < vars.size():
			hue = float(vars[variant].get("hue", 0.0))
		anatomy = {"folder": an["folder"], "slots": an["slots"], "fx": an.get("fx", "") if own_flight else "", "lean": an.get("lean", 1.0) if own_flight else 1.0,
			"hue": hue, "fx_cfg": an.get("fx_cfg", {}), "overlays": bool(def.get("dressable", false)), "neck_patch": bool(an.get("neck_patch", true))}
		# a creature can wear clothes cut to ITS limbs (overlay pictures); a costume is already clothing
		if bool(def.get("dressable", false)):
			show["ov_torso"] = not bool(top.get("bare", false))
			show["ov_waist"] = legs != "none"
			show["ov_thigh"] = legs != "none"
			show["ov_shin"] = legs == "long"
			show["ov_foot"] = not bool(boots.get("skin", false))
			show["ov_upper_arm"] = sleeves != "none"
			show["ov_forearm"] = sleeves == "long"
			show["ov_hand"] = not bool(gl.get("skin", false))
		# the head of a hero keeps the player's skin; the colour of cosmetic headgear follows the variant's hue
		if not head_custom and def.has("head_colors"):
			for k in def["head_colors"]:
				colors[k] = _hue_shift(def["head_colors"][k], float(anatomy["hue"]))
	show["chest"] = show["chest"] if not anatomy.is_empty() else str(cosm["chest"]) != ""
	show["bare_m"] = bool(show["bare"]) and not female
	show["bare_f"] = bool(show["bare"]) and female
	show["top_band"] = female and bool(show["bare"])             # a bare female torso always keeps its base top

	var head := {"shape": head_id, "eyes": c["eyes"], "eye_col": eye_i, "brows": c["brows"], "hair": c["hair"], "facial": c["facial"],
		"gear": c["headgear"], "species": species, "species_glow": HeadCatalog.SPECIES.get(head_id, {}).get("glow", Color.WHITE)}
	return {"colors": colors, "show": show, "cosm": cosm, "jp": jp, "body": body, "female": female, "anatomy": anatomy, "head": head, "garments": garments}


## Which clothing picture set each kind of clothing uses, and its colours. `def`/`ov`: a partial-set cosmetic may dress the
## body in its own pieces ("garm" inside a part) unless the player changed that component.
static func _garments(c: Dictionary, app: Dictionary, oc_t: Array, oc_b: Array, oc_g: Array, colors: Dictionary, def: Dictionary, ov: Dictionary) -> Dictionary:
	var g := {}
	var fin: Array = AppearanceCatalog.JETPACK_FINISHES[app["jp_col"]]
	var camo_t: Array = CAMO[app["top_col"]]
	var camo_b: Array = CAMO[app["bottom_col"]]
	var top := str(c["top"])
	var bot := str(c["bottom"])
	var boots := str(c["boots"])
	var gl := str(c["gloves"])
	var arm := str(c["armor"])
	var plain_t := [oc_t[1], oc_t[2], (oc_t[1] as Color).darkened(0.35), (oc_t[2] as Color).lightened(0.2)]
	var plain_b := [oc_b[1], oc_b[2], (oc_b[1] as Color).darkened(0.35), (oc_b[2] as Color).lightened(0.2)]
	var under := [UNDERWEAR, UNDERWEAR.lightened(0.15), UNDERWEAR.darkened(0.3), UNDERWEAR]
	if top != "none":
		g["top"] = {"id": top, "pal": camo_t if top == "uniform" else plain_t, "glow": fin[2]}
	elif str(app.get("avatar", "male")) == "female":
		g["top"] = {"id": "bra", "pal": under, "glow": fin[2]}
	if bot != "none":
		g["bottom"] = {"id": bot, "pal": camo_b if bot == "military" else plain_b, "glow": fin[2]}
	else:
		g["bottom"] = {"id": "briefs", "pal": under, "glow": fin[2]}
	if boots != "barefoot":
		var bc: Color = AppearanceCatalog.BOOTS.get(boots, {}).get("color", Color("3c4350"))
		g["boots"] = {"id": boots, "pal": [bc, bc.lightened(0.25), bc.darkened(0.35), oc_g[1]], "glow": fin[2]}
	if gl != "none":
		var gc: Color = AppearanceCatalog.GLOVES.get(gl, {}).get("color", Color("262c38"))
		g["gloves"] = {"id": gl, "pal": [gc, gc.lightened(0.25), gc.darkened(0.35), oc_g[1]], "glow": fin[2]}
	if arm != "none":
		g["armor"] = {"id": arm, "pal": [oc_t[2], (oc_t[2] as Color).darkened(0.3), (oc_t[2] as Color).lightened(0.25), oc_t[1]], "glow": fin[2]}
	# a partial-set cosmetic dresses the body in its own pieces
	if not def.is_empty():
		var parts: Dictionary = def.get("parts", {})
		for comp in CosmeticCatalog.COMPONENTS:
			if not parts.has(comp):
				continue
			var touched := false
			for sl in CosmeticCatalog.COMPONENT_SLOTS.get(comp, []):
				touched = touched or ov.has(sl)
			if touched:
				continue
			var gp: Dictionary = parts[comp].get("garm", {})
			for kind in gp:
				if gp[kind] is Dictionary and (gp[kind] as Dictionary).is_empty():
					g.erase(kind)
				else:
					g[kind] = gp[kind]
	return g


static func _hue_shift(c: Color, hue: float) -> Color:
	if absf(hue) < 0.001:
		return c
	return Color.from_hsv(fposmod(c.h + hue, 1.0), c.s, c.v, c.a)


# ------------------------------------------------------------------ network / save code
## Only the equipped cosmetic's overrides travel (the rest is the player's private collection).
static func encode(app: Dictionary, cosmetic_id := "", variant := 0) -> String:
	var a := sanitize(app)
	var keep := {}
	if cosmetic_id != "" and (a["ov"] as Dictionary).has(cosmetic_id):
		keep[cosmetic_id] = a["ov"][cosmetic_id]
	a["ov"] = keep
	return JSON.stringify({"a": a, "c": cosmetic_id, "v": variant, "f": VERSION})


# Returns {"app": sanitized dict, "cosmetic": id or ""}. Garbage in -> the default look out.
static func decode(code: String) -> Dictionary:
	var out := {"app": default_for("male"), "cosmetic": "", "variant": 0}
	if code == "" or code.length() > MAX_CODE_LEN:
		return out
	var parsed: Variant = JSON.parse_string(code)
	if parsed is Dictionary:
		out["app"] = sanitize(parsed.get("a", {}))
		var c := str(parsed.get("c", ""))
		out["cosmetic"] = c if CosmeticCatalog.DEFS.has(c) else ""
		var nv: int = (CosmeticCatalog.get_def(c).get("variants", []) as Array).size()
		var v := int(parsed.get("v", 0))
		out["variant"] = v if v >= 0 and v < maxi(nv, 1) else 0
	return out
