class_name HeadCatalog
extends RefCounted
## Everything about HEADS: shapes, eyes, brows, hair, facial hair, headgear and which of them fit which head.
## The pictures are generated per head shape (tools/gen_head_parts.py), so a hairstyle or a beard is drawn for the head
## it sits on instead of being one picture stretched over all of them. File names:
##   res://art/head/<shape>/skin.png  hair_<id>.png  hairb_<id>.png (back layer)  hairg_<id>.png (glow)
##                          facial_<id>.png  gear_<id>_<base|trim|lens|shine|back>.png
##   res://art/head/eyes/<style>_<near|far>_<base|iris|top>.png      res://art/head/brows/<style>_<near|far>.png

const DIR := "res://art/head/"
const PIX_PER_UNIT := 2.0              # picture pixels per design unit (design box 108 x 100, head pivot at design (65, 65))
const PIVOT_PX := Vector2(154, 194)    # head origin inside every head picture (pixels)
const UNITS_PER_GAME_PX := 2.5         # design units per in-game pixel (HEAD_ART)

const HUMAN_SHAPES := {"round": "Round", "oval": "Oval", "square": "Square"}
# the earlier ten-shape set was cut to these three; saved looks that used a removed shape map to the closest survivor
const LEGACY_SHAPES := {"angular": "square", "long": "oval", "broad": "square", "narrow": "oval", "heavyjaw": "square",
	"pointed": "oval", "cheekbone": "oval"}
# non-human heads belong to a species cosmetic (they are offered only while that cosmetic is equipped)
const SPECIES := {
	"lumen": {"name": "Lumen Skull", "eyes": "alien", "skin": Color(0.667, 0.62, 0.918), "glow": Color(0.38, 0.94, 1.0),
		"hair": {"crest_frill": "Bio Frill", "crest_nodes": "Glow Nodes"}, "facial": {},
		"gear": ["helmet", "visor", "crown", "headset", "hunter"], "brows": false},
	"insect": {"name": "Hive Skull", "eyes": "compound", "skin": Color(0.21, 0.52, 0.41), "glow": Color(1.0, 0.78, 0.31),
		"hair": {"antenna_straight": "Straight Antennae", "antenna_curled": "Curled Antennae", "antenna_feather": "Feathered Antennae"},
		"facial": {"mandible_short": "Short Mandibles", "mandible_long": "Long Mandibles"},
		"gear": ["crown", "headset"], "brows": false},
}

const EYES := {
	"round": "Round", "narrow": "Narrow", "almond": "Almond", "angular": "Angular", "heavy": "Heavy-lidded", "large": "Large",
	"small": "Small", "sleepy": "Sleepy", "cat": "Cat", "visor": "Futuristic", "glow": "Glowing", "compound": "Compound",
	"alien": "Alien",
}
# eyes that do not make sense on a human face are still allowed (the player chose them on purpose) but listed last
const EYE_COLORS := [["Blue", Color("5aa8e6")], ["Green", Color("58b26a")], ["Brown", Color("8a5a2b")], ["Hazel", Color("a07a30")],
	["Grey", Color("9aa4b4")], ["Amber", Color("ffb43a")], ["Violet", Color("a066e0")], ["Red", Color("ff4a4a")], ["Cyan", Color("40e8ff")]]

const BROWS := {"none": "None", "soft": "Soft", "arched": "Arched", "straight": "Straight", "thick": "Thick", "thin": "Thin", "angry": "Fierce"}

# tags: tall = sticks up (a helmet hides it), long = has a layer that hangs behind the head
const HAIR := {
	"none": {"name": "Bald"}, "buzz": {"name": "Buzz Cut"}, "crop": {"name": "Short Crop"}, "sidepart": {"name": "Side Part"},
	"fade": {"name": "Fade Quiff"}, "undercut": {"name": "Slick Undercut"}, "spiky": {"name": "Spiky"}, "mohawk": {"name": "Mohawk"},
	"afro": {"name": "Afro"}, "curly": {"name": "Curly"}, "wavy": {"name": "Wavy Bob", "back": true}, "long": {"name": "Long Flowing", "back": true},
	"pony": {"name": "Ponytail", "back": true}, "highpony": {"name": "High Ponytail", "back": true}, "bun": {"name": "Top Bun"},
	"braids": {"name": "Braids", "back": true}, "dreads": {"name": "Dreadlocks", "back": true}, "cyber": {"name": "Cyber Crest", "glow": true},
	"fantasy": {"name": "Fantasy Swept", "back": true},
}
const FACIAL := {
	"none": "Clean Shaven", "stubble": "Stubble", "short": "Short Beard", "full": "Full Beard", "goatee": "Goatee", "mustache": "Mustache",
	"handlebar": "Handlebar", "stache_beard": "Mustache + Beard", "chinstrap": "Chin Strap", "mutton": "Mutton Chops", "long": "Long Beard",
}
# hair: how it behaves under the item: keep (stays), front (front hair is hidden, hair hanging behind still shows), all (hidden)
# hides: other slots the item covers.  layers: which pictures exist.  tint: which colour group tints each layer.
const GEAR := {
	"none": {"name": "None", "hair": "keep"},
	"helmet": {"name": "Combat Helmet", "hair": "front", "layers": ["base", "trim", "shine", "det"]},
	"visor": {"name": "Visor Helmet", "hair": "front", "layers": ["base", "trim", "lens", "shine", "det"]},
	"beanie": {"name": "Beanie", "hair": "front", "layers": ["base", "trim", "shine", "det"]},
	"cap": {"name": "Cap", "hair": "front", "layers": ["base", "trim", "shine", "det"]},
	"beret": {"name": "Beret", "hair": "front", "layers": ["base", "trim", "shine", "det"]},
	"boonie": {"name": "Bush Hat", "hair": "front", "layers": ["base", "trim", "shine", "det"]},
	"headband": {"name": "Headband", "hair": "keep", "layers": ["base", "trim", "back", "shine", "det"]},
	"goggles": {"name": "Goggles", "hair": "keep", "layers": ["base", "trim", "lens", "shine", "det"]},
	"shades": {"name": "Sunglasses", "hair": "keep", "hides": ["eyes"], "layers": ["base", "trim", "lens", "shine", "det"], "dark_lens": true},
	"mask": {"name": "Respirator", "hair": "keep", "hides": ["facial"], "layers": ["base", "trim", "shine", "det"]},
	"hood": {"name": "Hood", "hair": "all", "layers": ["base", "trim", "back", "shine", "det"]},
	"crown": {"name": "Circlet", "hair": "keep", "layers": ["base", "trim", "lens", "shine", "det"], "gold": true},
	"headset": {"name": "Comms Headset", "hair": "keep", "layers": ["base", "trim", "lens", "shine", "det"]},
	"cowl": {"name": "Hero Cowl", "hair": "front", "layers": ["base", "trim", "back", "shine", "det"]},
	"hunter": {"name": "Stalker Helm", "hair": "all", "hides": ["facial"], "layers": ["base", "trim", "lens", "shine", "det"], "glow_lens": true},
}
const GEAR_LAYERS := ["back", "base", "trim", "lens", "shine", "det"]
const HUMAN_ONLY_GEAR := ["beanie", "cap", "beret", "boonie", "headband", "goggles", "shades", "mask", "hood", "cowl"]

static var _anchors := {}


static func is_species(head: String) -> bool:
	return SPECIES.has(head)


static func shape_dir(head: String) -> String:
	return "%s%s/" % [DIR, head if (HUMAN_SHAPES.has(head) or SPECIES.has(head)) else "round"]


static func head_name(head: String) -> String:
	return str(HUMAN_SHAPES.get(head, SPECIES.get(head, {}).get("name", head)))


# ---- what fits which head (the UI lists exactly this, so an incompatible pick cannot be made)
static func hair_options(head: String) -> Dictionary:
	if SPECIES.has(head):
		var o := {"none": {"name": "None"}}
		for k in SPECIES[head]["hair"]:
			o[k] = {"name": SPECIES[head]["hair"][k], "glow": k.begins_with("crest")}
		return o
	return HAIR


static func facial_options(head: String) -> Dictionary:
	var o := {}
	if SPECIES.has(head):
		o["none"] = {"name": "None"}
		for k in SPECIES[head]["facial"]:
			o[k] = {"name": SPECIES[head]["facial"][k]}
		return o
	for k in FACIAL:
		o[k] = {"name": FACIAL[k]}
	return o


static func gear_options(head: String) -> Dictionary:
	var o := {}
	for k in GEAR:
		if SPECIES.has(head) and k != "none" and not (SPECIES[head]["gear"] as Array).has(k):
			continue
		o[k] = GEAR[k]
	return o


static func brow_options(head: String) -> Dictionary:
	var o := {}
	for k in BROWS:
		if SPECIES.has(head) and k != "none":
			continue
		o[k] = {"name": BROWS[k]}
	return o


## Maps a removed (legacy) head shape id to one of the three current shapes; every other id is returned unchanged.
static func canon(head: String) -> String:
	return str(LEGACY_SHAPES.get(head, head))


static func anchor(head: String, key: String) -> Vector2:
	var d: Dictionary = HeadAnchors.DATA.get(head, HeadAnchors.DATA["round"])
	return d.get(key, Vector2(65, 65))


# design-unit point (108x100 head box) -> position relative to the head node, in game pixels
static func to_game(p: Vector2) -> Vector2:
	return (p - Vector2(65, 65)) / UNITS_PER_GAME_PX
