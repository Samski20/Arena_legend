class_name AppearanceCatalog
extends RefCounted
## Every choice in Character Customization. An option is just data: which PlayerRig parts it shows, which
## colour groups it uses. Add an entry here and it appears in the menu by itself.
## Purely cosmetic: nothing here touches health, speed, hitboxes, weapons or the jetpack's performance.
##
## "avatars" on an option = which base bodies it exists for. Switching avatar keeps every choice that is
## still available and falls back to that category's default for the rest (the menu says so).

const AVATARS := ["male", "female"]
const AVATAR_NAMES := {"male": "Male", "female": "Female"}

const SKIN_TONES := [Color("f6d7bd"), Color("e8bc9c"), Color("d29c76"), Color("b57a55"), Color("8a583a"), Color("5e3a27")]
const HAIR_COLORS := [Color("3a2a22"), Color("14110f"), Color("8a5a2b"), Color("d8b45a"), Color("a63a2a"), Color("c9ccd4"),
	Color("2fa8c8"), Color("d6559a"), Color("5ac85a"), Color("f2f2f2")]
const HAIR_COLOR_NAMES := ["Brown", "Black", "Auburn", "Blonde", "Red", "Silver", "Teal", "Pink", "Green", "White"]
const SKIN_NAMES := ["Fair", "Light", "Tan", "Bronze", "Deep", "Dark"]

# Outfit colours: [name, main, secondary (vest / trim)]
const OUTFIT_COLORS := [
	["Slate", Color("2f3a4c"), Color("5d6c82")], ["Olive", Color("4a5a36"), Color("7a8a56")],
	["Sand", Color("9a8860"), Color("c4b283")], ["Black", Color("1c1f26"), Color("3a404c")],
	["Navy", Color("1d2c52"), Color("3c5a9a")], ["Crimson", Color("6e2630"), Color("a8454c")],
	["Snow", Color("b8c4d0"), Color("e4ecf4")], ["Forest", Color("1f4a34"), Color("3f8a5e")],
]
const JETPACK_FINISHES := [
	["Steel", Color("5d6c82"), Color("4fd8ff")], ["Olive", Color("5a6a3c"), Color("9aff7a")],
	["Gunmetal", Color("2c323c"), Color("ff8a4d")], ["Gold", Color("c9a23a"), Color("fff0a0")],
	["Crimson", Color("a8454c"), Color("ff6a5a")], ["Violet", Color("6a4aa0"), Color("d0a8ff")],
]

# slot -> list of options. Keys inside an option:
#   name, avatars, and the rig settings listed under each category below.
# HEAD pieces come from HeadCatalog (pictures are generated per head shape so they fit it).
const HEAD := HeadCatalog.HUMAN_SHAPES                        # id -> name (a table of plain names; the menu wraps it)
const EYES := HeadCatalog.EYES
const BROWS := HeadCatalog.BROWS
const HEADGEAR := HeadCatalog.GEAR
const HAIR := HeadCatalog.HAIR
const FACIAL := {
	"none": {"name": "Clean Shaven"}, "stubble": {"name": "Stubble", "avatars": ["male"]}, "short": {"name": "Short Beard", "avatars": ["male"]},
	"full": {"name": "Full Beard", "avatars": ["male"]}, "goatee": {"name": "Goatee", "avatars": ["male"]}, "mustache": {"name": "Mustache", "avatars": ["male"]},
	"handlebar": {"name": "Handlebar", "avatars": ["male"]}, "stache_beard": {"name": "Mustache + Beard", "avatars": ["male"]},
	"chinstrap": {"name": "Chin Strap", "avatars": ["male"]}, "mutton": {"name": "Mutton Chops", "avatars": ["male"]}, "long": {"name": "Long Beard", "avatars": ["male"]},
}
# sleeves: "long" | "short" | "none" (bare arms). vest/pads/glow = extra layers.
const TOPS := {
	"none": {"name": "Shirtless", "bare": true, "sleeves": "none"},
	"tshirt": {"name": "T-Shirt", "sleeves": "short"},
	"tank": {"name": "Tank Top", "sleeves": "none"},
	"tactical": {"name": "Tactical Shirt", "sleeves": "long"},
	"uniform": {"name": "Military Uniform", "sleeves": "long"},
	"jacket": {"name": "Jacket", "sleeves": "long", "trim": true},
	"suit": {"name": "Combat Suit", "sleeves": "long", "glow": true},
}
# Optional protective gear: never attached by default to a clothing choice.
const ARMOR := {
	"none": {"name": "No Armour"}, "vest": {"name": "Military Vest", "vest": true},
	"plated": {"name": "Plated Armour", "vest": true, "pads": true},
}
const KNEEPADS := {"none": {"name": "No Knee Pads"}, "pads": {"name": "Knee Pads"}}
# legs: "long" = full trousers, "short" = shorts (bare shins), "none" = underwear only.
const BOTTOMS := {
	"none": {"name": "Underwear Only", "legs": "none"},
	"pants": {"name": "Trousers", "legs": "long"},
	"combat": {"name": "Combat Trousers", "legs": "long"},
	"military": {"name": "Military Trousers", "legs": "long"},
	"tactical": {"name": "Tactical Trousers", "legs": "long"},
	"armored": {"name": "Armoured Trousers", "legs": "long"},
	"shorts": {"name": "Shorts", "legs": "short"},
}
const BOOTS := {
	"boots": {"name": "Combat Boots", "color": Color("3c4350")},
	"sneakers": {"name": "Sneakers", "color": Color("d8dde6")},
	"hightops": {"name": "High-Tops", "color": Color("b8402f")},
	"runners": {"name": "Runners", "color": Color("3a78c4")},
	"plated": {"name": "Plated Boots", "color": Color("2c3340")},
	"barefoot": {"name": "Barefoot", "skin": true},
}
const GLOVES := {
	"none": {"name": "Bare Hands", "skin": true},
	"gloves": {"name": "Gloves", "color": Color("262c38")},
	"armored": {"name": "Armoured Forearms", "color": Color("1d222c"), "trim": true},
}
# Jetpacks are looks only: tex = which picture, scale = drawn size (never the hitbox, thrust or fuel).
const JETPACKS := {
	"own": {"name": "Its own flight anatomy", "tex": "none", "scale": 1.0, "finish": 0, "anatomy_only": true},
	"standard": {"name": "Standard Twin Tank", "tex": "standard", "scale": 1.0, "finish": 0},
	"military": {"name": "Military Field Pack", "tex": "military", "scale": 1.0, "finish": 1},
	"heavy": {"name": "Heavy Turbine", "tex": "heavy", "scale": 1.0, "finish": 2},
	"future": {"name": "Futuristic Drive", "tex": "future", "scale": 1.0, "finish": 0},
	"experimental": {"name": "Experimental Gyro", "tex": "experimental", "scale": 1.0, "finish": 5},
	"gilded": {"name": "Gilded Regalia", "tex": "gilded", "scale": 1.0, "finish": 3},
	"compact": {"name": "Compact Boosters", "tex": "compact", "scale": 1.0, "finish": 0},
	"alien": {"name": "Alien Bio-Drive", "tex": "alien", "scale": 1.0, "finish": 5},
	"wings": {"name": "Mechanical Wings", "tex": "wings", "scale": 1.0, "finish": 0},
}
const SHOULDER := {"none": {"name": "None"}, "pads": {"name": "Shoulder Armour"}}
const BACK := {"none": {"name": "None"}, "cape": {"name": "Cape"}}

# menu category -> option slots shown on it: [appearance key, title, table]. "head" tables are wrapped by Appearance.options().
const TABS := [
	["head", "HEAD", [["head", "Head shape", {}]]],
	["eyes", "EYES", [["eyes", "Eye shape", {}], ["brows", "Eyebrows", {}]]],
	["hair", "HAIR", [["hair", "Hairstyle", {}]]],
	["facial", "FACIAL HAIR", [["facial", "Facial hair", {}]]],
	["headgear", "HEADGEAR", [["headgear", "Helmets, hats, masks and eyewear", {}]]],
	["upper", "UPPER BODY", [["top", "Shirts and jackets", TOPS], ["armor", "Body armour", ARMOR], ["shoulder", "Shoulder armour", SHOULDER]]],
	["arms", "ARMS", [["gloves", "Gloves and forearms", GLOVES]]],
	["legs", "TROUSERS", [["bottom", "Trousers and shorts", BOTTOMS], ["kneepads", "Knee pads", KNEEPADS]]],
	["feet", "FOOTWEAR", [["boots", "Boots and shoes", BOOTS]]],
	["back", "BACK", [["jetpack", "Jetpack / flight", JETPACKS], ["back", "Back accessory", BACK]]],
]

# colour pickers: key -> [title, palette kind]
const COLOR_SLOTS := [["skin", "Skin tone", "skin"], ["hair_col", "Hair and facial hair colour", "hair"], ["eye_col", "Eye colour", "eye"],
	["gear_col", "Headgear colour", "outfit"], ["top_col", "Clothing and armour colour", "outfit"],
	["bottom_col", "Trouser colour", "outfit"], ["jp_col", "Jetpack finish", "finish"]]


static func table_for(key: String) -> Dictionary:
	match key:
		"head":
			var o := {}
			for k in HEAD:
				o[k] = {"name": HEAD[k]}
			return o
		"eyes":
			var o := {}
			for k in EYES:
				o[k] = {"name": EYES[k]}
			return o
		"brows":
			var o := {}
			for k in BROWS:
				o[k] = {"name": BROWS[k]}
			return o
		"hair": return HAIR
		"facial": return FACIAL
		"headgear": return HEADGEAR
	for c in TABS:
		for s in c[2]:
			if s[0] == key:
				return s[2]
	return {}


static func available(option: Dictionary, avatar: String) -> bool:
	return not option.has("avatars") or (option["avatars"] as Array).has(avatar)


static func palette_size(kind: String) -> int:
	match kind:
		"skin": return SKIN_TONES.size()
		"hair": return HAIR_COLORS.size()
		"outfit": return OUTFIT_COLORS.size()
		"finish": return JETPACK_FINISHES.size()
		"eye": return HeadCatalog.EYE_COLORS.size()
	return 1


static func palette_name(kind: String, i: int) -> String:
	match kind:
		"skin": return SKIN_NAMES[i]
		"hair": return HAIR_COLOR_NAMES[i]
		"outfit": return OUTFIT_COLORS[i][0]
		"finish": return JETPACK_FINISHES[i][0]
		"eye": return HeadCatalog.EYE_COLORS[i][0]
	return ""


static func palette_color(kind: String, i: int) -> Color:
	match kind:
		"skin": return SKIN_TONES[i]
		"hair": return HAIR_COLORS[i]
		"outfit": return OUTFIT_COLORS[i][1]
		"finish": return JETPACK_FINISHES[i][1]
		"eye": return HeadCatalog.EYE_COLORS[i][1]
	return Color.WHITE
