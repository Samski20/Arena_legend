class_name CosmeticCatalog
extends RefCounted
## Full-character cosmetics (a different species / suit / hero). Kept apart from Character Customization.
## Each cosmetic lists the COMPONENTS it replaces ("parts"); everything it does not list stays the player's own
## customised look. Components: head, torso, arms, legs, jetpack, back.
## A part patch may contain:  colors {group: Color}, show {flag: bool}, cosm {head, eyes, over, chest} (picture names),
##                            jp {tex, scale}, body {head: scale}.
## Rarity is for the collection only. No cosmetic changes any gameplay value.
## Unlocking: `owned_default` for now; AppearanceStore.unlock(id) is the hook for rewards / achievements later.

const RARITIES := ["common", "rare", "epic", "legendary", "mythic"]
const RARITY_NAMES := {"common": "COMMON", "rare": "RARE", "epic": "EPIC", "legendary": "LEGENDARY", "mythic": "MYTHIC"}
const RARITY_COLORS := {"common": Color("a9b3bb"), "rare": Color("4fa8ff"), "epic": Color("b45cff"), "legendary": Color("ffb43a"), "mythic": Color("ff4f6e")}
const THEMES := ["alien", "hunter", "hero"]
const THEME_NAMES := {"alien": "Alien", "hunter": "Hunter", "hero": "Hero"}
const COMPONENTS := ["head", "torso", "arms", "legs", "jetpack", "back"]

# which appearance slots belong to a component: a partial set's patch for that component is dropped as soon as the player
# changes one of them, so their choice always wins over the set
const COMPONENT_SLOTS := {"head": ["headgear"], "torso": ["top", "armor", "shoulder"], "arms": ["gloves"], "legs": ["bottom", "boots", "kneepads"],
	"jetpack": ["jetpack"], "back": ["back"]}

# the player's own body choices a creature starts with: nothing worn
const BARE := {"top": "none", "bottom": "none", "boots": "barefoot", "gloves": "none", "armor": "none", "kneepads": "none", "shoulder": "none", "back": "none"}


static func all() -> Array:
	return DEFS.keys()


static func get_def(id: String) -> Dictionary:
	return DEFS.get(id, {})


static func replaced(id: String) -> Array:
	return (get_def(id).get("parts", {}) as Dictionary).keys()


static func is_full(id: String) -> bool:
	return replaced(id).size() >= 5


static var DEFS := {
	# ---- complete anatomies: their own drawn body and head, own flight presentation (see CosmeticFx) ----
	# "defaults" = the cosmetic's own choice for each component. The player can override any one of them (Appearance.effective).
	"insectoid_drone": {
		"name": "Insectoid Drone", "theme": "alien", "rarity": "epic", "owned_default": true, "dressable": true, "species_head": "insect",
		"desc": "A chitin-shelled hive flyer: faceted eyes, mandibles, antennae, a swaying abdomen and four membrane wings that ARE its jetpack.",
		"flight": "Wings unfold and beat, with motion blur, glowing veins and wind glints.",
		"parts": {"head": {}, "torso": {}, "arms": {}, "legs": {}, "jetpack": {}, "back": {}},
		"defaults": {"head": "insect", "eyes": "compound", "eye_col": 7, "brows": "none", "hair": "antenna_curled", "facial": "mandible_short", "headgear": "none", "jetpack": "own",
			"top": "none", "bottom": "none", "boots": "barefoot", "gloves": "none"},
		"anatomy": {"folder": "insectoid", "merged_pelvis": true, "neck_patch": false, "slots": ["torso", "waist", "thigh", "shin", "foot", "upper_arm", "forearm", "hand"], "fx": "wings", "lean": 0.8, "fx_cfg": {"glow": Color(0.5, 1.0, 0.85)}},
		"variants": [{"name": "Emerald", "hue": 0.0}, {"name": "Ember", "hue": 0.62}, {"name": "Amethyst", "hue": 0.3}]},
	"lumen_seer": {
		"name": "Lumen Seer", "theme": "alien", "rarity": "legendary", "owned_default": true, "dressable": true, "species_head": "lumen",
		"desc": "A tall, reed-slender luminous alien with a swollen skull, three-fingered hands and glowing markings. Drifts on bioenergy, no pack.",
		"flight": "A pulsing energy ring under the feet, rising motes and two orbiting glow-orbs.",
		"parts": {"head": {}, "torso": {}, "arms": {}, "legs": {}, "jetpack": {}, "back": {}},
		"defaults": {"head": "lumen", "eyes": "alien", "eye_col": 8, "brows": "none", "hair": "crest_frill", "facial": "none", "headgear": "none", "jetpack": "own",
			"top": "none", "bottom": "none", "boots": "barefoot", "gloves": "none"},
		"anatomy": {"folder": "lumen", "merged_pelvis": true, "neck_patch": false, "slots": ["torso", "waist", "thigh", "shin", "foot", "upper_arm", "forearm", "hand"], "fx": "levitate", "lean": 0.5, "fx_cfg": {"glow": Color(0.4, 0.95, 1.0)}},
		"variants": [{"name": "Aurora", "hue": 0.0}, {"name": "Solar", "hue": 0.44}, {"name": "Nebula", "hue": 0.78}]},
	"comet_vanguard": {
		"name": "Comet Vanguard", "theme": "hero", "rarity": "mythic", "owned_default": true,
		"desc": "A teal-and-gold champion with a sculpted suit, a comet emblem, gold gauntlets and a long violet cape. Wears a hero cowl; change the face, eyes or cowl and the costume stays.",
		"flight": "The cape streams, ripples and settles with your movement; cold energy puffs at the boots.",
		"parts": {"head": {}, "torso": {}, "arms": {}, "legs": {}, "jetpack": {}, "back": {}},
		"defaults": {"head": "square", "eyes": "almond", "brows": "straight", "hair": "none", "facial": "none", "headgear": "cowl", "jetpack": "own"},
		"head_colors": {"helmet": Color("187a8a"), "accent": Color("ecbe42")},
		"anatomy": {"folder": "vanguard", "slots": ["torso", "waist", "thigh", "shin", "foot", "upper_arm", "forearm", "hand"], "fx": "cape", "lean": 1.4, "fx_cfg": {"glow": Color(1.0, 0.85, 0.4), "cape_tex": "cape.png"}},
		"variants": [{"name": "Teal", "hue": 0.0}, {"name": "Crimson", "hue": 0.45}, {"name": "Violet", "hue": 0.75}]},
	"night_guardian": {
		"name": "Night Guardian", "theme": "hero", "rarity": "epic", "owned_default": true,
		"desc": "A V-shouldered masked vigilante in a sculpted suit, gauntlets with fins and a long cape. No pack: the cape and the body carry the flight.",
		"flight": "The cape streams, ripples and settles with your movement; cold energy puffs at the boots.",
		"parts": {"head": {}, "torso": {}, "arms": {}, "legs": {}, "jetpack": {}, "back": {}},
		"defaults": {"head": "square", "eyes": "angular", "brows": "angry", "hair": "none", "facial": "none", "headgear": "cowl", "jetpack": "own"},
		"head_colors": {"helmet": Color("181e34"), "accent": Color("28345a")},
		"anatomy": {"folder": "guardian", "slots": ["torso", "waist", "thigh", "shin", "foot", "upper_arm", "forearm", "hand"], "fx": "cape", "lean": 1.4, "fx_cfg": {"glow": Color(0.75, 0.9, 1.0)}},
		"variants": [{"name": "Midnight", "hue": 0.0}, {"name": "Crimson", "hue": 0.35}, {"name": "Verdant", "hue": 0.74}]},
	# ---- armour sets on the standard human body (they keep human anatomy on purpose) ----
	"void_hunter": {
		"name": "Void Hunter", "theme": "hunter", "rarity": "legendary", "owned_default": false,
		"desc": "Angular stalker armour with a glowing slit visor. Replaces everything, jetpack included.",
		"defaults": {"headgear": "hunter", "hair": "none", "facial": "none"},
		"head_colors": {"helmet": Color("3b4048"), "accent": Color("22262d"), "cosm_over": Color("ff8a4d")},
		"parts": {
			"torso": {"colors": {"uniform": Color("22262d"), "vest": Color("4a4f58"), "gear": Color("14161a"), "glow": Color("ff8a4d")}, "show": {"bare": false, "vest": true, "pads": true, "chest": true, "top_band": false}, "cosm": {"chest": "hunter_chest.png"},
				"garm": {"top": {"id": "suit", "pal": [Color("22262d"), Color("3b4048"), Color("14161a"), Color("4a4f58")], "glow": Color("ff8a4d")}, "armor": {"id": "plated", "pal": [Color("4a4f58"), Color("2c3038"), Color("6a707c"), Color("22262d")], "glow": Color("ff8a4d")}}},
			"arms": {"colors": {"sleeve_up": Color("22262d"), "sleeve_fore": Color("3b4048"), "glove": Color("14161a")}, "show": {"forearm_trim": true},
				"garm": {"gloves": {"id": "armored", "pal": [Color("14161a"), Color("3b4048"), Color("0c0e10"), Color("ff8a4d")], "glow": Color("ff8a4d")}}},
			"legs": {"colors": {"pants": Color("22262d"), "shin_pants": Color("22262d"), "boots": Color("14161a"), "under": Color("22262d")}, "show": {"knee": true},
				"garm": {"bottom": {"id": "armored", "pal": [Color("22262d"), Color("3b4048"), Color("14161a"), Color("4a4f58")], "glow": Color("ff8a4d")}, "boots": {"id": "boots", "pal": [Color("14161a"), Color("3b4048"), Color("0c0e10"), Color("ff8a4d")], "glow": Color("ff8a4d")}}},
			"jetpack": {"jp": {"tex": "heavy", "scale": 1.0}, "colors": {"jetpack": Color("3b4048"), "glow": Color("ff8a4d")}},
		}},
	"solar_sentinel": {
		"name": "Solar Sentinel", "theme": "hero", "rarity": "mythic", "owned_default": false,
		"desc": "A radiant high-tech guardian in white and gold. Partial set with a matching cape.",
		"defaults": {"headgear": "cowl", "hair": "none", "facial": "none"},
		"head_colors": {"helmet": Color("e8eef6"), "accent": Color("ffd24d")},
		"parts": {
			"torso": {"colors": {"uniform": Color("e8eef6"), "vest": Color("c9a23a"), "gear": Color("8a6a1c"), "glow": Color("ffd24d")}, "show": {"bare": false, "vest": true, "pads": true, "chest": true, "top_band": false}, "cosm": {"chest": "hero_emblem.png"},
				"garm": {"top": {"id": "suit", "pal": [Color("e8eef6"), Color("c9a23a"), Color("b8c2d0"), Color("ffe08a")], "glow": Color("ffd24d")}}},
			"arms": {"colors": {"sleeve_up": Color("e8eef6"), "sleeve_fore": Color("c9a23a"), "glove": Color("8a6a1c")}, "show": {"forearm_trim": true},
				"garm": {"gloves": {"id": "gloves", "pal": [Color("c9a23a"), Color("ffe08a"), Color("8a6a1c"), Color("fff0b0")], "glow": Color("ffd24d")}}},
			"back": {"colors": {"cape": Color("c9a23a")}, "show": {"cape": true}},
		}},
}
