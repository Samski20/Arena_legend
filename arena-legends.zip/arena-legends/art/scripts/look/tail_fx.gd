class_name TailFx
extends CosmeticFx
## A three-segment tail for reptilian anatomies. It sways on its own, swings out behind you when you fly, whips with
## direction changes and drops when you fall. Segments are nested so each follows the one before it (secondary motion).
## Visual only. The wave uses sin(), no physics, no allocations per frame.

var _segs: Array = []
var _lag := 0.0
var _lift := 0.0


func _build() -> void:
	var root := Node2D.new()
	root.position = Vector2(-7, -4)
	root.z_index = -5
	add_child(root)
	var parent: Node2D = root
	var sizes := [Vector2(64, 32), Vector2(60, 26), Vector2(56, 20)]
	var files := ["tail_a.png", "tail_b.png", "tail_c.png"]
	for i in 3:
		var seg := Node2D.new()
		parent.add_child(seg)
		if i > 0:
			seg.position = Vector2((sizes[i - 1].x - 6) * 0.5, 0)
		_sprite(seg, files[i], Vector2(3, sizes[i].y * 0.5))
		_segs.append(seg)
		parent = seg


func _tick(delta: float, vel: Vector2, jetting: bool, on_floor: bool) -> void:
	var fs := signf(rig.global_transform.x.x)
	var lv := Vector2(vel.x * fs, vel.y)
	_lag = lerpf(_lag, clampf(lv.x * 0.0016, -0.5, 0.5), 1.0 - exp(-6.0 * delta))
	_lift = lerpf(_lift, clampf(-lv.y * 0.0012, -0.4, 0.4) + (0.12 if jetting else 0.0), 1.0 - exp(-5.0 * delta))
	var speed := 1.6 + (2.0 if jetting else 0.0) + absf(lv.x) * 0.004
	var base := [PI - 0.12, 0.0, 0.0]                  # the tail points backwards (rig faces +x), a little down
	for i in _segs.size():
		var wave := sin(_t * speed - i * 0.9) * (0.10 + 0.07 * i) * (1.0 + (0.8 if jetting else 0.0))
		var dir := _lag * (0.5 + 0.3 * i) + _lift * (0.4 + 0.3 * i)
		(_segs[i] as Node2D).rotation = float(base[i]) + wave + (dir if i > 0 else dir * 0.5)


func _on_landed(strength: float) -> void:
	_lift -= 0.25 * clampf(strength, 0.2, 1.5)
