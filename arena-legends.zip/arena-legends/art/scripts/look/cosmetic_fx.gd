class_name CosmeticFx
extends Node2D
## Base for a cosmetic's own movement + flight presentation (wings, cape, levitation ...). The PlayerRig creates one
## when an anatomy cosmetic is applied and calls update() every frame from update_visuals(). It only DRAWS:
## it reads the same velocity / jetting / on_floor values the rig already gets (those are what LAN syncs, so every
## client animates it locally and consistently). It never feeds anything back into movement, fuel or collisions.

const COSM := "res://art/cosmetics/"
var rig: PlayerRig
var folder := ""
var mat: Material
var cfg: Dictionary = {}
var _t := 0.0
var _was_jetting := false
var _was_floor := true


static func create(kind: String) -> CosmeticFx:
	match kind:
		"wings": return WingsFx.new()
		"cape": return CapeFx.new()
		"levitate": return LevitateFx.new()
	return null


func setup(r: PlayerRig, fx_folder: String, material: Material, config: Dictionary) -> void:
	rig = r
	folder = fx_folder
	mat = material
	cfg = config
	_build()
	rig.landed.connect(_on_landed)


func _build() -> void:
	pass


func _tex(file: String) -> Texture2D:
	return load(COSM + folder + "/" + file) as Texture2D


# Sprite whose picture is `file`, pivot given in picture pixels, drawn at half size (like the body art).
func _sprite(parent: Node, file: String, pivot: Vector2, sc := 0.5, additive := false) -> Sprite2D:
	var s := Sprite2D.new()
	s.texture = _tex(file)
	s.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	s.centered = false
	s.offset = -pivot
	s.scale = Vector2(sc, sc)
	if additive:
		var m := CanvasItemMaterial.new()
		m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		s.material = m
	elif mat != null:
		s.material = mat
	parent.add_child(s)
	return s


# Small, cheap particle puff (a handful of dots). Keep `amount` low: this runs on phones.
func _puff(parent: Node, amount: int, life: float, col: Color, speed: float, spread: float, dir: Vector2, size := 1.6, grav := Vector2.ZERO) -> CPUParticles2D:
	var p := CPUParticles2D.new()
	p.amount = amount
	p.lifetime = life
	p.local_coords = false
	p.direction = dir
	p.spread = spread
	p.initial_velocity_min = speed * 0.6
	p.initial_velocity_max = speed
	p.gravity = grav
	p.scale_amount_min = size * 0.6
	p.scale_amount_max = size
	var g := Gradient.new()
	g.set_color(0, col)
	g.set_color(1, Color(col.r, col.g, col.b, 0.0))
	p.color_ramp = g
	p.emitting = false
	parent.add_child(p)
	return p


func update(delta: float, vel: Vector2, jetting: bool, on_floor: bool) -> void:
	_t += delta
	_tick(delta, vel, jetting, on_floor)
	if jetting and not _was_jetting:
		_on_takeoff()
	_was_jetting = jetting
	_was_floor = on_floor


func _tick(_delta: float, _vel: Vector2, _jetting: bool, _on_floor: bool) -> void:
	pass


func _on_takeoff() -> void:
	pass


func _on_landed(_strength: float) -> void:
	pass
