class_name CustomizeMenu
extends CanvasLayer
## CUSTOMIZATION: Character Customization (body-part choices) and Cosmetics Collection (full-character sets).
## The preview is the REAL PlayerRig (same sprites and animation code as the game). Everything here is a draft
## until SAVE CHANGES; the base look and the equipped cosmetic are stored separately, so equipping a cosmetic
## never overwrites the customised avatar underneath.

signal closed

var _tab := "body"
var _app: Dictionary = {}            # draft base appearance
var _equipped := ""                  # draft equipped cosmetic
var _variant := 0                    # draft colour variant of the equipped cosmetic
var _preview_cos := ""               # cosmetic being previewed (may be locked, may differ from equipped)
var _dirty := false
var _filter_theme := 0
var _filter_rarity := 0
var _owned_only := false
var _anim := "idle"
var _rig: PlayerRig
var _rig_holder: Node2D
var _list: VBoxContainer
var _scroll: MenuScroll
var _tabs_row: HFlowContainer
var _stage_area: Control
var _zoom_head := false              # inspect: close-up of the head instead of the whole character
var _face_left := false              # inspect: turn the character around
var _zoom_btn: Button
var _cats_row: HFlowContainer
var _note: Label
var _save_btn: Button
var _overlay: Control
var _toast: Label
var _toast_t := 0.0
var _t := 0.0
var _root: Control

const TAB_LIST := [["body", "BODY"], ["head", "HEAD"], ["eyes", "EYES"], ["hair", "HAIR"], ["facial", "FACIAL HAIR"], ["headgear", "HEADGEAR"],
	["upper", "UPPER BODY"], ["arms", "ARMS"], ["legs", "TROUSERS"], ["feet", "FOOTWEAR"], ["back", "JETPACK + BACK"], ["cosmetics", "COSMETICS"], ["colours", "COLOURS"]]
const HEAD_TABS := ["head", "eyes", "hair", "facial", "headgear"]
# colour swatches shown inside the category they belong to
const COLOR_FOR := {"eyes": "eye_col", "hair": "hair_col", "facial": "hair_col", "headgear": "gear_col", "upper": "top_col", "legs": "bottom_col", "back": "jp_col"}


func _ready() -> void:
	layer = 106
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_root)
	var bg := ColorRect.new()
	bg.color = UITheme.SURFACE
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.add_child(bg)
	var ins := UITheme.safe_insets()
	var m := MarginContainer.new()
	m.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	m.add_theme_constant_override("margin_left", int(14 + ins.x))
	m.add_theme_constant_override("margin_right", int(14 + ins.z))
	m.add_theme_constant_override("margin_top", int(10 + ins.y))
	m.add_theme_constant_override("margin_bottom", int(10 + ins.w))
	_root.add_child(m)
	var cols := HBoxContainer.new()
	cols.add_theme_constant_override("separation", 12)
	m.add_child(cols)

	# ---- left: big live preview
	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.size_flags_stretch_ratio = 0.8
	left.add_theme_constant_override("separation", 8)
	cols.add_child(left)
	var stage := PanelContainer.new()
	stage.add_theme_stylebox_override("panel", UITheme.box(UITheme.SURFACE_2, 22, false, 0, 0))
	stage.size_flags_vertical = Control.SIZE_EXPAND_FILL
	stage.clip_contents = true
	left.add_child(stage)
	var stage_area := Control.new()
	stage_area.clip_contents = true
	stage.add_child(stage_area)
	_rig_holder = Node2D.new()
	_rig_holder.z_index = 20            # the rig uses negative z for its back layers: keep them above the stage panel
	stage_area.add_child(_rig_holder)
	_stage_area = stage_area
	stage_area.resized.connect(_layout_stage)
	_rig = PlayerRig.new()
	_rig.preview = true
	_rig_holder.add_child(_rig)
	var anim_row := HBoxContainer.new()
	anim_row.add_theme_constant_override("separation", 4)
	left.add_child(anim_row)
	for a in [["idle", "IDLE"], ["walk", "WALK"], ["aim", "AIM"], ["fly", "FLY"], ["fall", "FALL"]]:
		var b := MenuKit.button(str(a[1]), "tonal", 40, 12)
		b.custom_minimum_size = Vector2(46, 40)
		b.pressed.connect(func() -> void:
			_anim = str(a[0])
			if _anim == "aim":
				_rig.equip_weapon(WeaponCatalog.get_weapon("m4a1"))
			else:
				_rig.unequip_weapon())
		anim_row.add_child(b)
	var shoot := MenuKit.button("FIRE", "tonal", 40, 12)
	shoot.custom_minimum_size = Vector2(46, 40)
	shoot.pressed.connect(func() -> void:
		if _anim == "aim":
			_rig.fire_effects(0))
	anim_row.add_child(shoot)
	var turn := MenuKit.button("TURN", "tonal", 40, 12)
	turn.custom_minimum_size = Vector2(46, 40)
	turn.pressed.connect(func() -> void: _face_left = not _face_left)
	anim_row.add_child(turn)
	_zoom_btn = MenuKit.button("HEAD", "tonal", 40, 12)
	_zoom_btn.custom_minimum_size = Vector2(46, 40)
	_zoom_btn.pressed.connect(func() -> void:
		_zoom_head = not _zoom_head
		_layout_stage())
	anim_row.add_child(_zoom_btn)

	# ---- right: tabs + options
	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.size_flags_stretch_ratio = 1.2
	right.add_theme_constant_override("separation", 8)
	cols.add_child(right)
	_tabs_row = HFlowContainer.new()
	_tabs_row.add_theme_constant_override("h_separation", 6)
	_tabs_row.add_theme_constant_override("v_separation", 6)
	right.add_child(_tabs_row)
	_cats_row = HFlowContainer.new()
	_cats_row.add_theme_constant_override("h_separation", 6)
	_cats_row.add_theme_constant_override("v_separation", 6)
	right.add_child(_cats_row)
	_note = MenuKit.label("", 13, UITheme.WARM)
	right.add_child(_note)
	_scroll = MenuScroll.new()
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right.add_child(_scroll)
	_list = VBoxContainer.new()
	_list.add_theme_constant_override("separation", 8)
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll.add_child(_list)
	var foot := HBoxContainer.new()
	foot.add_theme_constant_override("separation", 8)
	right.add_child(foot)
	var back := MenuKit.button("BACK", "tonal", 48, 15)
	back.pressed.connect(_on_back)
	foot.add_child(back)
	var reset := MenuKit.button("RESET APPEARANCE", "tonal", 48, 13)
	reset.pressed.connect(_on_reset)
	foot.add_child(reset)
	_save_btn = MenuKit.button("SAVE CHANGES", "primary", 48, 15)
	_save_btn.pressed.connect(_on_save)
	foot.add_child(_save_btn)
	_toast = MenuKit.label("", 15, UITheme.ON_PRIMARY, true)
	_toast.add_theme_stylebox_override("normal", UITheme.box(UITheme.PRIMARY, 18, false, 16, 8))
	_toast.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_toast.position = Vector2(-100, -90)
	_toast.visible = false
	_root.add_child(_toast)


func open() -> void:
	AppearanceStore.ensure()
	_app = AppearanceStore.app.duplicate(true)
	_equipped = AppearanceStore.equipped
	_variant = AppearanceStore.variant
	_preview_cos = _equipped
	_dirty = false
	_tab = "body"
	_zoom_head = false
	_face_left = false
	visible = true
	_rebuild()
	_refresh_preview()
	_layout_stage.call_deferred()
	_save_btn.grab_focus.call_deferred()


func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("ui_cancel") and _overlay == null:
		get_viewport().set_input_as_handled()
		_on_back()


# ------------------------------------------------------------------ preview
func _refresh_preview() -> void:
	_rig.apply_appearance(Appearance.resolve(_app, _preview_cos, _variant if _preview_cos == _equipped else 0))


func _process(delta: float) -> void:
	if not visible or _rig == null:
		return
	_t += delta
	if _toast_t > 0.0:
		_toast_t -= delta
		if _toast_t <= 0.0:
			_toast.visible = false
	var vel := Vector2.ZERO
	var jet := false
	var floor_ := true
	match _anim:
		"walk":
			vel = Vector2(150, 0)
		"fly":
			vel = Vector2(240, -60)
			jet = true
			floor_ = false
		"fall":
			vel = Vector2(40, 380)
			floor_ = false
	var aim := _rig_holder.global_position + Vector2(-300 if _face_left else 300, -40 + sin(_t * 1.2) * 20)
	_rig.update_visuals(vel, aim, jet, floor_, delta, false, false)


func _say(text: String) -> void:
	_toast.text = text
	_toast.visible = true
	_toast_t = 2.0


# ------------------------------------------------------------------ frame
func _rebuild() -> void:
	var keep := _scroll.scroll_vertical
	for c in _tabs_row.get_children():
		_tabs_row.remove_child(c)
		c.queue_free()
	for t in TAB_LIST:
		var b := MenuKit.button(str(t[1]), "primary" if _tab == t[0] else "tonal", 38, 12)
		b.custom_minimum_size = Vector2(54, 38)
		b.size_flags_horizontal = Control.SIZE_FILL
		b.pressed.connect(func() -> void:
			_tab = str(t[0])
			if _tab != "cosmetics" and _tab != "colours":
				_preview_cos = _equipped
			_zoom_head = HEAD_TABS.has(_tab)            # head categories look at the head, the others at the whole character
			_layout_stage()
			_refresh_preview()
			_rebuild())
		_tabs_row.add_child(b)
	for c in _cats_row.get_children():
		_cats_row.remove_child(c)
		c.queue_free()
	_cats_row.visible = false
	_zoom_btn.text = "BODY" if _zoom_head else "HEAD"
	for c in _list.get_children():
		_list.remove_child(c)
		c.queue_free()
	_note.text = ""
	match _tab:
		"cosmetics": _page_cosmetics()
		"colours": _page_colours()
		"body": _page_body()
		_: _page_slots(_tab)
	_save_btn.text = "SAVE CHANGES" + (" *" if _dirty else "")
	_restore.call_deferred(keep)


func _restore(v: int) -> void:
	_scroll.scroll_vertical = v


func _changed() -> void:
	_dirty = true
	_refresh_preview()
	_rebuild.call_deferred()


# ------------------------------------------------------------------ stage (fit the whole character, or just the head)
func _layout_stage() -> void:
	if _stage_area == null or _rig_holder == null:
		return
	var sz := _stage_area.size
	if sz.x < 10.0 or sz.y < 10.0:
		return
	if _zoom_head:
		var k := minf(sz.x * 0.62 / 46.0, sz.y * 0.62 / 52.0)
		_rig_holder.scale = Vector2(k, k)
		_rig_holder.position = Vector2(sz.x * 0.5 - 4.0 * k, sz.y * 0.5 + 63.0 * k)
	else:
		var k := minf(sz.y * 0.86 / 160.0, sz.x * 0.68 / 120.0)       # character spans about -105 .. +55 game pixels
		_rig_holder.scale = Vector2(k, k)
		_rig_holder.position = Vector2(sz.x * 0.46, sz.y * 0.5 + 25.0 * k)


# ------------------------------------------------------------------ editing helpers (modular)
# Where a choice is stored: while a cosmetic is equipped, a component it supplies by default is OVERRIDDEN for that
# cosmetic only; a component the cosmetic leaves to the player is just the player's own look.
func _src(key: String) -> String:
	if _equipped == "":
		return ""
	var s := Appearance.source(_app, _equipped, key)
	if s == "mine":
		var def := CosmeticCatalog.get_def(_equipped)
		if not def.has("anatomy"):
			var ov := Appearance.overrides(_app, _equipped)
			for comp in def.get("parts", {}):
				var slots: Array = CosmeticCatalog.COMPONENT_SLOTS.get(comp, [])
				if slots.has(key):
					var touched := false
					for sl in slots:
						touched = touched or ov.has(sl)
					if not touched:
						return "default"
	return s


func _set_opt(key: String, id: String) -> void:
	var to_ov := _equipped != "" and (_src(key) != "mine" or not Appearance.options(key, _app, "").has(id))
	if to_ov:
		if not (_app["ov"] as Dictionary).has(_equipped):
			_app["ov"][_equipped] = {}
		_app["ov"][_equipped][key] = id
	else:
		_app[key] = id
		if _equipped != "":
			(Appearance.overrides(_app, _equipped) as Dictionary).erase(key)
	_changed()


func _set_color(key: String, i: int) -> void:
	var cosm_color: bool = _equipped != "" and (_src(key) != "mine" or CosmeticCatalog.get_def(_equipped).get("defaults", {}).has(key))
	if cosm_color:
		if not (_app["ov"] as Dictionary).has(_equipped):
			_app["ov"][_equipped] = {}
		_app["ov"][_equipped][key] = i
	else:
		_app[key] = i
	_changed()


func _reset_slot(key: String) -> void:
	if _equipped != "":
		(Appearance.overrides(_app, _equipped) as Dictionary).erase(key)
	_say("Back to the cosmetic's default")
	_changed()


# header of one component: title, where its current value comes from, and its own reset button
func _slot_header(title: String, key: String) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	_list.add_child(row)
	var t := MenuKit.label(title.to_upper(), 13, UITheme.PRIMARY, true)
	t.custom_minimum_size = Vector2(0, 30)
	t.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(t)
	var src := _src(key)
	if src == "":
		return
	var chip := MenuKit.label({"default": "COSMETIC DEFAULT", "custom": "CUSTOM", "mine": "MY STYLE"}[src], 11, {"default": UITheme.FLY, "custom": UITheme.WARM, "mine": UITheme.ON_VARIANT}[src], true)
	chip.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	chip.autowrap_mode = TextServer.AUTOWRAP_OFF
	row.add_child(chip)
	if Appearance.cosmetic_default(_equipped, key) != "" or src == "custom":
		var r := MenuKit.button("RESET", "tonal", 30, 11)
		r.custom_minimum_size = Vector2(60, 30)
		r.size_flags_horizontal = Control.SIZE_SHRINK_END
		r.size_flags_vertical = Control.SIZE_SHRINK_END
		r.disabled = src != "custom"
		r.tooltip_text = "Put this component back to the cosmetic's default"
		r.pressed.connect(func() -> void: _reset_slot(key))
		row.add_child(r)


# ------------------------------------------------------------------ BODY tab
func _page_body() -> void:
	_cosmetic_note()
	MenuKit.section(_list, "Body")
	MenuKit.segmented(_list, ["MALE", "FEMALE"], AppearanceCatalog.AVATARS.find(_app["avatar"]), func(i: int) -> void:
		var target := str(AppearanceCatalog.AVATARS[i])
		if target == _app["avatar"]:
			return
		var lost := Appearance.unavailable_for(_app, target)
		_app = Appearance.with_avatar(_app, target)         # keeps every compatible choice
		if not lost.is_empty():
			_say("Not available for %s: %s. Defaults used." % [target, ", ".join(lost)])
		_changed())
	MenuKit.hint(_list, "Male and female are only different looks. Health, speed, hitbox, jetpack and damage are identical.")
	MenuKit.section(_list, "Skin tone")
	_swatches("skin", "skin")
	MenuKit.hint(_list, "Each part has its own category: head, eyes, hair, facial hair, headgear, upper body, arms, trousers, footwear and back. Changing one never changes another.")


func _cosmetic_note() -> void:
	if _equipped == "":
		return
	var def := CosmeticCatalog.get_def(_equipped)
	_note.text = "%s is equipped. Your changes apply to its parts only; each part can go back to the cosmetic's default." % def.get("name", "")


# every category that lists options for one or more components
func _page_slots(tab: String) -> void:
	_cosmetic_note()
	for t in AppearanceCatalog.TABS:
		if t[0] != tab:
			continue
		for s in t[2]:
			var key := str(s[0])
			_slot_header(str(s[1]), key)
			var table := Appearance.options(key, _app, _equipped)
			if table.is_empty():
				MenuKit.hint(_list, "Part of %s's own design, so it is not changeable." % CosmeticCatalog.get_def(_equipped).get("name", "this cosmetic"))
				continue
			_options(key, table)
			_slot_hint(key)
		if COLOR_FOR.has(tab):
			var ck := str(COLOR_FOR[tab])
			for cs in AppearanceCatalog.COLOR_SLOTS:
				if cs[0] == ck:
					_slot_header(str(cs[1]), ck)
					_swatches(ck, str(cs[2]))
		if tab == "head":
			MenuKit.hint(_list, "Hair, facial hair and headgear are drawn for the head shape you pick, so they fit it.")


func _slot_hint(key: String) -> void:
	var gear: Dictionary = HeadCatalog.GEAR.get(Appearance.effective(_app, _equipped, "headgear"), {})
	if key == "hair" and str(gear.get("hair", "keep")) != "keep" and Appearance.effective(_app, _equipped, "headgear") != "none":
		MenuKit.hint(_list, "Your headgear covers %s of the hair." % ("all" if gear.get("hair") == "all" else "the front"), UITheme.WARM)
	if key == "facial" and (gear.get("hides", []) as Array).has("facial"):
		MenuKit.hint(_list, "Your headgear covers the lower face, so facial hair is hidden.", UITheme.WARM)
	if key == "eyes" and (gear.get("hides", []) as Array).has("eyes"):
		MenuKit.hint(_list, "Your headgear hides the eyes.", UITheme.WARM)


# COLOURS: palettes for the standard character, and the colour variants of a complete cosmetic.
func _page_colours() -> void:
	var cos_id := _preview_cos if _preview_cos != "" else _equipped
	var def := CosmeticCatalog.get_def(cos_id)
	var vars: Array = def.get("variants", [])
	if not vars.is_empty():
		MenuKit.section(_list, "%s variant" % def["name"])
		var names: Array = []
		for v in vars:
			names.append(str(v["name"]))
		MenuKit.choice_row(_list, "Variant", names, _variant if cos_id == _equipped else 0, func(i: int) -> void:
			if cos_id != _equipped:
				_say("Equip %s first to change its variant." % def["name"])
				return
			_variant = i
			_changed())
		MenuKit.hint(_list, "Variants recolour the whole character. They never change what it is.")
	MenuKit.section(_list, "Standard character colours")
	for slot in AppearanceCatalog.COLOR_SLOTS:
		MenuKit.hint(_list, str(slot[1]), UITheme.ON_SURFACE)
		_swatches(str(slot[0]), str(slot[2]))


func _options(key: String, table: Dictionary) -> void:
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list.add_child(grid)
	var cur := Appearance.effective(_app, _equipped, key)
	var dflt := Appearance.cosmetic_default(_equipped, key)
	for id in table:
		var opt: Dictionary = table[id]
		var nm := str(opt["name"]) + ("  (default)" if id == dflt else "")
		var b := MenuKit.button(nm, "primary" if cur == id else "tonal", 44, 13)
		b.pressed.connect(func() -> void: _set_opt(key, str(id)))
		grid.add_child(b)


func _swatches(key: String, kind: String) -> void:
	var row := HFlowContainer.new()
	row.add_theme_constant_override("h_separation", 8)
	row.add_theme_constant_override("v_separation", 8)
	_list.add_child(row)
	var cur := Appearance.effective_color(_app, _equipped, key) if key == "eye_col" else int(_app[key])
	for i in AppearanceCatalog.palette_size(kind):
		var b := Button.new()
		b.custom_minimum_size = Vector2(46, 46)
		var col := AppearanceCatalog.palette_color(kind, i)
		var sb := UITheme.box(col, 23, false, 0, 0)
		if cur == i:
			sb.set_border_width_all(4)
			sb.border_color = UITheme.PRIMARY
		else:
			sb.set_border_width_all(2)
			sb.border_color = Color(1, 1, 1, 0.25)
		for st in ["normal", "hover", "pressed", "focus"]:
			b.add_theme_stylebox_override(st, sb)
		b.tooltip_text = AppearanceCatalog.palette_name(kind, i)
		b.pressed.connect(func() -> void: _set_color(key, i))
		row.add_child(b)


# ------------------------------------------------------------------ COSMETICS tab
func _page_cosmetics() -> void:
	var themes: Array = ["ALL"]
	for t in CosmeticCatalog.THEMES:
		themes.append(str(CosmeticCatalog.THEME_NAMES[t]).to_upper())
	var rar: Array = ["ALL"]
	for r in CosmeticCatalog.RARITIES:
		rar.append(str(CosmeticCatalog.RARITY_NAMES[r]))
	MenuKit.choice_row(_list, "Category", themes, _filter_theme, func(i: int) -> void:
		_filter_theme = i
		_rebuild.call_deferred())
	MenuKit.choice_row(_list, "Rarity", rar, _filter_rarity, func(i: int) -> void:
		_filter_rarity = i
		_rebuild.call_deferred())
	MenuKit.toggle_row(_list, "Owned only", _owned_only, func(v: bool) -> void:
		_owned_only = v
		_rebuild.call_deferred())
	var own_n := 0
	for id in CosmeticCatalog.all():
		if AppearanceStore.is_owned(id):
			own_n += 1
	MenuKit.hint(_list, "Collection: %d of %d owned. Tap one to preview it; locked ones can be previewed but not equipped." % [own_n, CosmeticCatalog.all().size()])
	var shown := 0
	for id in CosmeticCatalog.all():
		var def := CosmeticCatalog.get_def(id)
		if _filter_theme > 0 and def["theme"] != CosmeticCatalog.THEMES[_filter_theme - 1]:
			continue
		if _filter_rarity > 0 and def["rarity"] != CosmeticCatalog.RARITIES[_filter_rarity - 1]:
			continue
		var owned := AppearanceStore.is_owned(id)
		if _owned_only and not owned:
			continue
		shown += 1
		_cosmetic_card(id, def, owned)
	if shown == 0:
		MenuKit.hint(_list, "Nothing matches these filters.")
	if _equipped != "":
		var un := MenuKit.button("UNEQUIP COSMETIC  (back to my customised look)", "tonal", 48, 14)
		un.pressed.connect(func() -> void:
			_equipped = ""
			_preview_cos = ""
			_changed())
		_list.add_child(un)


func _cosmetic_card(id: String, def: Dictionary, owned: bool) -> void:
	var v := MenuKit.card(_list)
	var rc: Color = CosmeticCatalog.RARITY_COLORS[def["rarity"]]
	var head := HBoxContainer.new()
	v.add_child(head)
	var nm := MenuKit.label(str(def["name"]), 17, UITheme.ON_SURFACE, true)
	nm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(nm)
	var tag := MenuKit.label("%s  %s" % [CosmeticCatalog.RARITY_NAMES[def["rarity"]], "" if owned else "LOCKED"], 12, rc, true)
	head.add_child(tag)
	v.add_child(MenuKit.label(str(def["desc"]), 13, UITheme.ON_VARIANT))
	if def.has("flight"):
		v.add_child(MenuKit.label("Flight: " + str(def["flight"]), 12, UITheme.PRIMARY))
	v.add_child(MenuKit.label(("Own body and animations" if def.has("anatomy") else "Replaces: " + ", ".join(CosmeticCatalog.replaced(id)) + ("  ·  full set" if CosmeticCatalog.is_full(id) else "  ·  partial set")), 12, UITheme.ON_VARIANT))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	v.add_child(row)
	var pv := MenuKit.button("PREVIEWING" if _preview_cos == id else "PREVIEW", "primary" if _preview_cos == id else "tonal", 42, 13)
	pv.pressed.connect(func() -> void:
		_preview_cos = id
		_refresh_preview()
		_rebuild.call_deferred())
	row.add_child(pv)
	var eq := MenuKit.button("EQUIPPED" if _equipped == id else ("EQUIP" if owned else "LOCKED"), "tonal", 42, 13)
	eq.disabled = not owned or _equipped == id
	eq.pressed.connect(func() -> void:
		_equipped = id
		_variant = 0
		_preview_cos = id
		_changed())
	row.add_child(eq)


# ------------------------------------------------------------------ footer
func _on_save() -> void:
	AppearanceStore.app = Appearance.sanitize(_app)
	AppearanceStore.equipped = _equipped if AppearanceStore.is_owned(_equipped) else ""
	AppearanceStore.variant = _variant if AppearanceStore.equipped != "" else 0
	_dirty = false
	_say("Appearance saved" if AppearanceStore.save_all() else "Could not save on this device")
	_rebuild.call_deferred()


func _on_reset() -> void:
	_confirm("Reset appearance to the default look? (Cosmetics you own are kept.)", func() -> void:
		_app = Appearance.default_for(str(_app["avatar"]))
		_equipped = ""
		_preview_cos = ""
		_changed())


func _on_back() -> void:
	if _dirty:
		_confirm("Leave without saving your changes?", _close)
	else:
		_close()


func _close() -> void:
	visible = false
	closed.emit()


func _confirm(text: String, on_yes: Callable) -> void:
	if _overlay != null:
		_overlay.queue_free()
	var r := ColorRect.new()
	r.color = Color(0, 0, 0, 0.6)
	r.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.add_child(r)
	_overlay = r
	var c := CenterContainer.new()
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	r.add_child(c)
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UITheme.panel_box(22, 18))
	p.custom_minimum_size = Vector2(340, 0)
	c.add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	p.add_child(v)
	v.add_child(MenuKit.label(text, 17, UITheme.ON_SURFACE, true))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	v.add_child(row)
	var yes := MenuKit.button("YES", "danger", 46, 15)
	yes.pressed.connect(func() -> void:
		r.queue_free()
		_overlay = null
		on_yes.call())
	row.add_child(yes)
	var no := MenuKit.button("CANCEL", "tonal", 46, 15)
	no.pressed.connect(func() -> void:
		r.queue_free()
		_overlay = null)
	row.add_child(no)
