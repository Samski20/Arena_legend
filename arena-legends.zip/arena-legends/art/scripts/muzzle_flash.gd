class_name MuzzleFlash
extends Node2D
## A quick burst of fire at the barrel tip. One hangs on each gun's muzzle (see PlayerRig.fire_effects).
## It is a few flat polygons (outer flame, inner flame, white core), so it costs almost nothing. The shape
## is re-rolled for every shot, so automatic fire flickers instead of repeating one picture.
## It draws pointing along +x of its parent, so it follows the gun's aim and the way the player faces.

const LIFE := 0.06                    # seconds a flash stays on screen

# style -> [spikes, length (px), fan half-angle (rad), forward boost]
const STYLES := {
	"pistol":  [6, 10.0, 1.25, 1.5],
	"smg":     [6, 9.0, 1.25, 1.6],
	"rifle":   [7, 13.0, 1.30, 1.8],
	"mg":      [8, 15.0, 1.30, 1.7],
	"shotgun": [9, 17.0, 1.20, 1.3],
	"sniper":  [7, 20.0, 1.55, 2.0],      # wide fan: the muzzle brake blows fire out sideways
	"magnum":  [8, 15.0, 1.30, 1.6],
}

var _t := 0.0
var _size := 1.0
var _bright := 1.0
var _outer := PackedVector2Array()
var _inner := PackedVector2Array()
var _core := PackedVector2Array()


func _ready() -> void:
	z_index = 3                       # in front of the gun and the hands
	visible = false
	set_process(false)


func fire(style: String, size := 1.0, bright := 1.0) -> void:
	_size = size
	_bright = bright
	_build(STYLES.get(style, STYLES["rifle"]))
	_t = LIFE
	visible = true
	set_process(true)
	queue_redraw()


func hide_now() -> void:
	_t = 0.0
	visible = false
	set_process(false)


func _process(delta: float) -> void:
	_t -= delta
	if _t <= 0.0:
		hide_now()
	else:
		queue_redraw()


func _build(style: Array) -> void:
	var n: int = style[0]
	var length: float = float(style[1]) * _size
	var fan: float = style[2]
	var fwd: float = style[3]
	_outer = _star(n, length, fan, fwd, 0.30)
	_inner = _star(n, length * 0.64, fan * 0.9, fwd, 0.28)
	_core = _star(maxi(n - 2, 4), length * 0.34, fan * 0.8, 1.2, 0.35)


# A star that is mostly forward: the spike lengths follow cos(angle) so the longest ones point out of the barrel.
func _star(n: int, length: float, fan: float, fwd: float, valley: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	pts.append(Vector2(-2.5, -2.0))
	var step := (2.0 * fan) / float(n - 1)
	for i in n:
		var a := -fan + step * float(i)
		var l := length * (0.5 + 0.5 * cos(a * 0.9)) * randf_range(0.78, 1.15)
		if absf(a) < 0.22:
			l *= fwd
		pts.append(Vector2(cos(a), sin(a)) * l + Vector2(1.5, 0.0))
		if i < n - 1:
			var am := a + step * 0.5
			pts.append(Vector2(cos(am), sin(am)) * length * valley + Vector2(1.5, 0.0))
	pts.append(Vector2(-2.5, 2.0))
	return pts


func _draw() -> void:
	if _t <= 0.0 or _outer.size() < 3:
		return
	var k := clampf(_t / LIFE, 0.0, 1.0)             # 1 = just fired, 0 = gone
	var s := 0.65 + 0.35 * k                          # shrinks as it dies
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(s, s))
	draw_colored_polygon(_outer, Color(1.0, 0.45, 0.1, 0.95))
	draw_colored_polygon(_inner, Color(1.0, 0.82, 0.25, 1.0))
	draw_colored_polygon(_core, Color(1.0, 1.0, 0.92).lerp(Color.WHITE, clampf(_bright - 1.0, 0.0, 1.0)))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
