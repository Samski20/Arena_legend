class_name WeaponCatalog
extends RefCounted
## The one list of every weapon in the game. To add a weapon:
##   1. make its .tres (right-click > New Resource > WeaponData) and its sprite in art/weapons/
##   2. add one line to PATHS below
## Maps, spawners and menus ask the catalog, so nothing else needs editing.
## Weapons from different eras live side by side: filter with all("Futuristic"), all("Medieval"),
## by_category("Sniper Rifle")... A futuristic gun never forces other eras to look futuristic.

const PATHS := {
	# id: path to the weapon resource
	"ak47": "res://art/scripts/rifle.tres",
	"mp5": "res://art/scripts/smg.tres",
	"spas12": "res://art/scripts/shotgun.tres",
	"barrett_m82": "res://art/scripts/sniper.tres",
	# --- one-handed: pair any two of these (or with the MP5) to dual wield with Q ---
	"glock": "res://art/scripts/glock.tres",
	"desert_eagle": "res://art/scripts/desert_eagle.tres",
	"uzi": "res://art/scripts/uzi.tres",
	"colt_python": "res://art/scripts/revolver.tres",
	# --- two-handed ---
	"m4a1": "res://art/scripts/m4a1.tres",
	"m249": "res://art/scripts/m249.tres",
	"thompson": "res://art/scripts/thompson.tres",
	"m16a4": "res://art/scripts/m16a4.tres",
	"svd_dragunov": "res://art/scripts/svd_dragunov.tres",
	"rpg7": "res://art/scripts/rpg7.tres",
	"double_barrel": "res://art/scripts/double_barrel.tres",
	# --- ideas for later: "katana", "longbow", "crossbow", "plasma_rifle"...
}

static var _cache: Dictionary = {}


static func get_weapon(id: String) -> WeaponData:
	if _cache.has(id):
		return _cache[id]
	if not PATHS.has(id) or not ResourceLoader.exists(PATHS[id]):
		return null
	var w := load(PATHS[id]) as WeaponData
	_cache[id] = w
	return w


# Every weapon, or only those of one era ("Modern", "Futuristic", "Medieval"...).
static func all(era := "") -> Array[WeaponData]:
	var out: Array[WeaponData] = []
	for id in PATHS:
		var w := get_weapon(id)
		if w != null and (era == "" or w.era == era):
			out.append(w)
	return out


static func by_category(category: String, era := "") -> Array[WeaponData]:
	var out: Array[WeaponData] = []
	for w in all(era):
		if w.category == category:
			out.append(w)
	return out
