class_name LanMenu
extends CanvasLayer
## LAN multiplayer menus: MAIN (host / join) -> HOST SETUP or JOIN -> LOBBY. Built from code like the rest of the
## project's menus, large touch-friendly buttons, and it resizes with the window (phones included).

signal back_pressed


## Tap-to-cycle setting button with the small part of the OptionButton API this menu uses.
class CycleChoice extends Button:
	signal item_selected(index: int)
	var selected := 0
	var _names: PackedStringArray = PackedStringArray()
	var _meta: Array = []
	var item_count: int:
		get:
			return _names.size()

	func _init() -> void:
		alignment = HORIZONTAL_ALIGNMENT_LEFT
		pressed.connect(_on_pressed)

	func add_item(label: String) -> void:
		_names.append(label)
		_meta.append(null)
		if _names.size() == 1:
			select(0)

	func set_item_metadata(index: int, value: Variant) -> void:
		_meta[index] = value

	func get_item_metadata(index: int) -> Variant:
		return _meta[index]

	## Like OptionButton.select(): shows the value, does NOT emit item_selected.
	func select(index: int) -> void:
		if _names.is_empty():
			return
		selected = clampi(index, 0, _names.size() - 1)
		text = "%s   ›" % _names[selected]

	func _on_pressed() -> void:
		if _names.size() < 2:
			return
		select((selected + 1) % _names.size())
		item_selected.emit(selected)


## Whole-number  [ - ]  value  [ + ]  control used instead of SpinBox. A SpinBox needs mouse input (and its text box
## never takes a finger when emulate_mouse_from_touch is off), so on a phone it could not be changed. Hold a button
## to repeat. Same small API as the SpinBox it replaces: value, value_changed, editable.
class Stepper extends HBoxContainer:
	signal value_changed(value: float)
	var min_value := 1
	var max_value := 10
	var minus: Button
	var plus: Button
	var readout: Label
	var value: float = 1.0:
		set(v):
			value = clampf(roundf(v), float(min_value), float(max_value))
			_refresh()
	var editable := true:
		set(e):
			editable = e
			if minus != null:
				minus.disabled = not e
				plus.disabled = not e
	var _held := 0
	var _hold_t := 0.0
	var _repeated := false

	func _init() -> void:
		add_theme_constant_override("separation", 8)
		minus = Button.new()
		minus.text = "-"
		minus.custom_minimum_size = Vector2(64, 46)
		readout = Label.new()
		readout.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		readout.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		readout.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		readout.custom_minimum_size = Vector2(60, 46)
		plus = Button.new()
		plus.text = "+"
		plus.custom_minimum_size = Vector2(64, 46)
		add_child(minus)
		add_child(readout)
		add_child(plus)
		minus.button_down.connect(_down.bind(-1))
		plus.button_down.connect(_down.bind(1))
		minus.pressed.connect(_tap.bind(-1))
		plus.pressed.connect(_tap.bind(1))

	func setup(minv: int, maxv: int, start: int) -> void:
		min_value = minv
		max_value = maxv
		value = float(start)

	func _refresh() -> void:
		if readout != null:
			readout.text = str(int(value))

	func _down(dir: int) -> void:
		_held = dir
		_hold_t = 0.45
		_repeated = false

	func _tap(dir: int) -> void:
		if _repeated:
			return                              # a hold already stepped; the release must not add one more
		_step(dir)

	func _step(dir: int) -> void:
		var nv := clampf(value + float(dir), float(min_value), float(max_value))
		if nv != value:
			value = nv
			value_changed.emit(value)

	func _process(delta: float) -> void:
		if _held == 0:
			return
		var b: Button = minus if _held < 0 else plus
		if b.disabled or b.get_draw_mode() != BaseButton.DRAW_PRESSED:
			_held = 0
			return
		_hold_t -= delta
		if _hold_t <= 0.0:
			_hold_t = 0.07
			_repeated = true
			_step(_held)


const MapRegistry = preload("res://art/scripts/map_registry.gd")

const C_TEXT := UITheme.ON_SURFACE
const C_DIM := UITheme.ON_VARIANT
const C_ERR := UITheme.ERROR
const C_OK := UITheme.PRIMARY

var _dim: ColorRect
var _panel: PanelContainer
var _scroll: ScrollContainer
var _screens := {}                  # name -> VBoxContainer
var _screen := "main"
var _syncing := false

# main
var _name_edit: LineEdit
# host
var _h_room: LineEdit
var _h_map: CycleChoice
var _h_max: Stepper
var _h_kills: Stepper
var _h_err: Label
# join
var _j_list: VBoxContainer
var _j_ip: LineEdit
var _j_port: LineEdit
var _j_status: Label
var _j_join: Button
var _j_search_hint: Label
# lobby
var _l_title: Label
var _l_addr: Label
var _l_players: VBoxContainer
var _l_map: CycleChoice
var _l_max: Stepper
var _l_kills: Stepper
var _l_look_row: HBoxContainer              # colour swatches
var _l_look_btns: Array[Button] = []
var _l_name: LineEdit
var _l_time: CycleChoice
var _l_wrate: CycleChoice
var _l_trate: CycleChoice
var _h_time: CycleChoice
var _h_wrate: CycleChoice
var _h_trate: CycleChoice
var _l_start: Button
var _l_msg: Label
var _l_hint: Label

# touch scrolling (the project turns emulate_mouse_from_touch off, so the ScrollContainer never sees a finger drag)
const DRAG_THRESHOLD := 12.0         # px a finger must travel before it counts as a scroll, not a tap
var _touch_id := -1
var _touch_travel := 0.0
var _touch_scrolling := false
var _frac := 0.0
var _inertia := 0.0                  # px/s
var _cancelled: Array[BaseButton] = []


func _ready() -> void:
	layer = 105
	process_mode = Node.PROCESS_MODE_ALWAYS
	_dim = ColorRect.new()
	_dim.color = Color(UITheme.SCRIM.r, UITheme.SCRIM.g, UITheme.SCRIM.b, 0.92)
	_dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_dim)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	_panel = PanelContainer.new()
	_panel.add_theme_stylebox_override("panel", _panel_style())
	center.add_child(_panel)
	_scroll = ScrollContainer.new()
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_panel.add_child(_scroll)
	var holder := MarginContainer.new()
	holder.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll.add_child(holder)
	var stack := VBoxContainer.new()
	stack.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	holder.add_child(stack)

	_build_main(stack)
	_build_host(stack)
	_build_join(stack)
	_build_lobby(stack)

	Net.lobby_updated.connect(_on_lobby_updated)
	Net.status_changed.connect(_on_status)
	Net.join_failed.connect(_on_join_failed)
	Net.chat_notice.connect(_on_notice)
	Net.discovery.hosts_changed.connect(_refresh_hosts)
	get_viewport().size_changed.connect(_fit)
	_fit()
	show_screen("main")


func _fit() -> void:
	var vp := get_viewport().get_visible_rect().size
	_panel.custom_minimum_size = Vector2(clampf(vp.x - 32.0, 300.0, 600.0), 0.0)
	_scroll.custom_minimum_size = Vector2(clampf(vp.x - 90.0, 260.0, 540.0), clampf(vp.y - 90.0, 260.0, 640.0))


# ------------------------------------------------------------------ touch scrolling
func _input(event: InputEvent) -> void:
	if not visible or _scroll == null:
		return
	if event is InputEventScreenTouch:
		var te := event as InputEventScreenTouch
		if te.pressed:
			if _touch_id == -1 and _scroll.get_global_rect().has_point(te.position):
				_touch_id = te.index
				_touch_travel = 0.0
				_touch_scrolling = false
				_inertia = 0.0
				_frac = 0.0
		elif te.index == _touch_id:
			_touch_id = -1
			if not _touch_scrolling:
				_inertia = 0.0
				_tap_text_fields(te.position)
	elif event is InputEventScreenDrag:
		var de := event as InputEventScreenDrag
		if de.index != _touch_id:
			return
		_touch_travel += absf(de.relative.y)
		if not _touch_scrolling and _touch_travel >= DRAG_THRESHOLD:
			_touch_scrolling = true
			_cancel_pressed_buttons()        # the finger started on a button: scrolling must not also press it
		if _touch_scrolling:
			_scroll_by(-de.relative.y)
			_inertia = -de.velocity.y
			get_viewport().set_input_as_handled()


func _tap_text_fields(pos: Vector2) -> void:
	# A finger tap on a text box focuses it and opens the phone keyboard; a tap anywhere else closes the keyboard.
	var hit: LineEdit = null
	for n in _scroll.find_children("*", "LineEdit", true, false):
		var le := n as LineEdit
		if le != null and le.is_visible_in_tree() and le.editable and le.get_global_rect().has_point(pos):
			hit = le
			break
	var focused := get_viewport().gui_get_focus_owner()
	if hit != null:
		hit.grab_focus()
		hit.edit()
	elif focused is LineEdit:
		focused.release_focus()


func _cancel_pressed_buttons() -> void:
	for n in _scroll.find_children("*", "BaseButton", true, false):
		var b := n as BaseButton
		if b != null and not b.disabled and b.get_draw_mode() == BaseButton.DRAW_PRESSED:
			b.disabled = true                # disabling a held button cancels the press
			_cancelled.append(b)


func _process(delta: float) -> void:
	if not _cancelled.is_empty():
		for b in _cancelled:
			if is_instance_valid(b):
				b.disabled = false
		_cancelled.clear()
	if _touch_id != -1 or absf(_inertia) < 25.0 or _scroll == null:
		return
	var before := _scroll.scroll_vertical
	_scroll_by(_inertia * delta)
	if _scroll.scroll_vertical == before:
		_inertia = 0.0                       # hit the top or bottom
	else:
		_inertia *= exp(-5.0 * delta)


func _scroll_by(px: float) -> void:
	_frac += px
	var whole := int(_frac)
	_frac -= float(whole)
	if whole != 0:
		_scroll.scroll_vertical += whole


# ------------------------------------------------------------------ public
func open() -> void:
	visible = true
	if Net.phase == Net.Phase.LOBBY:
		show_screen("lobby")
	else:
		show_screen("main")


func close() -> void:
	visible = false
	Net.discovery.stop_searching()


func show_screen(name: String) -> void:
	_screen = name
	for k in _screens:
		_screens[k].visible = k == name
	if name == "join":
		Net.discovery.start_searching()
		_j_search_hint.text = "Looking for games on this network ..." if Net.discovery.search_ok else "Automatic search is unavailable here: type the host's IP below."
		_refresh_hosts()
	else:
		Net.discovery.stop_searching()
	if name == "lobby":
		_refresh_lobby()
	_scroll.scroll_vertical = 0
	if _screens.has(name):
		UITheme.fade_in(_screens[name], 0.16)


# ------------------------------------------------------------------ styling helpers
func _panel_style() -> StyleBoxFlat:
	return UITheme.panel_box(20, 18)


# Kept for the swatch / readout boxes below: a soft tonal box (no outline).
func _btn_style(color: Color) -> StyleBoxFlat:
	return UITheme.box(color, 18, false, 14, 8)


func _button(text: String, color := Color("253b4b"), height := 56.0) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, height)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("font_size", 18)
	UITheme.style_button(b, UITheme.role_of(color))
	return b


func _label(text: String, size := 16, color := C_TEXT, wrap := true) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if wrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size = Vector2(220, 0)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l


func _heading(text: String, sub := "") -> Control:
	var box := VBoxContainer.new()
	var h := _label(text, 26, C_TEXT)
	h.add_theme_font_override("font", UITheme.font(true))
	h.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(h)
	if sub != "":
		var s := _label(sub, 14, C_DIM)
		s.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(s)
	box.add_child(HSeparator.new())
	return box


func _line_edit(text: String, placeholder: String, max_len := 24) -> LineEdit:
	var e := LineEdit.new()
	e.text = text
	e.placeholder_text = placeholder
	e.max_length = max_len
	e.custom_minimum_size = Vector2(0, 46)
	e.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	e.add_theme_font_size_override("font_size", 18)
	e.text_submitted.connect(func(_t: String) -> void: e.release_focus())     # keyboard "done" closes it
	return e


func _row(label_text: String, control: Control) -> HBoxContainer:
	var r := HBoxContainer.new()
	r.add_theme_constant_override("separation", 10)
	var l := _label(label_text, 16, C_DIM, false)
	l.custom_minimum_size = Vector2(142, 0)
	l.size_flags_horizontal = Control.SIZE_FILL
	r.add_child(l)
	control.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	r.add_child(control)
	return r


func _screen_box(name: String, parent: Control) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(v)
	_screens[name] = v
	return v


func _map_option() -> CycleChoice:
	var o := _cycle_button()
	for info in MapRegistry.all_maps():
		o.add_item(str(info["name"]))
		o.set_item_metadata(o.item_count - 1, str(info["id"]))
	return o


func _choice(names: Array) -> CycleChoice:
	var o := _cycle_button()
	for n in names:
		o.add_item(str(n))
	return o


# A setting you change by TAPPING it (it steps to the next value). Used instead of OptionButton: the project
# turns emulate_mouse_from_touch off, so a drop-down's pop-up list never receives the finger and the menu got stuck.
func _cycle_button() -> CycleChoice:
	var o := CycleChoice.new()
	o.custom_minimum_size = Vector2(0, 46)
	o.add_theme_font_size_override("font_size", 16)
	UITheme.style_button(o, "field")
	return o


func _time_names() -> Array:
	var out: Array = []
	for m in Net.TIME_OPTIONS:
		out.append("No limit" if m == 0 else "%d min" % m)
	return out


func _swatch_style(c: Color, selected: bool) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = c
	sb.set_corner_radius_all(23)                # round colour dots
	sb.set_border_width_all(4 if selected else 0)
	sb.border_color = Color.WHITE
	return sb


func _map_index(o: CycleChoice, map_id: String) -> int:
	for i in o.item_count:
		if str(o.get_item_metadata(i)) == map_id:
			return i
	return 0


func _spin(minv: int, maxv: int, value: int) -> Stepper:
	var st := Stepper.new()
	st.setup(minv, maxv, value)
	st.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for b in [st.minus, st.plus]:
		b.add_theme_font_size_override("font_size", 24)
		UITheme.style_button(b, "tonal")
	st.readout.add_theme_font_size_override("font_size", 19)
	st.readout.add_theme_font_override("font", UITheme.font(true))
	st.readout.add_theme_color_override("font_color", C_TEXT)
	st.readout.add_theme_stylebox_override("normal", UITheme.box(UITheme.SURFACE_2, 18, false, 10, 6))
	return st


# ------------------------------------------------------------------ MAIN
func _build_main(parent: Control) -> void:
	var v := _screen_box("main", parent)
	v.add_child(_heading("MULTIPLAYER", "Play with friends on the same Wi-Fi. No internet needed."))
	_name_edit = _line_edit(Net.local_name, "Your name", 16)
	_name_edit.text_changed.connect(func(t: String) -> void: Net.set_my_name(t))
	v.add_child(_row("YOUR NAME", _name_edit))
	var host := _button("HOST GAME", Color("2f5a3c"), 66)
	host.pressed.connect(func() -> void: show_screen("host"))
	v.add_child(host)
	var join := _button("JOIN GAME", Color("2f4f6b"), 66)
	join.pressed.connect(func() -> void: show_screen("join"))
	v.add_child(join)
	var back := _button("BACK")
	back.pressed.connect(func() -> void: back_pressed.emit())
	v.add_child(back)
	var notes := _label("Everyone must be on the same Wi-Fi (not a guest network) and run the same version of the game. Host: allow UDP %d in your firewall." % Net.PORT, 13, C_DIM)
	v.add_child(notes)


# ------------------------------------------------------------------ HOST SETUP
func _build_host(parent: Control) -> void:
	var v := _screen_box("host", parent)
	v.add_child(_heading("HOST A GAME", "You are the match authority"))
	_h_room = _line_edit("", "Room name (optional)", 24)
	v.add_child(_row("ROOM", _h_room))
	_h_map = _map_option()
	v.add_child(_row("MAP", _h_map))
	_h_max = _spin(Net.MIN_PLAYERS, Net.MAX_PLAYERS_LIMIT, Net.DEFAULT_MAX_PLAYERS)
	v.add_child(_row("MAX PLAYERS", _h_max))
	_h_kills = _spin(1, 50, Net.DEFAULT_KILL_LIMIT)
	v.add_child(_row("KILLS TO WIN", _h_kills))
	_h_time = _choice(_time_names())
	_h_time.select(Net.TIME_OPTIONS.find(Net.DEFAULT_TIME_MIN))
	v.add_child(_row("TIME LIMIT", _h_time))
	_h_wrate = _choice(Net.WEAPON_RATE_NAMES)
	_h_wrate.select(Net.DEFAULT_WEAPON_RATE)
	v.add_child(_row("WEAPON SPAWNS", _h_wrate))
	_h_trate = _choice(Net.THROW_RATE_NAMES)
	_h_trate.select(Net.DEFAULT_THROW_RATE)
	v.add_child(_row("THROWABLES", _h_trate))
	v.add_child(_label("Playing on a phone hotspot? Turn the hotspot on first, then tap CREATE LOBBY. Friends connect to your hotspot's Wi-Fi and tap JOIN GAME: your game shows up in their list, no IP needed.", 14, C_OK))
	_h_err = _label("", 15, C_ERR)
	v.add_child(_h_err)
	var create := _button("CREATE LOBBY", Color("2f5a3c"), 62)
	create.pressed.connect(_on_create_pressed)
	v.add_child(create)
	var back := _button("BACK")
	back.pressed.connect(func() -> void: show_screen("main"))
	v.add_child(back)


func _on_create_pressed() -> void:
	_h_err.text = ""
	var map_id := str(_h_map.get_item_metadata(_h_map.selected))
	var err := Net.host_game(_h_room.text, map_id, int(_h_max.value), int(_h_kills.value), Net.PORT,
		{"time_limit": Net.TIME_OPTIONS[_h_time.selected], "weapon_rate": _h_wrate.selected, "throwable_rate": _h_trate.selected})
	if err != "":
		_h_err.text = err
		return
	show_screen("lobby")


# ------------------------------------------------------------------ JOIN
func _build_join(parent: Control) -> void:
	var v := _screen_box("join", parent)
	v.add_child(_heading("JOIN A GAME", "Connect to the host's Wi-Fi / hotspot first, then pick the game below"))
	_j_search_hint = _label("", 14, C_DIM)
	v.add_child(_j_search_hint)
	_j_list = VBoxContainer.new()
	_j_list.add_theme_constant_override("separation", 8)
	v.add_child(_j_list)
	v.add_child(HSeparator.new())
	v.add_child(_label("Not listed? Type the host's address (shown on the host's lobby screen):", 14, C_DIM))
	_j_ip = _line_edit(Net.last_ip, "IP address, e.g. 192.168.1.23", 45)
	v.add_child(_row("IP", _j_ip))
	_j_port = _line_edit(str(Net.last_port), "Port", 5)
	v.add_child(_row("PORT", _j_port))
	_j_status = _label("", 15, C_DIM)
	v.add_child(_j_status)
	_j_join = _button("JOIN", Color("2f4f6b"), 62)
	_j_join.pressed.connect(_on_join_pressed)
	v.add_child(_j_join)
	var back := _button("BACK")
	back.pressed.connect(_on_join_back)
	v.add_child(back)


func _on_join_back() -> void:
	Net.cancel_join()
	_j_status.text = ""
	_j_join.disabled = false
	show_screen("main")


func _on_join_pressed() -> void:
	var port := int(_j_port.text) if _j_port.text.is_valid_int() else -1
	_start_join(_j_ip.text, port)


func _start_join(ip: String, port: int) -> void:
	_j_status.add_theme_color_override("font_color", C_DIM)
	_j_status.text = "Connecting ..."
	_j_join.disabled = true
	Net.join_game(ip, port)


func _refresh_hosts() -> void:
	if _j_list == null:
		return
	for c in _j_list.get_children():
		c.queue_free()
	var keys: Array = Net.discovery.hosts.keys()
	keys.sort()
	if keys.is_empty():
		var none := _label("No games found yet ...", 15, C_DIM)
		_j_list.add_child(none)
		return
	for k in keys:
		var h: Dictionary = Net.discovery.hosts[k]
		var full: bool = int(h["players"]) >= int(h["max"])
		var b := _button("%s\n%s   %d/%d players   %s:%d" % [h["room"], h["map"], h["players"], h["max"], h["ip"], h["port"]], Color("2f4f6b"), 66)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.add_theme_font_size_override("font_size", 16)
		if h["locked"]:
			b.text += "   (match running)"
		b.disabled = h["locked"] or full or Net.mode != Net.Mode.OFFLINE
		var ip: String = h["ip"]
		var port: int = h["port"]
		b.pressed.connect(func() -> void:
			_j_ip.text = ip
			_j_port.text = str(port)
			_start_join(ip, port))
		_j_list.add_child(b)


func _on_join_failed(reason: String) -> void:
	if _j_status == null:
		return
	_j_join.disabled = false
	_j_status.add_theme_color_override("font_color", C_ERR)
	_j_status.text = reason
	if _screen != "join":
		show_screen("join")


func _on_status(text: String) -> void:
	if _screen == "join" and _j_status != null:
		_j_status.add_theme_color_override("font_color", C_DIM)
		_j_status.text = text
	if _l_msg != null and _screen == "lobby":
		_l_hint.text = text


# ------------------------------------------------------------------ LOBBY
func _build_lobby(parent: Control) -> void:
	var v := _screen_box("lobby", parent)
	_l_title = _label("LOBBY", 26, C_TEXT)
	_l_title.add_theme_font_override("font", UITheme.font(true))
	_l_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(_l_title)
	_l_addr = _label("", 15, C_OK)
	_l_addr.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(_l_addr)
	v.add_child(HSeparator.new())
	v.add_child(_label("PLAYERS", 15, C_DIM))
	_l_players = VBoxContainer.new()
	_l_players.add_theme_constant_override("separation", 6)
	v.add_child(_l_players)
	v.add_child(HSeparator.new())
	v.add_child(_label("MATCH SETTINGS (host controls these)", 15, C_DIM))
	_l_map = _map_option()
	_l_map.item_selected.connect(func(i: int) -> void:
		if not _syncing:
			Net.host_set_map(str(_l_map.get_item_metadata(i))))
	v.add_child(_row("MAP", _l_map))
	_l_max = _spin(Net.MIN_PLAYERS, Net.MAX_PLAYERS_LIMIT, Net.DEFAULT_MAX_PLAYERS)
	_l_max.value_changed.connect(func(val: float) -> void:
		if not _syncing:
			Net.host_set_max_players(int(val)))
	v.add_child(_row("MAX PLAYERS", _l_max))
	_l_kills = _spin(1, 50, Net.DEFAULT_KILL_LIMIT)
	_l_kills.value_changed.connect(func(val: float) -> void:
		if not _syncing:
			Net.host_set_kill_limit(int(val)))
	v.add_child(_row("KILLS TO WIN", _l_kills))
	_l_time = _choice(_time_names())
	_l_time.item_selected.connect(func(i: int) -> void:
		if not _syncing:
			Net.host_set_time_limit(Net.TIME_OPTIONS[i]))
	v.add_child(_row("TIME LIMIT", _l_time))
	_l_wrate = _choice(Net.WEAPON_RATE_NAMES)
	_l_wrate.item_selected.connect(func(i: int) -> void:
		if not _syncing:
			Net.host_set_weapon_rate(i))
	v.add_child(_row("WEAPON SPAWNS", _l_wrate))
	_l_trate = _choice(Net.THROW_RATE_NAMES)
	_l_trate.item_selected.connect(func(i: int) -> void:
		if not _syncing:
			Net.host_set_throwable_rate(i))
	v.add_child(_row("THROWABLES", _l_trate))
	v.add_child(HSeparator.new())
	v.add_child(_label("YOU", 15, C_DIM))
	_l_name = _line_edit(Net.local_name, "Your name", 16)
	_l_name.text_submitted.connect(func(t: String) -> void: Net.set_my_name(t))
	_l_name.focus_exited.connect(func() -> void: Net.set_my_name(_l_name.text))
	v.add_child(_row("NAME", _l_name))
	_l_look_row = HBoxContainer.new()
	_l_look_row.add_theme_constant_override("separation", 8)
	for i in Net.LOOKS.size():
		var b := Button.new()
		b.custom_minimum_size = Vector2(46, 46)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.tooltip_text = str(Net.LOOKS[i]["name"])
		b.pressed.connect(func() -> void: Net.set_my_look(i))
		_l_look_row.add_child(b)
		_l_look_btns.append(b)
	v.add_child(_row("COLOUR", _l_look_row))
	_l_msg = _label("", 14, C_DIM)
	v.add_child(_l_msg)
	_l_hint = _label("", 14, C_DIM)
	v.add_child(_l_hint)
	_l_start = _button("START MATCH", Color("2f5a3c"), 66)
	_l_start.pressed.connect(func() -> void: Net.host_start_match())
	v.add_child(_l_start)
	var leave := _button("LEAVE LOBBY", Color("6b2f2f"))
	leave.pressed.connect(func() -> void: Net.leave("You left the lobby."))
	v.add_child(leave)


func _on_lobby_updated() -> void:
	if _screen == "lobby" or (Net.phase == Net.Phase.LOBBY and visible):
		if _screen != "lobby":
			show_screen("lobby")
		else:
			_refresh_lobby()


func _on_notice(text: String) -> void:
	if _l_msg != null:
		_l_msg.text = text


func _refresh_lobby() -> void:
	if _l_title == null or Net.mode == Net.Mode.OFFLINE:
		return
	_syncing = true
	var s: Dictionary = Net.settings
	_l_title.text = str(s.get("room", "Arena")).to_upper()
	if Net.is_host():
		var ips := LanDiscovery.local_ipv4()
		var ip_text := ", ".join(ips) if not ips.is_empty() else "(no network address found: are you on Wi-Fi?)"
		_l_addr.text = "Friends join at   %s   port %d" % [ip_text, int(s.get("port", Net.PORT))]
		_l_hint.text = "" if Net.discovery.host_ok else "Automatic discovery is off (port busy): friends must type your IP."
	else:
		_l_addr.text = "Connected to %s" % ("%s:%d" % [Net.last_ip, Net.last_port])
		_l_hint.text = "Waiting for the host to start the match ..."
	for c in _l_players.get_children():
		c.queue_free()
	var ids: Array = Net.roster.keys()
	ids.sort()
	for id in ids:
		var r: Dictionary = Net.roster[id]
		var row := HBoxContainer.new()
		var tag := "HOST" if id == 1 else "READY"
		var you := "  (you)" if id == Net.my_id() else ""
		var dot := ColorRect.new()
		dot.color = Net.look_swatch(int(r["look"]))
		dot.custom_minimum_size = Vector2(18, 18)
		dot.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		row.add_child(dot)
		var n := _label("  %s%s" % [r["name"], you], 18, C_TEXT, false)
		n.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(n)
		var look := _label(str(Net.LOOKS[int(r["look"])]["name"]), 14, C_DIM, false)
		look.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		row.add_child(look)
		var st := _label("   " + tag, 14, C_OK if id == 1 else C_DIM, false)
		st.size_flags_horizontal = Control.SIZE_SHRINK_END
		row.add_child(st)
		_l_players.add_child(row)
	var cap := int(s.get("max_players", 4))
	_l_msg.text = "%d / %d players" % [Net.roster.size(), cap]
	_l_map.select(_map_index(_l_map, str(s.get("map_id", "abandoned_station"))))
	_l_max.value = cap
	_l_kills.value = int(s.get("kill_limit", 10))
	var host := Net.is_host()
	_l_map.disabled = not host
	_l_max.editable = host
	_l_kills.editable = host
	_l_start.visible = host
	_l_time.select(maxi(0, Net.TIME_OPTIONS.find(int(s.get("time_limit", Net.DEFAULT_TIME_MIN)))))
	_l_wrate.select(clampi(int(s.get("weapon_rate", Net.DEFAULT_WEAPON_RATE)), 0, Net.WEAPON_RATE_NAMES.size() - 1))
	_l_trate.select(clampi(int(s.get("throwable_rate", Net.DEFAULT_THROW_RATE)), 0, Net.THROW_RATE_NAMES.size() - 1))
	_l_time.disabled = not host
	_l_wrate.disabled = not host
	_l_trate.disabled = not host
	var mine: int = int(Net.roster.get(Net.my_id(), {}).get("look", Net.local_look))
	for i in _l_look_btns.size():
		var btn := _l_look_btns[i]
		var col := Net.look_swatch(i)
		var taken := Net.look_taken(i, Net.my_id())
		btn.disabled = taken
		btn.text = "X" if taken else ""
		btn.add_theme_stylebox_override("normal", _swatch_style(col, i == mine))
		btn.add_theme_stylebox_override("hover", _swatch_style(col.lightened(0.15), i == mine))
		btn.add_theme_stylebox_override("pressed", _swatch_style(col.lightened(0.3), true))
		btn.add_theme_stylebox_override("disabled", _swatch_style(col.darkened(0.5), false))
	if not _l_name.has_focus():
		_l_name.text = str(Net.roster.get(Net.my_id(), {}).get("name", Net.local_name))
	_syncing = false
