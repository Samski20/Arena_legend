class_name RemotePlayer
extends CharacterBody2D
## The local stand-in for another player's character (a "puppet").
##
## Every peer has one puppet per OTHER player. It is driven only by the state that player streams (position,
## velocity, aim, animation flags) and draws the normal PlayerRig, so remote players look and animate like the
## real thing. On the HOST the puppet is also that player's hit-box: bullets, blasts, mines and zones hit it with
## the same take_damage() / apply_status() / apply_stun() calls they use on a normal Player, and the puppet turns
## those into authoritative results (health, kills) and RPCs to the real owner (knockback, status, death...).
## On clients the puppet takes no damage at all: it is purely visual.

signal died(victim, killer)

# state flag bits (net_pack_state() in player.gd builds them, net_receive() reads them)
const F_JET := 1
const F_CROUCH := 2
const F_FLOOR := 4
const F_DEAD := 8
const F_DUAL := 16
const F_FLIP := 32
const F_FLIP_RIGHT := 64
const S_SMOKED := 128
const S_BURN := 256
const S_CRYO := 512
const S_POISON := 1024
const S_STUN := 2048
const S_EMP := 4096
const S_NOFLIGHT := 8192
const S_GRAVITY := 16384
const STATUS_BITS := {"smoked": S_SMOKED, "burn": S_BURN, "cryo": S_CRYO, "poison": S_POISON, "stun": S_STUN, "emp": S_EMP, "noflight": S_NOFLIGHT, "gravity": S_GRAVITY}

const INTERP_DELAY := 0.10           # we draw other players this far in the past so 20 Hz updates look smooth
const MAX_EXTRAPOLATE := 0.12
const AIM_REACH := 300.0
# same numbers as player.gd
const REGEN_DELAY := 3.0
const REGEN_RATE := 12.0
const BLOCK_DAMAGE_MULT := 0.2

var peer_id := 0
var display_name := ""
var look := 0
var max_health := 100
var health := 100
var is_dead := false
var last_attacker: Node = null
var blocking := false               # crouch shield (read by the shield maths and by StatusFX)
var crouching := false
var aim_dir := Vector2.RIGHT
var visuals: PlayerRig
var health_bar: ProgressBar
var name_label: Label
var _status := {}                   # type -> {"t": seconds left, "power": x, "src": Node}   (StatusFX reads this)
var _dot_accum := {}
var _time_since_hit := 0.0
var _regen_accum := 0.0
var _snaps: Array = []              # [{t, pos, vel, aim, flags}]
var _flags := 0
var _prev_flags := 0
var _ignore_until := 0.0            # after a teleport the old in-flight positions are ignored for a moment
var _hit_flash := 0.0
var _have_snap := false
var _dead_fade := 0.0


func _ready() -> void:
	add_to_group("player")           # spawners / out-of-bounds treat us like any other fighter
	add_to_group("net_puppet")
	collision_layer = 2              # bullets and blasts see us (they mask layer 2) ...
	collision_mask = 0               # ... but nobody collides with us physically: players pass through each other
	var shape := CollisionShape2D.new()
	var capsule := CapsuleShape2D.new()
	capsule.radius = 16.0
	capsule.height = 48.0            # identical to the Player scene's hit-box
	shape.shape = capsule
	add_child(shape)

	visuals = PlayerRig.new()
	visuals.name = "Visuals"
	visuals.scale = Vector2(0.45, 0.45)
	add_child(visuals)
	Net.apply_player_look(visuals, peer_id)

	health_bar = ProgressBar.new()
	health_bar.name = "HealthBar"
	health_bar.offset_left = -40.0
	health_bar.offset_top = -55.0
	health_bar.offset_right = 40.0
	health_bar.offset_bottom = -47.0
	health_bar.show_percentage = false
	health_bar.max_value = max_health
	health_bar.value = health
	health_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0, 0, 0, 0.92)
	bg.set_corner_radius_all(3)
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(1, 0.35, 0.1, 1)
	fill.set_corner_radius_all(3)
	health_bar.add_theme_stylebox_override("background", bg)
	health_bar.add_theme_stylebox_override("fill", fill)
	add_child(health_bar)

	name_label = Label.new()
	name_label.text = display_name
	name_label.position = Vector2(-70, -80)
	name_label.size = Vector2(140, 20)
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_label.add_theme_font_size_override("font_size", 14)
	name_label.add_theme_color_override("font_outline_color", Color.BLACK)
	name_label.add_theme_constant_override("outline_size", 5)
	name_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	name_label.add_theme_color_override("font_color", Net.look_swatch(look).lightened(0.35))   # name in the player's colour
	add_child(name_label)


func setup(id: int, pname: String, look_index: int) -> void:
	peer_id = id
	display_name = pname
	look = look_index
	name = "Puppet_%d" % id


# ------------------------------------------------------------------ incoming state
func net_receive(st: PackedFloat32Array) -> void:
	if st.size() < 7:
		return
	var now := Time.get_ticks_msec() / 1000.0
	if now < _ignore_until:
		return
	_snaps.append({"t": now, "pos": Vector2(st[0], st[1]), "vel": Vector2(st[2], st[3]), "aim": st[4], "flags": int(st[5])})
	if _snaps.size() > 14:
		_snaps.pop_front()
	_have_snap = true


func _process(delta: float) -> void:
	_hit_flash = maxf(0.0, _hit_flash - delta)
	if is_dead:
		_dead_fade += delta
		return
	if _have_snap:
		_sample(delta)
	_apply_status_visuals(delta)


func _sample(delta: float) -> void:
	var now := Time.get_ticks_msec() / 1000.0
	var t := now - INTERP_DELAY
	var a: Dictionary = _snaps[0]
	var b: Dictionary = _snaps[0]
	var found := false
	for i in range(_snaps.size() - 1):
		if _snaps[i]["t"] <= t and _snaps[i + 1]["t"] >= t:
			a = _snaps[i]
			b = _snaps[i + 1]
			found = true
			break
	var pos: Vector2
	var vel: Vector2
	if found:
		var span := maxf(float(b["t"]) - float(a["t"]), 0.0001)
		var f := clampf((t - float(a["t"])) / span, 0.0, 1.0)
		pos = (a["pos"] as Vector2).lerp(b["pos"], f)
		vel = (a["vel"] as Vector2).lerp(b["vel"], f)
	else:
		var last: Dictionary = _snaps[_snaps.size() - 1]
		if t > float(last["t"]):
			var ahead := minf(t - float(last["t"]), MAX_EXTRAPOLATE)
			pos = (last["pos"] as Vector2) + (last["vel"] as Vector2) * ahead     # a late packet: coast on its velocity
			vel = last["vel"]
		else:
			pos = _snaps[0]["pos"]                                                   # the very first packets
			vel = _snaps[0]["vel"]
		b = last
	global_position = pos
	velocity = vel
	_flags = int(b["flags"])
	var ang := float(b["aim"])
	aim_dir = Vector2.RIGHT.rotated(ang)
	crouching = (_flags & F_CROUCH) != 0
	blocking = crouching
	var jetting := (_flags & F_JET) != 0
	var on_floor := (_flags & F_FLOOR) != 0
	if (_flags & F_FLIP) != 0 and (_prev_flags & F_FLIP) == 0:
		visuals.start_flip(1.0 if (_flags & F_FLIP_RIGHT) != 0 else -1.0)
	_prev_flags = _flags
	var shoulder: Vector2 = visuals.aim_pivot.global_position
	visuals.update_visuals(vel, shoulder + aim_dir * AIM_REACH, jetting, on_floor, delta, crouching, blocking)
	while _snaps.size() > 3 and float(_snaps[1]["t"]) < t - 0.5:
		_snaps.pop_front()


## Status visuals. On clients the owner's flag bits drive them; on the host the puppet's own authoritative
## status table (set by zones) is used instead, so the flags must not keep refreshing it.
func _apply_status_visuals(delta: float) -> void:
	if not Net.is_host():
		for type in STATUS_BITS:
			if (_flags & int(STATUS_BITS[type])) != 0:
				_status[type] = {"t": 0.3, "power": 1.0, "src": null}
			elif _status.has(type):
				_status[type]["t"] = minf(float(_status[type]["t"]), 0.15)
	if not _status.is_empty():
		StatusFX.attach(self)
	var tint := Color(1, 1, 1)
	if _status.has("cryo"):
		tint = Color(0.65, 0.9, 1.3)
	elif _status.has("burn"):
		tint = Color(1.25, 0.8, 0.6) if int(Time.get_ticks_msec() / 120) % 2 == 0 else Color(1.1, 0.7, 0.5)
	elif _status.has("poison"):
		tint = Color(0.7, 1.15, 0.6)
	elif _status.has("stun"):
		tint = Color(1.4, 1.4, 0.8) if int(Time.get_ticks_msec() / 70) % 2 == 0 else Color(1, 1, 1)
	elif _status.has("emp"):
		tint = Color(0.8, 1.0, 1.4) if int(Time.get_ticks_msec() / 90) % 2 == 0 else Color(1.0, 1.1, 1.0)
	elif _status.has("noflight"):
		tint = Color(1.15, 1.1, 0.8)
	var smoked := _status.has("smoked")
	tint.a = 0.07 if smoked else 1.0
	visuals.modulate = tint
	modulate = Color(1, 0.3, 0.3) if _hit_flash > 0.0 else Color(1, 1, 1)
	health_bar.visible = not smoked and not is_dead
	name_label.visible = not smoked and not is_dead


# ------------------------------------------------------------------ equipment (reliable events from the owner)
func net_set_loadout(main: WeaponData, off: WeaponData, secondary: WeaponData, is_dual: bool, hip: Texture2D) -> void:
	if main != null:
		visuals.equip_weapon(main)
	if is_dual and off != null:
		visuals.equip_off_hand(off)
	else:
		visuals.unequip_off_hand()
	visuals.set_secondary(secondary)
	visuals.set_hip_throwable(hip)


func net_fire_fx(w: WeaponData, hand: int) -> void:
	if is_dead or w == null:
		return
	visuals.fire_effects(hand)
	GunAudio.shoot(self, w)


func net_set_health(hp: int, flash: bool) -> void:
	health = hp
	health_bar.value = hp
	if flash:
		_hit_flash = 0.1


func net_set_dead() -> void:
	if is_dead and not visible:
		return
	is_dead = true
	_status.clear()
	_dot_accum.clear()
	var tw := create_tween()
	tw.tween_property(self, "modulate:a", 0.0, 0.3)
	tw.tween_callback(func() -> void: visible = false)


func net_respawn(pos: Vector2) -> void:
	is_dead = false
	health = max_health
	health_bar.value = health
	_status.clear()
	_dot_accum.clear()
	_snaps.clear()
	_have_snap = false
	global_position = pos
	modulate = Color(1, 1, 1, 1)
	visible = true
	last_attacker = null
	_time_since_hit = 0.0
	_ignore_until = Time.get_ticks_msec() / 1000.0 + 0.25


# ------------------------------------------------------------------ the Player-shaped API that hits use (HOST only does anything)
func blast_center() -> Vector2:
	return global_position + Vector2(0, -18)


func _shield_covers(hit_direction: Vector2) -> bool:
	if not blocking:
		return false
	var from_dir := Vector2.ZERO
	if hit_direction != Vector2.ZERO:
		from_dir = -hit_direction.normalized()
	elif is_instance_valid(last_attacker) and last_attacker is Node2D:
		from_dir = (last_attacker.global_position - visuals.aim_pivot.global_position).normalized()
	else:
		return false
	return absf(aim_dir.angle_to(from_dir)) <= PlayerRig.SHIELD_HALF_ANGLE


func is_shielding_toward(world_point: Vector2) -> bool:
	if not blocking or is_dead:
		return false
	var to_point: Vector2 = world_point - visuals.aim_pivot.global_position
	if to_point.length() < 1.0:
		return true
	return absf(aim_dir.angle_to(to_point.normalized())) <= PlayerRig.SHIELD_HALF_ANGLE


func take_damage(amount, hit_direction := Vector2.ZERO, ignore_shield := false) -> void:
	if not Net.is_host() or is_dead:
		return
	_time_since_hit = 0.0
	if not ignore_shield and _shield_covers(hit_direction):
		amount = maxi(1, roundi(amount * BLOCK_DAMAGE_MULT))
		hit_direction *= 0.3
	health = maxi(health - int(amount), 0)
	health_bar.value = health
	_hit_flash = 0.1
	Net.game.host_puppet_hit(self, health, hit_direction)
	if health <= 0:
		_die()


func _die() -> void:
	if is_dead:
		return
	is_dead = true
	_status.clear()
	_dot_accum.clear()
	died.emit(self, last_attacker)           # net_match.gd scores the kill and schedules the respawn


func apply_status(type: String, duration: float, power := 1.0, source: Node = null) -> void:
	if not Net.is_host() or is_dead:
		return
	if _status.has(type):
		var cur: Dictionary = _status[type]
		cur["t"] = maxf(cur["t"], duration)
		cur["power"] = maxf(cur["power"], power)
		if source != null:
			cur["src"] = source
	else:
		_status[type] = {"t": duration, "power": power, "src": source}
	Net.game.host_send_status(peer_id, type, duration, power)       # the owner applies the movement effect to itself


func has_status(type: String) -> bool:
	return _status.has(type)


func apply_stun(duration: float, immunity := 1.0, source: Node = null) -> void:
	if not Net.is_host() or is_dead or duration <= 0.0:
		return
	Net.game.host_send_stun(peer_id, duration, immunity)


func net_gravity(center: Vector2, speed: float, radius: float, seconds: float) -> void:
	if Net.is_host() and not is_dead:
		Net.game.host_send_gravity(peer_id, center, speed, radius, seconds)


## Portal: the owner is moved by its own client, the host just tells it where.
func net_teleport(pos: Vector2) -> void:
	if not Net.is_host() or is_dead:
		return
	global_position = pos
	_snaps.clear()
	_ignore_until = Time.get_ticks_msec() / 1000.0 + 0.3
	Net.game.host_send_teleport(peer_id, pos)


func clear_statuses() -> void:
	_status.clear()
	_dot_accum.clear()


# ------------------------------------------------------------------ host-side upkeep: damage over time + regeneration
func _physics_process(delta: float) -> void:
	if not Net.is_host() or is_dead:
		return
	_time_since_hit += delta
	for type in _status.keys():
		if not _status.has(type):
			continue
		var s: Dictionary = _status[type]
		s["t"] -= delta
		if type == "burn" or type == "poison":
			_dot_accum[type] = float(_dot_accum.get(type, 0.0)) + float(s["power"]) * delta
			if _dot_accum[type] >= 1.0:
				var dmg := int(_dot_accum[type])
				_dot_accum[type] -= dmg
				if is_instance_valid(s["src"]) and s["src"] != self:
					last_attacker = s["src"]          # kill credit for the thrower
				take_damage(dmg, Vector2.ZERO, true)
				if is_dead:
					return
		if s["t"] <= 0.0:
			_status.erase(type)
			_dot_accum.erase(type)
	if _time_since_hit >= REGEN_DELAY and health < max_health:
		_regen_accum += REGEN_RATE * delta
		if _regen_accum >= 1.0:
			var gain := int(_regen_accum)
			_regen_accum -= gain
			health = mini(health + gain, max_health)
			health_bar.value = health
