class_name NetSpawn
extends RefCounted
## Spawn-point finder for network matches. It uses the REAL player's hit-box (capsule 16 x 48 around the node origin)
## and only checks the map's solid geometry (layer 1 bodies other than characters), so it is exact for the player
## and independent of where other players happen to stand (the host spreads them out by distance instead).

const BODY_RADIUS := 15.0          # the player capsule is 16; 1 px less so standing exactly on the floor is not an overlap
const BODY_HEIGHT := 46.0          # the player capsule is 48
const FOOT := 24.0                 # node origin -> sole of the foot
const RAY_UP := 120.0
const RAY_DOWN := 420.0
const MIN_NORMAL_Y := 0.62         # floors up to ~52 degrees
const WORLD_MASK := 1


static func _solid_ok(space: PhysicsDirectSpaceState2D, origin: Vector2, exclude: Array[RID]) -> bool:
	var shape := CapsuleShape2D.new()
	shape.radius = BODY_RADIUS
	shape.height = BODY_HEIGHT
	var q := PhysicsShapeQueryParameters2D.new()
	q.shape = shape
	q.transform = Transform2D(0.0, origin)
	q.collision_mask = WORLD_MASK
	q.collide_with_bodies = true
	q.collide_with_areas = false
	q.exclude = exclude
	for hit in space.intersect_shape(q, 8):
		if not (hit.collider is CharacterBody2D):
			return false
	return true


## The node-origin position that puts the player's feet on the floor under `hint`, or Vector2.INF.
static func resolve_column(space: PhysicsDirectSpaceState2D, hint: Vector2, exclude: Array[RID]) -> Vector2:
	var from := hint + Vector2(0.0, -RAY_UP)
	var ray := PhysicsRayQueryParameters2D.create(from, from + Vector2(0.0, RAY_UP + RAY_DOWN), WORLD_MASK, exclude)
	ray.collide_with_areas = false
	ray.hit_from_inside = false
	var hit := space.intersect_ray(ray)
	if hit.is_empty() or hit["collider"] is CharacterBody2D:
		return Vector2.INF
	var n: Vector2 = hit["normal"]
	if n.y > -MIN_NORMAL_Y:
		return Vector2.INF
	var ground: Vector2 = hit["position"]
	var origin := ground + Vector2(0.0, -(FOOT + 2.0))
	if not _solid_ok(space, origin, exclude):
		return Vector2.INF
	# room above the head so nobody spawns in a crawl space the jetpack can't use
	var head := ground + Vector2(0.0, -(FOOT * 2.0 + 60.0))
	var up_q := PhysicsRayQueryParameters2D.create(ground + Vector2(0, -10), head, WORLD_MASK, exclude)
	if not space.intersect_ray(up_q).is_empty():
		return Vector2.INF
	return origin


## Closest valid spot to `hint` (spirals sideways and up/down); Vector2.INF if the area has none.
static func resolve_near(space: PhysicsDirectSpaceState2D, hint: Vector2, exclude: Array[RID]) -> Vector2:
	var offsets: Array[float] = [0.0]
	for k in range(1, 25):
		offsets.append(float(k) * 30.0)
		offsets.append(float(-k) * 30.0)
	for lift in [0.0, -120.0, 120.0, -240.0, 240.0]:
		for dx in offsets:
			var s := resolve_column(space, hint + Vector2(dx, lift), exclude)
			if s != Vector2.INF:
				return s
	return Vector2.INF
