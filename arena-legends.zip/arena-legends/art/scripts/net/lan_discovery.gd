class_name LanDiscovery
extends Node
## LAN host discovery over UDP (no internet, no servers).
##
## HOST  : listens on DISCOVERY_PORT and answers "who is hosting?" queries with a small JSON description,
##         and also broadcasts the same description every couple of seconds.
## JOINER: broadcasts a query once a second (limited broadcast + each local /24 broadcast + loopback, so a host
##         running on the same computer is found too) and listens for replies / beacons.
##
## Discovery is a convenience only: routers with client isolation (guest Wi-Fi) or firewalls can block it, which
## is why the join screen also has a manual IP + port box.

const MAGIC := "ARENA_LEGENDS_LAN_V1"
const QUERY := "ARENA_LEGENDS_QUERY_V1"
const DISCOVERY_PORT := 24681        # hosts listen here (UDP)
const SEARCH_PORT := 24682           # joiners listen here for host beacons (UDP); falls back to a random port
const BEACON_EVERY := 2.0
const QUERY_EVERY := 1.0
const HOST_TTL := 6.0                # a host not heard from for this long disappears from the list

signal hosts_changed

var hosts := {}                      # "ip:port" -> {room, map, players, max, ip, port, locked, seen}
var host_ok := false                 # true when the host beacon socket is up
var search_ok := false

var _srv: PacketPeerUDP
var _cli: PacketPeerUDP
var _info_cb: Callable
var _beacon_t := 0.0
var _query_t := 0.0
var _searching := false
var _hosting := false
var _query_n := 0


# ---------------------------------------------------------------- host side
## info_cb returns a Dictionary: {room, map, players, max, port, locked}
func start_hosting(info_cb: Callable) -> void:
	stop_hosting()
	_info_cb = info_cb
	_srv = PacketPeerUDP.new()
	_srv.set_broadcast_enabled(true)
	var err := _srv.bind(DISCOVERY_PORT)
	host_ok = err == OK
	if not host_ok:
		push_warning("LanDiscovery: could not listen on UDP %d (error %d). Joiners must type the IP." % [DISCOVERY_PORT, err])
		_srv = null
	_hosting = true
	_beacon_t = 0.0
	set_process(true)


func stop_hosting() -> void:
	_hosting = false
	host_ok = false
	if _srv != null:
		_srv.close()
		_srv = null
	_update_processing()


# ---------------------------------------------------------------- joiner side
func start_searching() -> void:
	stop_searching()
	hosts.clear()
	_cli = PacketPeerUDP.new()
	_cli.set_broadcast_enabled(true)
	var err := _cli.bind(SEARCH_PORT)
	if err != OK:
		err = _cli.bind(0)                       # port taken (second game on this computer): any free port still gets replies
	search_ok = err == OK
	if not search_ok:
		push_warning("LanDiscovery: search socket failed (error %d)." % err)
		_cli = null
		return
	_searching = true
	_query_n = 0
	_query_t = 0.0
	set_process(true)
	hosts_changed.emit()


func stop_searching() -> void:
	_searching = false
	search_ok = false
	if _cli != null:
		_cli.close()
		_cli = null
	_update_processing()


func _update_processing() -> void:
	set_process(_hosting or _searching)


func _ready() -> void:
	set_process(false)


func _exit_tree() -> void:
	stop_hosting()
	stop_searching()


# ---------------------------------------------------------------- helpers
## Private IPv4 addresses of this device (what a friend would type to join).
static func local_ipv4() -> Array[String]:
	var out: Array[String] = []
	var fallback: Array[String] = []
	for a in IP.get_local_addresses():
		var s := str(a)
		if s.contains(":") or not s.is_valid_ip_address():
			continue                                  # IPv6 / garbage
		if s.begins_with("127.") or s.begins_with("169.254.") or s == "0.0.0.0":
			continue
		if s.begins_with("192.168.") or s.begins_with("10.") or _is_172_private(s):
			if not out.has(s):
				out.append(s)
		elif not fallback.has(s):
			fallback.append(s)
	if out.is_empty():
		return fallback
	return out


static func _is_172_private(s: String) -> bool:
	if not s.begins_with("172."):
		return false
	var parts := s.split(".")
	if parts.size() != 4:
		return false
	var second := int(parts[1])
	return second >= 16 and second <= 31


static func broadcast_targets() -> Array[String]:
	var out: Array[String] = ["255.255.255.255", "127.0.0.1"]
	for ip in local_ipv4():
		var p := ip.split(".")
		if p.size() == 4:
			var b := "%s.%s.%s.255" % [p[0], p[1], p[2]]       # assumes a /24, by far the most common home network
			if not out.has(b):
				out.append(b)
	return out


## Direct (unicast) query targets for phone-hotspot / odd networks where broadcasts do not arrive:
## the usual hotspot gateway addresses (.1 / .2 / .254) and the iOS hotspot's /28 broadcast, every second;
## plus every address of each local /24 now and then (254 tiny packets, still unicast so it works when broadcast is blocked).
static func unicast_targets(full_sweep: bool) -> Array[String]:
	var out: Array[String] = []
	var mine := local_ipv4()
	for ip in mine:
		var p := ip.split(".")
		if p.size() != 4:
			continue
		var base := "%s.%s.%s." % [p[0], p[1], p[2]]
		for last in [1, 2, 254]:
			var t := base + str(last)
			if t != ip and not out.has(t):
				out.append(t)
		if p[0] == "172" and p[1] == "20" and p[2] == "10":
			out.append("172.20.10.15")                    # iOS hotspot: 172.20.10.0/28
		if full_sweep:
			for last in range(1, 255):
				var t2 := base + str(last)
				if t2 != ip and not out.has(t2):
					out.append(t2)
	return out


func _process(delta: float) -> void:
	if _hosting and _srv != null:
		_serve_queries()
		_beacon_t -= delta
		if _beacon_t <= 0.0:
			_beacon_t = BEACON_EVERY
			_send_beacon()
	if _searching and _cli != null:
		_query_t -= delta
		if _query_t <= 0.0:
			_query_t = QUERY_EVERY
			_send_query()
		_read_replies()
		_expire()


func _info_json() -> String:
	var info: Dictionary = _info_cb.call() if _info_cb.is_valid() else {}
	info["magic"] = MAGIC
	return JSON.stringify(info)


func _serve_queries() -> void:
	while _srv.get_available_packet_count() > 0:
		var pkt := _srv.get_packet()
		var ip := _srv.get_packet_ip()
		var port := _srv.get_packet_port()
		if pkt.get_string_from_utf8() != QUERY:
			continue
		_srv.set_dest_address(ip, port)
		_srv.put_packet(_info_json().to_utf8_buffer())


func _send_beacon() -> void:
	var data := _info_json().to_utf8_buffer()
	for target in broadcast_targets():
		_srv.set_dest_address(target, SEARCH_PORT)
		_srv.put_packet(data)


func _send_query() -> void:
	var data := QUERY.to_utf8_buffer()
	for target in broadcast_targets():
		_cli.set_dest_address(target, DISCOVERY_PORT)
		_cli.put_packet(data)
	var sweep := _query_n < 3 or _query_n % 4 == 0           # full sweep right away, then every 4th second
	_query_n += 1
	for target in unicast_targets(sweep):
		_cli.set_dest_address(target, DISCOVERY_PORT)
		_cli.put_packet(data)


func _read_replies() -> void:
	var changed := false
	while _cli.get_available_packet_count() > 0:
		var pkt := _cli.get_packet()
		var ip := _cli.get_packet_ip()
		var parsed = JSON.parse_string(pkt.get_string_from_utf8())
		if typeof(parsed) != TYPE_DICTIONARY or parsed.get("magic", "") != MAGIC:
			continue
		var port := int(parsed.get("port", 0))
		if port <= 0 or port > 65535:
			continue
		var key := "%s:%d" % [ip, port]
		var entry := {
			"room": str(parsed.get("room", "Arena")).left(24),
			"map": str(parsed.get("map", "")).left(32),
			"players": int(parsed.get("players", 1)),
			"max": int(parsed.get("max", 4)),
			"locked": bool(parsed.get("locked", false)),
			"ip": ip, "port": port,
			"seen": Time.get_ticks_msec(),
		}
		if not hosts.has(key) or hosts[key]["room"] != entry["room"] or hosts[key]["players"] != entry["players"] \
				or hosts[key]["locked"] != entry["locked"] or hosts[key]["map"] != entry["map"]:
			changed = true
		hosts[key] = entry
	if changed:
		hosts_changed.emit()


func _expire() -> void:
	var now := Time.get_ticks_msec()
	var gone: Array = []
	for k in hosts:
		if now - int(hosts[k]["seen"]) > int(HOST_TTL * 1000.0):
			gone.append(k)
	for k in gone:
		hosts.erase(k)
	if not gone.is_empty():
		hosts_changed.emit()
