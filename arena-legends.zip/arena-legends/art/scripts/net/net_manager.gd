extends Node
## Net (autoload): LAN multiplayer connection + lobby layer. Godot high-level multiplayer API over ENet.
##
## Architecture (v1):
##   * The HOST is the match authority. Everyone else is a client of that host. Star topology, no relays.
##   * Each player drives their OWN character locally (movement and the jetpack feel exactly as offline) and
##     streams its state to the host; the host forwards it to the other clients (see net_match.gd).
##   * Everything that decides a result lives on the host: bullets / rockets / grenades that deal damage,
##     explosions, zones, mines, portals, health, kills, respawns, pickups, scores and the match timer.
##     Clients only get cosmetic copies and are TOLD their results (new health, knockback, status, respawn spot).
##   * This script owns the connection, the lobby roster, LAN discovery and the match life-cycle
##     (lobby -> loading -> countdown -> playing -> ended -> lobby). net_match.gd (child node "Game") owns the
##     in-match replication. Both are RPC hubs: the node path /root/Net/Game is identical on every peer.
##
## Port: UDP 24680 (game, ENet) and UDP 24681/24682 (optional LAN discovery).

const PORT := 24680
const PROTOCOL := 2           # 2: players also send their appearance code (_c_set_app)
const MAX_PLAYERS_LIMIT := 8
const MIN_PLAYERS := 2
const DEFAULT_MAX_PLAYERS := 4
const DEFAULT_KILL_LIMIT := 10
const JOIN_TIMEOUT := 8.0
const HELLO_TIMEOUT := 5.0
const LOAD_TIMEOUT := 25.0
const COUNTDOWN := 3.0
const ENDED_SECONDS := 8.0
const CFG_PATH := "user://lan.cfg"

enum Mode { OFFLINE, HOST, CLIENT }
enum Phase { OFFLINE, CONNECTING, LOBBY, LOADING, COUNTDOWN, PLAYING, ENDED }

## Character looks the lobby offers. They are PlayerRig loadout colour overrides (apply_loadout), so they use
## the existing customisation system. Index 0 = the stock "Sentinel" look.
const LOOKS := [
	{"name": "Sentinel", "colors": {}},
	{"name": "Crimson", "colors": {"helmet": Color("8a2f35"), "accent": Color("5e1f26"), "vest": Color("a8454c"), "uniform": Color("3e2226"), "pants": Color("3e2226"), "jetpack": Color("a8454c"), "glow": Color("ff6a5a"), "visor": Color("ffd0c8")}},
	{"name": "Verdant", "colors": {"helmet": Color("4c7a4a"), "accent": Color("34542f"), "vest": Color("5f9460"), "uniform": Color("27402a"), "pants": Color("27402a"), "jetpack": Color("5f9460"), "glow": Color("7dff9a"), "visor": Color("d3ffd8")}},
	{"name": "Amber", "colors": {"helmet": Color("a8782c"), "accent": Color("70501c"), "vest": Color("c9962f"), "uniform": Color("4a3a1c"), "pants": Color("4a3a1c"), "jetpack": Color("c9962f"), "glow": Color("ffc24d"), "visor": Color("fff0c2")}},
	{"name": "Violet", "colors": {"helmet": Color("6a4aa0"), "accent": Color("46307a"), "vest": Color("8566bd"), "uniform": Color("2f2548"), "pants": Color("2f2548"), "jetpack": Color("8566bd"), "glow": Color("c49cff"), "visor": Color("ecdcff")}},
	{"name": "Arctic", "colors": {"helmet": Color("9fb7c8"), "accent": Color("6f8798"), "vest": Color("c4d8e6"), "uniform": Color("56697a"), "pants": Color("56697a"), "jetpack": Color("c4d8e6"), "glow": Color("9fe8ff"), "visor": Color("ffffff")}},
]

## Host-chosen match options (shown in the lobby). Stored in `settings` as plain numbers / indexes.
const TIME_OPTIONS := [0, 2, 3, 5, 10, 15]                       # minutes; 0 = no time limit
const DEFAULT_TIME_MIN := 10
const WEAPON_RATE_NAMES := ["Rare", "Normal", "Frequent", "Plenty"]
const WEAPON_RATE_MULT := [0.5, 1.0, 2.0, 3.0]                   # how fast map guns come back
const DEFAULT_WEAPON_RATE := 1
const THROW_RATE_NAMES := ["Off", "Rare", "Normal", "Frequent", "Plenty"]
const THROW_RATE_MULT := [0.0, 0.5, 1.0, 2.0, 3.0]               # how often throwables appear
const DEFAULT_THROW_RATE := 2

signal status_changed(text: String)          # join progress / lobby info line
signal join_failed(reason: String)
signal lobby_updated                          # roster or settings changed
signal left(reason: String)                   # we are out of the game (the scene reloads right after)
signal phase_changed(phase: int)
signal chat_notice(text: String)              # short messages ("Sam joined", "Host left"...)

const NetGame = preload("res://art/scripts/net/net_match.gd")
const MapRegistry = preload("res://art/scripts/map_registry.gd")

var mode := Mode.OFFLINE
var phase := Phase.OFFLINE
var settings := {"room": "Arena", "map_id": "abandoned_station", "max_players": DEFAULT_MAX_PLAYERS, "kill_limit": DEFAULT_KILL_LIMIT,
	"time_limit": DEFAULT_TIME_MIN, "weapon_rate": DEFAULT_WEAPON_RATE, "throwable_rate": DEFAULT_THROW_RATE}
var roster := {}                              # peer id -> {name, look, loaded}
var game: Node                                # NetGame: in-match replication
var discovery: LanDiscovery
var notice := ""                              # shown once by the menu after we were thrown out of a game
var local_name := "Player"
var local_look := 0
var last_ip := ""
var last_port := PORT
var host_ip_list: Array[String] = []

var _hello_waiting := {}                      # peer id -> true while the host waits for its hello
var _load_started := 0.0
var _end_t := 0.0
var _joining_to := ""
var _join_token := 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS       # the lobby / match flow must run even if the offline menu paused the tree
	discovery = LanDiscovery.new()
	discovery.name = "Discovery"
	add_child(discovery)
	game = NetGame.new()
	game.name = "Game"
	add_child(game)
	_load_config()
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	set_process(false)


# ------------------------------------------------------------------ queries used everywhere
func is_host() -> bool:
	return mode == Mode.HOST


func is_client() -> bool:
	return mode == Mode.CLIENT


## True from the moment a match starts loading until it is over: gameplay scripts switch to network behaviour.
func match_active() -> bool:
	return mode != Mode.OFFLINE and phase >= Phase.LOADING


func my_id() -> int:
	return multiplayer.get_unique_id() if mode != Mode.OFFLINE else 1


func name_of(id: int) -> String:
	return str(roster.get(id, {}).get("name", "Player %d" % id))


func consume_notice() -> String:
	var n := notice
	notice = ""
	return n


func look_colors(index: int) -> Dictionary:
	return LOOKS[clampi(index, 0, LOOKS.size() - 1)]["colors"]


func map_name(map_id: String) -> String:
	var info: Dictionary = MapRegistry.get_map(map_id)
	return str(info.get("name", map_id))


func _set_phase(p: Phase) -> void:
	if phase == p:
		return
	phase = p
	phase_changed.emit(int(p))


# ------------------------------------------------------------------ config (name, last address, look)
func _load_config() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(CFG_PATH) == OK:
		local_name = str(cfg.get_value("lan", "name", ""))
		local_look = clampi(int(cfg.get_value("lan", "look", 0)), 0, LOOKS.size() - 1)
		last_ip = str(cfg.get_value("lan", "ip", ""))
		last_port = clampi(int(cfg.get_value("lan", "port", PORT)), 1, 65535)
	if local_name.strip_edges() == "":
		local_name = "Player%d" % (randi() % 900 + 100)


func save_config() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("lan", "name", local_name)
	cfg.set_value("lan", "look", local_look)
	cfg.set_value("lan", "ip", last_ip)
	cfg.set_value("lan", "port", last_port)
	cfg.save(CFG_PATH)


static func clean_name(raw: String) -> String:
	var s := raw.strip_edges().replace("\n", " ").replace("\t", " ")
	return s.left(16) if s != "" else "Player"


# ------------------------------------------------------------------ HOST
## Creates the room. Returns "" on success or a human readable error.
func host_game(room: String, map_id: String, max_players: int, kill_limit: int, port := PORT, extra := {}) -> String:
	if mode != Mode.OFFLINE:
		return "Already in a game."
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(port, MAX_PLAYERS_LIMIT - 1)
	if err != OK:
		var why := "port %d is probably already used (another copy of the game hosting?)" % port if err == ERR_CANT_CREATE else "error %d" % err
		return "Could not start the host: %s." % why
	multiplayer.multiplayer_peer = peer
	mode = Mode.HOST
	settings = {
		"room": clean_name(room) if room.strip_edges() != "" else "%s's Arena" % clean_name(local_name),
		"map_id": map_id if not MapRegistry.get_map(map_id).is_empty() else "abandoned_station",
		"max_players": clampi(max_players, MIN_PLAYERS, MAX_PLAYERS_LIMIT),
		"kill_limit": clampi(kill_limit, 1, 100),
		"time_limit": int(extra.get("time_limit", DEFAULT_TIME_MIN)) if int(extra.get("time_limit", DEFAULT_TIME_MIN)) in TIME_OPTIONS else DEFAULT_TIME_MIN,
		"weapon_rate": clampi(int(extra.get("weapon_rate", DEFAULT_WEAPON_RATE)), 0, WEAPON_RATE_MULT.size() - 1),
		"throwable_rate": clampi(int(extra.get("throwable_rate", DEFAULT_THROW_RATE)), 0, THROW_RATE_MULT.size() - 1),
		"port": port,
	}
	roster = {1: {"name": clean_name(local_name), "look": local_look, "loaded": false, "app": AppearanceStore.net_code()}}
	host_ip_list = LanDiscovery.local_ipv4()
	last_port = port
	save_config()
	_set_phase(Phase.LOBBY)
	discovery.start_hosting(_discovery_info)
	status_changed.emit("Hosting \"%s\" on port %d" % [settings["room"], port])
	lobby_updated.emit()
	return ""


func _discovery_info() -> Dictionary:
	return {
		"room": settings.get("room", "Arena"),
		"map": map_name(str(settings.get("map_id", ""))),
		"players": roster.size(),
		"max": int(settings.get("max_players", DEFAULT_MAX_PLAYERS)),
		"port": int(settings.get("port", PORT)),
		"locked": phase != Phase.LOBBY,
	}


## Host-only lobby edits. Clients have no way to call these (they are plain functions, not RPCs).
func host_set_map(map_id: String) -> void:
	if mode == Mode.HOST and phase == Phase.LOBBY and not MapRegistry.get_map(map_id).is_empty():
		settings["map_id"] = map_id
		_broadcast_lobby()


func host_set_max_players(n: int) -> void:
	if mode == Mode.HOST and phase == Phase.LOBBY:
		settings["max_players"] = clampi(n, maxi(MIN_PLAYERS, roster.size()), MAX_PLAYERS_LIMIT)
		_broadcast_lobby()


func host_set_kill_limit(n: int) -> void:
	if mode == Mode.HOST and phase == Phase.LOBBY:
		settings["kill_limit"] = clampi(n, 1, 100)
		_broadcast_lobby()


func host_set_time_limit(minutes: int) -> void:
	if mode == Mode.HOST and phase == Phase.LOBBY and minutes in TIME_OPTIONS:
		settings["time_limit"] = minutes
		_broadcast_lobby()


func host_set_weapon_rate(i: int) -> void:
	if mode == Mode.HOST and phase == Phase.LOBBY:
		settings["weapon_rate"] = clampi(i, 0, WEAPON_RATE_MULT.size() - 1)
		_broadcast_lobby()


func host_set_throwable_rate(i: int) -> void:
	if mode == Mode.HOST and phase == Phase.LOBBY:
		settings["throwable_rate"] = clampi(i, 0, THROW_RATE_MULT.size() - 1)
		_broadcast_lobby()


func host_set_room_name(room: String) -> void:
	if mode == Mode.HOST and phase == Phase.LOBBY and room.strip_edges() != "":
		settings["room"] = clean_name(room)
		_broadcast_lobby()


func set_my_look(index: int) -> void:
	index = clampi(index, 0, LOOKS.size() - 1)
	if mode == Mode.HOST:
		if look_taken(index, 1):
			return
		local_look = index
		roster[1]["look"] = local_look
		save_config()
		_broadcast_lobby()
	elif mode == Mode.CLIENT and phase == Phase.LOBBY:
		_c_set_look.rpc_id(1, index)             # the host decides (colours are unique per player)
	else:
		local_look = index
		save_config()


func set_my_name(n: String) -> void:
	local_name = clean_name(n)
	save_config()
	if mode == Mode.HOST and roster.has(1):
		roster[1]["name"] = _unique_name(local_name, 1)
		_broadcast_lobby()
	elif mode == Mode.CLIENT and phase == Phase.LOBBY:
		_c_set_name.rpc_id(1, local_name)


## Is this colour already worn by somebody else?
func look_taken(index: int, except_id := -1) -> bool:
	for id in roster:
		if id != except_id and int(roster[id]["look"]) == index:
			return true
	return false


func first_free_look(preferred: int, except_id := -1) -> int:
	preferred = clampi(preferred, 0, LOOKS.size() - 1)
	for k in LOOKS.size():
		var i := (preferred + k) % LOOKS.size()
		if not look_taken(i, except_id):
			return i
	return preferred


## The colour shown for a look in the lobby / name labels.
func look_swatch(index: int) -> Color:
	var c: Dictionary = LOOKS[clampi(index, 0, LOOKS.size() - 1)]["colors"]
	return c.get("vest", Color("7f93ad"))


func _unique_name(n: String, except_id: int) -> String:
	var base := clean_name(n)
	var out := base
	var k := 2
	while _name_taken_by_other(out, except_id):
		out = "%s %d" % [base.left(13), k]
		k += 1
	return out


func _name_taken_by_other(n: String, except_id: int) -> bool:
	for id in roster:
		if id != except_id and str(roster[id]["name"]) == n:
			return true
	return false


func _broadcast_lobby() -> void:
	lobby_updated.emit()
	if mode == Mode.HOST:
		_s_lobby.rpc(settings, roster)


# ------------------------------------------------------------------ JOIN
func join_game(ip: String, port := PORT) -> void:
	if mode != Mode.OFFLINE:
		join_failed.emit("Already in a game.")
		return
	ip = ip.strip_edges()
	if ip == "":
		join_failed.emit("Type the host's IP address (shown on the host's lobby screen).")
		return
	if port < 1 or port > 65535:
		join_failed.emit("The port must be between 1 and 65535.")
		return
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip, port)
	if err != OK:
		join_failed.emit("Could not start connecting to %s:%d (error %d). Check the address." % [ip, port, err])
		return
	multiplayer.multiplayer_peer = peer
	mode = Mode.CLIENT
	last_ip = ip
	last_port = port
	save_config()
	_set_phase(Phase.CONNECTING)
	_joining_to = "%s:%d" % [ip, port]
	status_changed.emit("Connecting to %s ..." % _joining_to)
	_join_token += 1
	var token := _join_token
	await get_tree().create_timer(JOIN_TIMEOUT).timeout
	if token == _join_token and phase == Phase.CONNECTING:
		_fail_join("No answer from %s. Check that the host is running, you are on the same Wi-Fi (guest networks often isolate devices), the IP is right and the host's firewall allows UDP %d." % [_joining_to, port])


func cancel_join() -> void:
	if phase == Phase.CONNECTING:
		_join_token += 1
		_reset_connection()


func _fail_join(reason: String) -> void:
	_join_token += 1
	_reset_connection()
	join_failed.emit(reason)


func _on_connected_to_server() -> void:
	var p := multiplayer.multiplayer_peer as ENetMultiplayerPeer
	if p != null and p.get_peer(1) != null:
		p.get_peer(1).set_timeout(32, 3000, 8000)          # notice a dead host in at most ~8 s instead of ~30 s
	status_changed.emit("Connected. Joining the lobby ...")
	_c_hello.rpc_id(1, local_name, local_look, PROTOCOL)


func _on_connection_failed() -> void:
	if mode == Mode.CLIENT and phase == Phase.CONNECTING:
		_fail_join("Could not connect to %s. Is the host running, on the same Wi-Fi, and is UDP %d open in its firewall?" % [_joining_to, last_port])


func _on_server_disconnected() -> void:
	if mode == Mode.CLIENT:
		leave("The host closed the game or the connection was lost.")


# ------------------------------------------------------------------ peers (host view)
func _on_peer_connected(id: int) -> void:
	if mode != Mode.HOST:
		return
	var p := multiplayer.multiplayer_peer as ENetMultiplayerPeer
	if p != null and p.get_peer(id) != null:
		p.get_peer(id).set_timeout(32, 3000, 8000)
	_hello_waiting[id] = true
	await get_tree().create_timer(HELLO_TIMEOUT).timeout
	if _hello_waiting.has(id):
		_hello_waiting.erase(id)
		if not roster.has(id):
			_kick(id)                                         # connected but never said hello: not our game


func _on_peer_disconnected(id: int) -> void:
	_hello_waiting.erase(id)
	if mode != Mode.HOST or not roster.has(id):
		return
	var who := name_of(id)
	roster.erase(id)
	game.peer_left(id)
	chat_notice.emit("%s left the game." % who)
	_s_notice.rpc("%s left the game." % who)
	_broadcast_lobby()
	if phase == Phase.LOADING:
		_check_all_loaded()


func _kick(id: int) -> void:
	var p := multiplayer.multiplayer_peer as ENetMultiplayerPeer
	if p != null and p.get_peer(id) != null:
		p.disconnect_peer(id)


# ------------------------------------------------------------------ lobby RPCs
@rpc("any_peer", "reliable")
func _c_hello(pname: String, look: int, proto: int) -> void:
	if mode != Mode.HOST:
		return
	var id := multiplayer.get_remote_sender_id()
	_hello_waiting.erase(id)
	if roster.has(id):
		return
	var reject := ""
	if proto != PROTOCOL:
		reject = "Game version mismatch (host %d, you %d). Everyone needs the same build." % [PROTOCOL, proto]
	elif phase != Phase.LOBBY:
		reject = "A match is already in progress. Try again when the host is back in the lobby."
	elif roster.size() >= int(settings["max_players"]):
		reject = "The room is full (%d/%d)." % [roster.size(), int(settings["max_players"])]
	if reject != "":
		_s_reject.rpc_id(id, reject)
		await get_tree().create_timer(0.3).timeout
		_kick(id)
		return
	var n := clean_name(pname)
	var base := n
	var k := 2
	while _name_taken(n):
		n = "%s %d" % [base.left(13), k]
		k += 1
	roster[id] = {"name": n, "look": first_free_look(look, id), "loaded": false, "app": ""}
	chat_notice.emit("%s joined." % n)
	_s_notice.rpc("%s joined." % n)
	_s_welcome.rpc_id(id, settings, roster)
	_broadcast_lobby()


func _name_taken(n: String) -> bool:
	for id in roster:
		if str(roster[id]["name"]) == n:
			return true
	return false


@rpc("any_peer", "reliable")
func _c_set_look(look: int) -> void:
	if mode != Mode.HOST or phase != Phase.LOBBY:
		return
	var id := multiplayer.get_remote_sender_id()
	if roster.has(id) and not look_taken(clampi(look, 0, LOOKS.size() - 1), id):
		roster[id]["look"] = clampi(look, 0, LOOKS.size() - 1)
	_broadcast_lobby()                           # (also tells a refused client what it really has)


## A player's look: a short JSON of ids. The host validates it (size, known ids) and re-publishes the clean version.
@rpc("any_peer", "reliable")
func _c_set_app(code: String) -> void:
	if mode != Mode.HOST or phase != Phase.LOBBY:
		return
	var id := multiplayer.get_remote_sender_id()
	if roster.has(id):
		var d := Appearance.decode(code)
		roster[id]["app"] = Appearance.encode(d["app"], d["cosmetic"], d["variant"])
		_broadcast_lobby()


## Draws peer `id`'s saved look on a rig; falls back to the stock look if the code is missing or invalid.
## The lobby colour only tints the glow trim, so players stay tell-apart-able but keep their own outfit.
func apply_player_look(rig: PlayerRig, id: int) -> void:
	var entry: Dictionary = roster.get(id, {})
	var code := str(entry.get("app", ""))
	if code != "":
		var d := Appearance.decode(code)
		rig.apply_appearance(Appearance.resolve(d["app"], d["cosmetic"], d["variant"]))
		var glow: Variant = look_colors(int(entry.get("look", 0))).get("glow", null)
		if glow is Color:
			rig.apply_loadout({"glow": glow})
	else:
		rig.apply_loadout(look_colors(int(entry.get("look", 0))))


@rpc("any_peer", "reliable")
func _c_set_name(pname: String) -> void:
	if mode != Mode.HOST or phase != Phase.LOBBY:
		return
	var id := multiplayer.get_remote_sender_id()
	if roster.has(id):
		roster[id]["name"] = _unique_name(pname, id)
		_broadcast_lobby()


@rpc("authority", "reliable")
func _s_welcome(s: Dictionary, r: Dictionary) -> void:
	settings = s
	roster = r
	local_look = int(roster.get(multiplayer.get_unique_id(), {}).get("look", local_look))
	_join_token += 1
	_set_phase(Phase.LOBBY)
	status_changed.emit("In lobby: %s" % settings.get("room", "Arena"))
	lobby_updated.emit()
	_c_set_app.rpc_id(1, AppearanceStore.net_code())          # tell the host what we look like (ids only, no pictures)


@rpc("authority", "reliable")
func _s_reject(reason: String) -> void:
	if mode == Mode.CLIENT and phase == Phase.CONNECTING:
		_fail_join(reason)


@rpc("authority", "reliable")
func _s_lobby(s: Dictionary, r: Dictionary) -> void:
	if mode != Mode.CLIENT:
		return
	settings = s
	roster = r
	lobby_updated.emit()


@rpc("authority", "reliable")
func _s_notice(text: String) -> void:
	if mode == Mode.CLIENT:
		chat_notice.emit(text)


# ------------------------------------------------------------------ match life-cycle
func host_can_start() -> String:
	if mode != Mode.HOST:
		return "Only the host can start the match."
	if phase != Phase.LOBBY:
		return "The match is already starting."
	return ""


func host_start_match() -> void:
	if host_can_start() != "":
		return
	_set_phase(Phase.LOADING)
	_load_started = Time.get_ticks_msec() / 1000.0
	for id in roster:
		roster[id]["loaded"] = false
	_s_prepare.rpc(settings)           # call_local: the host loads too
	set_process(true)


@rpc("authority", "call_local", "reliable")
func _s_prepare(s: Dictionary) -> void:
	settings = s
	_set_phase(Phase.LOADING)
	game.prepare(s)                    # tells the arena to load the map, then reports back via loaded()


## net_match.gd calls this when the local map + puppets are ready.
func loaded() -> void:
	if mode == Mode.HOST:
		if roster.has(1):
			roster[1]["loaded"] = true
		_check_all_loaded()
	elif mode == Mode.CLIENT:
		_c_loaded.rpc_id(1)


@rpc("any_peer", "reliable")
func _c_loaded() -> void:
	if mode != Mode.HOST or phase != Phase.LOADING:
		return
	var id := multiplayer.get_remote_sender_id()
	if roster.has(id):
		roster[id]["loaded"] = true
		_check_all_loaded()


func _check_all_loaded() -> void:
	if mode != Mode.HOST or phase != Phase.LOADING:
		return
	for id in roster:
		if not bool(roster[id]["loaded"]):
			return
	_host_go()


func _host_go() -> void:
	var spawns: Dictionary = game.host_compute_spawns()
	_s_go.rpc(spawns, COUNTDOWN)


@rpc("authority", "call_local", "reliable")
func _s_go(spawns: Dictionary, seconds: float) -> void:
	_set_phase(Phase.COUNTDOWN)
	game.begin(spawns, seconds)


## net_match.gd flips COUNTDOWN -> PLAYING itself when the countdown ends.
func set_playing() -> void:
	if phase == Phase.COUNTDOWN:
		_set_phase(Phase.PLAYING)


func host_end_match(winner_id: int, scores: Dictionary) -> void:
	if mode != Mode.HOST or phase >= Phase.ENDED:
		return
	_s_match_over.rpc(winner_id, scores)
	_end_t = ENDED_SECONDS
	set_process(true)


@rpc("authority", "call_local", "reliable")
func _s_match_over(winner_id: int, scores: Dictionary) -> void:
	_set_phase(Phase.ENDED)
	game.on_match_over(winner_id, scores)


func host_return_to_lobby() -> void:
	if mode != Mode.HOST:
		return
	_s_return_to_lobby.rpc()


@rpc("authority", "call_local", "reliable")
func _s_return_to_lobby() -> void:
	game.reset()
	for id in roster:
		roster[id]["loaded"] = false
	_set_phase(Phase.LOBBY)
	get_tree().paused = false
	get_tree().reload_current_scene.call_deferred()      # clean world; the connection (this autoload) stays


func _process(delta: float) -> void:
	if mode != Mode.HOST:
		set_process(false)
		return
	if phase == Phase.LOADING:
		var waited := Time.get_ticks_msec() / 1000.0 - _load_started
		if waited > LOAD_TIMEOUT:
			for id in roster.keys():
				if id != 1 and not bool(roster[id]["loaded"]):
					_s_notice.rpc("%s took too long to load and was removed." % name_of(id))
					_kick(id)
			_load_started = 1.0e12                              # kick once
			_check_all_loaded()
	elif phase == Phase.ENDED:
		_end_t -= delta
		if _end_t <= 0.0:
			set_process(false)
			host_return_to_lobby()
	else:
		set_process(false)


# ------------------------------------------------------------------ leaving
## Leave the current lobby / match (button, host gone, connection lost). Returns to the main menu.
func leave(reason := "") -> void:
	if mode == Mode.OFFLINE:
		return
	if mode == Mode.HOST and roster.size() > 1:
		_s_closed.rpc("The host closed the lobby.")
		await get_tree().create_timer(0.35).timeout          # let the message leave before the socket closes
	_reset_connection()
	notice = reason
	left.emit(reason)
	get_tree().paused = false
	if get_tree().current_scene != null:
		get_tree().reload_current_scene.call_deferred()


@rpc("authority", "reliable")
func _s_closed(reason: String) -> void:
	if mode == Mode.CLIENT:
		leave(reason)


func _reset_connection() -> void:
	discovery.stop_hosting()
	discovery.stop_searching()
	var p := multiplayer.multiplayer_peer
	if p != null and not (p is OfflineMultiplayerPeer):
		p.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()      # releases the port
	mode = Mode.OFFLINE
	phase = Phase.OFFLINE
	roster.clear()
	_hello_waiting.clear()
	game.reset()
	set_process(false)
	phase_changed.emit(int(phase))
