extends Node
## In-match replication and host authority (child "Game" of the Net autoload; same node path on every peer).
##
##   state      each player streams its own position / aim / animation flags (20 Hz, unreliable) -> host -> others
##   combat     clients REQUEST shots and throws; the host validates them, runs the damaging projectile, and tells
##              everyone what to draw. Damage / health / kills / respawns are decided only on the host.
##   pickups    weapon + throwable pickups are owned by the host; clients request, the host grants.
##   scoring    kills, deaths and the winner are decided on the host.
##
## Gameplay scripts (player.gd, bullet.gd, throwable.gd ...) call into this node only through the hooks below and
## only when Net.match_active(); offline play never touches it.

signal respawn_granted(pos: Vector2)
signal scores_changed
signal kill_feed(text: String)
signal big_message(text: String)       # "3", "2", "1", "GO!" ...
signal match_finished(winner: String)

const BULLET_SCENE := preload("res://bullet.tscn")
const NetSpawnR = preload("res://art/scripts/net/net_spawn.gd")

const STATE_HZ := 20.0
const HEALTH_HZ := 5.0
const RESPAWN_DELAY := 2.3             # offline: 0.3 s fade + 2.0 s wait
const MAX_SHOT_ORIGIN_ERROR := 170.0   # a muzzle is never farther than this from the shooter's body
const MAX_PICKUP_DISTANCE := 150.0
const MIN_THROW_GAP := 0.35
const AMMO_REQUEST_GAP := 0.35

var arena: Node
var local_player: Node2D
var puppets := {}                      # peer id -> RemotePlayer
var scores := {}                       # peer id -> {"kills": int, "deaths": int}
var kill_limit := 10
var time_limit := 0.0                  # seconds, 0 = no limit
var time_left := 0.0                   # counts down while playing (the host's clock is the real one)
var weapon_rate := 1.0
var throwable_rate := 1.0
var _time_sync_acc := 0.0
var map_id := ""
var started := false                   # begin() ran: state streaming is on
var playing := false                   # countdown finished: shooting / scoring is live
var over := false

var _state_acc := 0.0
var _health_acc := 0.0
var _last_health_sent := {}
var _host := {}                        # host only: peer id -> {allowed, main, off, dual, inv, tok, last, last_throw}
var _net_nodes := {}                   # net id -> cosmetic copy (throwable / rocket / zone) on this peer
var _next_id := 1                      # host only
var _pickups := {}                     # "m0".."mN" / "dN" -> WeaponPickup
var _tpickups := {}                    # int id -> ThrowablePickup
var _pending_respawn := {}
var _overlay: CanvasLayer
var _big: Label
var _ammo_req_t := {}
var _wid_cache := {}
var _wid_by_path := {}


# =========================================================================================== life-cycle
func reset() -> void:
	started = false
	playing = false
	over = false
	for id in puppets:
		if is_instance_valid(puppets[id]):
			puppets[id].queue_free()
	puppets.clear()
	scores.clear()
	_host.clear()
	_net_nodes.clear()
	_pickups.clear()
	_tpickups.clear()
	_pending_respawn.clear()
	_last_health_sent.clear()
	_ammo_req_t.clear()
	_next_id = 1
	local_player = null
	arena = null
	if _overlay != null:
		_overlay.queue_free()
		_overlay = null
		_big = null


func _running() -> bool:
	return Net.match_active() and arena != null and is_instance_valid(arena) and local_player != null and is_instance_valid(local_player)


func prepare(s: Dictionary) -> void:
	reset()
	map_id = str(s.get("map_id", "abandoned_station"))
	kill_limit = int(s.get("kill_limit", 10))
	time_limit = float(int(s.get("time_limit", 0))) * 60.0
	time_left = time_limit
	weapon_rate = float(Net.WEAPON_RATE_MULT[clampi(int(s.get("weapon_rate", Net.DEFAULT_WEAPON_RATE)), 0, Net.WEAPON_RATE_MULT.size() - 1)])
	throwable_rate = float(Net.THROW_RATE_MULT[clampi(int(s.get("throwable_rate", Net.DEFAULT_THROW_RATE)), 0, Net.THROW_RATE_MULT.size() - 1)])
	arena = get_tree().current_scene
	if arena == null or not arena.has_method("net_prepare_match"):
		Net.leave("This scene cannot run a network match.")
		return
	await arena.net_prepare_match(map_id)
	if Net.phase != Net.Phase.LOADING:
		return                                   # the match was cancelled while loading
	local_player = arena.get_node_or_null("Player") as Node2D
	if local_player == null:
		Net.leave("Could not find the local player in the arena.")
		return
	Net.apply_player_look(local_player.visuals, Net.my_id())
	if Net.is_host():
		local_player.died.connect(_on_local_died)
	for id in Net.roster:
		scores[id] = {"kills": 0, "deaths": 0}
		if id != Net.my_id():
			_make_puppet(id)
	_apply_spawn_rates()
	_index_weapon_pickups()
	_prepare_throwable_pickups()
	if Net.is_host():
		for id in Net.roster:
			if id != 1:
				_host_reset_peer(id)
	Net.loaded()


## Host option "spawn rate": scales how fast map guns come back and how often throwables show up.
## Only the host runs these timers (clients just mirror what the host announces), but we apply it everywhere.
func _apply_spawn_rates() -> void:
	for n in get_tree().get_nodes_in_group("weapon_pickup"):
		if not n.is_drop:
			n.respawn_time = maxf(n.respawn_time / weapon_rate, 1.0)
	for sp in get_tree().get_nodes_in_group("throwable_spawner"):
		if throwable_rate <= 0.0:
			sp.max_active = 0
			sp.initial_spawns = 0
			sp.set_process(false)
			for tp in get_tree().get_nodes_in_group("throwable_pickup"):
				tp.queue_free()
		else:
			sp.interval = maxf(sp.interval / throwable_rate, 1.0)
			sp._timer = sp.interval
			sp.max_active = maxi(1, roundi(sp.max_active * throwable_rate))


func _make_puppet(id: int) -> void:
	if puppets.has(id) and is_instance_valid(puppets[id]):
		return                                   # never two puppets for one peer
	var p := RemotePlayer.new()
	p.setup(id, Net.name_of(id), int(Net.roster.get(id, {}).get("look", 0)))
	p.visible = false
	arena.add_child(p)
	puppets[id] = p
	if Net.is_host():
		p.died.connect(_on_puppet_died)


## HOST: where each player starts. Runs once after everyone has loaded (so the map's physics is up to date).
func host_compute_spawns() -> Dictionary:
	var cands: Array = arena.net_spawn_candidates()
	var taken: Array[Vector2] = []
	var out := {}
	var ids: Array = Net.roster.keys()
	ids.sort()
	cands.shuffle()
	var i := 0
	for id in ids:
		var wanted: Vector2 = cands[i % cands.size()]
		i += 1
		var spot: Vector2 = NetSpawnR.resolve_near(local_player.get_world_2d().direct_space_state, wanted, [local_player.get_rid()])
		taken.append(spot)
		out[id] = spot
	return out


func begin(spawns: Dictionary, seconds: float) -> void:
	if arena == null or local_player == null:
		return
	started = true
	var mine: Vector2 = spawns.get(Net.my_id(), local_player.global_position)
	arena.net_place_local(mine)
	for id in puppets:
		var p: RemotePlayer = puppets[id]
		p.global_position = spawns.get(id, mine)
		p.visible = true
	local_player.set_physics_process(false)      # frozen for the countdown
	if Net.is_host():
		_sync_pickups_to_everyone()
	scores_changed.emit()
	_run_countdown(seconds)


func _run_countdown(seconds: float) -> void:
	var left := int(ceil(seconds))
	while left > 0:
		big_message.emit(str(left))
		_show_big(str(left))
		await get_tree().create_timer(1.0).timeout
		if not started:
			return
		left -= 1
	big_message.emit("GO!")
	_show_big("GO!")
	if is_instance_valid(local_player):
		local_player.set_physics_process(true)
	playing = true
	Net.set_playing()
	await get_tree().create_timer(0.8).timeout
	_show_big("")


func _show_big(text: String) -> void:
	if _overlay == null:
		_overlay = CanvasLayer.new()
		_overlay.layer = 60
		add_child(_overlay)
		_big = Label.new()
		_big.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		_big.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_big.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		_big.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_big.add_theme_font_size_override("font_size", 84)
		_big.add_theme_color_override("font_outline_color", Color.BLACK)
		_big.add_theme_constant_override("outline_size", 12)
		_overlay.add_child(_big)
	_big.text = text


func peer_left(id: int) -> void:
	if puppets.has(id):
		if is_instance_valid(puppets[id]):
			puppets[id].queue_free()
		puppets.erase(id)
	_host.erase(id)
	scores.erase(id)
	_last_health_sent.erase(id)
	scores_changed.emit()


func on_match_over(winner_id: int, final_scores: Dictionary) -> void:
	over = true
	playing = false
	scores = final_scores
	scores_changed.emit()
	var who := Net.name_of(winner_id) if winner_id != 0 else "Nobody"
	match_finished.emit(who)
	if winner_id == 0:
		_show_big("TIME'S UP - DRAW!" if time_limit > 0.0 and time_left <= 0.5 else "DRAW!")
	else:
		_show_big("%s WINS!" % who.to_upper())


# =========================================================================================== per-frame
func _physics_process(delta: float) -> void:
	if not started or not _running():
		return
	if playing and not over and time_limit > 0.0:
		time_left = maxf(time_left - delta, 0.0)
		if Net.is_host():
			_time_sync_acc += delta
			if _time_sync_acc >= 2.0:
				_time_sync_acc = 0.0
				_s_time.rpc(time_left)
			if time_left <= 0.0:
				_host_time_up()
	_state_acc += delta
	if _state_acc >= 1.0 / STATE_HZ:
		_state_acc = 0.0
		var st: PackedFloat32Array = local_player.net_pack_state()
		if Net.is_host():
			_s_state.rpc(1, st)
		else:
			_c_state.rpc_id(1, st)
	if Net.is_host():
		_health_acc += delta
		if _health_acc >= 1.0 / HEALTH_HZ:
			_health_acc = 0.0
			_broadcast_healths()


@rpc("any_peer", "call_remote", "unreliable_ordered", 1)
func _c_state(st: PackedFloat32Array) -> void:
	if not Net.is_host() or not started:
		return
	var id := multiplayer.get_remote_sender_id()
	if puppets.has(id) and is_instance_valid(puppets[id]):
		puppets[id].net_receive(st)
	for other in Net.roster:
		if other != id and other != 1:
			_s_state.rpc_id(other, id, st)


@rpc("authority", "call_remote", "unreliable_ordered", 1)
func _s_state(id: int, st: PackedFloat32Array) -> void:
	if puppets.has(id) and is_instance_valid(puppets[id]):
		puppets[id].net_receive(st)


func _broadcast_healths() -> void:
	var changed := false
	var data := {}
	var lp_hp := int(local_player.health)
	data[1] = lp_hp
	for id in puppets:
		data[id] = int(puppets[id].health)
	for id in data:
		if _last_health_sent.get(id, -1) != data[id]:
			changed = true
	if changed:
		_last_health_sent = data.duplicate()
		_s_healths.rpc(data)


@rpc("authority", "call_remote", "reliable")
func _s_healths(data: Dictionary) -> void:
	for id in data:
		if id == Net.my_id():
			if is_instance_valid(local_player):
				local_player.net_set_health(int(data[id]))
		elif puppets.has(id) and is_instance_valid(puppets[id]):
			puppets[id].net_set_health(int(data[id]), false)


# =========================================================================================== loadout
func weapon_id(w: WeaponData) -> String:
	if w == null:
		return ""
	if _wid_cache.has(w):
		return _wid_cache[w]
	if _wid_by_path.is_empty():
		for id in WeaponCatalog.PATHS:
			_wid_by_path[WeaponCatalog.PATHS[id]] = id
	var found := str(_wid_by_path.get(w.resource_path, ""))
	_wid_cache[w] = found
	return found


## player.gd calls this whenever its weapons, dual wield state or selected grenade change.
func local_loadout_changed() -> void:
	if not _running():
		return
	var p = local_player
	var hip := ""
	var t: ThrowableData = p.current_throwable()
	if t != null and int(p._throw_counts.get(t, 0)) > 0:
		hip = t.catalog_id
	var d := [weapon_id(p.weapon), weapon_id(p.off_weapon) if p.dual else "", weapon_id(p._secondary_weapon()), p.dual, hip]
	if Net.is_host():
		_s_loadout.rpc(1, d)
	else:
		_c_loadout.rpc_id(1, d)


@rpc("any_peer", "reliable")
func _c_loadout(d: Array) -> void:
	if not Net.is_host() or not started:
		return
	var id := multiplayer.get_remote_sender_id()
	if not _host.has(id) or d.size() < 5:
		return
	var hd: Dictionary = _host[id]
	var allowed: Dictionary = hd["allowed"]
	for i in 3:
		var wid := str(d[i])
		if wid != "" and not allowed.has(wid):
			return                                # claims a gun it never picked up: ignored
	hd["main"] = str(d[0])
	hd["off"] = str(d[1])
	hd["dual"] = bool(d[3]) and str(d[1]) != ""
	_s_loadout.rpc(id, d)                         # host relays to every client (and applies it to its own puppet)


@rpc("authority", "call_local", "reliable")
func _s_loadout(id: int, d: Array) -> void:
	if id == Net.my_id() or not puppets.has(id) or not is_instance_valid(puppets[id]) or d.size() < 5:
		return
	var hip_tex: Texture2D = null
	if str(d[4]) != "":
		var td := ThrowableCatalog.get_data(str(d[4]))
		if td != null:
			hip_tex = td.icon
	puppets[id].net_set_loadout(WeaponCatalog.get_weapon(str(d[0])), WeaponCatalog.get_weapon(str(d[1])),
		WeaponCatalog.get_weapon(str(d[2])), bool(d[3]), hip_tex)


# =========================================================================================== gunfire
func _spawn_bullet(w: WeaponData, origin: Vector2, dir: Vector2, shooter: Node, visual: bool) -> void:
	var b = BULLET_SCENE.instantiate()
	b.global_position = origin
	b.setup(w, dir, shooter)
	if visual:
		b.set("net_visual", true)
	arena.add_child(b)


## CLIENT: the local player just fired. It already spawned its own cosmetic bullets; this asks the host to run the
## real ones.
func client_fire(w: WeaponData, hand: int, origin: Vector2, dirs: PackedVector2Array) -> void:
	if _running() and Net.is_client() and playing:
		_c_fire.rpc_id(1, weapon_id(w), hand, origin, dirs)


## HOST: the host's own player fired (the real bullets are already in the world); tell everyone how to draw it.
func host_fire_event(w: WeaponData, hand: int, origin: Vector2, dirs: PackedVector2Array, rocket_id: int) -> void:
	if _running() and Net.is_host():
		_s_fire_fx.rpc(1, weapon_id(w), hand, origin, dirs, rocket_id)


@rpc("any_peer", "reliable")
func _c_fire(wid: String, hand: int, origin: Vector2, dirs: PackedVector2Array) -> void:
	if not Net.is_host() or not playing or over:
		return
	var id := multiplayer.get_remote_sender_id()
	var p: RemotePlayer = puppets.get(id)
	if p == null or p.is_dead or not _host.has(id):
		return
	var hd: Dictionary = _host[id]
	var w := WeaponCatalog.get_weapon(wid)
	if w == null or hand < 0 or hand > 1:
		return
	# the weapon must be the one the host believes is in that hand
	if hand == 0 and hd["main"] != wid:
		return
	if hand == 1 and (not hd["dual"] or hd["off"] != wid):
		return
	if dirs.is_empty() or dirs.size() > maxi(w.pellets, 1):
		return
	if origin.distance_to(p.global_position) > MAX_SHOT_ORIGIN_ERROR:
		return                                    # muzzle nowhere near the body: reject
	# rate limit: a token bucket sized to the weapon's fastest cadence (burst guns included)
	var gap := w.shot_gap("auto")
	if w.modes().has("burst"):
		gap = minf(gap, w.burst_interval)
	gap = maxf(gap * 0.55, 0.02)
	var now := Time.get_ticks_msec() / 1000.0
	var tok: Array = hd["tok"]
	var last: Array = hd["last"]
	tok[hand] = minf(float(tok[hand]) + (now - float(last[hand])) / gap, 4.0)
	last[hand] = now
	if float(tok[hand]) < 1.0:
		return
	tok[hand] = float(tok[hand]) - 1.0
	var clean := PackedVector2Array()
	for d in dirs:
		if d.length() < 0.5:
			return
		clean.append(d.normalized())
	var rocket_id := 0
	if w.projectile_kind == "rocket":
		var r := Rocket.launch(w, origin, clean[0], p, get_tree())
		rocket_id = _new_id()
		r.net_id = rocket_id
	else:
		for d in clean:
			_spawn_bullet(w, origin, d, p, false)
	p.net_fire_fx(w, hand)
	for other in Net.roster:
		if other == 1:
			continue
		if other == id and rocket_id == 0:
			continue                              # the shooter already drew its own bullets
		_s_fire_fx.rpc_id(other, id, wid, hand, origin, clean, rocket_id)


@rpc("authority", "call_local", "reliable")
func _s_fire_fx(shooter_id: int, wid: String, hand: int, origin: Vector2, dirs: PackedVector2Array, rocket_id: int) -> void:
	if Net.is_host() or arena == null or not is_instance_valid(arena):
		return                                    # the host already has the real thing in its world
	var w := WeaponCatalog.get_weapon(wid)
	if w == null:
		return
	var shooter: Node = puppets.get(shooter_id)
	if shooter_id != Net.my_id() and shooter != null and is_instance_valid(shooter):
		shooter.net_fire_fx(w, hand)
	if rocket_id != 0:
		var r := Rocket.new()
		r.data = w
		r.direction = dirs[0].normalized()
		r.speed = w.projectile_speed
		r.max_range = w.max_range
		r.shooter = shooter
		r.rotation = r.direction.angle()
		r.net_visual = true
		r.net_id = rocket_id
		arena.add_child(r)
		r.global_position = origin
		_net_nodes[rocket_id] = r
		return
	if shooter_id == Net.my_id():
		return
	for d in dirs:
		_spawn_bullet(w, origin, d, shooter, true)


func _new_id() -> int:
	_next_id += 1
	return _next_id


## HOST: an authoritative rocket / bomb / zone is gone without a blast (EMP'd, expired, hit a wall...).
func host_net_gone(net_id: int) -> void:
	if net_id != 0 and _running() and Net.is_host():
		_s_net_gone.rpc(net_id)


@rpc("authority", "call_remote", "reliable")
func _s_net_gone(net_id: int) -> void:
	var n = _net_nodes.get(net_id)
	_net_nodes.erase(net_id)
	if n != null and is_instance_valid(n):
		n.queue_free()


# =========================================================================================== throwables
## CLIENT: asks the host to throw. The local copy of the bomb is created when the host's answer arrives.
func client_throw(t: ThrowableData, pos: Vector2, vel: Vector2) -> void:
	if _running() and Net.is_client() and playing:
		_c_throw.rpc_id(1, t.catalog_id, pos, vel)


## HOST: the host's own player throws (or a validated client request). Creates the real bomb and tells everyone.
func host_throw(peer: int, thrower: Node2D, t: ThrowableData, pos: Vector2, vel: Vector2) -> void:
	var bomb := Throwable.new()
	bomb.setup(t, thrower, vel)
	bomb.net_id = _new_id()
	arena.add_child(bomb)
	bomb.global_position = pos
	_s_throwable.rpc(bomb.net_id, t.catalog_id, pos, vel, peer)


@rpc("any_peer", "reliable")
func _c_throw(tid: String, pos: Vector2, vel: Vector2) -> void:
	if not Net.is_host() or not playing or over:
		return
	var id := multiplayer.get_remote_sender_id()
	var p: RemotePlayer = puppets.get(id)
	if p == null or p.is_dead or not _host.has(id):
		return
	var t := ThrowableCatalog.get_data(tid)
	if t == null:
		return
	var hd: Dictionary = _host[id]
	var inv: Dictionary = hd["inv"]
	var now := Time.get_ticks_msec() / 1000.0
	if int(inv.get(tid, 0)) <= 0 or now - float(hd["last_throw"]) < MIN_THROW_GAP:
		return
	if pos.distance_to(p.global_position) > MAX_SHOT_ORIGIN_ERROR or vel.length() > t.throw_speed + 700.0:
		return
	hd["last_throw"] = now
	inv[tid] = int(inv[tid]) - 1
	host_throw(id, p, t, pos, vel)


@rpc("authority", "call_remote", "reliable")
func _s_throwable(net_id: int, tid: String, pos: Vector2, vel: Vector2, thrower_id: int) -> void:
	var t := ThrowableCatalog.get_data(tid)
	if t == null or arena == null or not is_instance_valid(arena):
		return
	var bomb := Throwable.new()
	bomb.setup(t, null, vel)
	bomb.net_visual = true
	bomb.net_id = net_id
	arena.add_child(bomb)
	bomb.global_position = pos
	_net_nodes[net_id] = bomb


## HOST: a bomb (or rocket warhead) went off. `net_id` is 0 for rocket warheads.
func host_explosion(net_id: int, pos: Vector2, radius: float, color: Color, style: String, shake: float) -> void:
	if _running() and Net.is_host():
		_s_explosion.rpc(net_id, pos, radius, color, style, shake)


@rpc("authority", "call_remote", "reliable")
func _s_explosion(net_id: int, pos: Vector2, radius: float, color: Color, style: String, shake: float) -> void:
	var n = _net_nodes.get(net_id)
	_net_nodes.erase(net_id)
	if n != null and is_instance_valid(n):
		n.queue_free()                            # the bomb's cosmetic copy is replaced by the blast
	if arena == null or not is_instance_valid(arena):
		return
	var fx := BlastFX.new()
	fx.setup(radius, color, style)
	fx.shake_scale = shake
	arena.add_child(fx)
	fx.global_position = pos
	GunAudio.boom_at(get_tree(), pos)


func host_zone_created(zone: Node2D, t: ThrowableData) -> void:
	if not (_running() and Net.is_host()) or t.catalog_id == "":
		return
	var id := _new_id()
	zone.set("net_id", id)
	_s_zone.rpc(id, t.catalog_id, zone.global_position)


@rpc("authority", "call_remote", "reliable")
func _s_zone(net_id: int, tid: String, pos: Vector2) -> void:
	var t := ThrowableCatalog.get_data(tid)
	if t == null or arena == null or not is_instance_valid(arena):
		return
	var zone := ThrowableZone.new()
	zone.setup(t, null)
	zone.net_visual = true
	zone.net_id = net_id
	arena.add_child(zone)
	zone.global_position = pos
	_net_nodes[net_id] = zone


func host_zone_dispelled(net_id: int) -> void:
	if net_id != 0 and _running() and Net.is_host():
		_s_zone_dispel.rpc(net_id)


@rpc("authority", "call_remote", "reliable")
func _s_zone_dispel(net_id: int) -> void:
	var z = _net_nodes.get(net_id)
	if z != null and is_instance_valid(z):
		z.dispel()


# =========================================================================================== damage results (host -> owner)
func host_puppet_hit(p: RemotePlayer, hp: int, push: Vector2) -> void:
	_s_hit.rpc_id(p.peer_id, hp, push)


@rpc("authority", "call_remote", "reliable")
func _s_hit(hp: int, push: Vector2) -> void:
	if is_instance_valid(local_player):
		local_player.net_apply_hit(hp, push)


func host_send_status(peer: int, type: String, duration: float, power: float) -> void:
	_s_status.rpc_id(peer, type, duration, power)


@rpc("authority", "call_remote", "reliable")
func _s_status(type: String, duration: float, power: float) -> void:
	if is_instance_valid(local_player):
		local_player.apply_status(type, duration, power, null)


func host_send_stun(peer: int, duration: float, immunity: float) -> void:
	_s_stun.rpc_id(peer, duration, immunity)


@rpc("authority", "call_remote", "reliable")
func _s_stun(duration: float, immunity: float) -> void:
	if is_instance_valid(local_player):
		local_player.apply_stun(duration, immunity, null)


func host_send_gravity(peer: int, center: Vector2, speed: float, radius: float, seconds: float) -> void:
	_s_gravity.rpc_id(peer, center, speed, radius, seconds)


@rpc("authority", "call_remote", "reliable")
func _s_gravity(center: Vector2, speed: float, radius: float, seconds: float) -> void:
	if is_instance_valid(local_player):
		local_player.net_gravity(center, speed, radius, seconds)


func host_send_teleport(peer: int, pos: Vector2) -> void:
	_s_teleport.rpc_id(peer, pos)


@rpc("authority", "call_remote", "reliable")
func _s_teleport(pos: Vector2) -> void:
	if is_instance_valid(local_player):
		local_player.net_teleport_local(pos)


# =========================================================================================== deaths, kills, respawns, scores
func _id_of(n: Node) -> int:
	if n == null or not is_instance_valid(n):
		return 0
	if n == local_player:
		return Net.my_id()
	if n is RemotePlayer:
		return (n as RemotePlayer).peer_id
	return 0


func _on_local_died(victim: Node, killer: Node) -> void:
	if Net.is_host() and playing:
		_host_kill(1, killer)


@rpc("authority", "unreliable_ordered", "call_remote")
func _s_time(left: float) -> void:
	time_left = left                             # keeps clients on the host's clock (they count down locally in between)


## Time ran out: the player with the most kills wins; a tie for first is a draw.
func _host_time_up() -> void:
	if over or not playing:
		return
	var best := -1
	var winner := 0
	var tie := false
	for id in scores:
		var k := int(scores[id]["kills"])
		if k > best:
			best = k
			winner = id
			tie = false
		elif k == best:
			tie = true
	Net.host_end_match(0 if tie else winner, scores)


func _on_puppet_died(victim: Node, killer: Node) -> void:
	if Net.is_host() and playing:
		_host_kill((victim as RemotePlayer).peer_id, killer)


func _host_kill(victim_id: int, killer_node: Node) -> void:
	if over or not scores.has(victim_id):
		return
	var killer_id := _id_of(killer_node)
	scores[victim_id]["deaths"] = int(scores[victim_id]["deaths"]) + 1
	var credited := killer_id != 0 and killer_id != victim_id and scores.has(killer_id)
	if credited:
		scores[killer_id]["kills"] = int(scores[killer_id]["kills"]) + 1
	_s_died.rpc(victim_id, killer_id if credited else 0, scores)
	if victim_id != 1:
		_respawn_puppet_later(victim_id)
	if credited and int(scores[killer_id]["kills"]) >= kill_limit:
		Net.host_end_match(killer_id, scores)


@rpc("authority", "call_local", "reliable")
func _s_died(victim_id: int, killer_id: int, new_scores: Dictionary) -> void:
	scores = new_scores
	var killer_text := "%s eliminated %s" % [Net.name_of(killer_id), Net.name_of(victim_id)] if killer_id != 0 else "%s died" % Net.name_of(victim_id)
	kill_feed.emit(killer_text)
	scores_changed.emit()
	if victim_id == Net.my_id():
		if Net.is_client() and is_instance_valid(local_player):
			local_player.net_die()
	elif puppets.has(victim_id) and is_instance_valid(puppets[victim_id]):
		puppets[victim_id].net_set_dead()


func _respawn_puppet_later(id: int) -> void:
	await get_tree().create_timer(RESPAWN_DELAY).timeout
	if not started or over or not puppets.has(id) or not Net.roster.has(id):
		return
	var spot := _pick_spawn(id)
	_host_reset_peer(id)
	_s_respawned.rpc(id, spot)


@rpc("authority", "call_local", "reliable")
func _s_respawned(id: int, spot: Vector2) -> void:
	if id == Net.my_id():
		_pending_respawn[id] = spot
		respawn_granted.emit(spot)
	elif puppets.has(id) and is_instance_valid(puppets[id]):
		puppets[id].net_respawn(spot)


## player.gd's die() asks where (and when) to come back. Offline it never gets here.
func request_respawn_position(p: Node2D) -> Vector2:
	var me := Net.my_id()
	if Net.is_host():
		await get_tree().create_timer(RESPAWN_DELAY - 0.3).timeout
		if not _running() or over:
			return p.global_position
		var spot := _pick_spawn(me)
		_s_respawned.rpc(1, spot)
		return spot
	if _pending_respawn.has(me):
		var early: Vector2 = _pending_respawn[me]
		_pending_respawn.erase(me)
		return early
	var granted: Vector2 = await respawn_granted
	_pending_respawn.erase(me)
	return granted


func _pick_spawn(for_id: int) -> Vector2:
	var cands: Array = arena.net_spawn_candidates()
	var others: Array[Vector2] = []
	for id in puppets:
		var p: RemotePlayer = puppets[id]
		if id != for_id and is_instance_valid(p) and not p.is_dead:
			others.append(p.global_position)
	if for_id != 1 and is_instance_valid(local_player) and not bool(local_player.is_dead):
		others.append(local_player.global_position)
	var best: Vector2 = cands[0]
	var best_d := -1.0
	for c in cands:
		var nearest := 1.0e9
		for o in others:
			nearest = minf(nearest, (c as Vector2).distance_to(o))
		if nearest > best_d:
			best_d = nearest
			best = c
	var probe: Node2D = local_player if is_instance_valid(local_player) else null
	if probe == null:
		return best
	return NetSpawnR.resolve_near(probe.get_world_2d().direct_space_state, best, [probe.get_rid()])


func _host_reset_peer(id: int) -> void:
	var start_w := "ak47"
	if is_instance_valid(local_player) and not local_player._spawn_loadout.is_empty():
		var sid := weapon_id(local_player._spawn_loadout[0])
		if sid != "":
			start_w = sid
	var inv := {}
	for tid in local_player.starting_throwables:
		var d := ThrowableCatalog.get_data(tid)
		if d != null:
			inv[tid] = mini(local_player.starting_throwable_count, d.max_count)
	_host[id] = {"allowed": {start_w: true}, "main": start_w, "off": "", "dual": false, "inv": inv,
		"tok": [3.0, 3.0], "last": [Time.get_ticks_msec() / 1000.0, Time.get_ticks_msec() / 1000.0], "last_throw": 0.0}
	if puppets.has(id) and is_instance_valid(puppets[id]):
		var p: RemotePlayer = puppets[id]
		p.is_dead = false
		p.health = p.max_health
		p.last_attacker = null
		p.clear_statuses()


# =========================================================================================== weapon pickups
func _index_weapon_pickups() -> void:
	_pickups.clear()
	var list: Array = []
	for n in get_tree().get_nodes_in_group("weapon_pickup"):
		if not n.is_drop:
			list.append(n)
	list.sort_custom(func(a, b) -> bool:
		var pa: Vector2 = a.global_position
		var pb: Vector2 = b.global_position
		return pa.x < pb.x or (is_equal_approx(pa.x, pb.x) and pa.y < pb.y))
	for i in list.size():
		var n = list[i]
		n.net_id = "m%d" % i
		n.net_role = 1 if Net.is_host() else 2
		_pickups[n.net_id] = n


func _sync_pickups_to_everyone() -> void:
	var list: Array = []
	for id in _pickups:
		var n = _pickups[id]
		if is_instance_valid(n) and not n.is_drop:
			list.append([id, weapon_id(n.weapon), int(n._stock), bool(n._active)])
	_s_pickups_sync.rpc(list)
	var tlist: Array = []
	for id in _tpickups:
		var tp = _tpickups[id]
		if is_instance_valid(tp):
			tlist.append([id, tp.data.catalog_id, tp.global_position])
	_s_tpickups_sync.rpc(tlist)


@rpc("authority", "call_remote", "reliable")
func _s_pickups_sync(list: Array) -> void:
	for e in list:
		var n = _pickups.get(str(e[0]))
		if n != null and is_instance_valid(n):
			n.net_set_state(WeaponCatalog.get_weapon(str(e[1])), int(e[2]), bool(e[3]))


## HOST: a map pickup was taken / expired / respawned, or a dropped gun appeared / vanished.
func host_pickup_state(n: Node) -> void:
	if _running() and Net.is_host() and n.net_id != "":
		_s_pickup_state.rpc(n.net_id, weapon_id(n.weapon), int(n._stock), bool(n._active))


@rpc("authority", "call_remote", "reliable")
func _s_pickup_state(id: String, wid: String, stock: int, active: bool) -> void:
	var n = _pickups.get(id)
	if n != null and is_instance_valid(n):
		n.net_set_state(WeaponCatalog.get_weapon(wid), stock, active)


func host_drop_removed(n: Node) -> void:
	if _running() and Net.is_host() and n.net_id != "":
		_pickups.erase(n.net_id)
		_s_drop_gone.rpc(n.net_id)


@rpc("authority", "call_remote", "reliable")
func _s_drop_gone(id: String) -> void:
	var n = _pickups.get(id)
	_pickups.erase(id)
	if n != null and is_instance_valid(n):
		n.net_free()


## A player left a gun on the floor (swap / replaced). Host creates it for everybody.
func local_drop(w: WeaponData, ammo: int, reserve: int, pos: Vector2) -> void:
	if not _running():
		return
	if Net.is_host():
		_host_make_drop(1, w, ammo, reserve, pos)
	else:
		_c_drop.rpc_id(1, weapon_id(w), ammo, reserve, pos)


@rpc("any_peer", "reliable")
func _c_drop(wid: String, ammo: int, reserve: int, pos: Vector2) -> void:
	if not Net.is_host() or not started:
		return
	var id := multiplayer.get_remote_sender_id()
	var p: RemotePlayer = puppets.get(id)
	if p == null or not _host.has(id) or p.is_dead:
		return
	var w := WeaponCatalog.get_weapon(wid)
	if w == null or not _host[id]["allowed"].has(wid):
		return
	if pos.distance_to(p.global_position) > MAX_SHOT_ORIGIN_ERROR:
		pos = p.global_position + Vector2(0, 6)
	_host_make_drop(id, w, clampi(ammo, 0, w.magazine_size), clampi(reserve, 0, w.reserve_ammo), pos)


func _host_make_drop(dropper: int, w: WeaponData, ammo: int, reserve: int, pos: Vector2) -> void:
	var drop := WeaponPickup.new()
	drop.weapon = w
	drop.is_drop = true
	drop.drop_ammo = ammo
	drop.drop_reserve = reserve
	drop.net_id = "d%d" % _new_id()
	drop.net_role = 1
	if dropper == 1:
		drop.ignore_body = local_player
	arena.add_child(drop)
	drop.global_position = pos
	_pickups[drop.net_id] = drop
	_s_drop_spawn.rpc(drop.net_id, weapon_id(w), ammo, reserve, pos, dropper)


@rpc("authority", "call_remote", "reliable")
func _s_drop_spawn(id: String, wid: String, ammo: int, reserve: int, pos: Vector2, dropper: int) -> void:
	var w := WeaponCatalog.get_weapon(wid)
	if w == null or arena == null or not is_instance_valid(arena) or _pickups.has(id):
		return
	var drop := WeaponPickup.new()
	drop.weapon = w
	drop.is_drop = true
	drop.drop_ammo = ammo
	drop.drop_reserve = reserve
	drop.net_id = id
	drop.net_role = 2
	if dropper == Net.my_id():
		drop.ignore_body = local_player
	arena.add_child(drop)
	drop.global_position = pos
	_pickups[id] = drop


## CLIENT: the player pressed PICK UP / DUAL WIELD next to a pickup.
func client_pickup_request(n: Node, mode: String) -> void:
	if _running() and Net.is_client() and playing and n.net_id != "":
		_c_pickup.rpc_id(1, n.net_id, mode)


@rpc("any_peer", "reliable")
func _c_pickup(pid: String, mode: String) -> void:
	if not Net.is_host() or not playing or over:
		return
	var id := multiplayer.get_remote_sender_id()
	var p: RemotePlayer = puppets.get(id)
	var n = _pickups.get(pid)
	if p == null or p.is_dead or n == null or not is_instance_valid(n) or not _host.has(id):
		return
	if not n.is_available() or n.global_position.distance_to(p.global_position) > MAX_PICKUP_DISTANCE:
		return
	var w: WeaponData = n.weapon
	var wid := weapon_id(w)
	var hd: Dictionary = _host[id]
	if mode == "dual":
		var held := WeaponCatalog.get_weapon(str(hd["main"]))
		if hd["dual"] or held == null or not held.one_handed or not w.one_handed:
			return
	var give_ammo: int = n.drop_ammo if n.is_drop else -1
	var give_reserve: int = int(n._stock) if n.is_drop else -1
	hd["allowed"][wid] = true
	n.net_take()                                  # removes it for everybody (map pickup: respawns later; drop: gone)
	_s_grant_weapon.rpc_id(id, wid, mode, give_ammo, give_reserve)


@rpc("authority", "call_remote", "reliable")
func _s_grant_weapon(wid: String, mode: String, ammo: int, reserve: int) -> void:
	var w := WeaponCatalog.get_weapon(wid)
	if w == null or not is_instance_valid(local_player):
		return
	if mode == "dual":
		local_player.dual_wield_pickup(w, ammo, reserve)
	else:
		local_player.pickup_weapon(w, ammo, reserve)


## CLIENT: standing on a pickup of a gun we carry: ask for ammo (host decides how much).
func client_ammo_request(n: Node, want: int) -> void:
	if not (_running() and Net.is_client() and playing) or n.net_id == "" or want <= 0:
		return
	var now := Time.get_ticks_msec() / 1000.0
	if now - float(_ammo_req_t.get(n.net_id, 0.0)) < AMMO_REQUEST_GAP:
		return
	_ammo_req_t[n.net_id] = now
	_c_ammo.rpc_id(1, n.net_id, want)


@rpc("any_peer", "reliable")
func _c_ammo(pid: String, want: int) -> void:
	if not Net.is_host() or not playing or over:
		return
	var id := multiplayer.get_remote_sender_id()
	var p: RemotePlayer = puppets.get(id)
	var n = _pickups.get(pid)
	if p == null or p.is_dead or n == null or not is_instance_valid(n) or not _host.has(id):
		return
	if not n.is_available() or n.global_position.distance_to(p.global_position) > MAX_PICKUP_DISTANCE:
		return
	var wid := weapon_id(n.weapon)
	if not _host[id]["allowed"].has(wid):
		return
	var got: int = clampi(want, 0, mini(int(n._stock), n.weapon.reserve_ammo))
	if got <= 0:
		return
	n.net_give_ammo(got)
	_s_grant_ammo.rpc_id(id, wid, got)


@rpc("authority", "call_remote", "reliable")
func _s_grant_ammo(wid: String, amount: int) -> void:
	var w := WeaponCatalog.get_weapon(wid)
	if w != null and is_instance_valid(local_player):
		local_player.add_ammo(w, amount)


# =========================================================================================== throwable pickups
func _prepare_throwable_pickups() -> void:
	_tpickups.clear()
	for sp in get_tree().get_nodes_in_group("throwable_spawner"):
		if Net.is_host():
			continue
		sp.set_process(false)                     # clients never roll spawns: the host tells them
		sp.call("net_clear")
	if Net.is_host():
		for tp in get_tree().get_nodes_in_group("throwable_pickup"):
			host_tpickup_created(tp)


## HOST: the spawner made a pickup (also called for the ones that existed before the match began).
func host_tpickup_created(tp: Node) -> void:
	if not Net.is_host() or tp.net_id != 0:
		return
	tp.net_id = _new_id()
	tp.net_role = 1
	_tpickups[tp.net_id] = tp
	if started:
		_s_tpickup_spawn.rpc(tp.net_id, tp.data.catalog_id, tp.global_position)


@rpc("authority", "call_remote", "reliable")
func _s_tpickup_spawn(id: int, tid: String, pos: Vector2) -> void:
	var t := ThrowableCatalog.get_data(tid)
	if t == null or arena == null or not is_instance_valid(arena) or _tpickups.has(id):
		return
	var tp := ThrowablePickup.new()
	tp.data = t
	tp.net_id = id
	tp.net_role = 2
	arena.add_child(tp)
	tp.global_position = pos
	_tpickups[id] = tp


@rpc("authority", "call_remote", "reliable")
func _s_tpickups_sync(list: Array) -> void:
	for e in list:
		_s_tpickup_spawn(int(e[0]), str(e[1]), e[2])


## HOST: a throwable pickup was taken or timed out.
func host_tpickup_removed(tp: Node) -> void:
	if tp.net_id == 0 or not (_running() and Net.is_host()):
		return
	_tpickups.erase(tp.net_id)
	_s_tpickup_gone.rpc(tp.net_id)


@rpc("authority", "call_remote", "reliable")
func _s_tpickup_gone(id: int) -> void:
	var tp = _tpickups.get(id)
	_tpickups.erase(id)
	if tp != null and is_instance_valid(tp):
		tp.net_remove()


func client_tpickup_request(tp: Node) -> void:
	if not (_running() and Net.is_client() and playing) or tp.net_id == 0:
		return
	var now := Time.get_ticks_msec() / 1000.0
	if now - float(_ammo_req_t.get("t%d" % tp.net_id, 0.0)) < 0.4:
		return
	_ammo_req_t["t%d" % tp.net_id] = now
	_c_tpickup.rpc_id(1, tp.net_id)


@rpc("any_peer", "reliable")
func _c_tpickup(tid_net: int) -> void:
	if not Net.is_host() or not playing or over:
		return
	var id := multiplayer.get_remote_sender_id()
	var p: RemotePlayer = puppets.get(id)
	var tp = _tpickups.get(tid_net)
	if p == null or p.is_dead or tp == null or not is_instance_valid(tp) or not _host.has(id):
		return
	if tp.global_position.distance_to(p.global_position) > MAX_PICKUP_DISTANCE:
		return
	var t: ThrowableData = tp.data
	var inv: Dictionary = _host[id]["inv"]
	if int(inv.get(t.catalog_id, 0)) >= t.max_count:
		return                                    # full of that type: it stays on the floor
	inv[t.catalog_id] = mini(int(inv.get(t.catalog_id, 0)) + t.pickup_amount, t.max_count)
	tp.net_take()
	_s_grant_throwable.rpc_id(id, t.catalog_id, t.pickup_amount)


@rpc("authority", "call_remote", "reliable")
func _s_grant_throwable(tid: String, amount: int) -> void:
	var t := ThrowableCatalog.get_data(tid)
	if t != null and is_instance_valid(local_player):
		local_player.add_throwable(t, amount)
