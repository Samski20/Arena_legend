class_name ThrowableSpawner
extends Node2D
## Randomly drops throwable pickups on a set of spots, using only throwables that are
## allowed on this map (see ThrowableCatalog).
##
## Setup: add a Node2D to your level, attach this script, type the map's id into
## Map Id, and fill Spawn Points with surface positions (where the pickup should
## lie, i.e. the floor / platform top). The Abandoned Station map does all of this
## for you.

@export var map_id := ""
@export var spawn_points: PackedVector2Array = PackedVector2Array()
@export var interval := 7.0            # seconds between new spawns
@export var max_active := 6            # never more than this many lying around
@export var initial_spawns := 4        # how many appear at the very start
@export var keep_away_from_players := 220.0   # don't drop one right on top of someone

var _slots := {}          # spawn point index -> ThrowablePickup
var _timer := 0.0
var _enabled := true      # match setup: OFF stops every spawn


func _ready() -> void:
	add_to_group("throwable_spawner")
	# prints what this map can spawn, so a missing throwable is obvious in the Output panel
	var names: PackedStringArray = []
	for d in ThrowableCatalog.for_map(map_id):
		names.append(d.catalog_id)
	print("ThrowableSpawner [%s] can spawn: %s" % [map_id, ", ".join(names)])
	if names.is_empty():
		push_warning("ThrowableSpawner: no throwables are allowed on map '%s'" % map_id)
	for i in initial_spawns:
		_spawn_one()
	_timer = interval


func _process(delta: float) -> void:
	if not _enabled:
		return
	_timer -= delta
	if _timer <= 0.0:
		_timer = interval * randf_range(0.8, 1.25)       # a little irregular so it feels random
		_spawn_one()


func _spawn_one() -> void:
	if not _enabled or spawn_points.is_empty() or _slots.size() >= max_active:
		return

	# free spots, preferring ones that aren't next to a fighter
	var free: Array[int] = []
	var far: Array[int] = []
	for i in spawn_points.size():
		if _slots.has(i):
			continue
		free.append(i)
		if not _fighter_near(to_global(spawn_points[i])):
			far.append(i)
	var options := far if not far.is_empty() else free
	if options.is_empty():
		return
	var index: int = options.pick_random()

	# prefer a type that isn't already lying around
	var lying: Array = []
	for p in _slots.values():
		if is_instance_valid(p):
			lying.append(p.data)
	var data := ThrowableCatalog.pick_random(map_id, lying)
	if data == null:
		return

	var pickup := ThrowablePickup.new()
	pickup.data = data
	pickup.position = spawn_points[index]
	add_child(pickup)
	_slots[index] = pickup
	pickup.collected.connect(func(_p) -> void: _slots.erase(index))
	if Net.match_active() and Net.is_host():
		Net.game.host_tpickup_created(pickup)


func _fighter_near(world_pos: Vector2) -> bool:
	for n in get_tree().get_nodes_in_group("player"):
		if n is Node2D and (n as Node2D).global_position.distance_to(world_pos) < keep_away_from_players:
			return true
	return false


# CLIENT in a network match: the host decides what spawns, so forget whatever this map rolled on its own.
func net_clear() -> void:
	for p in _slots.values():
		if is_instance_valid(p):
			p.queue_free()
	_slots.clear()


# Offline match setup. rate_index 0 = OFF. interval_mult scales the time between spawns (higher = slower).
# max_pickups 0 = keep the map's own limit. Spawn RATE and the MAXIMUM lying around stay independent settings.
func configure_match(rate_index: int, interval_mult: float, max_pickups: int) -> void:
	net_clear()                                          # drop what this map rolled before the rules were applied
	_enabled = rate_index > 0 and not ThrowableCatalog.spawn_pool(map_id).is_empty()
	if max_pickups > 0:
		max_active = max_pickups
	if not _enabled:
		return
	interval = maxf(interval * interval_mult, 1.5)
	_timer = interval
	for i in mini(initial_spawns, max_active):
		_spawn_one()
