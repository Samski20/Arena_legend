extends Node
## Autoload "AudioMgr": volume control + menu silence.
##  - Two buses, SFX (every gun / step / explosion player is moved onto it automatically) and Music, volumes from Settings.
##  - While the game is paused (main menu, pause menu, map menu, settings, customise, end screen) BOTH buses are muted,
##    so you never hear the battle going on behind a menu. They come back the moment play resumes.
##  - A quiet procedural background loop (no audio files needed) plays during play on the Music bus.

const MUSIC_RATE := 16000
var _music: AudioStreamPlayer
var _music_ready := false
var _was_audible := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	GameSettings.ensure_loaded()
	for bus_name in ["SFX", "Music"]:
		if AudioServer.get_bus_index(bus_name) == -1:
			AudioServer.add_bus()
			var i := AudioServer.bus_count - 1
			AudioServer.set_bus_name(i, bus_name)
			AudioServer.set_bus_send(i, "Master")
	get_tree().node_added.connect(_on_node_added)
	_adopt(get_tree().root)
	_music = AudioStreamPlayer.new()
	_music.bus = "Music"
	_music.volume_db = -6.0
	add_child(_music)
	_apply(false)


func _adopt(n: Node) -> void:
	_on_node_added(n)
	for c in n.get_children():
		_adopt(c)


func _on_node_added(n: Node) -> void:
	if n == _music:
		return
	if n is AudioStreamPlayer or n is AudioStreamPlayer2D or n is AudioStreamPlayer3D:
		if str(n.get("bus")) == "Master":
			n.set("bus", "SFX")


static func _db(v: float) -> float:
	return -80.0 if v <= 0.001 else linear_to_db(clampf(v, 0.0, 1.0))


func _apply(audible: bool) -> void:
	var si := AudioServer.get_bus_index("SFX")
	var mi := AudioServer.get_bus_index("Music")
	AudioServer.set_bus_volume_db(si, _db(GameSettings.sfx_volume))
	AudioServer.set_bus_volume_db(mi, _db(GameSettings.music_volume))
	AudioServer.set_bus_mute(si, not audible)
	AudioServer.set_bus_mute(mi, not audible)


func _process(_delta: float) -> void:
	var audible := not get_tree().paused
	_apply(audible)
	if audible and not _was_audible and not _music_ready:
		_build_music()
	if audible and _music_ready and not _music.playing:
		_music.play()
	_was_audible = audible


# A calm looping pad: a slow A-minor progression with a soft arpeggio on top (12 s, seamless).
func _build_music() -> void:
	_music_ready = true
	var secs := 12.0
	var n := int(secs * MUSIC_RATE)
	var bytes := PackedByteArray()
	bytes.resize(n * 2)
	var chords := [[110.0, 164.81, 220.0, 261.63], [87.31, 130.81, 174.61, 261.63], [98.0, 146.83, 196.0, 246.94], [82.41, 123.47, 164.81, 246.94]]
	var seg := secs / 4.0
	for i in n:
		var t := float(i) / MUSIC_RATE
		var ci := mini(int(t / seg), 3)
		var lt := t - ci * seg
		var env := minf(1.0, lt / 0.9) * minf(1.0, (seg - lt) / 0.9)
		var v := 0.0
		for f in chords[ci]:
			v += sin(TAU * f * t) * 0.16 + sin(TAU * f * 2.0 * t) * 0.03
		var step := int(lt / 0.5)
		var nf: float = (chords[ci][step % 4] as float) * 4.0
		var lt2 := lt - step * 0.5
		v += sin(TAU * nf * t) * exp(-lt2 * 5.0) * 0.12
		v *= env * (0.85 + 0.15 * sin(TAU * t / 6.0))
		bytes.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 14000.0))
	var s := AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = MUSIC_RATE
	s.stereo = false
	s.data = bytes
	s.loop_mode = AudioStreamWAV.LOOP_FORWARD
	s.loop_begin = 0
	s.loop_end = n
	_music.stream = s
