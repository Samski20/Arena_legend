class_name CasingField
extends Node2D
## All spent cartridge cases in the scene, drawn in ONE pass from a small fixed pool (MAX), so a stream of
## casings from an Uzi costs next to nothing. When the pool is full the oldest casing is reused.
## A casing flies out, tumbles, falls under gravity, bounces once or twice on the ground, then fades.

const MAX := 90                       # pool size (one draw pass, so this stays cheap)
const LIFE := 14.0                    # seconds a case / magazine stays on the ground before it is gone ...
const FADE := 2.5                     # ... fading out over the last part of that
const KINDS := {                      # in-game px: [length, thickness]
	"pistol": Vector2(3.2, 1.8),
	"rifle": Vector2(4.4, 1.9),
	"shotgun": Vector2(5.6, 2.8),
	"sniper": Vector2(6.6, 2.4),
}
const BRASS := Color(0.86, 0.68, 0.28)
const MAGS := {                       # empty magazines: [width, length] in in-game px
	"pistol": Vector2(5.0, 9.0),
	"smg": Vector2(4.2, 15.0),
	"rifle": Vector2(5.5, 12.5),
	"rifle_curved": Vector2(5.5, 14.0),
	"box": Vector2(12.0, 9.0),
	"sniper_box": Vector2(7.0, 12.0),
}

var _pool: Array = []                 # fixed-size array of dictionaries, reused
var _next := 0


# The one field of this scene (made on first use).
static func of(node: Node) -> CasingField:
	var root := node.get_tree().current_scene
	if root == null:
		return null
	var f := root.get_node_or_null("CasingField") as CasingField
	if f == null:
		f = CasingField.new()
		f.name = "CasingField"
		root.add_child(f)
	return f


func _init() -> void:
	z_index = 7                       # over the characters, under the effects
	for i in MAX:
		_pool.append({"on": false})


func _ready() -> void:
	set_process(false)


func eject(world_pos: Vector2, vel: Vector2, kind: String, color: Color, spin: float, gravity: float, scale_px := 1.0) -> void:
	var c: Dictionary = _pool[_next]
	_next = (_next + 1) % MAX
	c["on"] = true
	c["pos"] = world_pos
	c["vel"] = vel
	c["rot"] = randf() * TAU
	c["spin"] = spin * randf_range(0.6, 1.2) * (1.0 if randf() > 0.3 else -1.0)
	c["age"] = 0.0
	c["kind"] = kind
	c["size"] = (KINDS.get(kind, KINDS["rifle"]) as Vector2) * scale_px
	c["color"] = color
	c["grav"] = gravity
	c["rest"] = false
	set_process(true)


# An empty magazine falls out of the gun on reload. Same pool and physics as the cases, just a bigger, darker shape.
func drop_mag(world_pos: Vector2, vel: Vector2, kind: String, color: Color, gravity: float, scale_px := 1.0) -> void:
	eject(world_pos, vel, "mag_" + kind, color, 5.0, gravity, 1.0)
	var c: Dictionary = _pool[(_next - 1 + MAX) % MAX]
	c["size"] = (MAGS.get(kind, MAGS["pistol"]) as Vector2) * scale_px


func _process(delta: float) -> void:
	var any := false
	var space := get_world_2d().direct_space_state
	for c in _pool:
		if not c["on"]:
			continue
		c["age"] += delta
		if c["age"] >= LIFE:
			c["on"] = false
			continue
		any = true
		if c["rest"]:
			continue
		var vel: Vector2 = c["vel"]
		vel.y += float(c["grav"]) * delta
		var pos: Vector2 = c["pos"]
		var nxt := pos + vel * delta
		if vel.y > 0.0:                                       # falling: look for the ground
			var q := PhysicsRayQueryParameters2D.create(pos, nxt + Vector2(0, 1.5))
			q.collide_with_areas = false
			var hit := space.intersect_ray(q)
			if not hit.is_empty() and (hit["collider"] is StaticBody2D or hit["collider"] is TileMap):
				nxt = hit["position"] - Vector2(0, 0.5)
				vel.y = -vel.y * 0.32
				vel.x *= 0.55
				c["spin"] = float(c["spin"]) * 0.4
				if absf(vel.y) < 70.0:
					vel = Vector2.ZERO
					c["rest"] = true
					c["spin"] = 0.0
		c["vel"] = vel
		c["pos"] = nxt
		c["rot"] = float(c["rot"]) + float(c["spin"]) * delta
	queue_redraw()
	if not any:
		set_process(false)


func _draw() -> void:
	for c in _pool:
		if not c["on"]:
			continue
		var a := clampf((LIFE - float(c["age"])) / FADE, 0.0, 1.0)     # stays fully visible, fades at the very end
		var size: Vector2 = c["size"]
		var col: Color = c["color"]
		draw_set_transform(c["pos"], c["rot"], Vector2.ONE)
		if String(c["kind"]).begins_with("mag_"):
			_draw_mag(String(c["kind"]).substr(4), size, col, a)
		elif c["kind"] == "shotgun":
			draw_rect(Rect2(-size.x * 0.5, -size.y * 0.5, size.x * 0.72, size.y), Color(col.r, col.g, col.b, a))              # plastic hull
			draw_rect(Rect2(size.x * 0.22, -size.y * 0.5, size.x * 0.28, size.y), Color(BRASS.r, BRASS.g, BRASS.b, a))        # brass base
		else:
			draw_rect(Rect2(-size.x * 0.5, -size.y * 0.5, size.x, size.y), Color(col.r, col.g, col.b, a))
			draw_rect(Rect2(-size.x * 0.5, -size.y * 0.5, size.x, size.y * 0.35), Color(1, 1, 0.8, 0.45 * a))                 # highlight
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


# Each gun type has its own magazine shape (size = [width, length]); drawn dark with a lighter edge so it reads on any map.
func _draw_mag(kind: String, size: Vector2, col: Color, a: float) -> void:
	var body := Color(col.r, col.g, col.b, a)
	var edge := Color(minf(col.r + 0.28, 1.0), minf(col.g + 0.28, 1.0), minf(col.b + 0.28, 1.0), 0.8 * a)
	var w := size.x
	var l := size.y
	match kind:
		"rifle_curved":                         # AK style banana magazine
			var pts := PackedVector2Array()
			for i in 6:
				var u := float(i) / 5.0
				pts.append(Vector2(-l * 0.5 + u * l, -w * 0.9 * sin(u * PI * 0.9) * 0.5 + u * u * w * 0.9))
			draw_polyline(pts, body, w, true)
			draw_polyline(pts, edge, 1.0, true)
		"box":                                  # belt-fed box (M249)
			draw_rect(Rect2(-l * 0.5, -w * 0.5, l, w), body)
			draw_rect(Rect2(-l * 0.5, -w * 0.5, l, w * 0.18), edge)
			draw_rect(Rect2(l * 0.5, -w * 0.18, w * 0.4, w * 0.36), Color(BRASS.r, BRASS.g, BRASS.b, 0.9 * a))   # a few belt links
		_:                                      # straight stick magazines: pistol, SMG, M4, sniper
			draw_rect(Rect2(-l * 0.5, -w * 0.5, l, w), body)
			draw_rect(Rect2(-l * 0.5, -w * 0.5, l * 0.12, w), edge)                                              # feed lips
			draw_rect(Rect2(l * 0.5 - l * 0.1, -w * 0.5, l * 0.1, w), Color(edge.r, edge.g, edge.b, 0.5 * a))    # base plate
