extends Area2D
## Bullet. Weapons configure it through setup(), so every weapon can have its
## own damage, speed, range and knockback.

var direction := Vector2.RIGHT
var speed := 900.0
var damage := 10
var knockback := 80.0
var max_range := 900.0
var shooter: Node = null          # who fired it, so it never hits its owner

var _travelled := 0.0


func setup(weapon: WeaponData, dir: Vector2, who: Node) -> void:
	direction = dir
	rotation = dir.angle()
	speed = weapon.projectile_speed
	damage = weapon.damage
	knockback = weapon.knockback
	max_range = weapon.max_range
	shooter = who
	modulate = weapon.bullet_color
	if weapon.pellets > 1 and has_node("Sprite2D"):
		$Sprite2D.scale *= 0.55      # shotgun pellets are short sparks, not long streaks


func _ready() -> void:
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)


func _physics_process(delta: float) -> void:
	var step := direction * speed * delta
	global_position += step
	_travelled += step.length()
	if _travelled >= max_range:
		queue_free()


func _on_body_entered(body: Node) -> void:
	if body == shooter:
		return
	if body.has_method("take_damage"):
		if "last_attacker" in body:
			body.last_attacker = shooter      # kill credit
		body.take_damage(damage, direction * knockback)
	queue_free()
