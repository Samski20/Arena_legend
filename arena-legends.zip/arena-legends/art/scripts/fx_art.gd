class_name FXArt
extends RefCounted
## Loads (and caches) the effect textures from res://art/fx/.

const DIR := "res://art/fx/"
static var _cache := {}


static func tex(tex_name: String) -> Texture2D:
	if _cache.has(tex_name):
		return _cache[tex_name]
	var path := DIR + tex_name + ".png"
	var t: Texture2D = load(path) as Texture2D if ResourceLoader.exists(path) else null
	_cache[tex_name] = t
	return t


# a random variant: pick("puff", 4) -> puff_0 .. puff_3
static func pick(base: String, count: int) -> Texture2D:
	return tex("%s_%d" % [base, randi() % count])
