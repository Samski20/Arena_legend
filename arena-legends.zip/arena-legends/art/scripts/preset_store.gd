class_name PresetStore
extends RefCounted
## Save / load / rename / delete custom match presets. Built-in presets live in MatchConfig.

const PATH := "user://match_presets.cfg"
const VERSION := 1

static var _loaded := false
static var _presets: Array[Dictionary] = []   # {id, name, config: Dictionary}


static func ensure_loaded() -> void:
	if _loaded:
		return
	_loaded = true
	_presets = []
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	var ver := int(cfg.get_value("meta", "version", 1))
	var raw: Variant = cfg.get_value("presets", "list", [])
	if raw is Array:
		for e in raw:
			if e is Dictionary and e.has("config"):
				_presets.append(e)


static func all_custom() -> Array[Dictionary]:
	ensure_loaded()
	return _presets.duplicate(true)


static func get_preset(id: String) -> Dictionary:
	ensure_loaded()
	for p in _presets:
		if p.get("id", "") == id:
			return p
	return {}


static func save_preset(name: String, config: MatchConfig, existing_id := "") -> String:
	ensure_loaded()
	var id := existing_id
	if id == "":
		id = "preset_%d" % (Time.get_unix_time_from_system() as int)
	var entry := {"id": id, "name": name, "config": config.to_dict()}
	for i in _presets.size():
		if _presets[i].get("id", "") == id:
			_presets[i] = entry
			_persist()
			return id
	_presets.append(entry)
	_persist()
	return id


static func rename_preset(id: String, new_name: String) -> bool:
	ensure_loaded()
	for i in _presets.size():
		if _presets[i].get("id", "") == id:
			_presets[i]["name"] = new_name
			_persist()
			return true
	return false


static func delete_preset(id: String) -> bool:
	ensure_loaded()
	for i in _presets.size():
		if _presets[i].get("id", "") == id:
			_presets.remove_at(i)
			_persist()
			return true
	return false


static func _persist() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("meta", "version", VERSION)
	cfg.set_value("presets", "list", _presets)
	cfg.save(PATH)
