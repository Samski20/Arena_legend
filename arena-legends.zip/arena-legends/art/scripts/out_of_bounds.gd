extends Node
## Mini Militia-style out-of-bounds rule. A map adds one of these as a child.
##
## There are NO invisible walls on the left, right and top: fighters may fly past the edge of the
## map. How far past the edge they are is measured as the distance from the safe rectangle
## (left / right / top, and the bottom too when check_bottom is on). Then:
##
##   0 ........ warning_distance ........ damage_distance ........ full_damage_distance ... kill_distance
##   free flight   "come back" warning     health drains,           drains at the           dies at once
##                                         min_damage_per_second    max_damage_per_second
##
## Between damage_distance and full_damage_distance the damage rate rises in a straight line, so it
## is predictable. Natural health regeneration is paused while the drain is active, and it stops
## the moment the fighter is back inside the damage_distance line. At 0 health the normal die() of
## the player or bot runs (death, respawn, score handling). An out-of-bounds death gives nobody a kill.
##
## Everything below is an @export (and the map forwards its own oob_* exports), so it can be tuned
## in the Inspector while testing.

@export var safe_rect := Rect2(0.0, 0.0, 1000.0, 1000.0)    # the normal playable area (set by the map)
@export var warning_distance := 150.0
@export var damage_distance := 400.0
@export var full_damage_distance := 1400.0
@export var kill_distance := 2200.0
@export var min_damage_per_second := 10.0
@export var max_damage_per_second := 60.0
@export var damage_interval := 0.25          # damage is applied in small batches this often (seconds)
## Maps with a bottomless drop (no floor) turn this on: falling below the safe rectangle counts as
## being out of bounds too, and the fall is measured bottom_scale times faster, so you die soon.
@export var check_bottom := false
@export var bottom_scale := 1.5
@export var affect_bots := true
@export var show_warning := true

var _owed := {}          # instance id -> damage not yet applied (fractions carry over)
var _clock := {}         # instance id -> seconds since the last batch
var _label: Label
var _bar: ColorRect
var _bar_fill: ColorRect


func _ready() -> void:
	if show_warning:
		_build_warning()


# Distance from the safe area, counting only the left, right and top sides.
func distance_outside(p: Vector2) -> float:
	var dx := maxf(maxf(safe_rect.position.x - p.x, p.x - safe_rect.end.x), 0.0)
	var dy := maxf(safe_rect.position.y - p.y, 0.0)
	if check_bottom:
		dy = maxf(dy, maxf(p.y - safe_rect.end.y, 0.0) * bottom_scale)
	return Vector2(dx, dy).length()


# Damage per second at a given distance (0 below damage_distance).
func damage_rate_at(dist: float) -> float:
	if dist < damage_distance:
		return 0.0
	var span := maxf(full_damage_distance - damage_distance, 1.0)
	var t := clampf((dist - damage_distance) / span, 0.0, 1.0)
	return lerpf(min_damage_per_second, max_damage_per_second, t)


func _physics_process(delta: float) -> void:
	var player_state := {"dist": 0.0, "rate": 0.0, "hp": 0.0}
	for body in get_tree().get_nodes_in_group("player"):
		_step(body as Node2D, delta, true, player_state)
	if affect_bots:
		for body in get_tree().get_nodes_in_group("bot"):
			_step(body as Node2D, delta, false, player_state)
	_update_warning(player_state)


func _step(body: Node2D, delta: float, is_player: bool, state: Dictionary) -> void:
	if body == null or not is_instance_valid(body):
		return
	var id := body.get_instance_id()
	if body.get("is_dead") == true or body.get("dead") == true:
		_owed.erase(id)
		_clock.erase(id)
		return
	var dist := distance_outside(body.global_position)
	if is_player:
		state["dist"] = dist
		state["hp"] = float(body.get("health"))
	if dist < damage_distance:
		_owed.erase(id)                                  # back inside the line: the drain stops
		_clock.erase(id)
		return

	var rate := damage_rate_at(dist)
	if is_player:
		state["rate"] = rate
	# no healing while the drain is active
	if body.get("_time_since_hit") != null:
		body.set("_time_since_hit", 0.0)

	if dist >= kill_distance:
		_apply(body, is_player, maxi(int(body.get("health")), 1))
		_owed.erase(id)
		_clock.erase(id)
		return

	_owed[id] = float(_owed.get(id, 0.0)) + rate * delta
	_clock[id] = float(_clock.get(id, 0.0)) + delta
	if float(_clock[id]) >= damage_interval:
		_clock[id] = 0.0
		var whole := int(_owed[id])
		if whole >= 1:
			_owed[id] = float(_owed[id]) - float(whole)
			_apply(body, is_player, whole)


func _apply(body: Node2D, is_player: bool, amount: int) -> void:
	body.set("last_attacker", null)               # nobody gets the kill credit
	if is_player:
		body.set_meta("_oob", true)                            # lets Infinite Health know this is NOT combat damage
		body.call("take_damage", amount, Vector2.ZERO, true)   # true = ignore the shield
		body.remove_meta("_oob")
	else:
		body.call("take_damage", amount, Vector2.ZERO)


# ---------------------------------------------------------------- warning on screen

func _build_warning() -> void:
	var layer := CanvasLayer.new()
	layer.name = "OutOfBoundsWarning"
	layer.layer = 20
	add_child(layer)

	_label = Label.new()
	_label.set_anchors_preset(Control.PRESET_TOP_WIDE)
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.position.y = 64.0
	_label.add_theme_font_size_override("font_size", 24)
	_label.add_theme_color_override("font_outline_color", Color.BLACK)
	_label.add_theme_constant_override("outline_size", 6)
	_label.visible = false
	layer.add_child(_label)

	_bar = ColorRect.new()
	_bar.color = Color(0.0, 0.0, 0.0, 0.55)
	_bar.custom_minimum_size = Vector2(220.0, 8.0)
	_bar.size = Vector2(220.0, 8.0)
	_bar.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_bar.position = Vector2(-110.0, 100.0)
	_bar.visible = false
	layer.add_child(_bar)

	_bar_fill = ColorRect.new()
	_bar_fill.color = Color(1.0, 0.35, 0.2)
	_bar_fill.position = Vector2(1.0, 1.0)
	_bar_fill.size = Vector2(0.0, 6.0)
	_bar.add_child(_bar_fill)


func _update_warning(state: Dictionary) -> void:
	if _label == null:
		return
	var dist: float = state["dist"]
	if dist < warning_distance:
		_label.visible = false
		_bar.visible = false
		return
	_label.visible = true
	if dist < damage_distance:
		_label.text = "LEAVING THE ARENA - TURN BACK"
		_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.3))
		_bar.visible = false
		return
	var rate: float = state["rate"]
	var seconds := float(state["hp"]) / maxf(rate, 0.01)
	_label.text = "OUT OF BOUNDS - RETURN NOW  (%.1f s)" % seconds
	_label.add_theme_color_override("font_color", Color(1.0, 0.35, 0.3))
	_bar.visible = true
	var t := clampf((dist - damage_distance) / maxf(kill_distance - damage_distance, 1.0), 0.0, 1.0)
	_bar_fill.size.x = 218.0 * t
