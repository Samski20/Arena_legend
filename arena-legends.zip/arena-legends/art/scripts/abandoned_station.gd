class_name AbandonedStation
extends Node2D
## MAP 1: ABANDONED STATION.  5200 x 2600 px (about 4.5 screens wide, 4 tall).
##
## Everything is built by this script (collision, art, lights, particles, pickups,
## spawns), same style as your other scripts.
##
## SETUP
##  1. New scene -> root node = Node2D, name it AbandonedStation, attach this script.
##     (It must be the ROOT of the scene: player.gd looks for "SpawnPoint" there.)
##  2. In the Inspector drag player.tscn into Player Scene and bot.tscn into Bot Scene.
##     (Or place a node called "Player" in the scene yourself and leave Player Scene empty.)
##  3. Optional: drag match_manager.gd into Match Manager Script.
##  4. Run.
##
## TACTICAL SPOTS (callouts are painted on the walls):
##  - SNIPER NESTS (left + right, y=1350): roofed, front cover wall, long sightlines over the deck.
##  - CONTROL ROOM (top centre): the high ground. Two doors, a console to crouch behind.
##  - REACTOR HUB (centre): raised pad, two columns, catwalk roof. Close-range brawls.
##  - MAINTENANCE TUNNELS (under the deck): tight, pillars + crates. Drop in through the two hatches.
##  - GANTRIES (hanging platforms) + CATWALKS: mid-air lanes for jetpack fights.
##  - CARGO BAYS (spawns): crates and a low door to peek through.

const W := 5200.0
const H := 2600.0

# ---------- palette ----------
const C_BG := Color("0d1322")
const C_STEEL := Color("2a3450")
const C_STEEL_HI := Color("5b6e96")
const C_STEEL_LO := Color("141b2d")
const C_CYAN := Color("5ff0ff")
const C_ORANGE := Color("f28a2e")
const C_YELLOW := Color("e8b923")
const C_DARK := Color("12151d")
const C_RED := Color("ff3b3b")
const C_GREEN := Color("8ce037")

@export var map_id := "abandoned_station"    # throwables use this to decide what can spawn here
@export var player_scene: PackedScene
@export var bot_scene: PackedScene
@export var bot_count := 3
@export var match_manager_script: Script
@export var weapon_pool: Array[WeaponData] = []   # empty = loads rifle / shotgun / smg / sniper automatically
@export var show_callouts := true                 # painted area names on the walls
@export var darkness := Color(0.80, 0.85, 0.97)   # overall mood tint (white = no tint)

var _solids: Array = []        # {r: Rect2, kind: String}
var _windows: Array = []       # {rect, stars, planet, breach}
var _lights: Array = []
var _vents: Array = []
var _sparks: Array = []
var _t := 0.0

var _glow: Texture2D
var _puff: Texture2D
var _add_mat: CanvasItemMaterial
var _win_layer: Layer
var _q := 0                    # graphics quality: 0 Low (original look), 1 Medium, 2 High (Settings > Graphics Quality)
var _art_layers: Array = []    # the painted layers, so a quality change can rebuild them live
var _rng := RandomNumberGenerator.new()


# =====================================================================
#  small helper nodes (inner classes)
# =====================================================================
class Layer extends Node2D:
	var painter: Callable
	func _draw() -> void:
		if painter.is_valid():
			painter.call(self)


class Beacon extends Node2D:
	var color := Color(1, 0.2, 0.15)
	var spin := 3.2
	var length := 380.0
	func _process(delta: float) -> void:
		rotation += spin * delta
	func _draw() -> void:
		for side in [0.0, PI]:
			var a0: float = side - 0.22
			var a1: float = side + 0.22
			var pts := PackedVector2Array([Vector2.ZERO, Vector2(cos(a0), sin(a0)) * length, Vector2(cos(a1), sin(a1)) * length])
			var cols := PackedColorArray([Color(color.r, color.g, color.b, 0.55), Color(color.r, color.g, color.b, 0.0), Color(color.r, color.g, color.b, 0.0)])
			draw_polygon(pts, cols)
		draw_circle(Vector2.ZERO, 7.0, Color(color.r, color.g, color.b, 0.95))
		draw_circle(Vector2.ZERO, 14.0, Color(color.r, color.g, color.b, 0.25))


class ReactorCore extends Node2D:
	var t := 0.0
	var _r := RandomNumberGenerator.new()
	func _process(delta: float) -> void:
		t += delta
		queue_redraw()
	func _draw() -> void:
		var cyan := Color("5ff0ff")
		var steel := Color("2a3450")
		var hi := Color("5b6e96")
		var pulse := 0.5 + 0.5 * sin(t * 2.6)
		# base + cap
		draw_rect(Rect2(-78, -16, 156, 16), steel)
		draw_rect(Rect2(-78, -16, 156, 3), hi)
		draw_rect(Rect2(-62, -314, 124, 14), steel)
		draw_rect(Rect2(-62, -314, 124, 3), hi)
		# glass tube
		draw_rect(Rect2(-44, -300, 88, 284), Color(cyan.r, cyan.g, cyan.b, 0.07))
		draw_line(Vector2(-44, -300), Vector2(-44, -16), Color(cyan.r, cyan.g, cyan.b, 0.55), 2.0)
		draw_line(Vector2(44, -300), Vector2(44, -16), Color(cyan.r, cyan.g, cyan.b, 0.55), 2.0)
		# energy column
		var w := 20.0 + pulse * 8.0
		draw_rect(Rect2(-w * 0.5, -296, w, 278), Color(cyan.r, cyan.g, cyan.b, 0.30 + pulse * 0.12))
		draw_rect(Rect2(-w * 0.2, -296, w * 0.4, 278), Color(0.85, 1.0, 1.0, 0.65))
		# rings with a running light
		for i in 4:
			var y := -60.0 - i * 68.0
			var pts := PackedVector2Array()
			for k in 25:
				var a := TAU * k / 24.0
				pts.append(Vector2(cos(a) * 58.0, y + sin(a) * 11.0))
			draw_polyline(pts, Color(cyan.r, cyan.g, cyan.b, 0.5), 2.0)
			var dot := t * (2.0 + i * 0.4) + i
			draw_circle(Vector2(cos(dot) * 58.0, y + sin(dot) * 11.0), 4.0, Color(0.9, 1.0, 1.0, 0.95))
		# crackling bolts (re-rolled 10x a second)
		_r.seed = int(t * 10.0)
		for b in 2:
			var from := Vector2(0, -60.0 - _r.randf() * 200.0)
			var to := Vector2(_r.randf_range(-44.0, 44.0), from.y + _r.randf_range(-70.0, 70.0))
			var pts2 := PackedVector2Array([from])
			for s in 4:
				pts2.append(from.lerp(to, (s + 1) / 4.0) + Vector2(_r.randf_range(-9, 9), _r.randf_range(-9, 9)))
			draw_polyline(pts2, Color(0.9, 1.0, 1.0, 0.8), 1.6)


class Hologram extends Node2D:
	var t := 0.0
	func _process(delta: float) -> void:
		t += delta
		queue_redraw()
	func _draw() -> void:
		var flick := 0.75 + 0.25 * sin(t * 31.0) * sin(t * 7.0)
		if fmod(t, 5.3) > 5.1:
			flick *= 0.25                                   # occasional glitch
		var col := Color(0.37, 0.94, 1.0, 0.8 * flick)
		var th := t * 0.9
		var verts := [Vector3(1, 0, 0), Vector3(-1, 0, 0), Vector3(0, 1.25, 0), Vector3(0, -1.25, 0), Vector3(0, 0, 1), Vector3(0, 0, -1)]
		var pts: Array[Vector2] = []
		for v in verts:
			var x: float = v.x * cos(th) + v.z * sin(th)
			pts.append(Vector2(x, v.y * 0.9) * 34.0 + Vector2(0, -42))
		for i in verts.size():
			for j in range(i + 1, verts.size()):
				if (verts[i] + verts[j]).length() > 0.01:       # skip opposite corners
					draw_line(pts[i], pts[j], col, 1.5)
		# projector disc + orbit ring
		var ring := PackedVector2Array()
		for k in 25:
			var a := TAU * k / 24.0
			ring.append(Vector2(cos(a) * 50.0, -42.0 + sin(a + th) * 8.0))
		draw_polyline(ring, Color(col.r, col.g, col.b, 0.45 * flick), 1.2)
		draw_rect(Rect2(-22, -4, 44, 6), Color(0.2, 0.3, 0.4, 0.9))
		draw_line(Vector2(-18, -4), Vector2(-60, -88), Color(col.r, col.g, col.b, 0.1 * flick), 2.0)
		draw_line(Vector2(18, -4), Vector2(60, -88), Color(col.r, col.g, col.b, 0.1 * flick), 2.0)
		# scanlines
		var sy := fposmod(t * 40.0, 90.0)
		draw_line(Vector2(-46, -90 + sy), Vector2(46, -90 + sy), Color(col.r, col.g, col.b, 0.35 * flick), 1.5)
		draw_string(ThemeDB.fallback_font, Vector2(-58, 22), "STATION: OFFLINE", HORIZONTAL_ALIGNMENT_CENTER, 116.0, 12, Color(1.0, 0.45, 0.3, 0.85 * flick))


# =====================================================================
#  build
# =====================================================================
func _ready() -> void:
	GameSettings.ensure_loaded()
	_q = GameSettings.quality
	add_to_group("quality_aware")             # the settings menu calls apply_quality() on us
	add_to_group("map_" + map_id)
	_rng.seed = 1337
	_make_shared_resources()
	_define_layout()
	_define_windows()

	var cm := CanvasModulate.new()
	cm.color = darkness
	add_child(cm)

	_build_art_layers()
	_build_collisions()
	_build_lights_and_fx()
	_build_weapon_pickups()
	_build_throwable_spawner()
	_spawn_fighters()
	_add_match_manager()
	_add_vignette()


func _process(delta: float) -> void:
	_t += delta
	_update_lights()
	_update_vents()
	_update_sparks(delta)
	if _win_layer:
		_win_layer.queue_redraw()


func _make_shared_resources() -> void:
	_add_mat = CanvasItemMaterial.new()
	_add_mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	_glow = _radial_tex(128, false)
	_puff = _radial_tex(64, true)


# round soft blob. soft = true gives a fuller, puffier blob (smoke / dust), false = tight glow
func _radial_tex(size: int, soft: bool) -> Texture2D:
	var g := Gradient.new()
	if soft:
		g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0.55), Color(1, 1, 1, 0)])
		g.offsets = PackedFloat32Array([0.0, 0.45, 1.0])
	else:
		g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0)])
		g.offsets = PackedFloat32Array([0.0, 1.0])
	var tex := GradientTexture2D.new()
	tex.gradient = g
	tex.width = size
	tex.height = size
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.5)
	tex.fill_to = Vector2(1.0, 0.5)
	return tex


# =====================================================================
#  layout (all the solid geometry)
# =====================================================================
func _mirror(r: Rect2) -> Rect2:
	return Rect2(W - r.position.x - r.size.x, r.position.y, r.size.x, r.size.y)


func _add(r: Rect2, kind: String, mirrored := false) -> void:
	_solids.append({"r": r, "kind": kind})
	if mirrored:
		_solids.append({"r": _mirror(r), "kind": kind})


func _define_layout() -> void:
	# --- hull ---
	_add(Rect2(0, 2480, W, 120), "hull")            # maintenance floor
	_add(Rect2(0, 0, 60, H), "hull")                # left wall
	_add(Rect2(W - 60, 0, 60, H), "hull")           # right wall
	_add(Rect2(0, 0, W, 60), "hull")                # ceiling

	# --- main deck (two hatches drop into the maintenance tunnels) ---
	_add(Rect2(60, 2200, 1440, 40), "deck", true)
	_add(Rect2(1760, 2200, 1680, 40), "deck")

	# --- maintenance tunnels: pillars + crates ---
	_add(Rect2(800, 2240, 44, 240), "pillar", true)
	_add(Rect2(2180, 2240, 44, 240), "pillar", true)
	_add(Rect2(2578, 2240, 44, 240), "pillar")
	_add(Rect2(1250, 2410, 120, 70), "crate", true)

	# --- cargo bays (spawns): low door wall + crates ---
	_add(Rect2(700, 1930, 24, 150), "wall", true)
	_add(Rect2(1180, 2090, 140, 110), "crate", true)
	_add(Rect2(1060, 2150, 90, 50), "crate", true)
	_add(Rect2(1400, 2130, 90, 70), "crate", true)

	# --- reactor hub ---
	_add(Rect2(2300, 2080, 600, 120), "hub")
	_add(Rect2(2230, 2140, 70, 60), "hub")
	_add(Rect2(2900, 2140, 70, 60), "hub")
	_add(Rect2(2380, 1724, 40, 356), "column")
	_add(Rect2(2780, 1724, 40, 356), "column")
	_add(Rect2(2200, 1700, 800, 24), "cat")

	# --- control room (high ground) ---
	_add(Rect2(2150, 1050, 900, 30), "room")
	_add(Rect2(2150, 780, 900, 30), "roof")
	_add(Rect2(2150, 810, 30, 120), "room")
	_add(Rect2(3020, 810, 30, 120), "room")
	_add(Rect2(2520, 1010, 160, 40), "console")

	# --- catwalks, stepping platforms, gantries ---
	_add(Rect2(560, 1860, 700, 24), "cat", true)
	_add(Rect2(1950, 1960, 110, 24), "cat", true)
	_add(Rect2(1380, 1500, 420, 22), "gantry", true)
	_add(Rect2(900, 1620, 220, 22), "cat", true)

	# --- sniper nests ---
	_add(Rect2(260, 1350, 560, 28), "nest", true)
	_add(Rect2(260, 1170, 560, 24), "nest_roof", true)
	_add(Rect2(780, 1290, 26, 60), "wall", true)


func _build_collisions() -> void:
	for s in _solids:
		var r: Rect2 = s["r"]
		var body := StaticBody2D.new()
		body.position = r.get_center()
		body.add_to_group("map_solid")
		var shape := CollisionShape2D.new()
		var rect := RectangleShape2D.new()
		rect.size = r.size
		shape.shape = rect
		body.add_child(shape)
		add_child(body)


# =====================================================================
#  windows (space outside)
# =====================================================================
func _define_windows() -> void:
	_add_window(Rect2(1750, 150, 1700, 540), true, false)      # big observation window with the planet
	_add_window(Rect2(240, 260, 560, 700), false, false)
	_add_window(Rect2(W - 240 - 560, 260, 560, 700), false, false)
	_add_window(Rect2(3720, 60, 300, 250), false, true)        # hull breach


func _add_window(r: Rect2, planet: bool, breach: bool) -> void:
	var stars: Array = []
	var count := clampi(int(r.size.x * r.size.y / 4200.0), 40, 220)
	for i in count:
		stars.append([
			Vector2(_rng.randf() * r.size.x, _rng.randf() * r.size.y),     # position inside the window
			_rng.randf_range(0.01, 0.14),                                   # depth (parallax strength)
			_rng.randf_range(1.5, 3.4),                                     # size
			_rng.randf() * TAU,                                             # twinkle phase
			Color(0.75 + _rng.randf() * 0.25, 0.85 + _rng.randf() * 0.15, 1.0),
		])
	var debris: Array = []
	for i in 4:
		debris.append([_rng.randf(), _rng.randf(), _rng.randf_range(6.0, 16.0), _rng.randf_range(8.0, 22.0), _rng.randf() * TAU])
	_windows.append({"rect": r, "stars": stars, "planet": planet, "breach": breach, "debris": debris})


func _cam_center() -> Vector2:
	return get_canvas_transform().affine_inverse() * (get_viewport_rect().size * 0.5)


func _paint_windows(c: CanvasItem) -> void:
	var off := _cam_center() - Vector2(W, H) * 0.5          # how far the camera is from the map centre
	for w in _windows:
		var r: Rect2 = w["rect"]
		c.draw_rect(r, Color("03050b"))
		# faint nebula glow
		var neb := r.position + r.size * Vector2(0.28, 0.4) - off * 0.03
		_clipped_circle(c, neb, r.size.y * 0.55, Color(0.25, 0.15, 0.5, 0.10), r)
		_clipped_circle(c, neb + Vector2(60, 40), r.size.y * 0.32, Color(0.15, 0.35, 0.6, 0.09), r)
		# stars (wrap inside the window so they slide with parallax)
		for s in w["stars"]:
			var p: Vector2 = s[0]
			var depth: float = s[1]
			var sp := Vector2(fposmod(p.x - off.x * depth, r.size.x), fposmod(p.y - off.y * depth, r.size.y)) + r.position
			var tw := 0.55 + 0.45 * sin(_t * 1.7 + float(s[3]))
			var col: Color = s[4]
			c.draw_rect(Rect2(sp, Vector2(s[2], s[2])), Color(col.r, col.g, col.b, tw))
		# planet
		if w["planet"]:
			var pc := r.position + r.size * Vector2(0.72, 0.66) - off * 0.06
			var pr := 270.0
			_clipped_circle(c, pc, pr + 26.0, Color(0.3, 0.8, 1.0, 0.10), r)          # atmosphere
			_clipped_circle(c, pc, pr, Color("0f2745"), r)
			_clipped_circle(c, pc + Vector2(-22, -18), pr * 0.93, Color("17406b"), r)
			_clipped_circle(c, pc + Vector2(-70, -60), pr * 0.62, Color(0.3, 0.65, 0.9, 0.35), r)
			# storm bands
			for b in 4:
				var by := pc.y - pr * 0.6 + b * pr * 0.32
				var band := PackedVector2Array([Vector2(pc.x - pr, by), Vector2(pc.x + pr, by), Vector2(pc.x + pr, by + 14), Vector2(pc.x - pr, by + 14)])
				var inside := Geometry2D.intersect_polygons(band, _circle_poly(pc, pr * 0.97))
				for piece in inside:
					_clipped_poly(c, piece, Color(0.6, 0.85, 1.0, 0.07), r)
			# moon
			_clipped_circle(c, r.position + r.size * Vector2(0.18, 0.28) - off * 0.1, 34.0, Color("8b93a8"), r)
			_clipped_circle(c, r.position + r.size * Vector2(0.18, 0.28) - off * 0.1 + Vector2(8, 6), 30.0, Color("5f677c"), r)
		# drifting debris
		for d in w["debris"]:
			var dx := fposmod(float(d[0]) * r.size.x + _t * float(d[3]) - off.x * 0.08, r.size.x)
			var dy := float(d[1]) * r.size.y + sin(_t * 0.4 + float(d[4])) * 10.0
			var ang := _t * 0.5 + float(d[4])
			var sz: float = d[2]
			var poly := PackedVector2Array()
			for k in 5:
				var a := ang + TAU * k / 5.0
				poly.append(r.position + Vector2(dx, dy) + Vector2(cos(a), sin(a)) * sz * (0.6 + 0.4 * float(k % 2)))
			_clipped_poly(c, poly, Color(0.35, 0.38, 0.46), r)
		# frame
		if w["breach"]:
			_paint_breach_frame(c, r)
		else:
			var fr := C_STEEL
			c.draw_rect(Rect2(r.position.x - 20, r.position.y - 20, r.size.x + 40, 20), fr)
			c.draw_rect(Rect2(r.position.x - 20, r.end.y, r.size.x + 40, 20), fr)
			c.draw_rect(Rect2(r.position.x - 20, r.position.y, 20, r.size.y), fr)
			c.draw_rect(Rect2(r.end.x, r.position.y, 20, r.size.y), fr)
			c.draw_rect(r.grow(20), C_STEEL_LO, false, 3.0)
			c.draw_rect(r, Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.35), false, 2.0)
			var mx := r.position.x + 340.0
			while mx < r.end.x - 100.0:                     # window bars
				c.draw_rect(Rect2(mx - 7, r.position.y, 14, r.size.y), C_STEEL)
				c.draw_rect(Rect2(mx - 7, r.position.y, 3, r.size.y), C_STEEL_HI)
				mx += 340.0
			# glass sheen + a crack
			c.draw_line(r.position + Vector2(40, r.size.y - 30), r.position + Vector2(r.size.x * 0.35, 30), Color(1, 1, 1, 0.05), 24.0)
			if w["planet"]:
				var cp := r.position + Vector2(r.size.x * 0.58, r.size.y * 0.12)
				c.draw_polyline(PackedVector2Array([cp, cp + Vector2(30, 60), cp + Vector2(10, 110), cp + Vector2(52, 190), cp + Vector2(40, 250)]), Color(1, 1, 1, 0.22), 1.6)
				c.draw_polyline(PackedVector2Array([cp + Vector2(30, 60), cp + Vector2(90, 80), cp + Vector2(120, 130)]), Color(1, 1, 1, 0.16), 1.2)


func _paint_breach_frame(c: CanvasItem, r: Rect2) -> void:
	var rr := RandomNumberGenerator.new()
	rr.seed = 99
	var jag := PackedVector2Array()
	var steps := 14
	for i in steps + 1:
		jag.append(Vector2(r.position.x + r.size.x * i / steps, r.end.y + rr.randf_range(-6.0, 26.0)))     # bottom
	for i in range(1, steps):
		jag.append(Vector2(r.end.x + rr.randf_range(-6.0, 24.0), r.end.y - r.size.y * i / steps))        # right
	jag.append(Vector2(r.end.x, r.position.y))
	jag.append(Vector2(r.position.x, r.position.y))
	for i in range(steps - 1, 0, -1):
		jag.append(Vector2(r.position.x - rr.randf_range(-6.0, 24.0), r.end.y - r.size.y * i / steps))    # left
	c.draw_polyline(jag, Color(C_ORANGE.r, C_ORANGE.g, C_ORANGE.b, 0.9), 4.0)
	c.draw_polyline(jag, Color(0.05, 0.05, 0.08), 12.0)
	c.draw_polyline(jag, Color(C_ORANGE.r, C_ORANGE.g, C_ORANGE.b, 0.85), 3.0)
	# bent beams across the hole
	c.draw_line(r.position + Vector2(10, 60), r.position + Vector2(r.size.x - 30, 8), Color("2a3450"), 9.0)
	c.draw_line(r.position + Vector2(r.size.x * 0.5, r.size.y), r.position + Vector2(r.size.x * 0.62, r.size.y * 0.35), Color("2a3450"), 7.0)


func _circle_poly(center: Vector2, radius: float, n := 48) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in n:
		var a := TAU * i / float(n)
		pts.append(center + Vector2(cos(a), sin(a)) * radius)
	return pts


func _clipped_poly(c: CanvasItem, poly: PackedVector2Array, col: Color, clip: Rect2) -> void:
	var rect_poly := PackedVector2Array([clip.position, Vector2(clip.end.x, clip.position.y), clip.end, Vector2(clip.position.x, clip.end.y)])
	for piece in Geometry2D.intersect_polygons(poly, rect_poly):
		if piece.size() >= 3:
			c.draw_colored_polygon(piece, col)


func _clipped_circle(c: CanvasItem, center: Vector2, radius: float, col: Color, clip: Rect2) -> void:
	_clipped_poly(c, _circle_poly(center, radius), col, clip)


# =====================================================================
#  art layers
# =====================================================================
func _make_layer(z: int, painter: Callable) -> Layer:
	var l := Layer.new()
	l.z_index = z
	l.painter = painter
	add_child(l)
	_art_layers.append(l)
	return l


func _build_art_layers() -> void:
	_make_layer(-100, _paint_wall)
	_win_layer = _make_layer(-90, _paint_windows)
	_make_layer(-60, _paint_props)
	if _q == 0:
		_make_layer(-20, _paint_solids)           # Low: one layer, exactly the original drawing
	else:
		# Medium / High draw more per solid, so each solid gets its own layer: the engine then skips every
		# solid that is off screen instead of redrawing the whole station each frame.
		for item in _solids:
			_make_layer(-20, _paint_solid_one.bind(item))


# Called by the settings menu when Graphics Quality changes: repaints the station's artwork, live.
func apply_quality() -> void:
	var nq := GameSettings.quality
	if nq == _q and not _art_layers.is_empty():
		return
	_q = nq
	for l in _art_layers:
		if is_instance_valid(l):
			l.queue_free()
	_art_layers.clear()
	_win_layer = null
	_build_art_layers()


# ---------- back wall ----------
func _paint_wall(c: CanvasItem) -> void:
	_paint_wall_base(c)
	if _q >= 1:
		_wall_depth(c)


# Medium / High: the back wall gets some depth, a darker ceiling and floor and (High) grime stains.
func _wall_depth(c: CanvasItem) -> void:
	for i in 8:                                     # ceiling falls into shadow
		c.draw_rect(Rect2(0.0, float(i) * 36.0, W, 36.0), Color(0, 0, 0, 0.07 * (1.0 - float(i) / 8.0)))
	for i in 8:                                     # and so does the floor
		c.draw_rect(Rect2(0.0, H - float(i + 1) * 40.0, W, 40.0), Color(0, 0, 0, 0.06 * (1.0 - float(i) / 8.0)))
	if _q == 2:
		var rr := RandomNumberGenerator.new()
		rr.seed = 4242
		for i in 70:
			var x := rr.randf_range(0.0, W)
			var y := rr.randf_range(60.0, H - 60.0)
			var len := rr.randf_range(60.0, 220.0)
			c.draw_rect(Rect2(x, y, rr.randf_range(3.0, 7.0), len), Color(0.0, 0.0, 0.0, rr.randf_range(0.03, 0.07)))   # damp streaks
		for i in 40:
			c.draw_circle(Vector2(rr.randf_range(0.0, W), rr.randf_range(100.0, H - 100.0)), rr.randf_range(24.0, 60.0), Color(0.0, 0.0, 0.0, 0.035))   # dirt blotches


func _paint_wall_base(c: CanvasItem) -> void:
	c.draw_rect(Rect2(0, 0, W, H), C_BG)
	var line := Color(0.17, 0.22, 0.34, 0.9)
	var rr := RandomNumberGenerator.new()
	rr.seed = 7
	var gx := 0
	while gx * 260 < W:
		var gy := 0
		while gy * 260 < H:
			if rr.randf() < 0.38:
				c.draw_rect(Rect2(gx * 260 + 3, gy * 260 + 3, 254, 254), Color(1, 1, 1, 0.022))
			gy += 1
		gx += 1
	for x in range(0, int(W) + 1, 260):
		c.draw_line(Vector2(x, 0), Vector2(x, H), line, 2.0)
	for y in range(0, int(H) + 1, 260):
		c.draw_line(Vector2(0, y), Vector2(W, y), line, 2.0)
	# big structural ribs
	for x in range(400, int(W), 800):
		c.draw_rect(Rect2(x - 14, 60, 28, H - 60), Color(0.08, 0.11, 0.19))
		c.draw_rect(Rect2(x - 14, 60, 4, H - 60), Color(0.2, 0.26, 0.4, 0.8))
	# reactor chamber emblem behind the hub
	var ec := Vector2(2600, 1900)
	for i in 4:
		c.draw_arc(ec, 150.0 + i * 36.0, 0.0, TAU, 64, Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.07 + i * 0.01), 3.0)
	for i in 12:
		var a := TAU * i / 12.0
		c.draw_line(ec + Vector2(cos(a), sin(a)) * 150.0, ec + Vector2(cos(a), sin(a)) * 258.0, Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.07), 2.0)

	if show_callouts:
		_callout(c, "SECTOR 7  //  ABANDONED STATION", W * 0.5, 1330.0, 56, 0.10, true)
		_callout(c, "SNIPER NEST", 280.0, 1120.0, 46, 0.22, false, true)
		_callout(c, "CONTROL ROOM", 2600.0, 748.0, 40, 0.24, true)
		_callout(c, "REACTOR HUB", 2600.0, 1655.0, 46, 0.22, true)
		_callout(c, "MAINTENANCE", 1000.0, 2318.0, 38, 0.2, false, true)
		_callout(c, "CARGO BAY", 120.0, 1990.0, 40, 0.22, false, true)
		_callout(c, "GANTRY", 1390.0, 1450.0, 30, 0.22, false, true)
		_callout(c, "HATCH", 1630.0, 2262.0, 24, 0.5, true)
		_callout(c, "HATCH", 3570.0, 2262.0, 24, 0.5, true)


# draws text; `mirror` also draws the right-side twin. `center` = x is the middle of the text.
func _callout(c: CanvasItem, text: String, x: float, y: float, size: int, alpha: float, center := false, mirror := false) -> void:
	var font := ThemeDB.fallback_font
	var col := Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, alpha)
	var width := font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	var px := x - width * 0.5 if center else x
	c.draw_string(font, Vector2(px, y), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)
	if mirror:
		var mx := W - px - width
		c.draw_string(font, Vector2(mx, y), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)


# ---------- little drawing helpers ----------
func _panel(c: CanvasItem, r: Rect2, base: Color, hi: Color, lo: Color, seam := 120.0) -> void:
	c.draw_rect(r, base)
	c.draw_rect(Rect2(r.position.x, r.position.y + r.size.y * 0.55, r.size.x, r.size.y * 0.45), Color(0, 0, 0, 0.16))
	if r.size.x > seam * 1.5:
		var x := r.position.x + seam
		while x < r.end.x - 4.0:
			c.draw_line(Vector2(x, r.position.y + 3), Vector2(x, r.end.y - 3), lo, 2.0)
			x += seam
	if r.size.y > seam * 1.5:
		var y := r.position.y + seam
		while y < r.end.y - 4.0:
			c.draw_line(Vector2(r.position.x + 3, y), Vector2(r.end.x - 3, y), lo, 2.0)
			y += seam
	c.draw_rect(Rect2(r.position.x, r.position.y, r.size.x, 4), hi)
	c.draw_rect(Rect2(r.position.x, r.end.y - 3, r.size.x, 3), lo)
	c.draw_rect(r, lo, false, 2.0)
	if r.size.x > 30 and r.size.y > 30:
		for p in [Vector2(8, 10), Vector2(r.size.x - 8, 10), Vector2(8, r.size.y - 9), Vector2(r.size.x - 8, r.size.y - 9)]:
			c.draw_circle(r.position + p, 2.0, Color(hi.r, hi.g, hi.b, 0.55))


func _hazard(c: CanvasItem, r: Rect2) -> void:
	c.draw_rect(r, C_DARK)
	var step := 20.0
	var x := r.position.x - r.size.y
	while x < r.end.x:
		var poly := PackedVector2Array([
			Vector2(x, r.end.y), Vector2(x + step * 0.5, r.end.y),
			Vector2(x + step * 0.5 + r.size.y, r.position.y), Vector2(x + r.size.y, r.position.y)])
		_clipped_poly(c, poly, C_YELLOW, r)
		x += step


func _paint_solids(c: CanvasItem) -> void:
	for s in _solids:
		_paint_solid_one(c, s)


func _paint_solid_one(c: CanvasItem, s: Dictionary) -> void:
	var r: Rect2 = s["r"]
	match s["kind"]:
		"hull":
			_panel(c, r, Color("141b2c"), Color("33415f"), Color("0a0f1b"), 200.0)
		"deck":
			_paint_deck(c, r)
		"nest":
			_paint_deck(c, r)
		"nest_roof":
			_panel(c, r, Color("1d263b"), C_STEEL_HI, C_STEEL_LO, 140.0)
			c.draw_line(Vector2(r.position.x + 20, r.end.y + 4), Vector2(r.end.x - 20, r.end.y + 4), Color(C_ORANGE.r, C_ORANGE.g, C_ORANGE.b, 0.5), 2.0)
		"cat":
			_paint_catwalk(c, r, true)
		"gantry":
			_paint_catwalk(c, r, false)
		"pillar", "column":
			_paint_column(c, r)
		"crate":
			_paint_crate(c, r)
		"wall":
			_panel(c, r, C_STEEL, C_STEEL_HI, C_STEEL_LO, 80.0)
			_hazard(c, Rect2(r.position.x, r.position.y, r.size.x, 12))
			c.draw_line(Vector2(r.get_center().x, r.position.y + 18), Vector2(r.get_center().x, r.end.y - 6), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.5), 2.0)
		"hub":
			_panel(c, r, C_STEEL, C_ORANGE, C_STEEL_LO, 100.0)
		"room":
			_panel(c, r, Color("37425f"), C_CYAN.darkened(0.25), C_STEEL_LO, 150.0)
		"roof":
			_panel(c, r, Color("2a334c"), C_STEEL_HI, C_STEEL_LO, 150.0)
			c.draw_line(Vector2(r.position.x + 20, r.end.y + 4), Vector2(r.end.x - 20, r.end.y + 4), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.45), 2.0)
		"console":
			_panel(c, r, Color("2b3550"), C_CYAN, C_STEEL_LO, 80.0)
			c.draw_rect(Rect2(r.position.x + 12, r.position.y + 10, r.size.x - 24, 12), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.45))
	if _q >= 1:
		_solid_detail(c, r)


# Medium / High: extra finish on every solid. Medium adds soft light and shade bands plus rivet rows;
# High adds grime streaks, scuffs and a soft shadow cast below the solid.
func _solid_detail(c: CanvasItem, r: Rect2) -> void:
	if r.size.x < 30.0 or r.size.y < 16.0:
		return
	var thick := r.size.y >= 40.0
	var band := minf(r.size.y * 0.22, 26.0)
	c.draw_rect(Rect2(r.position.x + 2.0, r.position.y + 4.0, r.size.x - 4.0, band), Color(1, 1, 1, 0.045))
	c.draw_rect(Rect2(r.position.x + 2.0, r.end.y - band - 3.0, r.size.x - 4.0, band), Color(0, 0, 0, 0.10))
	if r.size.x >= 90.0:
		var x := r.position.x + 28.0
		while x < r.end.x - 20.0:
			c.draw_circle(Vector2(x, r.position.y + 9.0), 1.8, Color(0.62, 0.72, 0.92, 0.45))
			if thick:
				c.draw_circle(Vector2(x, r.end.y - 9.0), 1.8, Color(0.62, 0.72, 0.92, 0.35))
			x += 56.0
	if _q < 2:
		return
	var rr := RandomNumberGenerator.new()
	rr.seed = int(r.position.x * 7.0 + r.position.y * 13.0)
	var n := clampi(int(r.size.x * r.size.y / 30000.0), 1, 7)
	for i in n:
		var gx := rr.randf_range(r.position.x + 6.0, r.end.x - 10.0)
		c.draw_rect(Rect2(gx, r.position.y + 4.0, rr.randf_range(2.0, 5.0), minf(r.size.y - 8.0, rr.randf_range(20.0, 90.0))), Color(0, 0, 0, rr.randf_range(0.10, 0.20)))
		var sx := rr.randf_range(r.position.x + 8.0, r.end.x - 30.0)
		var sy := rr.randf_range(r.position.y + 6.0, r.end.y - 6.0)
		c.draw_line(Vector2(sx, sy), Vector2(sx + rr.randf_range(8.0, 24.0), sy - rr.randf_range(0.0, 4.0)), Color(1, 1, 1, 0.07), 1.5)
	c.draw_rect(Rect2(r.position.x, r.end.y, r.size.x, 10.0), Color(0, 0, 0, 0.16))
	c.draw_rect(Rect2(r.position.x, r.end.y + 10.0, r.size.x, 8.0), Color(0, 0, 0, 0.07))


func _paint_deck(c: CanvasItem, r: Rect2) -> void:
	_panel(c, r, C_STEEL, C_STEEL_HI, C_STEEL_LO, 120.0)
	c.draw_rect(Rect2(r.position.x, r.position.y, r.size.x, 7), Color("6d82ad"))
	c.draw_line(Vector2(r.position.x + 12, r.end.y + 5), Vector2(r.end.x - 12, r.end.y + 5), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.28), 2.0)
	if r.position.x > 70.0:
		_hazard(c, Rect2(r.position.x, r.position.y, 16, r.size.y))
	if r.end.x < W - 70.0:
		_hazard(c, Rect2(r.end.x - 16, r.position.y, 16, r.size.y))


func _paint_catwalk(c: CanvasItem, r: Rect2, rail: bool) -> void:
	c.draw_rect(r, Color("1a2236"))
	var x := r.position.x + 6.0
	while x < r.end.x - 4.0:
		c.draw_line(Vector2(x, r.position.y + 5), Vector2(x, r.end.y - 3), Color(0.38, 0.46, 0.66, 0.35), 2.0)
		x += 10.0
	c.draw_rect(Rect2(r.position.x, r.position.y, r.size.x, 4), C_STEEL_HI)
	c.draw_rect(Rect2(r.position.x, r.end.y - 3, r.size.x, 3), C_STEEL_LO)
	c.draw_rect(Rect2(r.position.x, r.position.y, 8, r.size.y), C_ORANGE)
	c.draw_rect(Rect2(r.end.x - 8, r.position.y, 8, r.size.y), C_ORANGE)
	var zig := PackedVector2Array()
	var xx := r.position.x
	var i := 0
	while xx <= r.end.x:
		zig.append(Vector2(xx, r.end.y + (16.0 if i % 2 == 1 else 0.0)))
		xx += 36.0
		i += 1
	if zig.size() >= 2:
		c.draw_polyline(zig, Color(0.32, 0.4, 0.58, 0.65), 2.0)
	if rail:
		var rx := r.position.x + 30.0
		while rx < r.end.x - 20.0:
			c.draw_line(Vector2(rx, r.position.y), Vector2(rx, r.position.y - 30), Color(0.55, 0.68, 0.9, 0.5), 2.0)
			rx += 90.0
		c.draw_line(Vector2(r.position.x + 30.0, r.position.y - 30), Vector2(r.end.x - 30.0, r.position.y - 30), Color(0.55, 0.68, 0.9, 0.5), 2.0)


func _paint_column(c: CanvasItem, r: Rect2) -> void:
	c.draw_rect(r, Color("232c45"))
	c.draw_rect(Rect2(r.position.x, r.position.y, 5, r.size.y), Color("4a5b82"))
	c.draw_rect(Rect2(r.end.x - 5, r.position.y, 5, r.size.y), Color("0f1424"))
	var y := r.position.y + 30.0
	while y < r.end.y - 10.0:
		c.draw_rect(Rect2(r.position.x - 3, y, r.size.x + 6, 8), Color("2e3a5c"))
		y += 70.0
	c.draw_line(Vector2(r.get_center().x, r.position.y + 6), Vector2(r.get_center().x, r.end.y - 6), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.55), 2.0)
	c.draw_rect(r, C_STEEL_LO, false, 2.0)


func _paint_crate(c: CanvasItem, r: Rect2) -> void:
	c.draw_rect(r, Color("2d3a4f"))
	c.draw_rect(r.grow(-6), Color("253144"))
	c.draw_line(r.position + Vector2(6, 6), r.end - Vector2(6, 6), Color("3a4a66"), 3.0)
	c.draw_line(Vector2(r.end.x - 6, r.position.y + 6), Vector2(r.position.x + 6, r.end.y - 6), Color("3a4a66"), 3.0)
	c.draw_rect(Rect2(r.position.x, r.position.y, r.size.x, 4), Color("5b6e96"))
	c.draw_rect(r, C_STEEL_LO, false, 3.0)
	for p in [Vector2(0, 0), Vector2(r.size.x - 14, 0), Vector2(0, r.size.y - 14), Vector2(r.size.x - 14, r.size.y - 14)]:
		c.draw_rect(Rect2(r.position + p, Vector2(14, 14)), C_ORANGE.darkened(0.25))
	if r.size.x >= 100:
		c.draw_string(ThemeDB.fallback_font, r.position + Vector2(0, r.size.y * 0.5 + 5), "CARGO", HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 14, Color(1, 1, 1, 0.3))


# ---------- background props (pipes, chains, cables, consoles...) ----------
func _paint_props(c: CanvasItem) -> void:
	var pipe := Color("1b2438")
	var pipe_hi := Color("3b4a6c")
	# ceiling pipe runs
	for run in [[60.0, 1700.0, 92.0, 22.0], [1900.0, 3300.0, 92.0, 22.0], [3500.0, 5140.0, 92.0, 22.0], [60.0, 5140.0, 128.0, 12.0]]:
		var x0: float = run[0]
		var x1: float = run[1]
		var py: float = run[2]
		var th: float = run[3]
		c.draw_rect(Rect2(x0, py, x1 - x0, th), pipe)
		c.draw_rect(Rect2(x0, py, x1 - x0, 3), pipe_hi)
		var fx := x0 + 150.0
		while fx < x1:
			c.draw_rect(Rect2(fx, py - 4, 10, th + 8), Color("26314b"))
			fx += 330.0
	# vertical pipes
	for vp in [[1000.0, 700.0], [1700.0, 900.0], [3500.0, 900.0], [4200.0, 700.0], [2000.0, 520.0], [3200.0, 520.0]]:
		var vx: float = vp[0]
		var vh: float = vp[1]
		c.draw_rect(Rect2(vx - 9, 100, 18, vh), pipe)
		c.draw_rect(Rect2(vx - 9, 100, 3, vh), pipe_hi)
		var jy := 220.0
		while jy < vh + 100.0:
			c.draw_rect(Rect2(vx - 13, jy, 26, 8), Color("26314b"))
			jy += 170.0
	# chains holding the gantries up
	for s in _solids:
		if s["kind"] == "gantry":
			var r: Rect2 = s["r"]
			for cx in [r.position.x + 40.0, r.end.x - 40.0]:
				var cy := 62.0
				while cy < r.position.y:
					c.draw_rect(Rect2(cx - 3, cy, 6, 11), Color("4a5878") if int(cy / 14.0) % 2 == 0 else Color("2e3850"))
					cy += 14.0
		elif s["kind"] == "nest":
			var r2: Rect2 = s["r"]
			_paint_truss(c, r2.position.x + 24.0, r2.end.y, 2200.0)
			_paint_truss(c, r2.end.x - 60.0, r2.end.y, 2200.0)
	# cables
	_cable(c, Vector2(120, 62), Vector2(980, 62), 90.0, Color("0b0e18"))
	_cable(c, Vector2(1100, 62), Vector2(1900, 880), 40.0, Color("0b0e18"))     # hangs down to a spark site
	_cable(c, Vector2(3300, 62), Vector2(3300, 720), 10.0, Color("0b0e18"))
	_cable(c, Vector2(2300, 62), Vector2(3000, 62), 110.0, Color("0b0e18"))
	_cable(c, Vector2(4200, 62), Vector2(5000, 62), 80.0, Color("0b0e18"))
	_cable(c, Vector2(1950, 2240), Vector2(2000, 2300), 12.0, Color("0b0e18"))

	# cargo bay doors + spawn pads
	for bx in [700.0, W - 724.0]:
		c.draw_rect(Rect2(bx - 10, 2070, 44, 10), C_YELLOW.darkened(0.2))
		c.draw_rect(Rect2(bx - 10, 2072, 44, 4), C_DARK)
		c.draw_rect(Rect2(bx - 16, 1930, 6, 270), Color("1a2236"))
		c.draw_rect(Rect2(bx + 34, 1930, 6, 270), Color("1a2236"))
	for px in [330.0, W - 330.0]:
		c.draw_rect(Rect2(px - 80, 2192, 160, 8), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.25))
		c.draw_rect(Rect2(px - 80, 2192, 160, 2), C_CYAN)
		c.draw_rect(Rect2(px - 50, 2186, 100, 6), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.4))
		# overhead gantry crane rail
		c.draw_rect(Rect2(px - 200, 1990, 400, 10), Color("1b2438"))
		c.draw_rect(Rect2(px - 24, 1998, 48, 26), Color("2d3a58"))
		c.draw_line(Vector2(px, 2024), Vector2(px, 2064), Color("4a5878"), 3.0)
		c.draw_rect(Rect2(px - 10, 2064, 20, 14), C_ORANGE.darkened(0.2))

	# control room consoles
	for cx in [2210.0, 2750.0]:
		c.draw_rect(Rect2(cx, 992, 240, 58), Color("232c45"))
		c.draw_rect(Rect2(cx, 992, 240, 4), Color("4a5b82"))
		c.draw_rect(Rect2(cx + 10, 880, 220, 100), Color("0a0f1c"))
		c.draw_rect(Rect2(cx + 10, 880, 220, 100), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.4), false, 2.0)
		for k in 6:
			var gy := 892.0 + k * 14.0
			c.draw_line(Vector2(cx + 22, gy), Vector2(cx + 22 + 40.0 + fposmod(k * 53.0, 120.0), gy), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.5), 2.0)
		c.draw_rect(Rect2(cx + 20, 1004, 200, 8), Color("101626"))

	# maintenance tunnel: ceiling beams, floor grating, toxic barrels
	var bx2 := 100.0
	while bx2 < W - 100.0:
		c.draw_rect(Rect2(bx2, 2244, 18, 236), Color("151c2e"))
		bx2 += 380.0
	var gx2 := 70.0
	while gx2 < W - 70.0:
		c.draw_line(Vector2(gx2, 2480), Vector2(gx2 + 16, 2492), Color(0.3, 0.38, 0.55, 0.25), 2.0)
		gx2 += 24.0
	c.draw_colored_polygon(_ellipse(Vector2(2030, 2478), 110.0, 7.0), Color(C_GREEN.r, C_GREEN.g, C_GREEN.b, 0.22))
	for bp in [Vector2(1955, 2480), Vector2(2000, 2480), Vector2(2105, 2480)]:
		_barrel(c, bp)


func _barrel(c: CanvasItem, base: Vector2) -> void:
	c.draw_rect(Rect2(base.x - 17, base.y - 52, 34, 52), Color("2c4a2a"))
	c.draw_rect(Rect2(base.x - 17, base.y - 52, 6, 52), Color("4a7a3a"))
	c.draw_rect(Rect2(base.x - 17, base.y - 40, 34, 5), Color("162616"))
	c.draw_rect(Rect2(base.x - 17, base.y - 14, 34, 5), Color("162616"))
	c.draw_circle(base + Vector2(0, -27), 6.0, C_YELLOW)
	c.draw_circle(base + Vector2(0, -27), 3.0, Color("2c4a2a"))


func _ellipse(center: Vector2, rx: float, ry: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in 24:
		var a := TAU * i / 24.0
		pts.append(center + Vector2(cos(a) * rx, sin(a) * ry))
	return pts


func _cable(c: CanvasItem, a: Vector2, b: Vector2, sag: float, col: Color) -> void:
	var pts := PackedVector2Array()
	for i in 21:
		var t := i / 20.0
		pts.append(a.lerp(b, t) + Vector2(0, sin(t * PI) * sag))
	c.draw_polyline(pts, col, 5.0)
	c.draw_polyline(pts, Color(0.2, 0.26, 0.4, 0.5), 1.5)


func _paint_truss(c: CanvasItem, x: float, top: float, bottom: float) -> void:
	var w := 36.0
	c.draw_rect(Rect2(x, top, 5, bottom - top), Color("1e2740"))
	c.draw_rect(Rect2(x + w, top, 5, bottom - top), Color("1e2740"))
	var y := top
	var flip := false
	while y < bottom - 100.0:
		var a := Vector2(x + (w if flip else 0.0), y)
		var b := Vector2(x + (0.0 if flip else w), y + 100.0)
		c.draw_line(a, b, Color("232d49"), 3.0)
		y += 100.0
		flip = not flip


# =====================================================================
#  lights + particle effects
# =====================================================================
func _add_light(pos: Vector2, color: Color, radius: float, intensity: float, mode := "steady", speed := 1.0, follow: CanvasItem = null) -> Sprite2D:
	var s := Sprite2D.new()
	s.texture = _glow
	s.position = pos
	s.scale = Vector2.ONE * (radius / 64.0)
	s.material = _add_mat
	s.z_index = 12
	s.modulate = Color(color.r, color.g, color.b, intensity)
	add_child(s)
	_lights.append({"node": s, "color": color, "base": intensity, "mode": mode, "speed": speed, "phase": _rng.randf() * 20.0, "follow": follow})
	return s


func _update_lights() -> void:
	for L in _lights:
		var n: Sprite2D = L["node"]
		var f := 1.0
		var sp: float = L["speed"]
		var ph: float = L["phase"]
		match L["mode"]:
			"flicker":
				var w := sin(_t * sp * 13.0 + ph) * sin(_t * sp * 7.3 + ph * 1.7)
				if w > 0.5:
					f = 0.08 + 0.25 * absf(sin(_t * 41.0))
			"blink":
				f = 1.0 if fmod(_t * sp + ph, 1.0) < 0.5 else 0.06
			"pulse":
				f = 0.6 + 0.4 * sin(_t * sp * 2.0 + ph)
		var col: Color = L["color"]
		n.modulate = Color(col.r, col.g, col.b, float(L["base"]) * f)
		var fol: CanvasItem = L["follow"]
		if fol != null:
			fol.modulate.a = f


# a ceiling lamp: fixture + light cone + glow
func _add_lamp(x: float, y: float, color: Color, cone_len: float, mode := "steady", dead := false) -> void:
	var fixture := Polygon2D.new()
	fixture.polygon = PackedVector2Array([Vector2(-26, 0), Vector2(26, 0), Vector2(18, 12), Vector2(-18, 12)])
	fixture.color = Color("0f1424")
	fixture.position = Vector2(x, y)
	fixture.z_index = -30
	add_child(fixture)
	if dead:
		return
	var cone := Polygon2D.new()
	cone.polygon = PackedVector2Array([Vector2(-16, 12), Vector2(16, 12), Vector2(cone_len * 0.32, cone_len), Vector2(-cone_len * 0.32, cone_len)])
	cone.vertex_colors = PackedColorArray([
		Color(color.r, color.g, color.b, 0.22), Color(color.r, color.g, color.b, 0.22),
		Color(color.r, color.g, color.b, 0.0), Color(color.r, color.g, color.b, 0.0)])
	cone.position = Vector2(x, y)
	cone.material = _add_mat
	cone.z_index = -15
	add_child(cone)
	_add_light(Vector2(x, y + 14), color, 70.0, 0.9, mode, 1.0, cone)


func _emitter(pos: Vector2, amount: int, life: float, dir: Vector2, spread: float, v0: float, v1: float, grav: Vector2, s0: float, s1: float, c0: Color, c1: Color, additive := false, grow := 1.0, rect := Vector2.ZERO, z := 5) -> CPUParticles2D:
	var p := CPUParticles2D.new()
	p.position = pos
	p.amount = amount
	p.lifetime = life
	p.direction = dir
	p.spread = spread
	p.initial_velocity_min = v0
	p.initial_velocity_max = v1
	p.gravity = grav
	p.scale_amount_min = s0
	p.scale_amount_max = s1
	p.texture = _puff
	var g := Gradient.new()
	g.colors = PackedColorArray([c0, c1])
	g.offsets = PackedFloat32Array([0.0, 1.0])
	p.color_ramp = g
	if grow != 1.0:
		var cv := Curve.new()
		cv.add_point(Vector2(0.0, 0.5))
		cv.add_point(Vector2(1.0, grow))
		p.scale_amount_curve = cv
	if rect != Vector2.ZERO:
		p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
		p.emission_rect_extents = rect
	if additive:
		p.material = _add_mat
	p.z_index = z
	add_child(p)
	return p


func _add_vent(pos: Vector2, period: float, duty: float, strong := true) -> void:
	var p := _emitter(pos, 30 if strong else 16, 1.7, Vector2(0, -1), 12.0, 110.0 if strong else 60.0, 220.0 if strong else 110.0,
		Vector2(0, -35), 0.4, 0.9, Color(0.85, 0.92, 1.0, 0.32), Color(0.85, 0.92, 1.0, 0.0), false, 2.4)
	p.emitting = false
	_vents.append({"node": p, "period": period, "duty": duty, "offset": _rng.randf() * period})


func _update_vents() -> void:
	for v in _vents:
		var period: float = v["period"]
		var node: CPUParticles2D = v["node"]
		node.emitting = fmod(_t + float(v["offset"]), period) < period * float(v["duty"])


func _add_spark_site(pos: Vector2, color := Color(1.0, 0.8, 0.35), min_gap := 1.4, max_gap := 4.0) -> void:
	var p := _emitter(pos, 18, 0.75, Vector2(0, 1), 75.0, 150.0, 340.0, Vector2(0, 900), 0.05, 0.1,
		Color(1.0, 0.85, 0.4, 1.0), Color(1.0, 0.3, 0.1, 0.0), true)
	p.one_shot = true
	p.explosiveness = 0.9
	p.emitting = false
	var flash := _add_light(pos, color, 90.0, 0.0, "steady")
	_sparks.append({"node": p, "flash": flash, "next": _rng.randf_range(0.5, max_gap), "min": min_gap, "max": max_gap, "level": 0.0, "color": color})


func _update_sparks(delta: float) -> void:
	for s in _sparks:
		s["next"] = float(s["next"]) - delta
		s["level"] = maxf(0.0, float(s["level"]) - delta * 4.5)
		if float(s["next"]) <= 0.0:
			s["next"] = _rng.randf_range(float(s["min"]), float(s["max"]))
			s["level"] = 1.0
			var p: CPUParticles2D = s["node"]
			p.restart()
			p.emitting = true
		# the flash light is also in _lights (base 0); this runs after _update_lights, so it wins
		var f: Sprite2D = s["flash"]
		var col: Color = s["color"]
		f.modulate = Color(col.r, col.g, col.b, float(s["level"]) * 0.9)


func _build_lights_and_fx() -> void:
	# ----- ceiling lamps (some flicker, one is dead) -----
	var lamp_x := [300.0, 760.0, 1220.0, 1700.0, 2160.0, 2600.0, 3040.0, 3500.0, 3980.0, 4440.0, 4900.0]
	for i in lamp_x.size():
		var x: float = lamp_x[i]
		var tint := Color(0.55, 0.9, 1.0)
		var mode := "steady"
		var dead := false
		if i == 2 or i == 8:
			mode = "flicker"
		if i == 4:
			dead = true
		if i == 9:
			tint = Color(1.0, 0.7, 0.4)
		_add_lamp(x, 62.0, tint, 620.0, mode, dead)

	# ----- maintenance tunnel lights: dim teal + red emergency -----
	var tunnel_x := [450.0, 1050.0, 1350.0, 2250.0, 2950.0, 3850.0, 4150.0, 4750.0]
	for i in tunnel_x.size():
		var emergency := i % 3 == 1
		var lx: float = tunnel_x[i]
		_add_lamp(lx, 2244.0, Color(1.0, 0.25, 0.2) if emergency else Color(0.4, 0.85, 0.95), 190.0, "flicker" if i == 2 else "steady")

	# ----- nest + control room + hub lights -----
	for nx in [540.0, W - 540.0]:
		_add_lamp(nx, 1196.0, Color(1.0, 0.7, 0.4), 260.0, "steady")
	_add_lamp(2400.0, 812.0, Color(0.55, 0.9, 1.0), 240.0)
	_add_lamp(2800.0, 812.0, Color(0.55, 0.9, 1.0), 240.0, "flicker")
	_add_lamp(2600.0, 1726.0, Color(0.5, 0.9, 1.0), 300.0)

	# ----- blinking status lights on the hatch edges + bay doors -----
	for hx in [1500.0, 1760.0, 3440.0, 3700.0]:
		_add_light(Vector2(hx + (-8.0 if hx in [1500.0, 3440.0] else 8.0), 2200.0), C_ORANGE, 40.0, 0.9, "blink", 1.2)
	for bx in [712.0, W - 712.0]:
		_add_light(Vector2(bx, 1940.0), Color(0.4, 1.0, 0.5), 36.0, 0.9, "pulse", 1.0)
	for sx in [330.0, W - 330.0]:
		_add_light(Vector2(sx, 2196.0), C_CYAN, 120.0, 0.45, "pulse", 0.7)

	# ----- hatch light shafts (shows where you can drop down) -----
	for hx in [1500.0, 3440.0]:
		var shaft := Polygon2D.new()
		shaft.polygon = PackedVector2Array([Vector2(hx + 10, 2240), Vector2(hx + 250, 2240), Vector2(hx + 210, 2480), Vector2(hx + 50, 2480)])
		shaft.vertex_colors = PackedColorArray([Color(0.55, 0.9, 1, 0.20), Color(0.55, 0.9, 1, 0.20), Color(0.55, 0.9, 1, 0.0), Color(0.55, 0.9, 1, 0.0)])
		shaft.material = _add_mat
		shaft.z_index = -14
		add_child(shaft)

	# ----- reactor core + glow -----
	var core := ReactorCore.new()
	core.position = Vector2(2600, 2080)
	core.z_index = -25
	add_child(core)
	_add_light(Vector2(2600, 1930), C_CYAN, 330.0, 0.42, "pulse", 0.9)
	_add_light(Vector2(2600, 2070), C_CYAN, 140.0, 0.5, "pulse", 1.3)
	var motes := _emitter(Vector2(2600, 2062), 26, 3.0, Vector2(0, -1), 6.0, 35.0, 85.0, Vector2.ZERO, 0.05, 0.1,
		Color(0.7, 1.0, 1.0, 0.9), Color(0.4, 0.9, 1.0, 0.0), true, 1.0, Vector2(32, 3), -24)
	motes.preprocess = 3.0

	# ----- control room hologram -----
	var holo := Hologram.new()
	holo.position = Vector2(2600, 1010)
	holo.z_index = -24
	holo.material = _add_mat
	add_child(holo)
	_add_light(Vector2(2600, 960), C_CYAN, 150.0, 0.35, "flicker", 0.6)
	for cx in [2330.0, 2870.0]:
		_add_light(Vector2(cx, 930), C_CYAN, 120.0, 0.35, "pulse", 0.5)
	for k in 4:
		_add_light(Vector2(2225.0 + k * 54.0, 1006.0), [C_CYAN, C_ORANGE, Color(0.4, 1.0, 0.5), C_RED][k], 22.0, 0.9, "blink", 0.8 + k * 0.45)
		_add_light(Vector2(2765.0 + k * 54.0, 1006.0), [C_ORANGE, Color(0.4, 1.0, 0.5), C_CYAN, C_RED][k], 22.0, 0.9, "blink", 1.1 + k * 0.3)

	# ----- steam vents -----
	_add_vent(Vector2(1630, 2200), 5.0, 0.55)
	_add_vent(Vector2(3570, 2200), 6.5, 0.55)
	_add_vent(Vector2(1800, 2480), 4.0, 0.5, false)
	_add_vent(Vector2(3400, 2480), 4.6, 0.5, false)
	_add_vent(Vector2(2180, 2080), 7.0, 0.35, false)

	# ----- sparks from broken wiring -----
	_add_spark_site(Vector2(1900, 880))
	_add_spark_site(Vector2(3300, 720))
	_add_spark_site(Vector2(1970, 2300), Color(0.6, 0.9, 1.0), 2.0, 5.0)
	_add_spark_site(Vector2(2320, 992), Color(0.6, 0.9, 1.0), 2.5, 6.0)
	_add_spark_site(Vector2(3830, 310), Color(1.0, 0.7, 0.3), 1.0, 2.6)

	# ----- hull breach: beacon + air venting out into space -----
	var beacon := Beacon.new()
	beacon.position = Vector2(3870, 330)
	beacon.length = 420.0
	beacon.material = _add_mat
	beacon.z_index = 9
	add_child(beacon)
	_add_light(Vector2(3870, 200), Color(1.0, 0.45, 0.2), 260.0, 0.35, "flicker", 0.8)
	_emitter(Vector2(3870, 285), 44, 1.3, Vector2(0, -1), 30.0, 60.0, 130.0, Vector2(0, -50), 0.12, 0.4,
		Color(1.0, 0.85, 0.7, 0.55), Color(1.0, 0.5, 0.2, 0.0), true, 0.5, Vector2(120, 6), 6)
	# bay beacons
	for bx in [712.0, W - 712.0]:
		var bc := Beacon.new()
		bc.position = Vector2(bx, 1950.0)
		bc.length = 300.0
		bc.spin = 4.0 if bx < W * 0.5 else -4.0
		bc.color = Color(1.0, 0.3, 0.2)
		bc.material = _add_mat
		bc.z_index = 9
		add_child(bc)

	# ----- coolant drips + toxic leak in the tunnels -----
	for dx in [1400.0, 3800.0, 900.0]:
		_emitter(Vector2(dx, 2250), 3, 0.9, Vector2(0, 1), 0.0, 0.0, 12.0, Vector2(0, 1100), 0.05, 0.08,
			Color(0.55, 0.9, 1.0, 0.9), Color(0.55, 0.9, 1.0, 0.0), true)
	_emitter(Vector2(2030, 2420), 14, 2.2, Vector2(0, -1), 18.0, 18.0, 50.0, Vector2(0, -22), 0.08, 0.2,
		Color(C_GREEN.r, C_GREEN.g, C_GREEN.b, 0.7), Color(C_GREEN.r, C_GREEN.g, C_GREEN.b, 0.0), true, 1.4, Vector2(60, 4))
	_add_light(Vector2(2030, 2450), C_GREEN, 160.0, 0.5, "pulse", 0.8)

	# ----- dust drifting through the whole station -----
	var dust := _emitter(Vector2(W * 0.5, H * 0.5), 280, 14.0, Vector2(1, -0.2), 180.0, 4.0, 18.0, Vector2.ZERO, 0.03, 0.09,
		Color(0.75, 0.88, 1.0, 0.45), Color(0.75, 0.88, 1.0, 0.0), false, 1.0, Vector2(W * 0.5 - 70.0, H * 0.5 - 70.0), 3)
	dust.preprocess = 12.0


# =====================================================================
#  gameplay: pickups, spawns, fighters
# =====================================================================
func _load_weapon_pool() -> Array[WeaponData]:
	if not weapon_pool.is_empty():
		return weapon_pool
	var out: Array[WeaponData] = WeaponCatalog.all()      # every weapon in the catalog (filter by era here if a map should)
	if out.is_empty():
		for path in ["rifle", "shotgun", "smg", "sniper"]:
			var full := "res://art/scripts/%s.tres" % path
			if ResourceLoader.exists(full):
				var w := load(full) as WeaponData
				if w != null:
					out.append(w)
	return out


func _build_weapon_pickups() -> void:
	var pool := _load_weapon_pool()
	if pool.is_empty():
		push_warning("AbandonedStation: no weapons found. Fill 'Weapon Pool' in the Inspector.")
		return
	# surface positions (where the weapon stands)
	var spots: Array[Vector2] = [
		Vector2(2600, 1700),            # reactor hub catwalk
		Vector2(540, 1350), Vector2(W - 540, 1350),       # sniper nests
		Vector2(2330, 1050),            # control room
		Vector2(1000, 2480), Vector2(W - 1000, 2480),     # maintenance tunnels
		Vector2(1250, 2090), Vector2(W - 1250, 2090),     # crate tops in the cargo hall
	]
	for p in spots:
		var wp := WeaponPickup.new()
		wp.weapon_pool = pool
		wp.respawn_time = 15.0
		wp.position = p
		add_child(wp)


func _build_throwable_spawner() -> void:
	var sp := ThrowableSpawner.new()
	sp.map_id = map_id
	sp.interval = 7.0
	sp.max_active = 6
	sp.initial_spawns = 4
	var pts := PackedVector2Array()
	for p in [
		Vector2(1150, 2200), Vector2(2600, 2080), Vector2(900, 1860),
		Vector2(1590, 1500), Vector2(1560, 2480), Vector2(2400, 2480),
		Vector2(2300, 1050), Vector2(420, 1350), Vector2(2300, 1700),
	]:
		pts.append(p)
		pts.append(Vector2(W - p.x, p.y))          # mirrored twin
	sp.spawn_points = pts
	add_child(sp)


func _spawn_fighters() -> void:
	var spawn := get_node_or_null("SpawnPoint") as Node2D
	if spawn == null:
		var m := Marker2D.new()
		m.name = "SpawnPoint"
		m.position = Vector2(330, 2150)
		add_child(m)
		spawn = m

	var player := get_node_or_null("Player") as Node2D
	if player == null and player_scene != null:
		player = player_scene.instantiate() as Node2D
		player.name = "Player"
		player.position = spawn.position
		add_child(player)
	elif player == null:
		push_warning("AbandonedStation: no Player. Assign Player Scene in the Inspector.")

	# keep the camera inside the station
	if player != null:
		for cam in player.find_children("*", "Camera2D", true, false):
			var cam2 := cam as Camera2D
			cam2.limit_left = 0
			cam2.limit_top = 0
			cam2.limit_right = int(W)
			cam2.limit_bottom = int(H)

	if bot_scene == null:
		return
	var bot_spots: Array[Vector2] = [
		Vector2(W - 330, 2150), Vector2(4300, 1810), Vector2(W - 540, 1300),
		Vector2(3800, 1450), Vector2(4700, 2150),
	]
	for i in mini(bot_count, bot_spots.size()):
		var bot := bot_scene.instantiate() as Node2D
		bot.position = bot_spots[i]          # set BEFORE add_child so the bot remembers it as its respawn spot
		add_child(bot)


func _add_match_manager() -> void:
	if match_manager_script == null or get_node_or_null("MatchManager") != null:
		return
	var mm := CanvasLayer.new()
	mm.name = "MatchManager"
	mm.set_script(match_manager_script)
	add_child(mm)


func _add_vignette() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 4
	add_child(layer)
	var g := Gradient.new()
	g.colors = PackedColorArray([Color(0, 0, 0, 0.0), Color(0, 0, 0, 0.0), Color(0.01, 0.02, 0.05, 0.6)])
	g.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
	var tex := GradientTexture2D.new()
	tex.gradient = g
	tex.width = 256
	tex.height = 256
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.5)
	tex.fill_to = Vector2(1.0, 0.5)
	var rect := TextureRect.new()
	rect.texture = tex
	rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	rect.stretch_mode = TextureRect.STRETCH_SCALE
	rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(rect)
