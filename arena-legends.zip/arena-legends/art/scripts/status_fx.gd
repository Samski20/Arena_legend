class_name StatusFX
extends Node2D
## Reusable visual layer for status effects (cryo, emp, noflight, burn, poison, gravity).
##
## HOW IT WORKS
##  - It is a child of any body that has statuses (the player, bots, dummies...).
##  - It only READS the body's "_status" table ({type: {"t": seconds left, ...}}), so it never
##    changes gameplay, and it works the same for the player, bots and the StatusEffects component.
##  - Each effect shows what is happening AND how long is left:
##        * a small ring under the character per active status (the arc shrinks as time runs out)
##        * cryo ice shards melt away one by one, the frost outline fades
##        * the other effects fade in their last moments
##  - It costs nothing when no status is active (no drawing, one tiny dictionary check).
##
## HOW TO USE IT
##  - You normally do nothing: apply_status() on the player / bots and StatusEffects.apply_status()
##    call StatusFX.attach(self) for you.
##  - New status later? Add a color to COLORS, then a small _draw_xxx and an emitter in _process.

const NODE_NAME := "StatusFX"
const MAX_PARTS := 48
const CENTER := Vector2(0, -6)          # middle of the body (host space; the rig is scaled 0.45)
const HALF_W := 12.0
const HALF_H := 28.0
const PIP_Y := 31.0                      # the duration rings sit just under the feet
const JP_FALLBACK := Vector2(-8.5, -19.0)

const COLORS := {
	"cryo": Color(0.55, 0.88, 1.0),
	"emp": Color(0.55, 0.95, 1.0),
	"noflight": Color(1.0, 0.85, 0.3),
	"burn": Color(1.0, 0.5, 0.15),
	"poison": Color(0.55, 0.95, 0.3),
	"gravity": Color(0.75, 0.6, 1.0),
	"stun": Color(1.0, 0.95, 0.4),
}

var _host: Node
var _add: Node2D                         # additive layer (glows, sparks, lightning)
var _live := {}                          # type -> seconds left (this frame)
var _was := {}                           # types that were active last frame
var _peak := {}                          # type -> longest time seen, so we can show a fraction
var _parts: Array = []
var _acc := {}
var _arcs: Array = []                    # EMP lightning polylines
var _arc_timer := 0.0
var _t := 0.0
var _flash_t := 0.0
var _flash_col := Color.WHITE
var _drew := false


# Safe to call as often as you like: creates the node once.
static func attach(host: Node) -> void:
	if host == null or host.get_node_or_null(NODE_NAME) != null:
		return
	var fx := StatusFX.new()
	fx.name = NODE_NAME
	host.add_child(fx)


func _ready() -> void:
	_host = get_parent()
	z_index = 10
	_add = Node2D.new()
	var mat := CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	_add.material = mat
	add_child(_add)
	_add.draw.connect(_draw_add)


# ------------------------------------------------------------------
#  update
# ------------------------------------------------------------------
func _read_status() -> Dictionary:
	if _host == null or not is_instance_valid(_host):
		return {}
	var s = _host.get("_status")
	if s is Dictionary:
		return s
	var comp := _host.get_node_or_null("StatusEffects")
	if comp != null:
		s = comp.get("_status")
		if s is Dictionary:
			return s
	return {}


func _process(delta: float) -> void:
	var st := _read_status()
	var live := {}
	for type in COLORS:
		if st.has(type) and st[type] is Dictionary:
			var left := float(st[type].get("t", 0.0))
			if left > 0.0:
				live[type] = left

	if live.is_empty() and _parts.is_empty() and _flash_t <= 0.0:
		_live = live
		_was = live
		if _drew:                                # clear the last frame once, then go idle
			_drew = false
			queue_redraw()
			_add.queue_redraw()
		return

	_t += delta
	_live = live
	for type in live:
		_peak[type] = maxf(float(_peak.get(type, 0.0)), float(live[type]))
		if not _was.has(type):
			_burst(type)
	for type in _peak.keys():
		if not live.has(type):
			_peak.erase(type)
	_was = live.duplicate()

	# the character is nearly invisible inside smoke, so keep the effects faint too
	modulate.a = 0.25 if st.has("smoked") else 1.0

	_emit_effects(delta)
	_update_parts(delta)
	_flash_t = maxf(_flash_t - delta, 0.0)
	_drew = true
	queue_redraw()
	_add.queue_redraw()


func _frac(type: String) -> float:
	var peak := float(_peak.get(type, 1.0))
	return clampf(float(_live.get(type, 0.0)) / maxf(peak, 0.01), 0.0, 1.0)


# fully visible for most of the effect, fading over the last ~40%
func _fade(type: String) -> float:
	return clampf(_frac(type) * 2.5, 0.0, 1.0)


func _jetpack_pos() -> Vector2:
	var rig = _host.get("visuals") if _host != null else null
	if rig != null:
		var jp = rig.get("jetpack")
		if jp is Node2D:
			return to_local((jp as Node2D).global_position)
	return JP_FALLBACK


func _body_point() -> Vector2:
	return CENTER + Vector2(randf_range(-HALF_W, HALF_W), randf_range(-HALF_H, HALF_H * 0.7))


func _count(key: String, per_sec: float, delta: float) -> int:
	var a := float(_acc.get(key, 0.0)) + per_sec * delta
	var n := int(a)
	_acc[key] = a - float(n)
	return n


func _emit_p(kind: String, pos: Vector2, vel: Vector2, life: float, size: float, col: Color,
		add := false, grav := Vector2.ZERO) -> void:
	if _parts.size() >= MAX_PARTS:
		return
	_parts.append({"p": pos, "v": vel, "life": life, "age": 0.0, "s": size, "c": col,
		"add": add, "k": kind, "g": grav})


func _update_parts(delta: float) -> void:
	var i := _parts.size() - 1
	while i >= 0:
		var pt: Dictionary = _parts[i]
		pt["age"] += delta
		if pt["age"] >= pt["life"]:
			_parts.remove_at(i)
		else:
			pt["v"] += pt["g"] * delta
			pt["p"] += pt["v"] * delta
		i -= 1


# a quick burst + expanding ring the moment a status lands
func _burst(type: String) -> void:
	var col: Color = COLORS[type]
	_flash_t = 0.25
	_flash_col = col
	var jp := _jetpack_pos()
	match type:
		"cryo":
			for i in 10:
				var a := randf() * TAU
				_emit_p("shard", CENTER + Vector2(cos(a) * HALF_W, sin(a) * HALF_H * 0.8),
					Vector2(cos(a), sin(a)) * randf_range(30, 60), 0.5, randf_range(2.5, 4.0),
					Color(0.85, 0.97, 1, 1))
		"emp":
			for i in 14:
				var a := randf() * TAU
				_emit_p("spark", jp, Vector2(cos(a), sin(a)) * randf_range(60, 130), 0.3, 6.0,
					Color(0.7, 1, 1, 1), true, Vector2(0, 150))
		"noflight":
			for i in 12:
				var a := randf() * TAU
				_emit_p("spark", jp, Vector2(cos(a), sin(a)) * randf_range(40, 100), 0.35, 5.0,
					Color(1, 0.9, 0.4, 1), true, Vector2(0, 120))
		"burn":
			for i in 8:
				_emit_p("flame", _body_point(), Vector2(randf_range(-15, 15), randf_range(-60, -25)),
					0.5, 4.0, Color(1, 0.6, 0.2, 0.9), true)
		"poison":
			for i in 6:
				_emit_p("bubble", _body_point(), Vector2(randf_range(-8, 8), randf_range(-35, -15)),
					0.8, randf_range(1.8, 3.2), Color(0.6, 1, 0.35, 0.9))
		"gravity":
			for i in 10:
				var a := randf() * TAU
				var d := Vector2(cos(a), sin(a))
				_emit_p("spark", CENTER + d * 36.0, -d * 110.0, 0.3, 7.0,
					Color(0.85, 0.75, 1, 1), true)


func _emit_effects(delta: float) -> void:
	var jp := _jetpack_pos()
	if _live.has("cryo"):
		for i in _count("cryo", 9.0, delta):
			_emit_p("shard", _body_point(), Vector2(randf_range(-6, 6), randf_range(10, 22)), 0.7,
				randf_range(2.0, 3.5), Color(0.85, 0.97, 1, 0.95))
	if _live.has("emp"):
		for i in _count("emp_jp", 16.0, delta):                       # the jetpack is what is shorting out
			var a := randf() * TAU
			_emit_p("spark", jp + Vector2(randf_range(-4, 4), randf_range(-4, 4)),
				Vector2(cos(a), sin(a)) * randf_range(40, 90), 0.25, 5.0, Color(0.7, 1, 1, 1),
				true, Vector2(0, 150))
		for i in _count("emp_body", 7.0, delta):
			var a2 := randf() * TAU
			_emit_p("spark", _body_point(), Vector2(cos(a2), sin(a2)) * randf_range(20, 50), 0.18, 4.0,
				Color(0.8, 1, 1, 1), true)
		_arc_timer -= delta
		if _arc_timer <= 0.0:
			_arc_timer = 0.07
			_make_arcs()
	if _live.has("noflight"):
		for i in _count("nof", 9.0, delta):
			_emit_p("spark", jp + Vector2(randf_range(-4, 4), randf_range(-2, 4)),
				Vector2(randf_range(-30, 30), randf_range(20, 70)), 0.35, 4.5, Color(1, 0.88, 0.35, 1),
				true, Vector2(0, 100))
	if _live.has("burn"):
		for i in _count("burn", 22.0, delta):
			_emit_p("flame", CENTER + Vector2(randf_range(-HALF_W, HALF_W), randf_range(-HALF_H * 0.2, HALF_H)),
				Vector2(randf_range(-8, 8), -randf_range(25, 50)), 0.5, randf_range(2.5, 4.5),
				Color(1, randf_range(0.4, 0.75), 0.15, 0.9), true)
	if _live.has("poison"):
		for i in _count("poison", 8.0, delta):
			_emit_p("bubble", _body_point(), Vector2(randf_range(-6, 6), -randf_range(18, 30)), 0.9,
				randf_range(1.6, 3.0), Color(0.6, 1, 0.35, 0.9))
	if _live.has("gravity"):
		for i in _count("grav", 16.0, delta):                         # specks being dragged inward
			var a3 := randf() * TAU
			var d := Vector2(cos(a3), sin(a3))
			_emit_p("spark", CENTER + d * 38.0, -d * 110.0, 0.32, 7.0, Color(0.85, 0.75, 1, 0.9), true)


func _make_arcs() -> void:
	_arcs.clear()
	for k in 2:
		var a1 := randf() * TAU
		var a2 := a1 + randf_range(0.8, 2.0)
		var pts := PackedVector2Array()
		for j in 7:
			var a := lerpf(a1, a2, float(j) / 6.0)
			var jitter := randf_range(-4.0, 4.0)
			pts.append(CENTER + Vector2(cos(a) * (HALF_W + 4.0 + jitter), sin(a) * (HALF_H + 3.0 + jitter)))
		_arcs.append(pts)


# ------------------------------------------------------------------
#  drawing: normal layer
# ------------------------------------------------------------------
func _ellipse(rx: float, ry: float, n := 20) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in n + 1:
		var a := TAU * float(i) / float(n)
		pts.append(CENTER + Vector2(cos(a) * rx, sin(a) * ry))
	return pts


func _draw() -> void:
	if _live.is_empty() and _parts.is_empty():
		return
	_draw_parts(false, self)
	if _live.has("cryo"):
		_draw_cryo()
	if _live.has("poison"):
		var pa := 0.18 + 0.08 * sin(_t * 5.0)
		draw_polyline(_ellipse(HALF_W + 3.0, HALF_H + 3.0), Color(0.5, 1, 0.3, pa * _fade("poison")), 1.4, true)
	_draw_pips()


func _draw_cryo() -> void:
	var f := _frac("cryo")
	var a := _fade("cryo")
	var ring := _ellipse(HALF_W + 3.0, HALF_H + 3.0)
	draw_colored_polygon(ring.slice(0, ring.size() - 1), Color(0.6, 0.9, 1.0, 0.12 * a))
	draw_polyline(ring, Color(0.7, 0.95, 1.0, 0.6 * a), 1.5, true)
	# ice shards around the body: they melt away one by one as the chill runs out
	var shown := ceili(f * 6.0)
	for k in shown:
		var ang := float(k) * TAU / 6.0 + 0.3
		var dir := Vector2(cos(ang), sin(ang))
		var base := CENTER + Vector2(dir.x * (HALF_W + 2.0), dir.y * (HALF_H + 2.0))
		var tip := base + dir * 6.0
		var perp := Vector2(-dir.y, dir.x) * 2.4
		draw_colored_polygon(PackedVector2Array([base + perp, tip, base - perp]),
			Color(0.82, 0.96, 1.0, 0.9 * maxf(a, 0.5)))


func _draw_pips() -> void:
	var types: Array = _live.keys()
	types.sort()
	var n := types.size()
	for i in n:
		var type: String = types[i]
		var c := Vector2((float(i) - float(n - 1) * 0.5) * 12.0, PIP_Y)
		var col: Color = COLORS[type]
		var f := _frac(type)
		if f < 0.25:                                    # blink when about to run out
			col.a = 0.5 + 0.5 * sin(_t * 18.0)
		draw_arc(c, 4.5, 0.0, TAU, 20, Color(0, 0, 0, 0.45), 3.2, true)
		draw_arc(c, 4.5, -PI / 2.0, -PI / 2.0 + TAU * f, 20, col, 2.0, true)
		draw_circle(c, 1.4, Color(col.r, col.g, col.b, col.a * 0.9))


# ------------------------------------------------------------------
#  drawing: additive layer (glows, sparks, lightning)
# ------------------------------------------------------------------
func _draw_add() -> void:
	if _live.is_empty() and _parts.is_empty() and _flash_t <= 0.0:
		return
	_draw_parts(true, _add)
	if _flash_t > 0.0:
		var k := _flash_t / 0.25
		_add.draw_arc(CENTER, lerpf(36.0, 12.0, k), 0.0, TAU, 28,
			Color(_flash_col.r, _flash_col.g, _flash_col.b, 0.8 * k), 2.0, true)
	if _live.has("emp"):
		var a := _fade("emp")
		for pts in _arcs:
			_add.draw_polyline(pts, Color(0.4, 0.9, 1.0, 0.35 * a), 3.0, true)
			_add.draw_polyline(pts, Color(0.85, 1.0, 1.0, 0.95 * a), 1.2, true)
	if _live.has("noflight"):
		_draw_noflight()
	if _live.has("gravity"):
		var g := _fade("gravity")
		for i in 2:
			var s := _t * 3.0 + float(i) * PI
			_add.draw_arc(CENTER, HALF_H + 5.0, s, s + 1.2, 10, Color(0.8, 0.65, 1.0, 0.7 * g), 1.6, true)
			_add.draw_arc(CENTER, HALF_H + 5.0, s, s + 1.2, 10, Color(0.6, 0.4, 1.0, 0.25 * g), 4.0, true)
	if _live.has("stun"):                                       # dizzy sparks circling the head
		var sa := _fade("stun")
		for i in 3:
			var ang := _t * 8.0 + float(i) * TAU / 3.0
			var sp := CENTER + Vector2(cos(ang) * (HALF_W + 2.0), -HALF_H - 5.0 + sin(ang) * 3.5)
			_add.draw_circle(sp, 3.2, Color(1.0, 0.9, 0.3, 0.35 * sa))
			_add.draw_circle(sp, 1.8, Color(1.0, 1.0, 0.85, 0.95 * sa))
	if _live.has("burn"):
		_add.draw_polyline(_ellipse(HALF_W + 2.0, HALF_H + 2.0),
			Color(1.0, 0.45, 0.1, (0.12 + 0.06 * sin(_t * 14.0)) * _fade("burn")), 3.0, true)


# a "no flight" sign on the jetpack plus chevrons dropping away from it
func _draw_noflight() -> void:
	var jp := _jetpack_pos()
	var a := _fade("noflight")
	var flick := 0.55 + 0.45 * sin(_t * 22.0)
	var col := Color(1.0, 0.85, 0.3, 0.9 * a * flick)
	_add.draw_arc(jp, 6.0, 0.0, TAU, 20, col, 1.5, true)
	_add.draw_line(jp + Vector2(-4.2, -4.2), jp + Vector2(4.2, 4.2), col, 1.5, true)
	for i in 3:
		var ph := fposmod(_t * 1.6 + float(i) / 3.0, 1.0)
		var p := jp + Vector2(0, 6.0 + ph * 14.0)
		var ca := Color(1.0, 0.85, 0.3, (1.0 - ph) * 0.8 * a)
		_add.draw_polyline(PackedVector2Array([p + Vector2(-3, -2), p + Vector2(0, 1), p + Vector2(3, -2)]), ca, 1.4, true)


func _draw_parts(add: bool, canvas: CanvasItem) -> void:
	for pt in _parts:
		if pt["add"] != add:
			continue
		var f: float = pt["age"] / pt["life"]
		var col: Color = pt["c"]
		col.a *= (1.0 - f)
		var size: float = pt["s"]
		var p: Vector2 = pt["p"]
		match pt["k"]:
			"flame":
				canvas.draw_circle(p, size * (1.0 - f * 0.8), col)
			"spark":
				var v: Vector2 = pt["v"]
				var d := v.normalized() if v.length() > 0.1 else Vector2.RIGHT
				canvas.draw_line(p, p - d * size, col, 1.3)
			"bubble":
				canvas.draw_circle(p, size, Color(col.r, col.g, col.b, col.a * 0.25))
				canvas.draw_arc(p, size, 0.0, TAU, 10, col, 1.0)
			"shard":
				canvas.draw_colored_polygon(PackedVector2Array([
					p + Vector2(0, -size), p + Vector2(size * 0.5, 0),
					p + Vector2(0, size), p + Vector2(-size * 0.5, 0)]), col)
			_:
				canvas.draw_circle(p, size, col)
