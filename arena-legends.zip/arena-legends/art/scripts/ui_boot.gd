extends Node
## Autoload ("UIBoot"). Gives EVERY button in the game the same Android-style feel without editing each menu:
## a quick press-down scale, a short haptic tick on tap. Also owns the soft screen vignette (Graphics Quality
## MEDIUM and HIGH only, so phones on LOW pay nothing for it).

var _vignette_layer: CanvasLayer
var _vignette: TextureRect
var _check := 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().node_added.connect(_on_node_added)
	GameSettings.ensure_loaded()
	_vignette_layer = CanvasLayer.new()
	_vignette_layer.layer = 4                     # above the world, below the HUD (5) and every menu
	add_child(_vignette_layer)
	_vignette = TextureRect.new()
	_vignette.texture = UITheme.radial_edge(Color(0, 0, 0, 0.42), 0.5)
	_vignette.set_anchors_preset(Control.PRESET_FULL_RECT)
	_vignette.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_vignette.stretch_mode = TextureRect.STRETCH_SCALE
	_vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_vignette_layer.add_child(_vignette)
	_vignette_layer.visible = GameSettings.quality >= 1


func _process(delta: float) -> void:
	_check -= delta
	if _check <= 0.0:
		_check = 0.5
		_vignette_layer.visible = GameSettings.quality >= 1


func _on_node_added(n: Node) -> void:
	if n is BaseButton and not n.has_meta("no_fx"):
		var b := n as BaseButton
		b.button_down.connect(_down.bind(b))
		b.button_up.connect(_up.bind(b))
		b.pressed.connect(_tap)


func _tap() -> void:
	UITheme.haptic(10)


func _down(b: BaseButton) -> void:
	if not is_instance_valid(b) or b.disabled:
		return
	b.pivot_offset = b.size * 0.5
	_scale_to(b, 0.96, 0.07)


func _up(b: BaseButton) -> void:
	if not is_instance_valid(b):
		return
	_scale_to(b, 1.0, 0.14)


func _scale_to(b: BaseButton, target: float, dur: float) -> void:
	if b.has_meta("fx_tween"):
		var old = b.get_meta("fx_tween")
		if old is Tween and (old as Tween).is_valid():
			(old as Tween).kill()
	var t := b.create_tween()
	t.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	t.set_ease(Tween.EASE_OUT)
	t.set_trans(Tween.TRANS_CUBIC)
	t.tween_property(b, "scale", Vector2(target, target), dur)
	b.set_meta("fx_tween", t)
