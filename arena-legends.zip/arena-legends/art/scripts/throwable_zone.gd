class_name ThrowableZone
extends Node2D
## A lingering area left behind by a throwable. It looks like the real thing instead of
## a circle: flames licking up from the floor, rolling green gas, growing ice crystals,
## a thick smoke cloud. Every zone_tick seconds it applies its status to everything inside
## that has apply_status() (players, bots).
##   burn / poison -> damage over time     cryo -> slow + sluggish jetpack
##   smoke         -> "smoked": whoever is inside is hidden from view
## Created by throwable.gd, which calls setup() right before adding it to the scene.

const PROCEDURAL := ["burn", "poison", "cryo", "smoke", "gravity", "emp", "noflight"]
const DISC := ["gravity", "emp", "noflight"]                      # round-field gadgets, drawn with code instead of a picture
const ELECTRONIC := ["decoy", "gravity", "noflight", "portal"]      # gadgets an EMP shuts down

var data: ThrowableData
var thrower: Node = null

var _age := 0.0
var _tick := 0.0
var _norm: FXField          # normal blending: smoke, gas, mist, ice
var _add: FXField           # additive: fire, glow, sparks
var _acc := {}              # spawn accumulators
var _fx: Node2D             # additive line layer (spiral arms, lightning, static)
var _arcs: Array = []
var _edge: Array = []
var _zig: Array = []
var _arc_time := -1.0
var _pulled: Array = []     # gravity: bodies currently caught in the well
var net_visual := false     # network match: cosmetic copy on a client; the host's copy applies every effect
var net_id := 0


func setup(d: ThrowableData, who: Node) -> void:
	data = d
	thrower = who


func _ready() -> void:
	add_to_group("throwable_zone")        # lets future counters (Nullifier, EMP field...) find areas
	if data.zone_effect == "decoy":
		add_to_group("decoy")             # bots look for these
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	z_index = 100 if data.zone_effect == "smoke" else 6     # smoke covers players
	_norm = FXField.new()
	add_child(_norm)
	_add = FXField.new()
	_add.additive = true
	add_child(_add)
	if DISC.has(data.zone_effect):
		_fx = Node2D.new()
		var mat := CanvasItemMaterial.new()
		mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		_fx.material = mat
		add_child(_fx)
		_fx.draw.connect(_draw_fx)
	_opening()


func _physics_process(delta: float) -> void:
	_age += delta
	if _age >= data.zone_duration:
		queue_free()
		return
	if net_visual:
		return                              # nothing to apply: effects come from the host as RPCs to each player
	_tick -= delta
	if _tick <= 0.0:
		_tick = data.zone_tick
		_affect_bodies()
	if data.zone_effect == "gravity":
		_pull_bodies(delta)


func _fade_len() -> float:
	return minf(1.2, data.zone_duration * 0.4)


func _process(delta: float) -> void:
	modulate.a = clampf((data.zone_duration - _age) / _fade_len(), 0.0, 1.0)      # fades out at the end
	var live := _age < data.zone_duration - minf(1.0, data.zone_duration * 0.35)   # stop making new stuff near the end
	if live:
		match data.zone_effect:
			"burn": _spawn_burn(delta)
			"poison": _spawn_poison(delta)
			"cryo": _spawn_cryo(delta)
			"smoke": _spawn_smoke(delta)
			"gravity": _spawn_gravity(delta)
			"emp": _spawn_emp(delta)
			"noflight": _spawn_noflight(delta)
			"decoy": _spawn_decoy(delta)
			"portal": _spawn_portal(delta)
	if _fx != null:
		_fx.queue_redraw()
	if not PROCEDURAL.has(data.zone_effect) and data.zone_texture != null:
		queue_redraw()


# Dispels the area early (a future Nullifier / Airburst weapon can call this).
func dispel() -> void:
	_age = maxf(_age, data.zone_duration - 0.6)
	if net_id != 0 and not net_visual and Net.match_active() and Net.is_host():
		Net.game.host_zone_dispelled(net_id)


func _center() -> Vector2:
	if data.zone_effect == "smoke":
		return global_position + Vector2(0, -data.zone_radius * 0.25)     # the cloud billows upward
	if DISC.has(data.zone_effect) or (not PROCEDURAL.has(data.zone_effect) and not data.zone_anchor_floor):
		return global_position + _disc_offset()
	return global_position


func _disc_offset() -> Vector2:
	return Vector2(0, -data.zone_radius * 0.35)       # round pictures hover a bit above the floor


func _affect_bodies() -> void:
	if data.zone_effect == "decoy" or data.zone_effect == "portal":
		return                                         # nothing to apply; bots just look for decoys
	if data.zone_effect == "emp":
		_emp_sweep()
	_pulled.clear()

	var circle := CircleShape2D.new()
	circle.radius = data.zone_radius * (0.85 if data.zone_effect == "smoke" else 0.92)
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = circle
	query.transform = Transform2D(0.0, _center())
	query.collision_mask = 0xFFFFFFFF
	query.collide_with_bodies = true
	query.collide_with_areas = false

	var seen := {}
	for hit in get_world_2d().direct_space_state.intersect_shape(query, 32):
		var body: Object = hit.collider
		if body == null or seen.has(body) or not (body is Node2D):
			continue
		seen[body] = true
		if data.zone_effect == "gravity":
			if body is CharacterBody2D:
				if body.has_method("net_gravity"):
					body.net_gravity(_center(), data.zone_power, data.zone_radius, data.zone_status_time)   # remote player: its owner pulls itself
				else:
					_pulled.append(body)
				# gives the caught player/bot a 'gravity' status so they get the swirl visual
				if body.has_method("apply_status"):
					body.apply_status("gravity", data.zone_status_time, 1.0, thrower)
				else:
					StatusEffects.apply_to(body as Node, "gravity", data.zone_status_time, 1.0, thrower)
			continue
		var type := "smoked" if data.zone_effect == "smoke" else data.zone_effect
		if body.has_method("apply_status"):
			body.apply_status(type, data.zone_status_time, data.zone_power, thrower)     # the player
		elif body.has_method("take_damage"):
			StatusEffects.apply_to(body as Node, type, data.zone_status_time, data.zone_power, thrower)   # bots + anything else


# ---------------- gadget particles ----------------
func _spawn_gravity(delta: float) -> void:
	var r := data.zone_radius
	var c := _disc_offset()
	for i in _n("pull", 55.0, delta):                   # speed lines streaking toward the core
		var ang := randf() * TAU
		var rad0 := r * randf_range(0.75, 1.05)
		var start := c + Vector2(cos(ang), sin(ang)) * rad0
		var inward := (c - start).normalized()
		var tang := Vector2(-inward.y, inward.x)
		var spd := rad0 / 0.6 * randf_range(0.85, 1.0)
		_add.emit(FXField.P(null, start, inward * spd + tang * spd * 0.5, 0.55,
			FXField.V(2.4), FXField.V(0.8), Color(0.85, 0.75, 1, 0.95), Color(0.5, 0.3, 1, 0),
			{"mode": "streak", "fade_in": 0.0, "trail": 0.05}))
	for i in _n("chunk", 10.0, delta):                  # rubble getting sucked in
		var ang := randf() * TAU
		var start := c + Vector2(cos(ang), sin(ang)) * r * randf_range(0.6, 0.95)
		var sz := randf_range(3.0, 6.0)
		_norm.emit(FXField.P(null, start, (c - start) * 1.6, 0.6, FXField.V(sz), FXField.V(1.0),
			Color(0.3, 0.24, 0.38, 1), Color(0.2, 0.15, 0.3, 0),
			{"mode": "box", "spin": randf_range(-10.0, 10.0), "fade_in": 0.0}))
	for i in _n("dust", 14.0, delta):                   # floor dust lifted toward the middle
		var start := Vector2(_tri() * r * 0.95, 8)
		_norm.emit(FXField.P(FXArt.pick("puff", 4), start, (c - start) * 1.3, 0.7, FXField.V(28), FXField.V(8),
			Color(0.55, 0.5, 0.65, 0.3), Color(0.4, 0.3, 0.6, 0), {"rot": randf() * TAU, "fade_in": 0.1}))
	for i in _n("core", 7.0, delta):                    # flicker around the core
		_add.emit(FXField.P(FXArt.tex("glow"), c, Vector2.ZERO, 0.25, FXField.V(r * 0.3), FXField.V(r * 0.55),
			Color(0.8, 0.65, 1, 0.5), Color(0.6, 0.4, 1, 0), {"fade_in": 0.0}))


func _spawn_emp(delta: float) -> void:
	var r := data.zone_radius
	var c := _disc_offset()
	for i in _n("zap", 45.0, delta):                    # crackling sparks everywhere
		var p := c + Vector2.from_angle(randf() * TAU) * r * sqrt(randf()) * 0.95
		_add.emit(FXField.P(FXArt.tex("spark"), p, Vector2(randf_range(-30, 30), randf_range(-30, 30)), randf_range(0.2, 0.45),
			FXField.V(randf_range(7, 14)), FXField.V(2.0), Color(0.75, 1, 1, 1), Color(0.3, 0.8, 1, 0), {"fade_in": 0.0}))
	for i in _n("wave", 1.8, delta):                    # pulses rolling outward
		_add.emit(FXField.P(FXArt.tex("ring"), c, Vector2.ZERO, 0.7, FXField.V(r * 0.15), FXField.V(r * 2.0),
			Color(0.5, 0.95, 1, 0.5), Color(0.3, 0.8, 1, 0), {"fade_in": 0.0}))
	for i in _n("flare", 3.0, delta):
		_add.emit(FXField.P(FXArt.tex("glow"), c + Vector2(randf_range(-r, r), randf_range(-r, r)) * 0.4, Vector2.ZERO, 0.4,
			FXField.V(r * 0.9), FXField.V(r * 1.5), Color(0.4, 0.85, 1, 0.22), Color(0.4, 0.85, 1, 0), {"fade_in": 0.1}))
	for i in _n("skitter", 10.0, delta):                # sparks skittering on the floor
		_add.emit(FXField.P(FXArt.tex("spark"), Vector2(_tri() * r, 6), Vector2(randf_range(-80, 80), -randf_range(40, 140)), 0.5,
			FXField.V(8), FXField.V(2.0), Color(0.8, 1, 1, 1), Color(0.3, 0.8, 1, 0), {"acc": Vector2(0, 500), "fade_in": 0.0}))


func _spawn_noflight(delta: float) -> void:
	var r := data.zone_radius
	var c := _disc_offset()
	for i in _n("down", 45.0, delta):                   # downdraft pinning everything to the floor
		var x := randf_range(-r * 0.9, r * 0.9)
		var y_top := c.y - sqrt(maxf(r * r - (x * x), 0.0)) * 0.95
		var spd := randf_range(320.0, 520.0)
		_add.emit(FXField.P(null, Vector2(x, y_top), Vector2(0, spd), maxf((8.0 - y_top) / spd, 0.1),
			FXField.V(2.5), FXField.V(1.2), Color(1, 0.85, 0.3, 0.9), Color(1, 0.55, 0.1, 0),
			{"mode": "streak", "fade_in": 0.0, "trail": 0.06}))
	for i in _n("press", 4.0, delta):                   # glow where the downdraft hits the ground
		_add.emit(FXField.P(FXArt.tex("glow"), Vector2(0, 8), Vector2.ZERO, 0.5, Vector2(r * 2.2, r * 0.35), Vector2(r * 2.4, r * 0.3),
			Color(1, 0.75, 0.2, 0.4), Color(1, 0.6, 0.1, 0), {"fade_in": 0.1}))
	for i in _n("gust", 7.0, delta):                    # dust blown sideways along the floor
		var side := 1.0 if randf() < 0.5 else -1.0
		_norm.emit(FXField.P(FXArt.pick("puff", 4), Vector2(randf_range(-r * 0.3, r * 0.3), 4), Vector2(side * randf_range(80, 160), -randf_range(0, 15)), 0.8,
			FXField.V(24), FXField.V(60), Color(0.75, 0.68, 0.45, 0.28), Color(0.75, 0.68, 0.45, 0), {"rot": randf() * TAU, "fade_in": 0.1}))
	for i in _n("static", 18.0, delta):                 # jammed-signal sparks
		_add.emit(FXField.P(FXArt.tex("spark"), c + Vector2.from_angle(randf() * TAU) * r * sqrt(randf()) * 0.9, Vector2.ZERO, randf_range(0.15, 0.35),
			FXField.V(randf_range(6, 11)), FXField.V(2.0), Color(1, 0.95, 0.6, 1), Color(1, 0.6, 0.1, 0), {"fade_in": 0.0}))


func _spawn_decoy(delta: float) -> void:
	for i in _n("base", 3.0, delta):                    # projector glow at its feet
		_add.emit(FXField.P(FXArt.tex("glow"), Vector2(0, 6), Vector2.ZERO, 0.7, Vector2(60, 16), Vector2(90, 22),
			Color(0.4, 0.9, 1, 0.5), Color(0.3, 0.8, 1, 0), {"fade_in": 0.1}))
	for i in _n("bit", 14.0, delta):                    # data bits drifting up off the hologram
		_add.emit(FXField.P(null, Vector2(randf_range(-20, 20), -randf_range(4, 56)), Vector2(randf_range(-10, 10), -randf_range(15, 45)),
			randf_range(0.5, 0.9), FXField.V(randf_range(2, 4)), FXField.V(1.5), Color(0.5, 1, 1, 0.9), Color(0.3, 0.8, 1, 0),
			{"mode": "box", "fade_in": 0.0}))
	for i in _n("glitch", 2.0, delta):                  # flickering slices
		_add.emit(FXField.P(null, Vector2(randf_range(-6, 6), -randf_range(6, 52)), Vector2.ZERO, 0.12, Vector2(randf_range(24, 44), 2), Vector2(randf_range(24, 44), 2),
			Color(0.7, 1, 1, 0.7), Color(0.7, 1, 1, 0), {"mode": "box", "fade_in": 0.0}))


func _spawn_portal(delta: float) -> void:
	var pc := Vector2(0, -45)
	for i in _n("rim", 70.0, delta):                    # sparks shed from the rim
		var ang := randf() * TAU
		var col := Color(1, 0.45, 0.95, 1) if randf() < 0.6 else Color(0.5, 1, 1, 1)
		_add.emit(FXField.P(FXArt.tex("spark"), pc + Vector2(cos(ang) * 34.0, sin(ang) * 48.0), Vector2(cos(ang) * 40.0, sin(ang) * 40.0 - 20.0),
			randf_range(0.35, 0.6), FXField.V(randf_range(8, 12)), FXField.V(2.0), col, Color(col.r, col.g, col.b, 0), {"fade_in": 0.0}))
	for i in _n("swirl", 30.0, delta):                  # streaks spiraling into the middle
		var ang := randf() * TAU
		var start := pc + Vector2(cos(ang) * 54.0, sin(ang) * 76.0)
		var inward := (pc - start)
		var tang := Vector2(-inward.y, inward.x).normalized()
		_add.emit(FXField.P(null, start, inward / 0.35 + tang * 60.0, 0.33, FXField.V(2.2), FXField.V(0.8),
			Color(1, 0.65, 1, 0.9), Color(0.7, 0.3, 1, 0), {"mode": "streak", "fade_in": 0.0, "trail": 0.05}))
	for i in _n("pulse", 4.0, delta):
		_add.emit(FXField.P(FXArt.tex("glow"), pc, Vector2.ZERO, 0.5, Vector2(80, 110), Vector2(105, 135),
			Color(1, 0.4, 0.95, 0.35), Color(1, 0.3, 0.9, 0), {"fade_in": 0.1}))


# ---------------- gadget line effects (drawn on the additive layer) ----------------
func _draw_fx() -> void:
	match data.zone_effect:
		"gravity": _fx_gravity()
		"emp": _fx_emp()
		"noflight": _fx_noflight()


func _fx_gravity() -> void:
	var r := data.zone_radius
	var c := _disc_offset()
	var open := clampf(_age / 0.3, 0.0, 1.0)
	for arm in 3:                                       # spiral arms with waves running inward
		var pts := PackedVector2Array()
		var cols := PackedColorArray()
		for i in 30:
			var t := float(i) / 29.0
			var ang := _age * 1.8 + arm * TAU / 3.0 - t * 3.6
			var rad := r * open * (0.08 + 0.92 * t)
			pts.append(c + Vector2(cos(ang), sin(ang)) * rad)
			var wave := 0.55 + 0.45 * sin(t * 13.0 + _age * 8.0)
			cols.append(Color(0.72, 0.58, 1.0, (0.2 + 0.8 * (1.0 - t)) * wave * open))
		_fx.draw_polyline_colors(pts, cols, 3.0, true)
	for k in 3:                                         # rings that shrink into the core
		var f := fmod(_age * 0.7 + k / 3.0, 1.0)
		_fx.draw_arc(c, r * (1.0 - f) * open, 0.0, TAU, 48, Color(0.8, 0.7, 1.0, 0.5 * f), 2.0, true)


func _arc(a: Vector2, b: Vector2) -> PackedVector2Array:
	var pts := PackedVector2Array()
	var n := 9
	var perp := (b - a).orthogonal().normalized()
	for i in n + 1:
		var t := float(i) / float(n)
		var p := a.lerp(b, t)
		if i > 0 and i < n:
			p += perp * randf_range(-1.0, 1.0) * 16.0 * sin(PI * t)
		pts.append(p)
	return pts


func _fx_emp() -> void:
	var r := data.zone_radius
	var c := _disc_offset()
	var open := clampf(_age / 0.2, 0.0, 1.0)
	if _age - _arc_time > 0.06:                         # new lightning every few frames = flicker
		_arc_time = _age
		_arcs.clear()
		_edge.clear()
		for k in 4:
			_arcs.append(_arc(c, c + Vector2.from_angle(randf() * TAU) * r * randf_range(0.7, 1.0)))
		for k in 3:
			var a0 := randf() * TAU
			var a1 := a0 + randf_range(-1.2, 1.2)
			_arcs.append(_arc(c + Vector2.from_angle(a0) * r * randf_range(0.2, 0.9), c + Vector2.from_angle(a1) * r * randf_range(0.2, 0.9)))
		for k in 3:
			_edge.append(Vector2(randf() * TAU, randf_range(0.3, 0.9)))
	for pts in _arcs:
		_fx.draw_polyline(pts, Color(0.35, 0.85, 1.0, 0.3 * open), 7.0, true)
		_fx.draw_polyline(pts, Color(0.9, 1.0, 1.0, 0.95 * open), 1.8, true)
	for e in _edge:                                     # the field edge only flickers in patches
		_fx.draw_arc(c, r * 0.97, e.x, e.x + e.y, 14, Color(0.5, 0.95, 1.0, 0.8 * open), 2.5, true)


func _fx_noflight() -> void:
	var r := data.zone_radius
	var c := _disc_offset()
	var open := clampf(_age / 0.25, 0.0, 1.0)
	var top := c.y - r
	var span := 8.0 - top
	for col in range(-3, 4):                            # chevrons scrolling down: "you're being forced down"
		var x := col * r * 0.26
		for k in 3:
			var frac := fposmod(_age * 0.9 + k / 3.0 + col * 0.137, 1.0)
			var y := top + frac * span
			if Vector2(x, y).distance_to(c) > r * 0.92:
				continue
			var a := sin(PI * frac) * 0.8 * open
			_fx.draw_polyline(PackedVector2Array([Vector2(x - 10, y - 7), Vector2(x, y + 3), Vector2(x + 10, y - 7)]),
				Color(1.0, 0.85, 0.3, a), 3.0, true)
	if _age - _arc_time > 0.09:                         # interference lines
		_arc_time = _age
		_zig.clear()
		_edge.clear()
		for k in 2:
			var dy := randf_range(-r * 0.8, r * 0.3)
			var half := sqrt(maxf(r * r - dy * dy, 0.0)) * 0.9
			var pts := PackedVector2Array()
			for i in 14:
				pts.append(Vector2(lerpf(-half, half, float(i) / 13.0), c.y + dy + randf_range(-5.0, 5.0)))
			_zig.append(pts)
		for k in 3:
			_edge.append(Vector2(randf_range(PI, TAU - 0.8), randf_range(0.3, 0.8)))
	for pts in _zig:
		_fx.draw_polyline(pts, Color(1.0, 0.8, 0.2, 0.25 * open), 6.0, true)
		_fx.draw_polyline(pts, Color(1.0, 0.95, 0.7, 0.9 * open), 1.6, true)
	for e in _edge:
		_fx.draw_arc(c, r * 0.97, e.x, e.x + e.y, 14, Color(1.0, 0.8, 0.25, 0.8 * open), 2.5, true)


# ---------------- gravity well ----------------
func _pull_bodies(delta: float) -> void:
	var c := _center()
	for b in _pulled:
		if not is_instance_valid(b):
			continue
		if ("is_dead" in b and bool(b.get("is_dead"))) or ("dead" in b and bool(b.get("dead"))):
			continue
		var to: Vector2 = c - (b as Node2D).global_position
		var d := to.length()
		if d < 12.0:
			continue                                   # already in the middle
		var speed := data.zone_power * lerpf(0.5, 1.0, clampf(d / data.zone_radius, 0.0, 1.0))
		(b as CharacterBody2D).move_and_collide(to / d * minf(speed * delta, d))
		if "velocity" in b:                            # the well soaks up their own momentum
			b.set("velocity", (b.get("velocity") as Vector2).move_toward(Vector2.ZERO, 900.0 * delta))


# ---------------- EMP ----------------
# Fries every flying bomb and mine in range, and shuts down electronic gadget zones.
func _emp_sweep() -> void:
	var c := _center()
	var r := data.zone_radius
	for n in get_tree().get_nodes_in_group("throwable"):
		if n is Node2D and (n as Node2D).global_position.distance_to(c) <= r:
			n.queue_free()
	for z in get_tree().get_nodes_in_group("throwable_zone"):
		if z == self or not (z is Node2D):
			continue
		var zd = z.get("data")
		if zd != null and ELECTRONIC.has(zd.zone_effect) and (z as Node2D).global_position.distance_to(c) <= r:
			z.call("dispel")


# ---------------- spawning helpers ----------------
func _n(key: String, per_sec: float, delta: float) -> int:
	_acc[key] = float(_acc.get(key, 0.0)) + per_sec * delta * clampf(_age / 0.35, 0.0, 1.0)
	var n := int(_acc[key])
	_acc[key] -= n
	return n


func _tri() -> float:                    # -1..1, more likely near the middle
	return (randf_range(-1.0, 1.0) + randf_range(-1.0, 1.0)) * 0.5


func _dir(ang: float) -> Vector2:
	return Vector2(cos(ang), sin(ang))


# ---------------- what happens the moment it lands ----------------
func _opening() -> void:
	if ["gravity", "emp", "noflight", "decoy", "portal"].has(data.zone_effect):
		_opening_gadget()
		return
	var r := data.zone_radius
	var dur := data.zone_duration
	match data.zone_effect:
		"burn":
			# scorched ground
			_norm.emit(FXField.P(FXArt.tex("puff_1"), Vector2(0, 10), Vector2.ZERO, dur, Vector2(r * 2.0, 22), Vector2(r * 2.0, 22),
				Color(0, 0, 0, 0.38), Color(0, 0, 0, 0), {"hold": 0.8, "fade_in": 0.03}))
			for i in 14:                 # flames whoosh outward along the floor
				var x := _tri() * r * 0.9
				var w := randf_range(30.0, 50.0)
				_add.emit(FXField.P(FXArt.pick("flame", 3), Vector2(0, 8), Vector2(x * 3.2, -randf_range(30, 80)), randf_range(0.5, 0.8),
					Vector2(w, w * 2.4), Vector2(w * 0.4, w * 2.0), Color(1, 0.9, 0.5, 0.95), Color(1, 0.22, 0.04, 0),
					{"anchor": Vector2(0.5, 1.0), "drag": 4.0, "fade_in": 0.05}))
		"poison":
			_norm.emit(FXField.P(FXArt.tex("puff_3"), Vector2(0, 10), Vector2.ZERO, dur, Vector2(r * 2.0, 26), Vector2(r * 2.0, 26),
				Color(0.3, 0.7, 0.12, 0.5), Color(0.3, 0.7, 0.12, 0), {"hold": 0.8, "fade_in": 0.05}))
			for i in 16:
				var target := Vector2(_tri() * r * 0.9, 8 - randf_range(0.0, r * 0.4))
				_norm.emit(FXField.P(FXArt.pick("puff", 4), Vector2.ZERO, target * 4.0, randf_range(2.0, 3.0),
					FXField.V(randf_range(60, 100)), FXField.V(randf_range(110, 160)), Color(0.55, 0.95, 0.2, 0.5), Color(0.3, 0.65, 0.1, 0),
					{"drag": 4.0, "spin": randf_range(-0.3, 0.3), "rot": randf() * TAU, "fade_in": 0.15}))
		"cryo":
			_norm.emit(FXField.P(FXArt.tex("puff_2"), Vector2(0, 10), Vector2.ZERO, dur, Vector2(r * 2.1, 28), Vector2(r * 2.1, 28),
				Color(0.75, 0.92, 1.0, 0.55), Color(0.75, 0.92, 1.0, 0), {"hold": 0.85, "fade_in": 0.05}))
			for i in 16:                 # ice crystals shoot up out of the floor
				var x := -r * 0.9 + i * (r * 1.8 / 15.0) + randf_range(-8.0, 8.0)
				var e := absf(x) / r
				var w := randf_range(18.0, 34.0)
				var h := w * randf_range(2.2, 3.2) * (1.0 - 0.35 * e)
				_norm.emit(FXField.P(FXArt.pick("shard", 3), Vector2(x, 10), Vector2.ZERO, dur, Vector2(w, h), Vector2(w, h),
					Color(1, 1, 1, 0.97), Color(1, 1, 1, 0),
					{"anchor": Vector2(0.5, 0.96), "grow": 0.3, "rot": randf_range(-0.25, 0.25), "hold": 0.85, "fade_in": 0.0, "delay": randf() * 0.25}))
		"smoke":
			var cen := Vector2(0, -r * 0.25)
			for i in 60:                 # the cloud billows outward from the bomb
				var ang := randf() * TAU
				var rad := sqrt(randf())
				var target := cen + Vector2(cos(ang) * r * 0.95 * rad, sin(ang) * r * 0.85 * rad)
				var start := Vector2(randf_range(-8, 8), randf_range(-8, 8))
				var g := randf_range(0.42, 0.62)
				_norm.emit(FXField.P(FXArt.pick("puff", 4), start, (target - start) * 4.0, dur + 0.5,
					FXField.V(randf_range(110, 170)), FXField.V(randf_range(130, 190)), Color(g, g + 0.01, g + 0.04, 0.98), Color(g, g + 0.01, g + 0.04, 0.98),
					{"drag": 4.0, "spin": randf_range(-0.15, 0.15), "rot": randf() * TAU, "fade_in": 0.04, "hold": 1.0, "delay": randf() * 0.25}))


# ---------------- gadget openings ----------------
func _opening_gadget() -> void:
	var r := data.zone_radius
	var dur := data.zone_duration
	var glow := FXArt.tex("glow")
	var ring := FXArt.tex("ring")
	match data.zone_effect:
		"gravity":
			var gc := _disc_offset()
			_norm.emit(FXField.P(glow, gc, Vector2.ZERO, dur, FXField.V(r * 0.7), FXField.V(r * 0.6),
				Color(0.02, 0.0, 0.07, 0.95), Color(0.02, 0.0, 0.07, 0.95), {"fade_in": 0.08, "hold": 1.0}))       # dark core
			_norm.emit(FXField.P(glow, gc, Vector2.ZERO, dur, FXField.V(r * 0.32), FXField.V(r * 0.28),
				Color(0, 0, 0, 1), Color(0, 0, 0, 1), {"fade_in": 0.08, "hold": 1.0}))
			_add.emit(FXField.P(glow, gc, Vector2.ZERO, dur, FXField.V(r * 1.9), FXField.V(r * 1.7),
				Color(0.5, 0.35, 1, 0.3), Color(0.5, 0.35, 1, 0.0), {"fade_in": 0.1}))
			_add.emit(FXField.P(ring, gc, Vector2.ZERO, 0.5, FXField.V(r * 0.3), FXField.V(r * 2.4),
				Color(0.75, 0.6, 1, 0.8), Color(0.5, 0.3, 1, 0), {"fade_in": 0.0}))
		"emp":
			var ec := _disc_offset()
			_add.emit(FXField.P(glow, ec, Vector2.ZERO, 0.3, FXField.V(r * 0.8), FXField.V(r * 3.0),
				Color(0.9, 1, 1, 1), Color(0.3, 0.85, 1, 0), {"fade_in": 0.0}))
			for k in 2:
				_add.emit(FXField.P(ring, ec, Vector2.ZERO, 0.45, FXField.V(r * 0.2), FXField.V(r * 2.3),
					Color(0.5, 0.95, 1, 0.9), Color(0.2, 0.7, 1, 0), {"fade_in": 0.0, "delay": k * 0.1}))
			for i in 36:
				_add.emit(FXField.P(null, ec, _dir(randf() * TAU) * randf_range(250.0, 700.0), randf_range(0.3, 0.6),
					FXField.V(2.6), FXField.V(0.8), Color(0.85, 1, 1, 1), Color(0.3, 0.8, 1, 0),
					{"mode": "streak", "drag": 2.2, "fade_in": 0.0, "trail": 0.04}))
		"noflight":
			var fc := _disc_offset()
			_add.emit(FXField.P(glow, fc, Vector2.ZERO, 0.3, FXField.V(r * 0.8), FXField.V(r * 2.6),
				Color(1, 0.95, 0.6, 1), Color(1, 0.7, 0.1, 0), {"fade_in": 0.0}))
			_add.emit(FXField.P(ring, Vector2(0, 8), Vector2.ZERO, 0.5, Vector2(r * 0.3, r * 0.1), Vector2(r * 2.4, r * 0.5),
				Color(1, 0.85, 0.3, 0.9), Color(1, 0.6, 0.1, 0), {"fade_in": 0.0}))
			for i in 28:
				var x := randf_range(-r, r)
				_add.emit(FXField.P(null, Vector2(x, fc.y - r * 0.8), Vector2(0, randf_range(500.0, 900.0)), randf_range(0.2, 0.4),
					FXField.V(3.0), FXField.V(1.0), Color(1, 0.9, 0.4, 1), Color(1, 0.55, 0.1, 0),
					{"mode": "streak", "fade_in": 0.0, "trail": 0.05}))
		"decoy":
			_add.emit(FXField.P(ring, Vector2(0, 6), Vector2.ZERO, 0.5, Vector2(20, 6), Vector2(120, 34),
				Color(0.5, 0.95, 1, 0.9), Color(0.3, 0.8, 1, 0), {"fade_in": 0.0}))
			_add.emit(FXField.P(glow, Vector2(0, -26), Vector2.ZERO, 0.35, FXField.V(30), FXField.V(130),
				Color(0.8, 1, 1, 0.8), Color(0.3, 0.8, 1, 0), {"fade_in": 0.0}))
			for i in 22:
				_add.emit(FXField.P(null, Vector2(randf_range(-18, 18), 6), Vector2(randf_range(-40, 40), -randf_range(80.0, 260.0)), randf_range(0.3, 0.7),
					FXField.V(2.4), FXField.V(0.8), Color(0.7, 1, 1, 1), Color(0.3, 0.8, 1, 0),
					{"mode": "streak", "drag": 2.0, "fade_in": 0.0, "trail": 0.04}))
		"portal":
			var pc := Vector2(0, -45)
			_add.emit(FXField.P(glow, pc, Vector2.ZERO, 0.4, FXField.V(40), FXField.V(240),
				Color(1, 0.85, 1, 1), Color(1, 0.3, 0.9, 0), {"fade_in": 0.0}))
			_add.emit(FXField.P(ring, pc, Vector2.ZERO, 0.5, FXField.V(30), FXField.V(200),
				Color(1, 0.5, 0.95, 0.9), Color(0.7, 0.3, 1, 0), {"fade_in": 0.0}))
			for i in 30:
				_add.emit(FXField.P(null, pc, _dir(randf() * TAU) * randf_range(200.0, 560.0), randf_range(0.3, 0.6),
					FXField.V(2.6), FXField.V(0.8), Color(1, 0.8, 1, 1), Color(0.8, 0.3, 1, 0),
					{"mode": "streak", "drag": 2.2, "fade_in": 0.0, "trail": 0.04}))


# ---------------- continuous effects ----------------
func _spawn_burn(delta: float) -> void:
	var r := data.zone_radius
	for i in _n("flame", 70.0, delta):                  # main flames along the floor
		var x := _tri() * r * 0.95
		var edge := absf(x) / r
		var w := randf_range(26.0, 44.0) * (1.0 - 0.35 * edge)
		var h := w * randf_range(2.0, 2.8) * (1.0 - 0.4 * edge)
		_add.emit(FXField.P(FXArt.pick("flame", 3), Vector2(x, 8 + randf_range(-3, 3)), Vector2(randf_range(-14, 14), -randf_range(25, 60)),
			randf_range(0.45, 0.8), Vector2(w, h), Vector2(w * 0.35, h * 0.9), Color(1, 0.9, 0.5, 0.95), Color(1, 0.22, 0.04, 0),
			{"anchor": Vector2(0.5, 1.0), "fade_in": 0.1, "acc": Vector2(randf_range(-60, 60), 0)}))
	for i in _n("core", 40.0, delta):                   # small hot cores
		var x := _tri() * r * 0.8
		var w := randf_range(14.0, 22.0)
		_add.emit(FXField.P(FXArt.pick("flame", 3), Vector2(x, 8), Vector2(0, -randf_range(20, 50)), randf_range(0.35, 0.55),
			Vector2(w, w * 2.2), Vector2(w * 0.4, w * 1.6), Color(1, 1, 0.8, 0.9), Color(1, 0.6, 0.1, 0),
			{"anchor": Vector2(0.5, 1.0), "fade_in": 0.1}))
	for i in _n("glow", 6.0, delta):                    # flickering light on the ground and above
		_add.emit(FXField.P(FXArt.tex("glow"), Vector2(0, 4), Vector2.ZERO, 0.5, Vector2(r * 2.3, r * 0.7), Vector2(r * 2.0, r * 0.6),
			Color(1, 0.45, 0.1, 0.55), Color(1, 0.3, 0.05, 0), {"anchor": Vector2(0.5, 0.6)}))
		_add.emit(FXField.P(FXArt.tex("glow"), Vector2(0, -r * 0.3), Vector2.ZERO, 0.5, Vector2(r * 1.6, r * 1.2), Vector2(r * 1.4, r * 1.0),
			Color(1, 0.4, 0.1, 0.2), Color(1, 0.3, 0.05, 0)))
	for i in _n("ember", 16.0, delta):                  # embers drifting up
		_add.emit(FXField.P(FXArt.tex("spark"), Vector2(_tri() * r * 0.9, 4), Vector2(randf_range(-45, 45), -randf_range(90, 210)),
			randf_range(0.9, 1.5), FXField.V(randf_range(5, 8)), FXField.V(2.0), Color(1, 0.85, 0.35, 1), Color(1, 0.3, 0.05, 0),
			{"acc": Vector2(0, 120), "drag": 0.3, "fade_in": 0.0}))
	for i in _n("smoke", 4.0, delta):                   # dark smoke above the fire
		_norm.emit(FXField.P(FXArt.pick("puff", 4), Vector2(_tri() * r * 0.7, -r * 0.35), Vector2(randf_range(-10, 10), -randf_range(30, 50)),
			randf_range(1.4, 2.0), FXField.V(50), FXField.V(110), Color(0.1, 0.09, 0.09, 0.4), Color(0.2, 0.19, 0.19, 0),
			{"spin": randf_range(-0.4, 0.4), "rot": randf() * TAU, "fade_in": 0.25}))


func _spawn_poison(delta: float) -> void:
	var r := data.zone_radius
	for i in _n("gas", 9.0, delta):                     # rolling green gas
		var w := randf_range(70.0, 110.0)
		_norm.emit(FXField.P(FXArt.pick("puff", 4), Vector2(_tri() * r * 0.9, 8 - randf_range(0.0, r * 0.45)),
			Vector2(randf_range(-12, 12), -randf_range(8, 22)), randf_range(2.2, 3.4), FXField.V(w), FXField.V(w * 1.7),
			Color(0.55, 0.95, 0.2, 0.5), Color(0.3, 0.65, 0.1, 0),
			{"spin": randf_range(-0.25, 0.25), "rot": randf() * TAU, "fade_in": 0.25}))
	for i in _n("dark", 4.0, delta):                    # darker toxic sludge near the floor
		_norm.emit(FXField.P(FXArt.pick("puff", 4), Vector2(_tri() * r * 0.8, 8 - randf_range(0.0, r * 0.2)),
			Vector2(randf_range(-8, 8), -randf_range(4, 12)), randf_range(2.0, 3.0), FXField.V(randf_range(60, 90)), FXField.V(randf_range(100, 130)),
			Color(0.18, 0.42, 0.08, 0.45), Color(0.15, 0.3, 0.06, 0), {"spin": randf_range(-0.2, 0.2), "rot": randf() * TAU, "fade_in": 0.25}))
	for i in _n("bubble", 7.0, delta):
		var s := randf_range(9.0, 16.0)
		_norm.emit(FXField.P(FXArt.tex("bubble"), Vector2(_tri() * r * 0.85, 6 - randf_range(0.0, r * 0.3)),
			Vector2(randf_range(-8, 8), -randf_range(28, 60)), randf_range(1.2, 2.0), FXField.V(s), FXField.V(s),
			Color(0.85, 1, 0.55, 0.9), Color(0.85, 1, 0.55, 0), {"fade_in": 0.1}))
	for i in _n("pool", 3.0, delta):                    # sickly glow on the ground
		_add.emit(FXField.P(FXArt.tex("glow"), Vector2(0, 6), Vector2.ZERO, 0.8, Vector2(r * 2.2, r * 0.5), Vector2(r * 2.2, r * 0.5),
			Color(0.4, 1, 0.2, 0.28), Color(0.3, 0.9, 0.1, 0)))


func _spawn_cryo(delta: float) -> void:
	var r := data.zone_radius
	for i in _n("mist", 8.0, delta):                    # cold mist rolling along the floor
		_norm.emit(FXField.P(FXArt.pick("puff", 4), Vector2(_tri() * r * 0.95, 6 - randf_range(0.0, r * 0.3)),
			Vector2(randf_range(-20, 20), -randf_range(6, 14)), randf_range(2.0, 3.0), FXField.V(80), FXField.V(140),
			Color(0.75, 0.92, 1.0, 0.4), Color(0.75, 0.92, 1.0, 0),
			{"spin": randf_range(-0.2, 0.2), "rot": randf() * TAU, "fade_in": 0.25}))
	for i in _n("sparkle", 18.0, delta):                # glittering frost
		_add.emit(FXField.P(FXArt.tex("spark"), Vector2(_tri() * r, -randf_range(0.0, r * 0.9)), Vector2(randf_range(-6, 6), randf_range(8, 22)),
			randf_range(1.0, 2.0), FXField.V(randf_range(5, 9)), FXField.V(3.0), Color(0.85, 0.97, 1, 1), Color(0.6, 0.9, 1, 0), {"fade_in": 0.3}))
	for i in _n("shard", 2.0, delta):                   # more crystals keep pushing up
		var x := _tri() * r * 0.85
		var w := randf_range(12.0, 22.0)
		var h := w * randf_range(2.2, 3.0)
		_norm.emit(FXField.P(FXArt.pick("shard", 3), Vector2(x, 10), Vector2.ZERO, 1.8, Vector2(w, h), Vector2(w, h),
			Color(1, 1, 1, 0.95), Color(1, 1, 1, 0), {"anchor": Vector2(0.5, 0.96), "grow": 0.25, "rot": randf_range(-0.3, 0.3), "hold": 0.6, "fade_in": 0.0}))


func _spawn_smoke(delta: float) -> void:
	var r := data.zone_radius
	var cen := Vector2(0, -r * 0.25)
	for i in _n("fill", 7.0, delta):                    # keeps the cloud thick
		var ang := randf() * TAU
		var rad := sqrt(randf())
		var g := randf_range(0.42, 0.62)
		_norm.emit(FXField.P(FXArt.pick("puff", 4), cen + Vector2(cos(ang) * r * 0.9 * rad, sin(ang) * r * 0.8 * rad), Vector2(randf_range(-8, 8), -randf_range(2, 10)),
			3.0, FXField.V(randf_range(110, 160)), FXField.V(randf_range(140, 190)), Color(g, g + 0.01, g + 0.04, 0.95), Color(g, g + 0.01, g + 0.04, 0),
			{"spin": randf_range(-0.15, 0.15), "rot": randf() * TAU, "fade_in": 0.15, "hold": 0.7}))
	for i in _n("wisp", 3.0, delta):                    # lighter wisps around the edge
		var ang := randf() * TAU
		_norm.emit(FXField.P(FXArt.pick("puff", 4), cen + Vector2(cos(ang) * r, sin(ang) * r * 0.9), Vector2(cos(ang) * 14, -8),
			2.0, FXField.V(randf_range(90, 130)), FXField.V(randf_range(120, 160)), Color(0.7, 0.72, 0.78, 0.5), Color(0.7, 0.72, 0.78, 0),
			{"rot": randf() * TAU, "fade_in": 0.2}))


# pictures for the gadget zones that keep their art (decoy, portal)
func _draw() -> void:
	if data == null or PROCEDURAL.has(data.zone_effect) or data.zone_texture == null:
		return
	var tex := data.zone_texture
	var open := clampf(_age / 0.25, 0.0, 1.0)
	if data.zone_anchor_floor:
		var sz := tex.get_size() * data.zone_art_scale
		var a := 1.0
		var glitch := false
		if data.zone_effect == "decoy":
			a = 0.75 + 0.2 * sin(_age * 16.0)
			glitch = fmod(_age, 1.7) < 0.08
			if glitch:
				a *= 0.5
		var w := sz.x * (0.55 + 0.45 * open)
		var h := sz.y * open
		var rect := Rect2(-w * 0.5, 6.0 - h, w, h)
		if glitch:                                      # color-split ghost images
			draw_texture_rect(tex, Rect2(rect.position + Vector2(-5, 0), rect.size), false, Color(1.0, 0.3, 0.9, 0.45))
			draw_texture_rect(tex, Rect2(rect.position + Vector2(5, 0), rect.size), false, Color(0.3, 1.0, 1.0, 0.45))
		draw_texture_rect(tex, rect, false, Color(1, 1, 1, a))
	else:
		var size := Vector2.ONE * data.zone_radius * 2.0 * open
		draw_texture_rect(tex, Rect2(_disc_offset() - size * 0.5, size), false, Color(1, 1, 1, open * 0.92))
