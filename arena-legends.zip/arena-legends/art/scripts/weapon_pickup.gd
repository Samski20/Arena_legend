class_name WeaponPickup
extends Area2D
## Weapon pickup. Ammo and weapons are two separate actions (like Mini Militia):
## - A weapon you already carry: walking over it takes its AMMO. The gun stays on the floor.
##   Each pickup holds a limited ammo supply, and a map pickup refills that supply after a delay.
##   You can ALSO press the pickup key (F) to SWAP: the copy you carry drops (with its ammo) and
##   the one on the floor is equipped (with its ammo), even though they are the same gun.
## - A weapon you DON'T carry: stand next to it and press the pickup key (F) to equip it.
##   If both of your slots are full, the gun in your hand drops on the floor (keeping its type and
##   ammo) and becomes a normal pickup anyone can take. Equipping a map pickup removes it until it respawns.
## Setup: add an Area2D to your arena, attach this script, then drag a weapon
## .tres (rifle.tres, shotgun.tres...) into its Weapon slot. It builds its own
## hitbox and visuals, so the node needs no children.
## Also add an input action named "pickup" (Project Settings > Input Map) bound to F.

@export var weapon: WeaponData
## Optional: fill this with several weapons and the pickup picks one at random
## (and a different one each time it respawns). Leave empty to always use Weapon.
@export var weapon_pool: Array[WeaponData] = []
@export var respawn_time := 12.0
@export var float_height := 11.0     # the gun lies on the floor: this is just half its picture height
## Map guns that nobody takes vanish after this many seconds (they blink at the end), then respawn after Respawn Time.
@export var spawn_lifetime := 40.0
var _age := 0.0                  # seconds this map gun has been lying there

# --- offline match setup (see MatchSession) ---
## Most map guns lying around at once (0 = every spot). Spawn RATE (respawn time) is a separate setting.
static var max_active_cap := 0
var match_off := false           # true = this spot never offers a gun in this match (rate OFF / no guns allowed)

const FLOOR_SCALE := 0.9          # guns on the floor are drawn at 90% of their in-hand size
var _sprite: Sprite2D
var _shape: CollisionShape2D
var _t := 0.0
var _active := true
var _bodies: Array = []        # players standing in range
var _stock := 0.0              # spare bullets on offer to anyone who carries this gun
var _stock_max := 0.0
var _regen := 0.0              # map pickups: seconds until the ammo supply is full again
var _flash := 0.0              # shows "+N AMMO" for a moment after taking ammo
var _flash_text := ""
var _taken := false            # set when someone equipped the weapon this frame
var _prompt_text := ""     # text shown above the weapon ("" = hidden)

# --- dropped weapons: the player creates these when a new gun replaces the one in hand ---
var is_drop := false          # true for a gun the player dropped
var drop_ammo := -1           # bullets left in its magazine when dropped (-1 = full)
var drop_reserve := -1        # spare bullets it had (-1 = full)
@export var drop_lifetime := 30.0   # a dropped gun is cleaned up after this many seconds (blinks for the last 5)
var _landed := false
var _fall_speed := 0.0
var _vx := 0.0
var _delay := 0.0             # short delay so you can't re-grab it in the same instant
var ignore_body: Node = null  # the player who just dropped this: no auto ammo-grab until they step away

# --- network match (see net_match.gd): the HOST owns pickups; clients only show them and send requests ---
var net_id := ""               # "m0".. for map guns, "d12" for dropped guns ("" = offline)
var net_role := 0              # 0 offline, 1 host, 2 client


func _ready() -> void:
	GameSettings.ensure_loaded()
	add_to_group("weapon_pickup")
	add_to_group("quality_aware")             # Settings > Graphics Quality calls apply_quality() on us
	if is_drop:
		_vx = randf_range(-70.0, 70.0)         # tiny sideways toss
		_delay = 0.4

	# hitbox
	_shape = CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 44.0
	_shape.shape = circle
	add_child(_shape)

	# floating weapon picture
	_sprite = Sprite2D.new()
	_sprite.scale = Vector2(FLOOR_SCALE, FLOOR_SCALE)
	add_child(_sprite)
	_roll_weapon()

	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)
	queue_redraw()


# Picks a random weapon from the pool (never the same one twice in a row) and updates the picture.
func _roll_weapon() -> void:
	if not weapon_pool.is_empty():
		var choices: Array = weapon_pool.filter(func(w): return w != null and w != weapon)
		if choices.is_empty():
			choices = weapon_pool.filter(func(w): return w != null)
		if not choices.is_empty():
			weapon = choices.pick_random()
	_apply_weapon_visual()
	_reset_stock()
	queue_redraw()


func _apply_weapon_visual() -> void:
	if weapon != null and weapon.texture != null:
		_sprite.texture = weapon.texture
		_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
		_sprite.scale = Vector2.ONE * FLOOR_SCALE / weapon.art_scale   # hi-res picture, a little smaller than in hand
		_sprite.position.y = -float(weapon.texture.get_height()) / weapon.art_scale * FLOOR_SCALE * 0.5 + 1.0   # lies on the floor


# Sets how much spare ammo this pickup offers: a fresh map gun offers a full reserve, a dropped
# gun offers exactly the spare bullets it had when it was dropped.
func _reset_stock() -> void:
	if weapon == null:
		return
	if is_drop and drop_reserve >= 0:
		_stock_max = float(drop_reserve)
	else:
		_stock_max = float(weapon.reserve_ammo)
	_stock = _stock_max
	_regen = 0.0


func _physics_process(delta: float) -> void:
	# a dropped gun falls until it lands on something solid
	if not is_drop or _landed:
		return
	_fall_speed = minf(_fall_speed + 1500.0 * delta, 1400.0)
	var from := global_position
	var to := from + Vector2(_vx * delta, _fall_speed * delta)
	_vx = move_toward(_vx, 0.0, 500.0 * delta)
	var query := PhysicsRayQueryParameters2D.create(from, to + Vector2(0, 2.0))
	var hit := get_world_2d().direct_space_state.intersect_ray(query)
	if not hit.is_empty() and not (hit.collider is CharacterBody2D):
		global_position = hit.position
		_landed = true
	else:
		global_position = to
		if global_position.y > 6000.0:
			queue_free()                       # fell out of the world


func _process(delta: float) -> void:
	_t += delta

	if is_drop:
		_delay -= delta
		if net_role != 2:                          # a client never times drops out: the host tells it
			drop_lifetime -= delta
			if drop_lifetime <= 0.0:
				if net_role == 1:
					Net.game.host_drop_removed(self)
				queue_free()
				return
			visible = drop_lifetime > 5.0 or int(drop_lifetime * 6.0) % 2 == 0   # blinks before vanishing

	# map guns nobody picks up vanish after a while and come back later (new random gun)
	if not is_drop and _active and net_role != 2:
		_age += delta
		var left := spawn_lifetime - _age
		visible = left > 5.0 or int(left * 6.0) % 2 == 0      # blinks before vanishing
		if left <= 0.0:
			_collect()
			return

	if _flash > 0.0:
		_flash -= delta
	if _regen > 0.0 and not is_drop and net_role != 2:
		_regen -= delta
		if _regen <= 0.0:
			_stock = _stock_max                # the map's ammo supply is full again
			if net_role == 1:
				Net.game.host_pickup_state(self)

	var new_text := ""
	if _active and weapon != null:
		_bodies = _bodies.filter(func(b): return is_instance_valid(b))
		for body in _bodies:
			var text := _serve(body)
			if _taken:
				_collect()
				return
			if new_text == "":
				new_text = text

	if new_text != _prompt_text:
		_prompt_text = new_text
		queue_redraw()


# What one player standing next to this pickup gets. Returns the prompt text to show.
#  - PICK UP (key F / touch button): equips the gun the normal way (the gun in hand is replaced when full).
#  - DUAL WIELD (key Q / touch button): only offered when the player holds a one-handed gun and this one is
#    one-handed too; the gun goes in the other hand.
# Only the pickup closest to the player reacts, so two guns lying together never both jump into your hands.
func _serve(body: Node) -> String:
	var label := weapon.display_name.to_upper()
	var mine: bool = not body.has_method("nearby_pickup") or body.nearby_pickup() == self
	var press_pick: bool = mine and _delay <= 0.0 and InputMap.has_action("pickup") and Input.is_action_just_pressed("pickup")
	var press_dual: bool = mine and _delay <= 0.0 and InputMap.has_action("dual_wield") and Input.is_action_just_pressed("dual_wield")
	var can_dual: bool = body.has_method("can_dual_with") and body.can_dual_with(weapon)

	if net_role == 2:
		return _serve_client(body, label, press_pick, press_dual, can_dual)
	var give_ammo := drop_ammo if is_drop else -1
	var give_reserve := int(_stock) if is_drop else -1       # a dropped gun keeps the ammo it still has

	# ----- carrying this gun already: walking over it takes its ammo, PICK UP swaps the two copies -----
	var text := ""
	if body.has_method("has_weapon") and body.has_weapon(weapon):
		var status := ""
		if body != ignore_body and int(_stock) > 0:
			var got: int = body.add_ammo(weapon, int(_stock))
			if got > 0:
				_stock -= got
				if not is_drop:
					_regen = respawn_time
				_flash = 0.9
				_flash_text = "+%d AMMO" % got
				if net_role == 1:
					Net.game.host_pickup_state(self)
		if _flash > 0.0:
			status = _flash_text
		elif int(_stock) <= 0:
			status = "(NO AMMO LEFT)"
		else:
			status = "(AMMO FULL)"
		if press_dual and can_dual:
			if body.dual_wield_pickup(weapon, give_ammo, give_reserve):
				_taken = true
				return ""
		elif press_pick:
			var swap_ammo := drop_ammo if is_drop else -1
			var swap_reserve := int(_stock) if is_drop else -1
			if body.pickup_weapon(weapon, swap_ammo, swap_reserve):      # swaps with the copy we carry
				_taken = true
		text = "[F]  SWAP %s  %s" % [label, status]
	else:
		# ----- a different gun: PICK UP equips it (the gun in hand drops if both slots are full) -----
		text = "[F]  %s" % label
		var dropped: WeaponData = body.would_drop_for(weapon) if body.has_method("would_drop_for") else null
		if dropped != null:
			text += "  (DROPS %s%s)" % [dropped.display_name.to_upper(), " + OFF-HAND GUN" if body.dual else ""]
		if press_dual and can_dual:
			if body.dual_wield_pickup(weapon, give_ammo, give_reserve):
				_taken = true
				return ""
		elif press_pick:
			if body.pickup_weapon(weapon, give_ammo, give_reserve):
				_taken = true
	if can_dual:
		text += "   [Q]  DUAL WIELD"
	return text


# Medium / High: a soft shadow under the gun so it sits on the floor instead of hovering over it.
func apply_quality() -> void:
	queue_redraw()


func _draw() -> void:
	if GameSettings.quality >= 1 and _sprite != null and weapon != null and weapon.texture != null:
		var rx := float(weapon.texture.get_width()) * absf(_sprite.scale.x) * 0.5 * 0.9
		var pts := PackedVector2Array()
		for i in 16:
			var a := TAU * float(i) / 16.0
			pts.append(Vector2(cos(a) * rx, 2.0 + sin(a) * 4.5))
		draw_colored_polygon(pts, Color(0, 0, 0, 0.20))
		if GameSettings.quality >= 2:                  # High: a darker core makes the contact shadow read better
			var core := PackedVector2Array()
			for p in pts:
				core.append(Vector2(p.x * 0.7, 2.0 + (p.y - 2.0) * 0.6))
			draw_colored_polygon(core, Color(0, 0, 0, 0.16))
	# "[F] SHOTGUN" (or "AMMO FULL") prompt while a player is next to it
	if _prompt_text != "" and weapon != null:
		var font := ThemeDB.fallback_font
		var text := _prompt_text
		var pos := Vector2(-190, -float_height - 36.0)      # wide enough for "[F]  SWAP BARRETT M82  (AMMO FULL)"
		draw_string_outline(font, pos, text, HORIZONTAL_ALIGNMENT_CENTER, 380.0, 18, 6, Color.BLACK)
		draw_string(font, pos, text, HORIZONTAL_ALIGNMENT_CENTER, 380.0, 18, Color.WHITE)


func _on_body_entered(body: Node) -> void:
	if body.has_method("pickup_weapon") and not _bodies.has(body):
		_bodies.append(body)
		if body.has_method("pickup_in_range"):
			body.pickup_in_range(self, true)          # the player's PICK UP / DUAL WIELD buttons key off this


func _on_body_exited(body: Node) -> void:
	_bodies.erase(body)
	if is_instance_valid(body) and body.has_method("pickup_in_range"):
		body.pickup_in_range(self, false)
	if body == ignore_body:
		ignore_body = null


# True while this pickup is lying there and can be taken (the player's buttons use this).
func is_available() -> bool:
	return _active and weapon != null and _delay <= 0.0 and is_inside_tree()


func _leave_all_bodies() -> void:
	for b in _bodies:
		if is_instance_valid(b) and b.has_method("pickup_in_range"):
			b.pickup_in_range(self, false)


func _exit_tree() -> void:
	_leave_all_bodies()


func _collect() -> void:
	_leave_all_bodies()
	if is_drop:
		if net_role == 1:
			Net.game.host_drop_removed(self)
		queue_free()                           # dropped guns don't respawn
		return
	_active = false
	_taken = false
	_bodies.clear()
	_prompt_text = ""
	visible = false
	_shape.set_deferred("disabled", true)
	if net_role == 1:
		Net.game.host_pickup_state(self)

	await get_tree().create_timer(respawn_time).timeout
	await _reactivate_when_allowed()


# Brings the gun back, but never beyond the match's "max weapons on the map" cap and never when OFF.
func _reactivate_when_allowed() -> void:
	while is_inside_tree() and not match_off and max_active_cap > 0 and _count_active() >= max_active_cap:
		await get_tree().create_timer(1.5).timeout
	if not is_inside_tree() or match_off:
		return

	_roll_weapon()                       # new random weapon each respawn (if a pool is set); also refills its ammo
	_age = 0.0
	visible = true
	_shape.set_deferred("disabled", false)
	_active = true
	queue_redraw()
	if net_role == 1:
		Net.game.host_pickup_state(self)


func _count_active() -> int:
	var n := 0
	for p in get_tree().get_nodes_in_group("weapon_pickup"):
		if p is WeaponPickup and (p as WeaponPickup)._active and not (p as WeaponPickup).is_drop:
			n += 1
	return n


# Offline match setup. pool = the allowed guns (already filtered), respawn_scale multiplies respawn_time,
# start_hidden = this spot waits because the "max guns on the map" cap is already used up.
func configure_match(pool: Array[WeaponData], respawn_scale: float, enabled: bool, start_hidden: bool) -> void:
	if is_drop:
		return
	if not enabled:
		match_off = true
		_hide_for_match()
		return
	match_off = false
	weapon_pool = pool
	weapon = null
	if respawn_scale > 0.0:
		respawn_time = maxf(respawn_time * respawn_scale, 3.0)
	_roll_weapon()
	if start_hidden:
		_hide_for_match()
		await get_tree().create_timer(respawn_time).timeout
		await _reactivate_when_allowed()


func _hide_for_match() -> void:
	_leave_all_bodies()
	_active = false
	_taken = false
	_bodies.clear()
	_prompt_text = ""
	visible = false
	if _shape != null:
		_shape.set_deferred("disabled", true)


# ======================= network match =======================
# CLIENT: same prompt text as _serve(), but the actions are REQUESTS to the host (which owns the pickup).
func _serve_client(body: Node, label: String, press_pick: bool, press_dual: bool, can_dual: bool) -> String:
	var text := ""
	if body.has_method("has_weapon") and body.has_weapon(weapon):
		var status := ""
		if body != ignore_body and int(_stock) > 0:
			var room: int = body.ammo_room(weapon)
			if room > 0:
				Net.game.client_ammo_request(self, mini(room, int(_stock)))
		status = "(NO AMMO LEFT)" if int(_stock) <= 0 else "(AMMO FULL)"
		if press_dual and can_dual:
			Net.game.client_pickup_request(self, "dual")
		elif press_pick:
			Net.game.client_pickup_request(self, "pick")
		text = "[F]  SWAP %s  %s" % [label, status]
	else:
		text = "[F]  %s" % label
		var dropped: WeaponData = body.would_drop_for(weapon) if body.has_method("would_drop_for") else null
		if dropped != null:
			text += "  (DROPS %s%s)" % [dropped.display_name.to_upper(), " + OFF-HAND GUN" if body.dual else ""]
		if press_dual and can_dual:
			Net.game.client_pickup_request(self, "dual")
		elif press_pick:
			Net.game.client_pickup_request(self, "pick")
	if can_dual:
		text += "   [Q]  DUAL WIELD"
	return text


# The host's view of this pickup, applied on a client (and used for the initial sync).
func net_set_state(w: WeaponData, stock: int, active: bool) -> void:
	if w != null and w != weapon:
		weapon = w
		_apply_weapon_visual()
	_stock = float(stock)
	_stock_max = maxf(_stock_max, _stock)
	if active and not _active:
		_active = true
		visible = true
		_shape.set_deferred("disabled", false)
	elif not active and _active:
		_leave_all_bodies()
		_active = false
		_bodies.clear()
		_prompt_text = ""
		visible = false
		_shape.set_deferred("disabled", true)
	queue_redraw()


# HOST: a validated client request took this pickup.
func net_take() -> void:
	_collect()


# HOST: a validated client request took `amount` spare bullets from it.
func net_give_ammo(amount: int) -> void:
	_stock -= amount
	if not is_drop:
		_regen = respawn_time
	Net.game.host_pickup_state(self)


func net_free() -> void:
	_leave_all_bodies()
	queue_free()
