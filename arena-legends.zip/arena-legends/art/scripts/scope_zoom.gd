class_name ScopeZoom
extends Node
## Sniper-style scope zoom for the player's camera. Reusable: it only reads the held weapon's
## "Scope" settings (zoom_steps, zoom_look_ahead), so any weapon can get a scope from the Inspector.
##
## Works like Mini Militia: one click pulls the camera BACK so you see much more of the map.
## CONTROLS (weapons that have zoom_steps only)
##   Right-click         -> next zoom step; with one step it simply toggles scope on / off
##   Mouse wheel up/down -> step further / back
##   Switching weapon, or dying, drops you back to the normal view.
##
## While scoped the camera also drifts a little toward your cursor, so you see further the way you aim.
## Your aim stays exact because the mouse position is converted by the same camera.
## zoom below 1 = zoomed out (sees farther). zoom above 1 = magnified (a classic scope).
##
## It never touches movement, shooting or physics; it only sets Camera2D.zoom and Camera2D.offset.

const SMOOTH := 9.0

var _player: Node
var _cam: Camera2D
var _weapon: WeaponData = null
var _step := 0                      # 0 = normal view, 1.. = index + 1 into the weapon's zoom_steps
var _zoom := 1.0
var _look := Vector2.ZERO
var _label: Label


static func attach(player: Node) -> void:
	if player == null or player.get_node_or_null("ScopeZoom") != null:
		return
	var z := ScopeZoom.new()
	z.name = "ScopeZoom"
	player.add_child(z)


func _ready() -> void:
	_player = get_parent()
	for c in _player.find_children("*", "Camera2D", true, false):
		_cam = c as Camera2D
		break
	if _cam == null:
		push_warning("ScopeZoom: the player has no Camera2D, scope zoom is off.")
		set_process(false)
		set_process_unhandled_input(false)
		return
	var layer := CanvasLayer.new()
	layer.layer = 5
	add_child(layer)
	_label = Label.new()
	_label.anchor_left = 0.5
	_label.anchor_right = 0.5
	_label.anchor_top = 1.0
	_label.anchor_bottom = 1.0
	_label.offset_left = -100.0
	_label.offset_right = 100.0
	_label.offset_top = -110.0
	_label.offset_bottom = -80.0
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.add_theme_font_size_override("font_size", 18)
	_label.modulate = Color(0.7, 1.0, 0.95, 0.0)
	layer.add_child(_label)


func _steps() -> PackedFloat32Array:
	var w = _player.get("weapon")
	if w is WeaponData:
		return (w as WeaponData).zoom_steps
	return PackedFloat32Array()


func _unhandled_input(event: InputEvent) -> void:
	var steps := _steps()
	if steps.is_empty():
		return
	if event.is_action_pressed("zoom"):
		_step = (_step + 1) % (steps.size() + 1)
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			_step = mini(_step + 1, steps.size())
			get_viewport().set_input_as_handled()
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_step = maxi(_step - 1, 0)
			get_viewport().set_input_as_handled()


func _process(delta: float) -> void:
	var w = _player.get("weapon")
	var steps := PackedFloat32Array()
	var reach_max := 0.0
	if w is WeaponData:
		steps = (w as WeaponData).zoom_steps
		reach_max = (w as WeaponData).zoom_look_ahead
	if w != _weapon:
		_weapon = w as WeaponData
		_step = 0                                   # a different gun starts unzoomed
	if (_player.get("is_dead") == true):
		_step = 0
	_step = mini(_step, steps.size())

	var target := 1.0 if _step == 0 else steps[_step - 1]
	var look_target := Vector2.ZERO
	if _step > 0:
		var strongest := 0.0                         # biggest zoom change among this weapon's steps
		for st in steps:
			strongest = maxf(strongest, absf(log(st)))
		var vp := get_viewport()
		var half := vp.get_visible_rect().size * 0.5
		var from_centre := vp.get_mouse_position() - half
		var reach := reach_max * (absf(log(target)) / maxf(strongest, 0.001))   # stronger step reaches farther
		look_target = (from_centre / half.x * reach).limit_length(reach)

	var k := 1.0 - exp(-SMOOTH * delta)
	_zoom = lerpf(_zoom, target, k)
	_look = _look.lerp(look_target, k)
	_cam.zoom = Vector2(_zoom, _zoom)
	_cam.offset = _look

	if _label:
		var view := 1.0 / target if target < 1.0 else target      # "2.0x" = twice as far (or magnified)
		_label.text = "SCOPE  %sx" % String.num(view, 1)
		var a := lerpf(_label.modulate.a, 0.85 if _step > 0 else 0.0, k)
		_label.modulate.a = a
