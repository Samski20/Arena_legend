extends RefCounted
## Bot difficulty levels. ONE place to tune how tough the bots are.
## The level is saved in GameSettings.bot_difficulty and picked in the MENU (map menu > BOT DIFFICULTY).
## bot.gd asks BotDifficulty.profile() for the numbers below, so to rebalance a level just edit its row.
##
##   hp / speed   multiply the bot's max health and walking speed
##   aim          multiplies aim error (smaller = deadlier aim)
##   fire         multiplies the time between shots (smaller = shoots faster)
##   shield       true = bot crouches behind its energy shield (blocks 80% of hits from the front, like you)
##   carry        how many throwables the bot spawns with (0 = never throws)
##   throw_cd     [min, max] seconds between throws
##   guns         0 = always the default rifle, 1 = random gun (no sniper / RPG), 2 = ANY gun in the catalog
##
## Every level: a killed bot drops the gun it holds (with some ammo) and any throwables it had left.

const ROOKIE := 0
const NORMAL := 1
const VETERAN := 2
const LEGEND := 3

const NAMES := ["ROOKIE", "NORMAL", "VETERAN", "LEGEND"]
const DESCRIPTIONS := [
	"Slow, weak aim, lower health.",
	"The original bots.",
	"Better aim, random guns, uses its shield, throws a bomb now and then.",
	"MAX: deadly aim, any gun, shield + crouch, throws a mix of bombs, extra health.",
]

const PROFILES := [
	{"hp": 0.8, "speed": 0.9, "aim": 1.6, "fire": 1.3, "shield": false, "carry": 0, "throw_cd": [8.0, 12.0], "guns": 0},
	{"hp": 1.0, "speed": 1.0, "aim": 1.0, "fire": 1.0, "shield": false, "carry": 0, "throw_cd": [8.0, 12.0], "guns": 0},
	{"hp": 1.2, "speed": 1.08, "aim": 0.6, "fire": 0.8, "shield": true, "carry": 1, "throw_cd": [6.0, 10.0], "guns": 1},
	{"hp": 1.5, "speed": 1.2, "aim": 0.3, "fire": 0.65, "shield": true, "carry": 3, "throw_cd": [3.0, 6.0], "guns": 2},
]

# throwables a bot never uses: the mine would blow up its own owner, the decoy / portal need the player's logic
const BOT_BANNED_THROWABLES := ["trap_mine", "decoy", "portal"]


## A match setup can force a level for ONE match without touching the saved setting (-1 = use the saved one).
static var override_level := -1


static func level() -> int:
	if override_level >= 0:
		return clampi(override_level, 0, NAMES.size() - 1)
	return clampi(GameSettings.bot_difficulty, 0, NAMES.size() - 1)


static func profile() -> Dictionary:
	return PROFILES[level()]


static func level_name() -> String:
	return NAMES[level()]


static func description() -> String:
	return DESCRIPTIONS[level()]


# A random gun for a bot at this level (null = keep the default rifle).
static func pick_weapon(guns_mode: int) -> WeaponData:
	if guns_mode <= 0:
		return null
	var pool: Array[WeaponData] = []
	for w in WeaponCatalog.all():
		if guns_mode == 1 and (w.category == "Sniper Rifle" or w.category == "Launcher"):
			continue
		pool.append(w)
	if pool.is_empty():
		return null
	return pool.pick_random()


# A weighted random throwable that bots are allowed to carry on this map.
static func pick_throwable(map_id: String) -> ThrowableData:
	var pool: Array[ThrowableData] = []
	var total := 0.0
	for d in ThrowableCatalog.for_map(map_id):
		if BOT_BANNED_THROWABLES.has(d.catalog_id):
			continue
		pool.append(d)
		total += maxf(d.spawn_weight, 0.01)
	if pool.is_empty():
		return null
	var roll := randf() * total
	for d in pool:
		roll -= maxf(d.spawn_weight, 0.01)
		if roll <= 0.0:
			return d
	return pool.back()


# Launch velocity for a lobbed bomb that lands near `to` (physics: gravity g, straight-line flight, low arc).
# err_rad = random error added to the throw angle (smaller = more accurate).
static func throw_velocity(from: Vector2, to: Vector2, max_speed: float, g: float, err_rad: float) -> Vector2:
	var dx := to.x - from.x
	var dy := -(to.y - from.y)                       # up is positive here
	var ax := maxf(absf(dx), 1.0)
	var sgn := 1.0 if dx >= 0.0 else -1.0
	var v := clampf(sqrt(maxf(ax, 60.0) * g) * 1.15, 250.0, max_speed)
	for _attempt in 2:
		var disc := v * v * v * v - g * (g * ax * ax + 2.0 * dy * v * v)
		if disc >= 0.0:
			var ang := atan((v * v - sqrt(disc)) / (g * ax))
			var dir := Vector2(sgn * cos(ang), -sin(ang))
			return dir.rotated(randf_range(-err_rad, err_rad) * sgn) * v
		v = max_speed                                   # too far for that speed: throw as hard as possible
	return Vector2(sgn, -1.0).normalized() * max_speed
