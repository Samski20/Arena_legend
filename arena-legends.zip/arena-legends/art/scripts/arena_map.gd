extends Node2D
## Builds the whole arena from code: ground, platforms, ramps, invisible
## boundary walls, a sky background and camera limits.
## Setup: add a Node2D to your arena scene, name it ArenaMap, attach this script.
## To change the layout, just edit the platform and ramp lists below.

@export var world_size := Vector2(3200, 1600)   # ground top is at y = 1500

# Solid platforms: Rect2(x, y, width, height). The first one is the ground.
var platforms: Array[Rect2] = [
	Rect2(0, 1500, 3200, 200),      # ground
	Rect2(1450, 1330, 300, 170),    # center block
	Rect2(350, 1260, 500, 36),      # low left
	Rect2(2350, 1260, 500, 36),     # low right
	Rect2(1250, 1130, 700, 36),     # low middle
	Rect2(750, 960, 420, 36),       # mid left
	Rect2(2030, 960, 420, 36),      # mid right
	Rect2(120, 760, 360, 36),       # high left
	Rect2(2720, 760, 360, 36),      # high right
	Rect2(1300, 720, 600, 36),      # top middle
]

# Ramps (triangles). Points 1 and 2 must be the sloped top edge.
var ramps: Array[PackedVector2Array] = [
	PackedVector2Array([Vector2(0, 1500), Vector2(380, 1500), Vector2(0, 1290)]),
	PackedVector2Array([Vector2(3200, 1500), Vector2(2820, 1500), Vector2(3200, 1290)]),
]

const DIRT := Color("7a5233")
const DIRT_DARK := Color("5a3a22")
const GRASS := Color("62b53c")
const OUTLINE := Color("2b2b3a")

var _body: StaticBody2D


func _ready() -> void:
	z_index = -10                       # always draw behind characters
	_body = StaticBody2D.new()
	add_child(_body)

	for r in platforms:
		_add_rect(r)
	for pts in ramps:
		var poly := CollisionPolygon2D.new()
		poly.polygon = pts
		_body.add_child(poly)

	# invisible walls and ceiling so nobody leaves the arena
	_add_rect(Rect2(-100, -500, 100, world_size.y + 900))
	_add_rect(Rect2(world_size.x, -500, 100, world_size.y + 900))
	_add_rect(Rect2(-100, -500, world_size.x + 200, 100))

	# keep the camera inside the arena
	var cam := get_tree().current_scene.find_child("Camera2D", true, false) as Camera2D
	if cam:
		cam.limit_left = 0
		cam.limit_right = int(world_size.x)
		cam.limit_top = -400
		cam.limit_bottom = int(world_size.y) + 100

	queue_redraw()


func _add_rect(r: Rect2) -> void:
	var shape := CollisionShape2D.new()
	var rs := RectangleShape2D.new()
	rs.size = r.size
	shape.shape = rs
	shape.position = r.position + r.size / 2.0
	_body.add_child(shape)


func _draw() -> void:
	# ----- sky: vertical gradient built from bands -----
	var top := Color("4aa3df")
	var bottom := Color("c8ecf7")
	var bands := 24
	var y0 := -500.0
	var total := world_size.y + 700.0
	for i in bands:
		var band_color := top.lerp(bottom, float(i) / (bands - 1))
		draw_rect(Rect2(-200, y0 + total * i / bands, world_size.x + 400, total / bands + 2.0), band_color)

	# ----- soft clouds -----
	var clouds := [Vector2(300, 250), Vector2(1100, 120), Vector2(1900, 300), Vector2(2700, 180), Vector2(1500, 500)]
	for c in clouds:
		for off in [Vector2(-50, 10), Vector2(0, -12), Vector2(55, 8), Vector2(0, 14)]:
			draw_circle(c + off, 46.0, Color(1, 1, 1, 0.55))

	# ----- platforms: dirt body, grass top, dark outline -----
	for r in platforms:
		draw_rect(r, DIRT)
		draw_rect(Rect2(r.position.x, r.end.y - minf(r.size.y, 16.0), r.size.x, minf(r.size.y, 16.0)), DIRT_DARK)
		draw_rect(Rect2(r.position.x, r.position.y, r.size.x, 12.0), GRASS)
		draw_rect(r, OUTLINE, false, 3.0)

	# ----- ramps -----
	for pts in ramps:
		draw_colored_polygon(pts, DIRT)
		draw_line(pts[1], pts[2], GRASS, 10.0)
		draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[0]]), OUTLINE, 3.0)
