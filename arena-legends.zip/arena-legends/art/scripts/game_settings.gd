class_name GameSettings
extends RefCounted
## Player settings that are saved between sessions (user://settings.cfg).
## Static, so any script can read them: GameSettings.fixed_sticks, GameSettings.stick_scale ...
## The settings menu (settings_menu.gd) edits them and calls save().

const PATH := "user://settings.cfg"

const DEFAULTS := {
	"fixed_sticks": true,     # sticks stay on screen at a fixed spot (false = they appear where you touch)
	"stick_scale": 1.0,       # size of both sticks
	"button_scale": 1.0,      # size of the round buttons and the weapon box
	"opacity": 1.0,           # how see-through the whole touch UI is
	"deadzone": 0.14,         # centre of the stick that is ignored
	"show_labels": true,      # RUN / FLY and AIM / FIRE text under the sticks
}

static var fixed_sticks: bool = DEFAULTS["fixed_sticks"]
static var stick_scale: float = DEFAULTS["stick_scale"]
static var button_scale: float = DEFAULTS["button_scale"]
static var opacity: float = DEFAULTS["opacity"]
static var deadzone: float = DEFAULTS["deadzone"]
static var show_labels: bool = DEFAULTS["show_labels"]
## Not a touch setting (so RESET leaves it alone): shows an FPS counter in the corner.
static var show_fps: bool = false
## Settings > Start with Maximum Weapon Zoom (OFF by default): equipping a weapon starts at its farthest allowed view
## instead of its default / last used zoom. Not a touch setting, so RESET leaves it alone.
static var max_weapon_zoom: bool = false
## Settings > Laser Sight: a red aiming laser on your gun (ON by default).
static var laser_sight: bool = true
## RESOLUTION QUALITY (Settings > Resolution): true = FAST (the game is drawn at the project's base size, about
## 648 px tall, and stretched to the screen: much cheaper on the GPU, a little softer); false = SHARP (drawn at
## the screen's full resolution). Phones start on FAST, PC on SHARP. This only changes how many pixels are drawn.
static var fast_resolution: bool = OS.has_feature("mobile") or OS.has_feature("web_android") or OS.has_feature("web_ios")
## GRAPHICS QUALITY (Settings > Graphics Quality): how much detail is drawn. 0 = Low (the original lightweight
## look), 1 = Medium, 2 = High (everything the maps can show). Independent of the resolution setting above.
## Phones start on Low, PC on High. Not a touch setting, so RESET leaves both alone.
static var quality: int = 0 if (OS.has_feature("mobile") or OS.has_feature("web_android") or OS.has_feature("web_ios")) else 2
static var _orig_scale_mode := -1
## BOT DIFFICULTY (map menu > BOT DIFFICULTY): 0 ROOKIE, 1 NORMAL, 2 VETERAN, 3 LEGEND (max). See bot_difficulty.gd.
## Not a touch setting, so RESET leaves it alone.
static var bot_difficulty: int = 1
## Settings > Haptics: short vibrations on taps, shots, hits and kills (phones only). Not a touch setting, so RESET leaves it alone.
static var haptics: bool = true
## Settings > Sound / Music volume (0..1). Applied by the AudioMgr autoload. Not touch settings, so RESET leaves them alone.
static var sfx_volume: float = 1.0
static var music_volume: float = 0.6

## Moved controls: id ("stick_l", "stick_r", "hover", "flip", "throw", ...) -> Vector2 offset in pixels
## from the default spot. Edited with the layout editor (settings > EDIT LAYOUT).
static var offsets: Dictionary = {}
## Per-button size multipliers (id -> float, 1.0 = normal), also set in the layout editor.
static var sizes: Dictionary = {}     # (the two sticks are in here too: "stick_l", "stick_r", each with its own value)
## Per-control opacity multipliers (id -> float 0.25..1.0, 1.0 = no extra fade), set in the layout editor.
## Each control has its own entry; the global "opacity" setting above still fades everything on top of it.
static var opacities: Dictionary = {}

static var _loaded := false


# Read / write a setting by name (the settings menu uses these).
static func get_value(key: String) -> float:
	match key:
		"stick_scale": return stick_scale
		"button_scale": return button_scale
		"opacity": return opacity
		"deadzone": return deadzone
		"sfx_volume": return sfx_volume
		"music_volume": return music_volume
	return 0.0


static func set_value(key: String, v: float) -> void:
	match key:
		"stick_scale": stick_scale = v
		"button_scale": button_scale = v
		"opacity": opacity = v
		"deadzone": deadzone = v
		"sfx_volume": sfx_volume = v
		"music_volume": music_volume = v


# Applies the Resolution setting to the game window right now (call after changing it, and once at start-up).
static func apply_resolution() -> void:
	var loop := Engine.get_main_loop()
	if not (loop is SceneTree):
		return
	var win: Window = (loop as SceneTree).root
	if fast_resolution:
		if win.content_scale_mode != Window.CONTENT_SCALE_MODE_VIEWPORT:
			_orig_scale_mode = win.content_scale_mode
			win.content_scale_mode = Window.CONTENT_SCALE_MODE_VIEWPORT
	elif _orig_scale_mode != -1:
		win.content_scale_mode = _orig_scale_mode as Window.ContentScaleMode
		_orig_scale_mode = -1


static func quality_name() -> String:
	return ["LOW", "MEDIUM", "HIGH"][clampi(quality, 0, 2)]


# Tells every map / pickup that listens (group "quality_aware") to redraw at the new graphics quality, live.
static func apply_quality() -> void:
	var loop := Engine.get_main_loop()
	if loop is SceneTree:
		(loop as SceneTree).call_group("quality_aware", "apply_quality")


static func ensure_loaded() -> void:
	if _loaded:
		return
	_loaded = true
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	fixed_sticks = bool(cfg.get_value("touch", "fixed_sticks", fixed_sticks))
	stick_scale = clampf(float(cfg.get_value("touch", "stick_scale", stick_scale)), 0.6, 1.6)
	button_scale = clampf(float(cfg.get_value("touch", "button_scale", button_scale)), 0.6, 1.5)
	opacity = clampf(float(cfg.get_value("touch", "opacity", opacity)), 0.25, 1.0)
	deadzone = clampf(float(cfg.get_value("touch", "deadzone", deadzone)), 0.0, 0.4)
	show_labels = bool(cfg.get_value("touch", "show_labels", show_labels))
	show_fps = bool(cfg.get_value("display", "show_fps", show_fps))
	max_weapon_zoom = bool(cfg.get_value("camera", "max_weapon_zoom", max_weapon_zoom))
	laser_sight = bool(cfg.get_value("camera", "laser_sight", laser_sight))
	# "fast_graphics" is the old name of the resolution setting; keep honouring saves made with it
	fast_resolution = bool(cfg.get_value("display", "fast_resolution", cfg.get_value("display", "fast_graphics", fast_resolution)))
	quality = clampi(int(cfg.get_value("display", "quality", quality)), 0, 2)
	bot_difficulty = clampi(int(cfg.get_value("game", "bot_difficulty", bot_difficulty)), 0, 3)
	haptics = bool(cfg.get_value("game", "haptics", haptics))
	sfx_volume = clampf(float(cfg.get_value("audio", "sfx_volume", sfx_volume)), 0.0, 1.0)
	music_volume = clampf(float(cfg.get_value("audio", "music_volume", music_volume)), 0.0, 1.0)
	var saved_sizes: Variant = cfg.get_value("layout", "sizes", {})
	sizes = {}
	if saved_sizes is Dictionary:
		for k in saved_sizes:
			sizes[String(k)] = clampf(float(saved_sizes[k]), 0.5, 2.0)
	var saved_ops: Variant = cfg.get_value("layout", "opacities", {})
	opacities = {}
	if saved_ops is Dictionary:
		for k in saved_ops:
			opacities[String(k)] = clampf(float(saved_ops[k]), 0.25, 1.0)
	var saved: Variant = cfg.get_value("layout", "offsets", {})
	offsets = {}
	if saved is Dictionary:
		for k in saved:
			if saved[k] is Vector2:
				offsets[String(k)] = saved[k]


static func save() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("touch", "fixed_sticks", fixed_sticks)
	cfg.set_value("touch", "stick_scale", stick_scale)
	cfg.set_value("touch", "button_scale", button_scale)
	cfg.set_value("touch", "opacity", opacity)
	cfg.set_value("touch", "deadzone", deadzone)
	cfg.set_value("touch", "show_labels", show_labels)
	cfg.set_value("display", "show_fps", show_fps)
	cfg.set_value("camera", "max_weapon_zoom", max_weapon_zoom)
	cfg.set_value("camera", "laser_sight", laser_sight)
	cfg.set_value("display", "fast_resolution", fast_resolution)
	cfg.set_value("display", "quality", quality)
	cfg.set_value("game", "bot_difficulty", bot_difficulty)
	cfg.set_value("game", "haptics", haptics)
	cfg.set_value("audio", "sfx_volume", sfx_volume)
	cfg.set_value("audio", "music_volume", music_volume)
	cfg.set_value("layout", "offsets", offsets)
	cfg.set_value("layout", "sizes", sizes)
	cfg.set_value("layout", "opacities", opacities)
	cfg.save(PATH)


static func reset_touch() -> void:
	fixed_sticks = DEFAULTS["fixed_sticks"]
	stick_scale = DEFAULTS["stick_scale"]
	button_scale = DEFAULTS["button_scale"]
	opacity = DEFAULTS["opacity"]
	deadzone = DEFAULTS["deadzone"]
	show_labels = DEFAULTS["show_labels"]
	offsets = {}
	sizes = {}
	opacities = {}
	save()
