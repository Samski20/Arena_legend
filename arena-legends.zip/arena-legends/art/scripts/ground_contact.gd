class_name GroundContact
extends Node2D
## Makes a character feel planted on the ground. It is added automatically by PlayerRig, so
## the player and every bot get it.
##   * soft contact shadow that follows the ground slope and fades as you rise
##   * dust puffs + debris on every footstep and a bigger burst + shock ring when landing
##   * procedural footstep / landing sounds that change with the surface (grass, stone, wood,
##     metal, water); the map says which surface is where through surface_kind_at(point)
##   * jetpack downwash kicks up dust when you hover close to the ground
##   * camera thump on hard landings (player only)
##   * the boots are dropped a couple of pixels so they sit IN the floor instead of hovering
## Everything is visual / audio only; it never touches movement or physics.

const FOOT_DROP := 2.5                 # pixels the whole rig is lowered (tweak if boots float or sink)
const SHADOW_FADE_HEIGHT := 320.0
const IMPACT_TIME := 0.38
const SAMPLE_RATE := 22050

# dust = puff colour, bits = chips / blades / droplets colour
const SURFACES := {
	"grass": {"dust": Color(0.46, 0.41, 0.29, 0.50), "bits": Color(0.30, 0.45, 0.20, 1.0)},
	"stone": {"dust": Color(0.62, 0.60, 0.55, 0.45), "bits": Color(0.56, 0.56, 0.52, 1.0)},
	"wood": {"dust": Color(0.52, 0.41, 0.29, 0.32), "bits": Color(0.46, 0.33, 0.21, 1.0)},
	"metal": {"dust": Color(0.52, 0.52, 0.55, 0.26), "bits": Color(0.72, 0.72, 0.76, 1.0)},
	"water": {"dust": Color(0.72, 0.86, 0.94, 0.50), "bits": Color(0.78, 0.90, 0.98, 1.0)},
}

# sound recipe per surface: thump pitch/decay/amount, noise brightness/decay/amount, click pitch/amount
const SOUNDS := {
	"grass": {"f0": 62.0, "td": 34.0, "ta": 0.55, "nlp": 0.16, "nd": 38.0, "na": 1.10, "cf": 0.0, "ca": 0.0},
	"stone": {"f0": 95.0, "td": 45.0, "ta": 0.60, "nlp": 0.55, "nd": 60.0, "na": 0.90, "cf": 2200.0, "ca": 0.25},
	"wood": {"f0": 120.0, "td": 38.0, "ta": 0.80, "nlp": 0.30, "nd": 48.0, "na": 0.55, "cf": 900.0, "ca": 0.12},
	"metal": {"f0": 190.0, "td": 28.0, "ta": 0.50, "nlp": 0.85, "nd": 42.0, "na": 0.70, "cf": 3100.0, "ca": 0.35},
	"water": {"f0": 90.0, "td": 24.0, "ta": 0.30, "nlp": 0.35, "nd": 16.0, "na": 1.00, "cf": 0.0, "ca": 0.0},
}

static var _sound_cache := {}

var body: CharacterBody2D
var vis: Node2D

var _has_ground := false
var _gpos := Vector2.ZERO
var _gnormal := Vector2.UP
var _height := 0.0
var _collider: Object = null

var _step_dust: CPUParticles2D
var _land_dust: CPUParticles2D
var _bits: CPUParticles2D
var _step_audio: AudioStreamPlayer2D
var _land_audio: AudioStreamPlayer2D

var _step_cd := 0.0
var _jet_cd := 0.0
var _impact_age := 99.0
var _impact_k := 0.0
var _impact_color := Color(1, 1, 1, 0.4)
var _shake := 0.0
var _cam: Camera2D
var _is_player := false


static func attach(rig: Node2D) -> void:
	var host := rig.get_parent() as CharacterBody2D
	if host == null or host.get_node_or_null("GroundContact") != null:
		return
	var gc := GroundContact.new()
	gc.name = "GroundContact"
	gc.body = host
	gc.vis = rig
	host.add_child.call_deferred(gc)      # deferred: the parent may still be setting up its children


func _ready() -> void:
	if body == null or vis == null:
		queue_free()
		return
	top_level = true
	z_index = -1
	_is_player = body.is_in_group("player")
	if _is_player:
		_cam = body.get_node_or_null("Camera2D") as Camera2D
	vis.position.y += FOOT_DROP
	if vis.has_signal("footstep"):
		vis.connect("footstep", _on_footstep)
	if vis.has_signal("landed"):
		vis.connect("landed", _on_landed)

	_step_dust = _make_puffs(5, 0.55, 26.0, 62.0, 60.0, 0.07, 0.13, Vector2(0, -20), 55.0)
	_land_dust = _make_puffs(14, 0.85, 70.0, 150.0, 88.0, 0.14, 0.26, Vector2(0, -10), 150.0)
	_bits = _make_bits()
	_step_audio = _make_audio(-15.0)
	_land_audio = _make_audio(-9.0)


# ---------- building the effect nodes ----------

func _make_puffs(amount: int, life: float, vmin: float, vmax: float, spread: float, smin: float, smax: float,
		grav: Vector2, damp: float) -> CPUParticles2D:
	var p := CPUParticles2D.new()
	p.local_coords = false
	p.one_shot = true
	p.emitting = false
	p.explosiveness = 0.95
	p.amount = amount
	p.lifetime = life
	p.direction = Vector2(0, -1)
	p.spread = spread
	p.initial_velocity_min = vmin
	p.initial_velocity_max = vmax
	p.gravity = grav
	p.damping_min = damp * 0.7
	p.damping_max = damp
	p.angle_max = 360.0
	p.scale_amount_min = smin
	p.scale_amount_max = smax
	p.set_meta("v", Vector2(vmin, vmax))
	p.set_meta("s", Vector2(smin, smax))
	var tex := FXArt.pick("puff", 4)
	if tex != null:
		p.texture = tex
	var grow := Curve.new()
	grow.add_point(Vector2(0.0, 0.55))
	grow.add_point(Vector2(1.0, 1.7))
	p.scale_amount_curve = grow
	var ramp := Gradient.new()
	ramp.offsets = PackedFloat32Array([0.0, 0.2, 1.0])
	ramp.colors = PackedColorArray([Color(1, 1, 1, 0.0), Color(1, 1, 1, 0.9), Color(1, 1, 1, 0.0)])
	p.color_ramp = ramp
	add_child(p)
	return p


func _make_bits() -> CPUParticles2D:
	var p := CPUParticles2D.new()
	p.local_coords = false
	p.one_shot = true
	p.emitting = false
	p.explosiveness = 1.0
	p.amount = 6
	p.lifetime = 0.6
	p.direction = Vector2(0, -1)
	p.spread = 75.0
	p.initial_velocity_min = 70.0
	p.initial_velocity_max = 170.0
	p.gravity = Vector2(0, 900)
	p.angle_max = 360.0
	p.angular_velocity_min = -400.0
	p.angular_velocity_max = 400.0
	p.scale_amount_min = 0.05
	p.scale_amount_max = 0.09
	var tex := FXArt.pick("shard", 3)
	if tex != null:
		p.texture = tex
	var ramp := Gradient.new()
	ramp.offsets = PackedFloat32Array([0.0, 0.7, 1.0])
	ramp.colors = PackedColorArray([Color(1, 1, 1, 1.0), Color(1, 1, 1, 0.9), Color(1, 1, 1, 0.0)])
	p.color_ramp = ramp
	add_child(p)
	return p


func _make_audio(volume: float) -> AudioStreamPlayer2D:
	var a := AudioStreamPlayer2D.new()
	a.volume_db = volume
	a.max_distance = 1200.0
	a.attenuation = 1.6
	add_child(a)
	return a


# ---------- every physics frame: where is the ground? ----------

func _physics_process(delta: float) -> void:
	if body == null or not is_instance_valid(body):
		return
	_step_cd = maxf(0.0, _step_cd - delta)
	_jet_cd = maxf(0.0, _jet_cd - delta)
	var hit := _probe(body.global_position.x)
	if hit.is_empty():
		_has_ground = false
	else:
		_has_ground = true
		_gpos = hit["position"]
		_gnormal = hit["normal"]
		_collider = hit["collider"]
		_height = maxf(0.0, _gpos.y - (body.global_position.y + 24.0))
	global_position = _gpos if _has_ground else body.global_position
	rotation = _gnormal.angle() + PI * 0.5 if _has_ground else 0.0

	# jetpack downwash kicks up dust while hovering low
	if _has_ground and _height < 150.0 and _jet_cd <= 0.0 and _is_jetting():
		_jet_cd = 0.09
		var spot := _gpos + Vector2(randf_range(-16.0, 16.0), 0.0)
		_burst(_step_dust, spot, _surface_now(), 1.0)


func _flag(prop: StringName) -> bool:
	if body == null:
		return false
	var v: Variant = body.get(prop)
	return v != null and bool(v)


func _is_jetting() -> bool:
	return _flag("jetpack_active") or _flag("_jetting")


func _probe(x: float) -> Dictionary:
	var space := body.get_world_2d().direct_space_state
	var excluded: Array[RID] = [body.get_rid()]
	var from := Vector2(x, body.global_position.y - 4.0)
	for i in 4:
		var q := PhysicsRayQueryParameters2D.create(from, from + Vector2(0.0, 700.0))
		q.exclude = excluded
		var hit := space.intersect_ray(q)
		if hit.is_empty():
			return {}
		var col = hit["collider"]
		if col is StaticBody2D or col is TileMapLayer:
			return hit
		excluded.append(hit["rid"])           # another character: look through it
	return {}


func _surface_at(p: Vector2, collider: Object) -> String:
	if collider != null and is_instance_valid(collider) and collider is Node and (collider as Node).has_meta("surface"):
		return String((collider as Node).get_meta("surface"))
	for n in get_tree().get_nodes_in_group("surface_provider"):
		if n.has_method("surface_kind_at"):
			return String(n.call("surface_kind_at", p))
	return "metal"


func _surface_now() -> String:
	return _surface_at(_gpos, _collider)


# ---------- events from the rig ----------

func _on_footstep(boot: Node2D, power: float) -> void:
	if not _has_ground or _step_cd > 0.0 or _height > 14.0:
		return
	_step_cd = 0.11
	var at := _gpos
	var surf := _surface_now()
	var hit := _probe(boot.global_position.x)
	if not hit.is_empty():
		at = hit["position"]
		surf = _surface_at(at, hit["collider"])
	if power > 0.5:
		_burst(_step_dust, at, surf, power)
		if surf == "grass" or surf == "water":
			_burst(_bits, at, surf, power * 0.5)
	_play(_step_audio, surf, false, power)


func _on_landed(strength: float) -> void:
	if not _has_ground or strength < 0.12:
		return
	strength = clampf(strength, 0.0, 1.5)
	var surf := _surface_now()
	_burst(_land_dust, _gpos, surf, strength)
	_burst(_bits, _gpos, surf, strength)
	_play(_land_audio, surf, true, strength)
	_impact_age = 0.0
	_impact_k = strength
	_impact_color = (SURFACES.get(surf, SURFACES["grass"]) as Dictionary)["dust"]
	if _is_player and strength > 0.45:
		_shake = maxf(_shake, 2.0 + 5.5 * (strength - 0.45))


func _burst(p: CPUParticles2D, at: Vector2, surf: String, power: float) -> void:
	var s: Dictionary = SURFACES.get(surf, SURFACES["grass"])
	p.global_position = at
	p.color = (s["bits"] as Color) if p == _bits else (s["dust"] as Color)
	if p != _bits:
		var v: Vector2 = p.get_meta("v")
		var sc: Vector2 = p.get_meta("s")
		var k := 0.6 + clampf(power, 0.0, 1.5) * 0.6
		p.initial_velocity_min = v.x * k
		p.initial_velocity_max = v.y * k
		p.scale_amount_min = sc.x * k
		p.scale_amount_max = sc.y * k
	p.restart()


func _play(player: AudioStreamPlayer2D, surf: String, heavy: bool, power: float) -> void:
	player.stream = _make_sound(surf, heavy, randi() % 3)
	player.pitch_scale = randf_range(0.9, 1.1)
	if heavy:
		player.volume_db = -11.0 + clampf(power, 0.0, 1.5) * 4.0
	else:
		player.volume_db = lerpf(-26.0, -13.0, clampf(power, 0.0, 1.0))
	player.play()


# ---------- procedural sounds (no audio files needed) ----------

static func _make_sound(surf: String, heavy: bool, variant: int) -> AudioStreamWAV:
	var key := "%s_%s_%d" % [surf, "h" if heavy else "s", variant]
	if _sound_cache.has(key):
		return _sound_cache[key]
	var r: Dictionary = SOUNDS.get(surf, SOUNDS["metal"])
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(key)
	var length := 0.30 if heavy else 0.16
	var n := int(float(SAMPLE_RATE) * length)
	var f0 := float(r["f0"]) * (0.62 if heavy else 1.0) * (1.0 + 0.08 * float(variant))
	var td := float(r["td"]) * (0.55 if heavy else 1.0)
	var nd := float(r["nd"]) * (0.6 if heavy else 1.0)
	var bytes := PackedByteArray()
	bytes.resize(n * 2)
	var lp := 0.0
	for i in n:
		var t := float(i) / float(SAMPLE_RATE)
		var attack := minf(1.0, t / 0.002)
		var thump := sin(TAU * f0 * t) * exp(-t * td) * float(r["ta"])
		lp = lerpf(lp, rng.randf() * 2.0 - 1.0, float(r["nlp"]))
		var noise := lp * exp(-t * nd) * float(r["na"])
		var click := 0.0
		if float(r["cf"]) > 0.0:
			click = sin(TAU * float(r["cf"]) * t) * exp(-t * 260.0) * float(r["ca"])
		var v := clampf((thump + noise + click) * attack, -1.0, 1.0)
		bytes.encode_s16(i * 2, int(v * 30000.0))
	var s := AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = SAMPLE_RATE
	s.stereo = false
	s.data = bytes
	_sound_cache[key] = s
	return s


# ---------- every frame: camera thump, shadow, shock ring ----------

func _process(delta: float) -> void:
	if _impact_age < IMPACT_TIME + 1.0:
		_impact_age += delta
	if _cam != null and is_instance_valid(_cam):
		if _shake > 0.01:
			_cam.position = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * _shake
			_shake = move_toward(_shake, 0.0, 40.0 * delta)
		elif _cam.position != Vector2.ZERO:
			_cam.position = Vector2.ZERO
	queue_redraw()


func _draw() -> void:
	if not _has_ground or body == null or vis == null:
		return
	var dead := _flag("dead") or _flag("is_dead")
	var alpha := vis.modulate.a * body.modulate.a
	if not dead:
		var k := clampf(1.0 - _height / SHADOW_FADE_HEIGHT, 0.0, 1.0)
		if k > 0.02:
			var w := (19.0 if _flag("crouching") else 16.0) + (1.0 - k) * 9.0
			var a := 0.34 * k * alpha
			draw_set_transform(Vector2(-3.0, 1.0), 0.0, Vector2(1.0, 0.24))
			draw_circle(Vector2.ZERO, w * 1.35, Color(0, 0, 0, a * 0.35))
			draw_circle(Vector2.ZERO, w, Color(0, 0, 0, a * 0.55))
			draw_circle(Vector2.ZERO, w * 0.62, Color(0, 0, 0, a * 0.80))
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if _impact_age < IMPACT_TIME:
		var u := _impact_age / IMPACT_TIME
		var radius := 8.0 + (36.0 + 46.0 * _impact_k) * u
		var col := _impact_color
		col.a *= (1.0 - u) * 0.9
		draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.18))
		draw_arc(Vector2.ZERO, radius, 0.0, TAU, 36, col, 1.5 + 3.0 * (1.0 - u), true)
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
