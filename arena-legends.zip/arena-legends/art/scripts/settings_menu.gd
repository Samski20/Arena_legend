class_name SettingsMenu
extends PanelContainer
## Settings page shown from the pause menu (arena_controller.gd). Touch-friendly: every value uses
## big  -  and  +  buttons instead of tiny sliders. Changes apply live to the touch controls (which are
## visible in the corners behind the lighter dim) and are saved straight away.

signal back_pressed
signal edit_layout_pressed

var _rows := {}          # setting name -> Label showing its value
var _fixed_btn: Button
var _labels_btn: Button
var _fps_btn: Button
var _gfx_btn: Button
var _res_btn: Button
var _zoom_btn: Button
var _laser_btn: Button
var _haptics_btn: Button

# --- touch scrolling -------------------------------------------------------------------------
# Godot's own ScrollContainer never sees a finger drag that starts on a button (the button eats it),
# and almost every row is a button, so the list would not scroll on phones. We scroll it ourselves:
# any finger that lands inside the list can drag it, with a little momentum after you let go.
const DRAG_THRESHOLD := 12.0         # px a finger must travel before it counts as a scroll, not a tap
var _scroll: ScrollContainer
var _touch_id := -1
var _touch_travel := 0.0
var _touch_scrolling := false
var _swallow_taps := false           # true after a scroll drag so the release does not also press a button
var _frac := 0.0
var _inertia := 0.0                  # px/s


func _ready() -> void:
	GameSettings.ensure_loaded()
	custom_minimum_size = Vector2(460, 0)
	size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	add_theme_stylebox_override("panel", UITheme.panel_box(20, 16))

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	add_child(column)

	var title := Label.new()
	title.text = "SETTINGS"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 22)
	title.add_theme_font_override("font", UITheme.font(true))
	title.add_theme_color_override("font_color", UITheme.ON_SURFACE)
	column.add_child(title)

	# pinned OUTSIDE the scroll list so it is always visible (a phone cannot always scroll the list)
	var edit := _button("EDIT LAYOUT  -  move / resize controls")
	edit.custom_minimum_size = Vector2(0, 54)
	UITheme.style_button(edit, "primary")
	edit.pressed.connect(func() -> void: edit_layout_pressed.emit())
	column.add_child(edit)

	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var vh := 600.0
	if is_inside_tree():
		vh = get_viewport_rect().size.y
	scroll.custom_minimum_size = Vector2(0, clampf(vh * 0.52, 150.0, 400.0))   # tall enough that most phones show every row
	scroll.scroll_deadzone = 100000          # switch Godot's own (unreliable) touch drag off; _input below does it
	column.add_child(scroll)
	_scroll = scroll

	var list := VBoxContainer.new()
	list.add_theme_constant_override("separation", 8)
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(list)

	_stepper_row(list, "sfx_volume", "Sound volume", 0.0, 1.0, 0.1)
	_stepper_row(list, "music_volume", "Music volume", 0.0, 1.0, 0.1)
	_fixed_btn = _toggle_row(list, "Fixed analog sticks", _on_fixed)
	_stepper_row(list, "stick_scale", "Stick size", 0.6, 1.6, 0.1)
	_stepper_row(list, "button_scale", "Button size", 0.6, 1.5, 0.1)
	_stepper_row(list, "opacity", "Control opacity", 0.25, 1.0, 0.05)
	_stepper_row(list, "deadzone", "Stick dead zone", 0.0, 0.4, 0.02)
	_labels_btn = _toggle_row(list, "Stick labels", _on_labels)
	_zoom_btn = _toggle_row(list, "Start with Maximum Weapon Zoom", _on_max_zoom)
	var zoom_hint := Label.new()
	zoom_hint.text = "Automatically start at the highest available zoom level for the equipped weapon."
	zoom_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	zoom_hint.custom_minimum_size = Vector2(380, 0)
	zoom_hint.add_theme_font_size_override("font_size", 13)
	zoom_hint.add_theme_color_override("font_color", UITheme.ON_VARIANT)
	list.add_child(zoom_hint)
	_laser_btn = _toggle_row(list, "Laser Sight", _on_laser)
	_haptics_btn = _toggle_row(list, "Haptics (vibration)", _on_haptics)
	_fps_btn = _toggle_row(list, "Show FPS", _on_fps)
	_gfx_btn = _toggle_row(list, "Graphics quality", _on_gfx)
	_res_btn = _toggle_row(list, "Resolution (Fast = smoother)", _on_res)

	var buttons := HBoxContainer.new()
	buttons.add_theme_constant_override("separation", 10)
	column.add_child(buttons)
	var reset := _button("RESET")
	UITheme.style_button(reset, "tonal")
	reset.pressed.connect(_on_reset)
	buttons.add_child(reset)
	var back := _button("BACK")
	UITheme.style_button(back, "primary")
	back.pressed.connect(func() -> void: back_pressed.emit())
	buttons.add_child(back)
	_refresh()


func _input(event: InputEvent) -> void:
	if _scroll == null or not is_visible_in_tree():
		return
	if event is InputEventScreenTouch:
		var te := event as InputEventScreenTouch
		if te.pressed:
			if _touch_id == -1 and _scroll.get_global_rect().has_point(te.position):
				_touch_id = te.index
				_touch_travel = 0.0
				_touch_scrolling = false
				_swallow_taps = false
				_inertia = 0.0
				_frac = 0.0
		elif te.index == _touch_id:
			_touch_id = -1
			if not _touch_scrolling:
				_inertia = 0.0
	elif event is InputEventScreenDrag:
		var de := event as InputEventScreenDrag
		if de.index != _touch_id:
			return
		_touch_travel += absf(de.relative.y)
		if not _touch_scrolling and _touch_travel >= DRAG_THRESHOLD:
			_touch_scrolling = true
			_swallow_taps = true
		if _touch_scrolling:
			_scroll_by(-de.relative.y)
			_inertia = -de.velocity.y
			get_viewport().set_input_as_handled()


func _process(delta: float) -> void:
	if _touch_id != -1 or absf(_inertia) < 25.0 or _scroll == null:
		return
	var before := _scroll.scroll_vertical
	_scroll_by(_inertia * delta)
	if _scroll.scroll_vertical == before:
		_inertia = 0.0                       # hit the top or bottom
	else:
		_inertia *= exp(-5.0 * delta)


func _scroll_by(px: float) -> void:
	_frac += px
	var whole := int(_frac)
	_frac -= float(whole)
	if whole != 0:
		_scroll.scroll_vertical += whole


func _button(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(64, 48)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("font_size", 18)
	return b


func _row_label(row: HBoxContainer, text: String) -> void:
	var l := Label.new()
	l.text = text
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART        # long names (Start with Maximum Weapon Zoom) wrap instead of widening the menu
	l.custom_minimum_size = Vector2(120, 0)
	l.add_theme_font_size_override("font_size", 17)
	l.add_theme_color_override("font_color", UITheme.ON_SURFACE)
	row.add_child(l)


func _toggle_row(parent: Control, text: String, handler: Callable) -> Button:
	var row := HBoxContainer.new()
	parent.add_child(row)
	_row_label(row, text)
	var b := _button("")
	b.size_flags_horizontal = Control.SIZE_SHRINK_END
	b.custom_minimum_size = Vector2(170, 48)
	b.pressed.connect(handler)
	row.add_child(b)
	return b


func _stepper_row(parent: Control, key: String, text: String, lo: float, hi: float, step: float) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	parent.add_child(row)
	_row_label(row, text)
	var minus := _button("-")
	minus.size_flags_horizontal = Control.SIZE_SHRINK_END
	minus.custom_minimum_size = Vector2(56, 48)
	minus.pressed.connect(_step.bind(key, -step, lo, hi))
	row.add_child(minus)
	var value := Label.new()
	value.custom_minimum_size = Vector2(64, 0)
	value.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	value.add_theme_font_size_override("font_size", 17)
	row.add_child(value)
	_rows[key] = value
	var plus := _button("+")
	plus.size_flags_horizontal = Control.SIZE_SHRINK_END
	plus.custom_minimum_size = Vector2(56, 48)
	plus.pressed.connect(_step.bind(key, step, lo, hi))
	row.add_child(plus)


func _step(key: String, delta: float, lo: float, hi: float) -> void:
	if _swallow_taps:
		return
	var v: float = snappedf(clampf(GameSettings.get_value(key) + delta, lo, hi), 0.01)
	GameSettings.set_value(key, v)
	_changed()


func _on_fixed() -> void:
	if _swallow_taps:
		return
	GameSettings.fixed_sticks = not GameSettings.fixed_sticks
	_changed()


func _on_labels() -> void:
	if _swallow_taps:
		return
	GameSettings.show_labels = not GameSettings.show_labels
	_changed()


func _on_fps() -> void:
	if _swallow_taps:
		return
	GameSettings.show_fps = not GameSettings.show_fps
	_changed()


func _on_max_zoom() -> void:
	if _swallow_taps:
		return
	GameSettings.max_weapon_zoom = not GameSettings.max_weapon_zoom      # the camera notices this on the next frame
	_changed()


func _on_haptics() -> void:
	if _swallow_taps:
		return
	GameSettings.haptics = not GameSettings.haptics
	_changed()
	if GameSettings.haptics:
		UITheme.haptic(30)                           # a sample buzz when you turn it on


func _on_laser() -> void:
	if _swallow_taps:
		return
	GameSettings.laser_sight = not GameSettings.laser_sight
	_changed()


func _on_gfx() -> void:                          # Graphics Quality: LOW -> MEDIUM -> HIGH -> LOW ...
	if _swallow_taps:
		return
	GameSettings.quality = (GameSettings.quality + 1) % 3
	GameSettings.apply_quality()
	_changed()


func _on_res() -> void:                          # Resolution Quality: FAST <-> SHARP (independent of the above)
	if _swallow_taps:
		return
	GameSettings.fast_resolution = not GameSettings.fast_resolution
	GameSettings.apply_resolution()
	_changed()


func _on_reset() -> void:
	GameSettings.reset_touch()
	_changed()


func _changed() -> void:
	GameSettings.save()
	_refresh()
	for t in get_tree().get_nodes_in_group("touch_controls"):
		t.call("apply_settings")


func _refresh() -> void:
	_fixed_btn.text = "FIXED: ON" if GameSettings.fixed_sticks else "FIXED: OFF (floating)"
	_labels_btn.text = "ON" if GameSettings.show_labels else "OFF"
	_fps_btn.text = "ON" if GameSettings.show_fps else "OFF"
	_zoom_btn.text = "ON" if GameSettings.max_weapon_zoom else "OFF"
	_laser_btn.text = "ON" if GameSettings.laser_sight else "OFF"
	_haptics_btn.text = "ON" if GameSettings.haptics else "OFF"
	UITheme.style_toggle(_fixed_btn, GameSettings.fixed_sticks)         # green chip = on, quiet = off
	UITheme.style_toggle(_labels_btn, GameSettings.show_labels)
	UITheme.style_toggle(_fps_btn, GameSettings.show_fps)
	UITheme.style_toggle(_zoom_btn, GameSettings.max_weapon_zoom)
	UITheme.style_toggle(_laser_btn, GameSettings.laser_sight)
	UITheme.style_toggle(_haptics_btn, GameSettings.haptics)
	_gfx_btn.text = GameSettings.quality_name()
	_res_btn.text = "FAST" if GameSettings.fast_resolution else "SHARP"
	for key in _rows:
		var v: float = GameSettings.get_value(key)
		(_rows[key] as Label).text = "%d%%" % roundi(v * 100.0)
