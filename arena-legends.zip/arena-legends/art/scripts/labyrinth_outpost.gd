class_name LabyrinthOutpost
extends Node2D
## DAYTIME MAP: LABYRINTH OUTPOST
## A bright, simple floating-island outpost: a grassy ground with a shallow basin and
## a small pond, five sky islands, a few stepping stones, and two bunkers at the ends.
##
## Everything is painted from code (no image files needed) and split in layers:
##   * Backdrop  - screen-space sky, sun, parallax clouds, hills, far islands, birds, windmill
##   * Terrain   - the solid islands, bunkers and props (painted once, never redrawn)
##   * WorldFx   - animated scenery: swaying grass and trees, flags, waterfall, pond,
##                 butterflies and drifting cloud shadows
##   * Particles - falling leaves, pollen, chimney smoke and waterfall mist
##
## To move or add land, edit _define_lands(). Collision is built from the same shapes
## that get painted, so what you see is what you can stand on.
##
## LOOK: a late-afternoon, muted-colour take. Two shaders (art/shaders/) do the heavy lifting:
##   * outpost_terrain.gdshader - bumpy, mottled, sun-lit surface on the whole static terrain
##   * outpost_grade.gdshader   - screen grade: darker exposure, split tone, bloom, vignette, grain
## HIDE BUSHES: six big bushes (HIDE_BUSH_SPOTS) the player and bots can hide in (see bush_cover.gd).
## GROUND CONTACT: grass bends around anyone walking through it and flattens under jetpack downwash.

const TERRAIN_SHADER_PATH := "res://art/shaders/outpost_terrain.gdshader"
const GRADE_SHADER_PATH := "res://art/shaders/outpost_grade.gdshader"

const WeaponCatalog = preload("res://art/scripts/weapon_catalog.gd")
const WeaponPickup = preload("res://art/scripts/weapon_pickup.gd")
const ThrowableSpawner = preload("res://art/scripts/throwable_spawner.gd")

const MAP_W := 5200.0
const MAP_H := 2600.0
const CEILING_Y := 640.0          # invisible ceiling; the jetpack lane above the highest island
const WEST_FLOOR_Y := 2140.0      # surface of the west plateau (west bunker floor)
const EAST_FLOOR_Y := 2170.0      # surface of the east plateau (east bunker floor)
const BASIN_Y := 2335.0

# Bunker roof slabs. These are the only solid parts of the bunkers; the rooms below are open.
const WEST_ROOF := Rect2(0, 1925, 490, 64)
const EAST_ROOF := Rect2(4710, 1955, 490, 56)
const WEST_ROOM_END := 470.0
const EAST_ROOM_START := 4730.0

# Waterfall and pond (decoration only)
const FALL_X := 2954.0
const FALL_TOP_Y := 1192.0
const POND_LEFT := 2922.0
const POND_RIGHT := 3148.0
const POND_SURFACE_Y := 2347.0

# ---- Palette (late afternoon: muted, natural) ----
const SKY_TOP_HIGH := Color("35597f")
const SKY_TOP_LOW := Color("6a93b3")
const SKY_HORIZON := Color("e3cfae")
const SOIL_TOP := Color("86694a")
const SOIL_BOTTOM := Color("4a3a2b")
const STRATA := Color(0.18, 0.12, 0.07, 0.22)
const OUTLINE := Color(0.07, 0.06, 0.04, 0.55)
const PILLAR_FILL := Color("746c60")
const PILLAR_EDGE := Color("463f35")
const GRASS := Color("56803a")
const GRASS_HI := Color("93ad52")
const GRASS_DARK := Color("33572c")
const GRASS_LINE := Color(0.10, 0.20, 0.10, 0.55)
const LEAF := Color("3f6a34")
const LEAF_HI := Color("7c9c4a")
const LEAF_EDGE := Color("22401f")
const LEAF_DEEP := Color("1f3a1d")
const ROCK_COLORS := [Color("8d928c"), Color("77807c"), Color("a29f93"), Color("96877a")]
const ROCK_EDGE := Color(0.18, 0.15, 0.11, 0.7)

# ---- Hide bushes (big bushes you can hide in) ----
const HIDE_BUSH_SPOTS := [
	["ground", 930.0], ["ground", 2150.0], ["ground", 3660.0],
	["sky_west", 1160.0], ["sky_mid_w", 1960.0], ["sky_mid_e", 3590.0],
]
const HIDE_W := 180.0
const HIDE_H := 88.0

@export var map_id := "labyrinth_outpost"
## Phones and tablets get a lighter look (no screen-grade or terrain shader, no cloud shadows, fewer
## blades / leaves / particles, throttled animation). Force it on or off here when testing on desktop.
@export_enum("Auto", "On", "Off") var lite_mode := 0

var _lite := false
var _frame := 0

var _lands: Array = []           # Array of Dictionary: id, kind, top, bottom, poly, rect
var _pillars: Array = []         # Array of PackedVector2Array (background rock columns)
var _static_body: StaticBody2D
var _terrain: Node2D
var _fx: Node2D
var _backdrop: CanvasLayer
var _sky_node: Node2D
var _birds_node: Node2D
var _windmill_node: Node2D
var _layers: Array = []          # parallax layers: node, s, drift, period

var _elapsed := 0.0
var _half := Vector2(576, 324)
var _cam_center := Vector2(MAP_W * 0.5, 1800.0)
var _cam_zoom := Vector2.ONE
var _view := Rect2(0, 0, MAP_W, MAP_H)

# scenery data (filled once in _scatter_scenery)
var _blade_base := PackedVector2Array()
var _blade_h := PackedFloat32Array()
var _blade_phase := PackedFloat32Array()
var _blade_tilt := PackedFloat32Array()
var _blade_color := PackedInt32Array()
var _flowers: Array = []         # Dictionary: pos, color, h
var _trees: Array = []           # Dictionary: pos, s
var _bushes: Array = []          # Vector3: x, y, scale
var _butterflies: Array = []     # Dictionary: center, r, speed, phase, color
var _flags: Array = []           # Dictionary: base, h, color
var _leaf_texture: Texture2D
var _hide_bushes: Array = []     # Dictionary: pos, area, leaves, rustle, fade
var _hide_front: Node2D          # foreground layer: front grass + hide-bush foliage (drawn over characters)
var _grade_layer: CanvasLayer
var _pushers: Array = []         # Vector3: feet x, feet y, push power (0 = standing, 1 = running, 2 = jetpack downwash)


func _ready() -> void:
	z_index = -10
	_lite = lite_mode == 1 or (lite_mode == 0 and (OS.has_feature("mobile") or OS.has_feature("web_android") or OS.has_feature("web_ios")))
	add_to_group("map_" + map_id)
	add_to_group("surface_provider")          # GroundContact asks us what a footstep lands on
	_define_lands()
	_build_collisions()
	_build_weapon_pickups()
	_build_throwable_spawner()
	_scatter_scenery()
	_build_hide_bushes()
	_build_scenery_nodes()
	_build_backdrop()
	_build_atmosphere_fx()
	_build_grade()
	_set_camera_limits()
	_update_camera_info()
	_update_backdrop()


func _process(delta: float) -> void:
	_elapsed += delta
	_update_camera_info()
	_update_backdrop()
	_collect_pushers()
	_update_hide_bushes(delta)
	_frame += 1
	# Lite mode: grass / foliage animate at 30 fps, sky / birds / windmill at about 12 fps.
	if not _lite or _frame % 2 == 0:
		_fx.queue_redraw()
		_hide_front.queue_redraw()
	if not _lite or _frame % 5 == 0:
		_sky_node.queue_redraw()
		_birds_node.queue_redraw()
		_windmill_node.queue_redraw()


# =====================================================================
#  LAND SHAPES  (the only place that decides where things are)
# =====================================================================

func _define_lands() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 90417
	# id, kind, top edge (left to right), underside depth
	var defs: Array = [
		["ground", "ground", PackedVector2Array([
			Vector2(0, WEST_FLOOR_Y), Vector2(1000, WEST_FLOOR_Y), Vector2(1250, 2250), Vector2(1450, BASIN_Y),
			Vector2(2330, BASIN_Y), Vector2(2480, 2278), Vector2(2720, 2278), Vector2(2870, BASIN_Y),
			Vector2(2900, BASIN_Y), Vector2(2960, 2362), Vector2(3110, 2362), Vector2(3170, BASIN_Y),
			Vector2(3750, BASIN_Y), Vector2(3980, 2240), Vector2(4250, EAST_FLOOR_Y), Vector2(MAP_W, EAST_FLOOR_Y)]), 0.0],
		["sky_west", "island", PackedVector2Array([
			Vector2(640, 1665), Vector2(800, 1625), Vector2(1230, 1625), Vector2(1400, 1670)]), 280.0],
		["sky_mid_w", "island", PackedVector2Array([
			Vector2(1520, 1445), Vector2(1680, 1415), Vector2(2060, 1415), Vector2(2200, 1450)]), 270.0],
		["sky_center", "island", PackedVector2Array([
			Vector2(2300, 1190), Vector2(2450, 1140), Vector2(2800, 1140), Vector2(2950, 1190)]), 340.0],
		["sky_mid_e", "island", PackedVector2Array([
			Vector2(3100, 1520), Vector2(3300, 1430), Vector2(3650, 1430), Vector2(3800, 1465)]), 280.0],
		["sky_east", "island", PackedVector2Array([
			Vector2(4050, 1720), Vector2(4200, 1685), Vector2(4650, 1685), Vector2(4800, 1725)]), 270.0],
		["stone_a", "stone", PackedVector2Array([Vector2(1480, 2010), Vector2(1740, 2010)]), 120.0],
		["stone_b", "stone", PackedVector2Array([Vector2(2560, 1900), Vector2(2840, 1900)]), 130.0],
		["stone_c", "stone", PackedVector2Array([Vector2(3880, 2000), Vector2(4130, 2000)]), 120.0],
		["lane_west", "stone", PackedVector2Array([Vector2(700, 1110), Vector2(960, 1110)]), 120.0],
		["lane_east", "stone", PackedVector2Array([Vector2(4380, 1090), Vector2(4660, 1090)]), 120.0],
	]
	for d in defs:
		var top: PackedVector2Array = d[2]
		var bottom := _make_underside(top, float(d[3]), String(d[1]), rng)
		var poly := PackedVector2Array(top)
		poly.append_array(bottom)
		var lo := poly[0]
		var hi := poly[0]
		for p in poly:
			lo = Vector2(minf(lo.x, p.x), minf(lo.y, p.y))
			hi = Vector2(maxf(hi.x, p.x), maxf(hi.y, p.y))
		_lands.append({
			"id": String(d[0]), "kind": String(d[1]), "top": top, "bottom": bottom,
			"poly": poly, "rect": Rect2(lo, hi - lo),
		})
	# Dim rock columns that sit BEHIND the islands (not solid) to give depth.
	_pillars = [
		PackedVector2Array([Vector2(2490, 1450), Vector2(2780, 1450), Vector2(2690, 1800), Vector2(2730, 2340),
			Vector2(2540, 2340), Vector2(2590, 1800)]),
	]


func _make_underside(top: PackedVector2Array, depth: float, kind: String, rng: RandomNumberGenerator) -> PackedVector2Array:
	var x0 := top[0].x
	var x1 := top[top.size() - 1].x
	var pts := PackedVector2Array()
	if kind == "ground":
		# Jagged rocky belly of the main ground, right to left.
		pts.append(Vector2(x1, 2480.0))
		var x := x1 - 90.0
		var n := 0
		while x > x0 + 60.0:
			var by := 2485.0 + rng.randf_range(-26.0, 30.0)
			if n % 4 == 2:
				pts.append(Vector2(x + 34.0, by))
				pts.append(Vector2(x, by + rng.randf_range(60.0, 105.0)))
				pts.append(Vector2(x - 34.0, by))
			else:
				pts.append(Vector2(x, by))
			x -= rng.randf_range(95.0, 135.0)
			n += 1
		pts.append(Vector2(x0, 2470.0))
		return pts
	var count := clampi(int((x1 - x0) / 55.0), 6, 18)
	for i in range(count + 1):
		var t := 1.0 - float(i) / float(count)
		var x := lerpf(x0, x1, t)
		var shape := pow(maxf(sin(PI * t), 0.0), 0.85)
		var y := _interp_y(top, x) + 30.0 + (depth - 30.0) * shape
		y += rng.randf_range(-10.0, 10.0) * shape
		if i % 2 == 1:
			y -= 14.0 * shape
		if i == count / 2 and kind == "island":
			y += 55.0 * shape
		pts.append(Vector2(x, y))
	return pts


func _interp_y(path: PackedVector2Array, x: float) -> float:
	for i in range(path.size() - 1):
		var a := path[i]
		var b := path[i + 1]
		if x >= minf(a.x, b.x) and x <= maxf(a.x, b.x):
			if is_equal_approx(a.x, b.x):
				return a.y
			return lerpf(a.y, b.y, (x - a.x) / (b.x - a.x))
	return path[0].y


func _land(id: String) -> Dictionary:
	for land in _lands:
		if land["id"] == id:
			return land
	return {}


func _surface(id: String, x: float) -> Vector2:
	var land := _land(id)
	if land.is_empty():
		return Vector2(x, WEST_FLOOR_Y)
	return Vector2(x, _interp_y(land["top"], x))


func _in_bunker(x: float) -> bool:
	return x < WEST_ROOF.end.x + 6.0 or x > EAST_ROOF.position.x - 6.0


# =====================================================================
#  COLLISION, PICKUPS, SPAWNERS
# =====================================================================

func _build_collisions() -> void:
	_static_body = StaticBody2D.new()
	_static_body.name = "MapCollision"
	_static_body.add_to_group("map_solid")
	add_child(_static_body)
	for land in _lands:
		var shape := CollisionPolygon2D.new()
		shape.polygon = land["poly"] as PackedVector2Array
		_static_body.add_child(shape)
	_add_collision_rect(WEST_ROOF)
	_add_collision_rect(EAST_ROOF)
	# Invisible boundaries and ceiling keep everyone inside the arena.
	_add_collision_rect(Rect2(-120, CEILING_Y - 600, 120, MAP_H + 900))
	_add_collision_rect(Rect2(MAP_W, CEILING_Y - 600, 120, MAP_H + 900))
	_add_collision_rect(Rect2(-120, CEILING_Y - 120, MAP_W + 240, 120))


func _add_collision_rect(rect: Rect2) -> void:
	var collision := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = rect.size
	collision.shape = shape
	collision.position = rect.position + rect.size * 0.5
	_static_body.add_child(collision)


func _build_weapon_pickups() -> void:
	var pool := WeaponCatalog.all()
	if pool.is_empty():
		push_warning("Labyrinth Outpost: weapon catalog is empty; no map weapons spawned.")
		return
	# land id, x   (the two guns that live in the main scene are moved by the arena controller)
	var spots: Array = [
		["sky_west", 1010.0], ["sky_center", 2625.0], ["sky_east", 4420.0],
		["lane_west", 830.0], ["lane_east", 4520.0], ["stone_b", 2700.0],
		["ground", 3520.0], ["ground", 1900.0],
	]
	for s in spots:
		var pickup := WeaponPickup.new()
		pickup.weapon_pool = pool
		pickup.respawn_time = 15.0
		var p := _surface(String(s[0]), float(s[1]))
		pickup.position = Vector2(p.x, p.y - 26.0)
		add_child(pickup)


func _build_throwable_spawner() -> void:
	var spawner := ThrowableSpawner.new()
	spawner.name = "LabyrinthThrowableSpawner"
	spawner.map_id = map_id
	spawner.interval = 7.0
	spawner.max_active = 6
	spawner.initial_spawns = 4
	var spots: Array = [
		["ground", 700.0], ["ground", 1700.0], ["ground", 2600.0], ["ground", 3400.0], ["ground", 4500.0],
		["sky_west", 920.0], ["sky_mid_w", 1850.0], ["sky_center", 2540.0], ["sky_mid_e", 3480.0],
		["sky_east", 4560.0], ["stone_a", 1610.0], ["stone_c", 4000.0], ["lane_west", 780.0], ["lane_east", 4600.0],
	]
	var points := PackedVector2Array()
	for s in spots:
		var p := _surface(String(s[0]), float(s[1]))
		points.append(Vector2(p.x, p.y - 2.0))
	spawner.spawn_points = points
	add_child(spawner)


func _set_camera_limits() -> void:
	var scene := get_tree().current_scene
	if scene == null:
		return
	var camera := scene.find_child("Camera2D", true, false) as Camera2D
	if camera != null:
		camera.limit_left = 0
		camera.limit_right = int(MAP_W)
		camera.limit_top = int(CEILING_Y) - 40
		camera.limit_bottom = int(MAP_H)


# =====================================================================
#  SCENERY DATA
# =====================================================================

func _scatter_scenery() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 31337
	# Swaying grass blades and flowers along every walkable top edge.
	for land in _lands:
		var top: PackedVector2Array = land["top"]
		var x0 := top[0].x
		var x1 := top[top.size() - 1].x
		var x := x0 + 18.0
		while x < x1 - 14.0:
			if not _in_bunker(x):
				_blade_base.append(Vector2(x, _interp_y(top, x) + 3.0))
				_blade_h.append(rng.randf_range(22.0, 42.0))
				_blade_phase.append(rng.randf_range(0.0, TAU))
				_blade_tilt.append(rng.randf_range(-0.25, 0.25))
				_blade_color.append(rng.randi_range(0, 2))
			x += rng.randf_range(30.0, 50.0)
		x = x0 + 30.0
		var flower_colors := [Color("d9d2c3"), Color("d8b94a"), Color("b9677a"), Color("8f79b5"), Color("c9873f")]
		while x < x1 - 30.0:
			if not _in_bunker(x):
				_flowers.append({
					"pos": Vector2(x, _interp_y(top, x) + 2.0),
					"color": flower_colors[rng.randi_range(0, flower_colors.size() - 1)],
					"h": rng.randf_range(10.0, 20.0),
				})
			x += rng.randf_range(160.0, 340.0)
	# Trees (trunks are static, canopies sway in WorldFx).
	for t in [
		["ground", 790.0, 1.25], ["ground", 1820.0, 1.1], ["ground", 3560.0, 1.0], ["ground", 4430.0, 1.2],
		["sky_west", 1040.0, 0.95], ["sky_mid_w", 1930.0, 0.85], ["sky_center", 2745.0, 0.75],
		["sky_mid_e", 3520.0, 0.85], ["sky_east", 4420.0, 0.95],
	]:
		_trees.append({"pos": _surface(String(t[0]), float(t[1])), "s": float(t[2])})
	for b in [
		["ground", 640.0, 1.0], ["ground", 1190.0, 0.9], ["ground", 2020.0, 0.9], ["ground", 2600.0, 0.8],
		["ground", 3330.0, 1.0], ["ground", 4120.0, 0.9], ["ground", 4640.0, 1.0], ["sky_west", 780.0, 0.8],
		["sky_mid_w", 1760.0, 0.7], ["sky_mid_e", 3390.0, 0.75], ["sky_east", 4330.0, 0.8],
		["sky_center", 2490.0, 0.8],
	]:
		var p := _surface(String(b[0]), float(b[1]))
		_bushes.append(Vector3(p.x, p.y, float(b[2])))
	# Butterflies loop around flower spots.
	var wing_colors := [Color("d49a3a"), Color("c97a9a"), Color("7fa6c9"), Color("d6cc6a"), Color("a98bc9")]
	for spot in [["ground", 1560.0], ["ground", 2200.0], ["ground", 3480.0], ["ground", 4600.0], ["sky_west", 960.0],
			["sky_mid_w", 1850.0], ["sky_center", 2680.0], ["sky_mid_e", 3520.0], ["sky_east", 4500.0], ["ground", 420.0]]:
		var p := _surface(String(spot[0]), float(spot[1]))
		_butterflies.append({
			"center": p + Vector2(0, -60), "r": rng.randf_range(40.0, 75.0), "speed": rng.randf_range(0.5, 1.0),
			"phase": rng.randf_range(0.0, TAU), "color": wing_colors[rng.randi_range(0, wing_colors.size() - 1)],
		})
	_flags = [
		{"base": Vector2(450, WEST_ROOF.position.y), "h": 128.0, "color": Color("3a6fb5")},
		{"base": Vector2(4742, EAST_ROOF.position.y), "h": 128.0, "color": Color("b9473a")},
		{"base": _surface("sky_center", 2625.0), "h": 118.0, "color": Color("d3a93a")},
	]
	_leaf_texture = _make_leaf_texture()


func _make_leaf_texture() -> Texture2D:
	var img := Image.create(20, 12, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	for y in 12:
		for x in 20:
			var nx := (float(x) - 9.5) / 9.5
			var ny := (float(y) - 5.5) / 5.5
			var width := 1.0 - nx * nx
			if width > 0.0 and absf(ny) < width:
				var shade := 1.0 - 0.18 * absf(ny) / maxf(width, 0.01)
				if y == 5 or y == 6:
					shade = 0.78
				img.set_pixel(x, y, Color(shade, shade, shade, 1.0))
	return ImageTexture.create_from_image(img)


# =====================================================================
#  NODES
# =====================================================================

func _build_scenery_nodes() -> void:
	_terrain = Node2D.new()
	_terrain.name = "Terrain"
	if _lite:
		_terrain.modulate = Color(0.86, 0.88, 0.92)      # cheap stand-in for the terrain shader's darker, cooler look
	else:
		_terrain.material = _make_material(TERRAIN_SHADER_PATH)
	_terrain.draw.connect(_paint_terrain.bind(_terrain))
	add_child(_terrain)
	_fx = Node2D.new()
	_fx.name = "WorldFx"
	_fx.draw.connect(_paint_fx.bind(_fx))
	add_child(_fx)
	# Drawn OVER the characters: short grass at their feet and the hide-bush foliage.
	_hide_front = Node2D.new()
	_hide_front.name = "ForegroundFx"
	_hide_front.z_index = 12                  # (the map sits at -10, so this is +2 on screen: above characters)
	_hide_front.draw.connect(_paint_front.bind(_hide_front))
	add_child(_hide_front)


func _make_material(path: String) -> ShaderMaterial:
	if not ResourceLoader.exists(path):
		push_warning("Labyrinth Outpost: shader not found: " + path)
		return null
	var shader := load(path) as Shader
	if shader == null:
		return null
	var mat := ShaderMaterial.new()
	mat.shader = shader
	return mat


func _build_grade() -> void:
	if _lite:
		return          # the grade reads the whole screen every frame (9 samples per pixel): far too heavy for phones
	var mat := _make_material(GRADE_SHADER_PATH)
	if mat == null:
		return
	_grade_layer = CanvasLayer.new()
	_grade_layer.name = "AfternoonGrade"
	_grade_layer.layer = 1                    # above the world, below the HUD / touch controls / menus
	add_child(_grade_layer)
	var rect := ColorRect.new()
	rect.name = "GradeRect"
	rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rect.material = mat
	_grade_layer.add_child(rect)


# What is under a footstep at this point (used by GroundContact for dust colour and sound).
func surface_kind_at(p: Vector2) -> String:
	if p.x < WEST_ROOM_END + 10.0 and p.y > WEST_ROOF.end.y:
		return "stone"
	if p.x > EAST_ROOM_START - 8.0 and p.y > EAST_ROOF.end.y:
		return "wood"
	if p.x > POND_LEFT and p.x < POND_RIGHT and p.y > POND_SURFACE_Y - 24.0:
		return "water"
	for land in _lands:
		if (land["rect"] as Rect2).grow(10.0).has_point(p) and String(land["kind"]) == "stone":
			return "stone"
	return "grass"


func _build_backdrop() -> void:
	_backdrop = CanvasLayer.new()
	_backdrop.name = "DaylightBackdrop"
	_backdrop.layer = -50
	add_child(_backdrop)

	_sky_node = Node2D.new()
	_sky_node.name = "SkyAndSun"
	_sky_node.draw.connect(_paint_sky.bind(_sky_node))
	_backdrop.add_child(_sky_node)

	_add_cloud_layer("CloudsFar", 0.10, 4.0, 1900.0, 7, 120.0, 520.0, 70.0, 120.0, Color(0.93, 0.88, 0.82, 0.60), 11)
	_add_hill_layer("HillsFar", 0.18, 500.0, 48.0, Color("8fa3a6"), Color("b9bfb4"), 5, false)
	_add_bg_islands()
	_add_cloud_layer("CloudsMid", 0.30, 11.0, 2100.0, 6, 280.0, 820.0, 60.0, 110.0, Color(0.94, 0.88, 0.80, 0.72), 23)
	var mid_hills := _add_hill_layer("HillsMid", 0.38, 990.0, 75.0, Color("5d7d58"), Color("7b9a66"), 9, true)
	_windmill_node = Node2D.new()
	_windmill_node.name = "Windmill"
	_windmill_node.position = Vector2(1500.0, _hill_y(1500.0, 990.0, 75.0, 9))
	_windmill_node.draw.connect(_paint_windmill.bind(_windmill_node))
	mid_hills.add_child(_windmill_node)
	_birds_node = Node2D.new()
	_birds_node.name = "Birds"
	_birds_node.draw.connect(_paint_birds.bind(_birds_node))
	_backdrop.add_child(_birds_node)
	_layers.append({"node": _birds_node, "s": 0.55, "drift": 0.0, "period": 0.0})
	_add_cloud_layer("CloudBanks", 0.6, 20.0, 2600.0, 4, 1330.0, 1480.0, 130.0, 210.0, Color(0.96, 0.86, 0.74, 0.55), 37)


func _add_cloud_layer(layer_name: String, s: float, drift: float, period: float, count: int, y_min: float,
		y_max: float, size_min: float, size_max: float, col: Color, seed_value: int) -> Node2D:
	var node := Node2D.new()
	node.name = layer_name
	node.draw.connect(_paint_cloud_layer.bind(node, s, period, count, y_min, y_max, size_min, size_max, col, seed_value))
	_backdrop.add_child(node)
	_layers.append({"node": node, "s": s, "drift": drift, "period": period})
	return node


func _add_hill_layer(layer_name: String, s: float, base: float, amp: float, col: Color, rim: Color,
		seed_value: int, with_trees: bool) -> Node2D:
	var node := Node2D.new()
	node.name = layer_name
	node.draw.connect(_paint_hill_layer.bind(node, s, base, amp, col, rim, seed_value, with_trees))
	_backdrop.add_child(node)
	_layers.append({"node": node, "s": s, "drift": 0.0, "period": 0.0})
	return node


func _add_bg_islands() -> void:
	var node := Node2D.new()
	node.name = "FarIslands"
	node.draw.connect(_paint_bg_islands.bind(node))
	_backdrop.add_child(node)
	_layers.append({"node": node, "s": 0.26, "drift": 0.0, "period": 0.0})


func _update_camera_info() -> void:
	_half = get_viewport_rect().size * 0.5
	var cam := get_viewport().get_camera_2d()
	if cam != null:
		_cam_center = cam.get_screen_center_position()
		_cam_zoom = cam.zoom
	var world_half := Vector2(_half.x / maxf(_cam_zoom.x, 0.1), _half.y / maxf(_cam_zoom.y, 0.1))
	_view = Rect2(_cam_center - world_half - Vector2(160, 160), world_half * 2.0 + Vector2(320, 320))


func _update_backdrop() -> void:
	for l in _layers:
		var node: Node2D = l["node"]
		var s: float = l["s"]
		var pos := _half - _cam_center * s
		var drift: float = l["drift"]
		if drift != 0.0:
			var period: float = l["period"]
			pos.x += fposmod(_elapsed * drift, period) - period
		node.position = pos


func _build_atmosphere_fx() -> void:
	# Leaves drifting down in the breeze.
	var leaves := CPUParticles2D.new()
	leaves.name = "FallingLeaves"
	leaves.texture = _leaf_texture
	leaves.amount = 42 if not _lite else 21
	leaves.lifetime = 18.0
	leaves.preprocess = 18.0
	leaves.position = Vector2(MAP_W * 0.5, 1450.0)
	leaves.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	leaves.emission_rect_extents = Vector2(MAP_W * 0.5, 820.0)
	leaves.direction = Vector2(0.8, 1.0)
	leaves.spread = 22.0
	leaves.initial_velocity_min = 25.0
	leaves.initial_velocity_max = 55.0
	leaves.gravity = Vector2(10.0, 14.0)
	leaves.angular_velocity_min = -140.0
	leaves.angular_velocity_max = 140.0
	leaves.angle_max = 360.0
	leaves.scale_amount_min = 0.8
	leaves.scale_amount_max = 1.5
	var leaf_ramp := Gradient.new()
	leaf_ramp.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
	leaf_ramp.colors = PackedColorArray([Color("8aa14a"), Color("b59b3e"), Color("a8622f")])
	leaves.color_initial_ramp = leaf_ramp
	add_child(leaves)

	# Pollen and dandelion fluff glittering in the sun.
	var pollen := CPUParticles2D.new()
	pollen.name = "Pollen"
	var glow := _load_fx_texture("res://art/fx/glow.png")
	if glow != null:
		pollen.texture = glow
	pollen.amount = 34 if not _lite else 17
	pollen.lifetime = 11.0
	pollen.preprocess = 11.0
	pollen.position = Vector2(MAP_W * 0.5, 1800.0)
	pollen.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	pollen.emission_rect_extents = Vector2(MAP_W * 0.5, 650.0)
	pollen.direction = Vector2(1.0, -0.25)
	pollen.spread = 35.0
	pollen.initial_velocity_min = 8.0
	pollen.initial_velocity_max = 22.0
	pollen.gravity = Vector2(0.0, -1.5)
	pollen.scale_amount_min = 0.05
	pollen.scale_amount_max = 0.13
	var pollen_ramp := Gradient.new()
	pollen_ramp.offsets = PackedFloat32Array([0.0, 0.2, 0.8, 1.0])
	pollen_ramp.colors = PackedColorArray([Color(1, 0.95, 0.7, 0.0), Color(1, 0.96, 0.72, 0.75), Color(1, 0.96, 0.72, 0.6), Color(1, 0.96, 0.72, 0.0)])
	pollen.color_ramp = pollen_ramp
	add_child(pollen)

	# Chimney smoke from the east bunker.
	var smoke := CPUParticles2D.new()
	smoke.name = "ChimneySmoke"
	var puff := _load_fx_texture("res://art/fx/puff_2.png")
	if puff != null:
		smoke.texture = puff
	smoke.amount = 14 if not _lite else 7
	smoke.lifetime = 5.0
	smoke.preprocess = 5.0
	smoke.position = Vector2(5068.0, 1876.0)
	smoke.direction = Vector2(0.35, -1.0)
	smoke.spread = 12.0
	smoke.initial_velocity_min = 24.0
	smoke.initial_velocity_max = 38.0
	smoke.gravity = Vector2(6.0, -4.0)
	smoke.scale_amount_min = 0.08
	smoke.scale_amount_max = 0.16
	var grow := Curve.new()
	grow.add_point(Vector2(0.0, 0.5))
	grow.add_point(Vector2(1.0, 2.4))
	smoke.scale_amount_curve = grow
	var smoke_ramp := Gradient.new()
	smoke_ramp.offsets = PackedFloat32Array([0.0, 0.25, 1.0])
	smoke_ramp.colors = PackedColorArray([Color(0.92, 0.92, 0.92, 0.0), Color(0.92, 0.92, 0.92, 0.55), Color(0.92, 0.92, 0.95, 0.0)])
	smoke.color_ramp = smoke_ramp
	add_child(smoke)

	# Mist where the waterfall hits the pond.
	var mist := CPUParticles2D.new()
	mist.name = "WaterfallMist"
	var mist_tex := _load_fx_texture("res://art/fx/puff_3.png")
	if mist_tex != null:
		mist.texture = mist_tex
	mist.amount = 14 if not _lite else 7
	mist.lifetime = 2.4
	mist.preprocess = 2.4
	mist.position = Vector2(FALL_X + 12.0, POND_SURFACE_Y - 6.0)
	mist.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	mist.emission_rect_extents = Vector2(26.0, 4.0)
	mist.direction = Vector2(0.4, -1.0)
	mist.spread = 50.0
	mist.initial_velocity_min = 14.0
	mist.initial_velocity_max = 40.0
	mist.gravity = Vector2(0.0, -6.0)
	mist.scale_amount_min = 0.06
	mist.scale_amount_max = 0.13
	var mist_ramp := Gradient.new()
	mist_ramp.offsets = PackedFloat32Array([0.0, 0.3, 1.0])
	mist_ramp.colors = PackedColorArray([Color(1, 1, 1, 0.0), Color(1, 1, 1, 0.45), Color(1, 1, 1, 0.0)])
	mist.color_ramp = mist_ramp
	add_child(mist)


func _load_fx_texture(path: String) -> Texture2D:
	if ResourceLoader.exists(path):
		return load(path) as Texture2D
	return null


# =====================================================================
#  BACKDROP PAINTING (screen space, parallax)
# =====================================================================

func _paint_sky(c: CanvasItem) -> void:
	var size := _half * 2.0
	var alt := clampf(inverse_lerp(900.0, 2300.0, _cam_center.y), 0.0, 1.0)
	var top_col := SKY_TOP_HIGH.lerp(SKY_TOP_LOW, alt)
	var mid_col := top_col.lerp(SKY_HORIZON, 0.55)
	var y1 := size.y * 0.55
	c.draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(size.x, 0), Vector2(size.x, y1), Vector2(0, y1)]),
		PackedColorArray([top_col, top_col, mid_col, mid_col]))
	c.draw_polygon(PackedVector2Array([Vector2(0, y1 - 1.0), Vector2(size.x, y1 - 1.0), Vector2(size.x, size.y), Vector2(0, size.y)]),
		PackedColorArray([mid_col, mid_col, SKY_HORIZON, SKY_HORIZON]))
	# Sun: soft halo, slowly turning rays, bright disc.
	var sun := Vector2(size.x * 0.80, size.y * 0.27)
	for i in 7:
		c.draw_circle(sun, 240.0 - float(i) * 28.0, Color(1.0, 0.80, 0.50, 0.04 + 0.014 * float(i)))
	var ray_count := 14
	for i in ray_count:
		var a := _elapsed * 0.04 + TAU * float(i) / float(ray_count)
		var pulse := 0.055 + 0.03 * sin(_elapsed * 0.8 + float(i) * 1.9)
		var p1 := sun + Vector2(cos(a - 0.05), sin(a - 0.05)) * 520.0
		var p2 := sun + Vector2(cos(a + 0.05), sin(a + 0.05)) * 520.0
		c.draw_colored_polygon(PackedVector2Array([sun, p1, p2]), Color(1.0, 0.84, 0.56, pulse))
	c.draw_circle(sun, 54.0, Color(1.0, 0.88, 0.62, 0.5))
	c.draw_circle(sun, 42.0, Color("ffd88a"))
	c.draw_circle(sun, 30.0, Color("fff0c4"))


func _paint_cloud_layer(c: CanvasItem, s: float, period: float, count: int, y_min: float, y_max: float,
		size_min: float, size_max: float, col: Color, seed_value: int) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value
	var spec: Array = []
	for i in count:
		spec.append([rng.randf_range(0.0, period), rng.randf_range(y_min, y_max), rng.randf_range(size_min, size_max)])
	var x_start := -1300.0
	var x_end := s * MAP_W + 1400.0 + period
	var k := 0
	while x_start + float(k) * period < x_end:
		for sp in spec:
			_paint_cloud(c, Vector2(x_start + float(k) * period + float(sp[0]), float(sp[1])), float(sp[2]), col)
		k += 1


func _paint_cloud(c: CanvasItem, center: Vector2, sz: float, col: Color) -> void:
	var shade := Color(col.r * 0.80, col.g * 0.88, col.b * 0.98, col.a)
	var offs := [Vector2(-1.05, 0.12), Vector2(-0.55, -0.22), Vector2(0.0, -0.46), Vector2(0.55, -0.2), Vector2(1.05, 0.12), Vector2(-0.3, 0.14), Vector2(0.35, 0.16)]
	var rads := [0.40, 0.52, 0.66, 0.52, 0.40, 0.5, 0.5]
	for i in offs.size():
		c.draw_circle(center + (offs[i] as Vector2) * sz + Vector2(0.0, sz * 0.1), float(rads[i]) * sz, shade)
	for i in offs.size():
		c.draw_circle(center + (offs[i] as Vector2) * sz, float(rads[i]) * sz, col)


func _hill_y(x: float, base: float, amp: float, seed_value: int) -> float:
	var p := float(seed_value) * 1.7
	return base - amp * (0.55 * sin(x * 0.0021 + p) + 0.3 * sin(x * 0.0054 + p * 2.1) + 0.15 * sin(x * 0.0123 + p * 0.6))


func _paint_hill_layer(c: CanvasItem, s: float, base: float, amp: float, col: Color, rim: Color,
		seed_value: int, with_trees: bool) -> void:
	var x_min := -1300.0
	var x_max := s * MAP_W + 1400.0
	var pts := PackedVector2Array()
	var x := x_min
	while x <= x_max:
		pts.append(Vector2(x, _hill_y(x, base, amp, seed_value)))
		x += 40.0
	var ridge := PackedVector2Array(pts)
	var haze := col.lerp(SKY_HORIZON, 0.85)
	var fill := PackedVector2Array(ridge)
	var fill_colors := PackedColorArray()
	for i in ridge.size():
		fill_colors.append(col)
	fill.append(Vector2(x_max, base + 700.0))
	fill.append(Vector2(x_min, base + 700.0))
	fill_colors.append(haze)
	fill_colors.append(haze)
	c.draw_polygon(fill, fill_colors)
	c.draw_rect(Rect2(x_min, base + 699.0, x_max - x_min, 1400.0), haze)
	c.draw_polyline(ridge, rim, 5.0, true)
	if with_trees:
		var rng := RandomNumberGenerator.new()
		rng.seed = seed_value * 97
		var tx := x_min + 60.0
		while tx < x_max:
			var ty := _hill_y(tx, base, amp, seed_value)
			var r := rng.randf_range(16.0, 30.0)
			c.draw_circle(Vector2(tx, ty - r * 0.55), r, Color("46674a"))
			c.draw_circle(Vector2(tx - r * 0.25, ty - r * 0.8), r * 0.6, Color("5b7d54"))
			tx += rng.randf_range(70.0, 190.0)


func _paint_bg_islands(c: CanvasItem) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242
	var x := -900.0
	var x_max := 0.26 * MAP_W + 1200.0
	while x < x_max:
		var w := rng.randf_range(190.0, 380.0)
		var y := rng.randf_range(380.0, 830.0)
		_paint_bg_island(c, Vector2(x, y), w, rng)
		x += rng.randf_range(420.0, 640.0)


func _paint_bg_island(c: CanvasItem, center: Vector2, w: float, rng: RandomNumberGenerator) -> void:
	var half := w * 0.5
	var rock := Color("8d9c9b")
	var rock_dark := Color("778887")
	var depth := w * 0.55
	var poly := PackedVector2Array([
		center + Vector2(-half, 0), center + Vector2(-half * 0.5, -14), center + Vector2(half * 0.5, -14), center + Vector2(half, 0),
		center + Vector2(half * 0.82, depth * 0.35), center + Vector2(half * 0.5, depth * 0.55),
		center + Vector2(half * 0.2, depth * 0.8), center + Vector2(0, depth), center + Vector2(-half * 0.2, depth * 0.78),
		center + Vector2(-half * 0.5, depth * 0.5), center + Vector2(-half * 0.82, depth * 0.3),
	])
	c.draw_polygon(poly, PackedColorArray([rock, rock, rock, rock, rock_dark, rock_dark, rock_dark, rock_dark, rock_dark, rock_dark, rock_dark]))
	var cap := PackedVector2Array([
		center + Vector2(-half - 4, 2), center + Vector2(-half * 0.5, -18), center + Vector2(half * 0.5, -18), center + Vector2(half + 4, 2),
		center + Vector2(half * 0.5, 12), center + Vector2(-half * 0.5, 12),
	])
	c.draw_colored_polygon(cap, Color("60805a"))
	c.draw_polyline(PackedVector2Array([cap[0], cap[1], cap[2], cap[3]]), Color("89a273"), 4.0, true)
	for i in 3:
		var tx := center.x + rng.randf_range(-half * 0.6, half * 0.6)
		var r := rng.randf_range(12.0, 20.0)
		c.draw_circle(Vector2(tx, center.y - 20.0 - r * 0.4), r, Color("476a47"))
	# A thin waterfall pours off some islands.
	if int(w) % 2 == 0:
		c.draw_line(center + Vector2(half * 0.9, 6), center + Vector2(half * 0.9, depth * 1.8), Color(0.85, 0.96, 1.0, 0.55), 4.0)


func _paint_windmill(c: CanvasItem) -> void:
	var tower := PackedVector2Array([Vector2(-18, 0), Vector2(18, 0), Vector2(11, -92), Vector2(-11, -92)])
	c.draw_colored_polygon(tower, Color("efe8d3"))
	c.draw_polyline(PackedVector2Array([tower[0], tower[3], tower[2], tower[1]]), Color("b7ac92"), 3.0, true)
	c.draw_colored_polygon(PackedVector2Array([Vector2(-16, -90), Vector2(16, -90), Vector2(0, -122)]), Color("d0715a"))
	c.draw_rect(Rect2(-6, -22, 12, 22), Color("9c7a52"))
	var hub := Vector2(0, -96)
	for i in 4:
		var a := _elapsed * 0.7 + float(i) * PI * 0.5
		var dir := Vector2(cos(a), sin(a))
		var side := Vector2(-dir.y, dir.x)
		c.draw_colored_polygon(PackedVector2Array([hub + dir * 8.0, hub + dir * 66.0, hub + dir * 66.0 + side * 15.0, hub + dir * 8.0 + side * 15.0]), Color("fbf7ea"))
		c.draw_line(hub, hub + dir * 66.0, Color("8d7757"), 3.0)
	c.draw_circle(hub, 6.0, Color("8d7757"))


func _paint_birds(c: CanvasItem) -> void:
	var flocks := [
		[0.0, 1060.0, 26.0, 5, 0.0], [2400.0, 800.0, 20.0, 4, 1.7], [4100.0, 1380.0, 32.0, 6, 3.1],
	]
	for f in flocks:
		var cx := fposmod(float(f[0]) + _elapsed * float(f[2]), 5400.0) - 1200.0
		var cy := float(f[1]) + sin(_elapsed * 0.35 + float(f[4])) * 24.0
		for b in int(f[3]):
			var bx := cx - float(b) * 34.0
			var by := cy + sin(float(b) * 2.1 + float(f[4])) * 22.0 + float(b % 2) * 14.0
			var flap := sin(_elapsed * 8.5 + float(b) * 1.3 + float(f[4])) * 6.0
			c.draw_polyline(PackedVector2Array([Vector2(bx - 10.0, by - 2.0 - flap), Vector2(bx, by + 2.0), Vector2(bx + 10.0, by - 2.0 - flap)]),
				Color("3a4a63"), 2.6, true)


# =====================================================================
#  TERRAIN PAINTING (once)
# =====================================================================

func _paint_terrain(c: CanvasItem) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 5150
	for pillar in _pillars:
		_paint_pillar(c, pillar as PackedVector2Array)
	for land in _lands:
		_paint_land(c, land, rng)
	_paint_stream(c)
	_paint_west_bunker(c)
	_paint_east_bunker(c)
	_paint_props(c)
	for b in _bushes:
		_paint_bush(c, b as Vector3)
	for hb in _hide_bushes:
		_paint_hide_bush_back(c, hb as Dictionary)
	for t in _trees:
		_paint_trunk(c, t["pos"] as Vector2, float(t["s"]))
	for f in _flowers:
		_paint_flower(c, f["pos"] as Vector2, f["color"] as Color, float(f["h"]))
	for fl in _flags:
		var base: Vector2 = fl["base"]
		var h: float = fl["h"]
		c.draw_line(base, base + Vector2(0, -h), Color("4b3a2b"), 5.0)
		c.draw_circle(base + Vector2(0, -h), 6.0, Color("f0d173"))
		c.draw_circle(base + Vector2(0, -h), 6.0, OUTLINE, false, 1.0, true)


func _paint_pillar(c: CanvasItem, poly: PackedVector2Array) -> void:
	c.draw_colored_polygon(poly, PILLAR_FILL)
	var closed := PackedVector2Array(poly)
	closed.append(poly[0])
	c.draw_polyline(closed, PILLAR_EDGE, 5.0, true)
	var lo := poly[0].y
	var hi := poly[0].y
	for p in poly:
		lo = minf(lo, p.y)
		hi = maxf(hi, p.y)
	var y := lo + 70.0
	while y < hi - 40.0:
		c.draw_line(Vector2(poly[0].x + 60, y), Vector2(poly[1].x - 60, y + 14.0), Color(0.2, 0.12, 0.06, 0.2), 3.0)
		y += 90.0


func _paint_land(c: CanvasItem, land: Dictionary, rng: RandomNumberGenerator) -> void:
	var poly: PackedVector2Array = land["poly"]
	var top: PackedVector2Array = land["top"]
	var bottom: PackedVector2Array = land["bottom"]
	var x0 := top[0].x
	var x1 := top[top.size() - 1].x
	var colors := PackedColorArray()
	for i in poly.size():
		colors.append(SOIL_TOP if i < top.size() else SOIL_BOTTOM)
	c.draw_polygon(poly, colors)
	# Earth strata
	for k in 3:
		var off := 66.0 + float(k) * 62.0
		var seg := PackedVector2Array()
		var x := x0 + 12.0
		while x < x1 - 12.0:
			if _interp_y(bottom, x) - _interp_y(top, x) > off + 30.0:
				seg.append(Vector2(x, _interp_y(top, x) + off + sin(x * 0.011 + float(k) * 1.7) * 9.0))
			else:
				if seg.size() > 1:
					c.draw_polyline(seg, STRATA, 4.0, true)
				seg = PackedVector2Array()
			x += 36.0
		if seg.size() > 1:
			c.draw_polyline(seg, STRATA, 4.0, true)
	# Rocks embedded in the soil
	var count := int((x1 - x0) / 60.0)
	for i in count:
		var rx := rng.randf_range(x0 + 20.0, x1 - 20.0)
		var ty := _interp_y(top, rx)
		var th := _interp_y(bottom, rx) - ty
		if th < 90.0:
			continue
		var ry := ty + rng.randf_range(42.0, th - 28.0)
		_paint_rock(c, Vector2(rx, ry), rng.randf_range(5.0, 13.0), rng)
	# Outline
	var closed := PackedVector2Array(poly)
	closed.append(poly[0])
	c.draw_polyline(closed, OUTLINE, 2.5, true)
	# Lumpy stones along the underside
	for i in range(1, bottom.size() - 1):
		var r := rng.randf_range(9.0, 17.0)
		_paint_rock(c, bottom[i] + Vector2(rng.randf_range(-6.0, 6.0), -r * 0.45), r, rng)
	# Hanging roots and vines under islands
	if land["kind"] != "ground":
		for i in range(1, bottom.size() - 1):
			if rng.randf() < 0.45:
				var p := bottom[i]
				var len := rng.randf_range(40.0, 105.0)
				var root := PackedVector2Array([p, p + Vector2(rng.randf_range(-8.0, 8.0), len * 0.35),
					p + Vector2(rng.randf_range(-14.0, 14.0), len * 0.7), p + Vector2(rng.randf_range(-12.0, 12.0), len)])
				c.draw_polyline(root, Color("4e3523"), 5.0, true)
				c.draw_polyline(root, Color("7d5a37"), 2.4, true)
				c.draw_circle(root[3], 5.0, GRASS_DARK)
				c.draw_circle(root[2] + Vector2(4.0, 0.0), 4.0, GRASS)
	# Grass
	_paint_grass(c, top, rng)


func _paint_rock(c: CanvasItem, center: Vector2, r: float, rng: RandomNumberGenerator) -> void:
	var n := rng.randi_range(6, 8)
	var pts := PackedVector2Array()
	for i in n:
		var a := TAU * float(i) / float(n) + rng.randf_range(-0.2, 0.2)
		var rr := r * rng.randf_range(0.78, 1.1)
		pts.append(center + Vector2(cos(a) * rr, sin(a) * rr * 0.82))
	var col: Color = ROCK_COLORS[rng.randi_range(0, ROCK_COLORS.size() - 1)]
	c.draw_colored_polygon(pts, col)
	c.draw_colored_polygon(PackedVector2Array([pts[0], pts[1], pts[2], center + Vector2(-r * 0.1, 0.0)]), Color(1, 1, 1, 0.22))
	var closed := PackedVector2Array(pts)
	closed.append(pts[0])
	c.draw_polyline(closed, ROCK_EDGE, 2.0, true)


func _paint_grass(c: CanvasItem, top: PackedVector2Array, rng: RandomNumberGenerator) -> void:
	var x0 := top[0].x
	var x1 := top[top.size() - 1].x
	var path := PackedVector2Array()
	var x := x0
	while x < x1:
		path.append(Vector2(x, _interp_y(top, x) + sin(x * 0.09) * 1.4 + rng.randf_range(-0.8, 0.8)))
		x += 14.0
	path.append(Vector2(x1, top[top.size() - 1].y))
	c.draw_polyline(_shift(path, Vector2(0, 13)), GRASS_DARK, 26.0, true)
	c.draw_polyline(_shift(path, Vector2(0, 9)), GRASS, 18.0, true)
	c.draw_polyline(_shift(path, Vector2(0, 3)), GRASS_HI, 5.0, true)
	# Hanging fringe under the turf
	var fx := x0 + 14.0
	while fx < x1 - 14.0:
		var fy := _interp_y(top, fx) + 24.0
		c.draw_colored_polygon(PackedVector2Array([Vector2(fx - 5.0, fy - 3.0), Vector2(fx + 5.0, fy - 3.0), Vector2(fx + rng.randf_range(-2.0, 2.0), fy + rng.randf_range(6.0, 13.0))]), GRASS_DARK)
		fx += rng.randf_range(22.0, 40.0)
	c.draw_polyline(_shift(path, Vector2(0, -1)), GRASS_LINE, 3.0, true)
	# Spiky tufts along the edge
	var tx := x0 + 8.0
	while tx < x1 - 8.0:
		if not _in_bunker(tx):
			_paint_tuft(c, Vector2(tx, _interp_y(top, tx) + 2.0), rng)
		tx += rng.randf_range(15.0, 28.0)


func _shift(path: PackedVector2Array, offset: Vector2) -> PackedVector2Array:
	var out := PackedVector2Array()
	for p in path:
		out.append(p + offset)
	return out


func _paint_tuft(c: CanvasItem, base: Vector2, rng: RandomNumberGenerator) -> void:
	for j in 3:
		var dx := (float(j) - 1.0) * 5.0 + rng.randf_range(-2.0, 2.0)
		var h := rng.randf_range(9.0, 19.0)
		var tip := base + Vector2(dx + rng.randf_range(-4.0, 4.0), -h)
		var blade := PackedVector2Array([base + Vector2(dx - 4.0, 0.0), tip, base + Vector2(dx + 4.0, 0.0)])
		c.draw_colored_polygon(blade, GRASS if j % 2 == 0 else GRASS_HI)
		c.draw_polyline(PackedVector2Array([blade[0], blade[1], blade[2]]), GRASS_LINE, 1.3, true)


func _paint_stream(c: CanvasItem) -> void:
	# A thin stream running across the top of the centre island towards the waterfall.
	var land := _land("sky_center")
	var top: PackedVector2Array = land["top"]
	var pts := PackedVector2Array()
	var x := 2735.0
	while x <= 2950.0:
		pts.append(Vector2(x, _interp_y(top, x) + 7.0))
		x += 18.0
	c.draw_polyline(pts, Color("2a6684"), 11.0, true)
	c.draw_polyline(pts, Color("6aa8bb"), 7.0, true)
	# Rocky lip where the stream spills over.
	_paint_rock(c, Vector2(2944.0, 1204.0), 14.0, RandomNumberGenerator.new())


func _paint_trunk(c: CanvasItem, base: Vector2, s: float) -> void:
	_soft_shadow(c, base + Vector2(-16.0 * s, 2.0), 56.0 * s, 8.0 * s)
	var trunk := PackedVector2Array([
		base + Vector2(-12.0 * s, 4.0), base + Vector2(-8.0 * s, -20.0 * s), base + Vector2(-5.0 * s, -82.0 * s),
		base + Vector2(5.0 * s, -82.0 * s), base + Vector2(8.0 * s, -20.0 * s), base + Vector2(12.0 * s, 4.0)])
	c.draw_colored_polygon(trunk, Color("4d3a29"))
	# sunlit right side and bark furrows
	c.draw_colored_polygon(PackedVector2Array([
		base + Vector2(2.0 * s, 4.0), base + Vector2(3.0 * s, -82.0 * s), base + Vector2(5.0 * s, -82.0 * s),
		base + Vector2(8.0 * s, -20.0 * s), base + Vector2(12.0 * s, 4.0)]), Color("6c5238"))
	for i in 5:
		var fy := (-10.0 - float(i) * 14.0) * s
		c.draw_line(base + Vector2(-5.0 * s, fy), base + Vector2(-3.0 * s, fy - 9.0 * s), Color(0.1, 0.07, 0.04, 0.5), 1.5)
	c.draw_polyline(PackedVector2Array([trunk[0], trunk[1], trunk[2], trunk[3], trunk[4], trunk[5]]), OUTLINE, 1.2, true)


func _paint_flower(c: CanvasItem, p: Vector2, col: Color, h: float) -> void:
	var hh := h * 0.7
	c.draw_line(p, p + Vector2(0, -hh), GRASS_LINE, 1.4)
	for i in 5:
		var a := TAU * float(i) / 5.0
		c.draw_circle(p + Vector2(0, -hh) + Vector2(cos(a), sin(a)) * 2.4, 1.9, col)
	c.draw_circle(p + Vector2(0, -hh), 1.5, Color("b8872a"))


func _paint_bush(c: CanvasItem, b: Vector3) -> void:
	var p := Vector2(b.x, b.y + 3.0)
	var s := b.z
	_soft_shadow(c, p + Vector2(-6.0 * s, 0.0), 44.0 * s, 7.0 * s)
	var rng := RandomNumberGenerator.new()
	rng.seed = int(b.x * 7.0 + b.y)
	var leaves: Array = []
	for i in 52:
		var a := rng.randf() * PI
		var r := sqrt(rng.randf())
		var xl := -cos(a) * r
		var yl := sin(a) * r
		var lit := clampf(0.18 + yl * 0.5 + xl * 0.25 + rng.randf() * 0.3, 0.0, 1.0)
		leaves.append([p + Vector2(xl * 34.0, -yl * 30.0 - 2.0) * s, rng.randf() * TAU, rng.randf_range(9.0, 15.0) * s, lit])
	leaves.sort_custom(func(l1, l2): return float(l1[3]) < float(l2[3]))
	c.draw_colored_polygon(_dome_points(p, 30.0 * s, 24.0 * s, 14, 0.0), Color(0.08, 0.14, 0.07))
	for lf in leaves:
		c.draw_colored_polygon(_leaf_poly(lf[0] as Vector2, float(lf[1]), float(lf[2])), _leaf_color(float(lf[3])))


func _paint_props(c: CanvasItem) -> void:
	# West side
	_paint_sandbags(c, Vector2(520.0, WEST_FLOOR_Y - 34.0))
	_paint_crate(c, Vector2(610.0, WEST_FLOOR_Y - 52.0), 52.0)
	_paint_crate(c, Vector2(666.0, WEST_FLOOR_Y - 40.0), 40.0)
	_paint_barrel(c, Vector2(880.0, WEST_FLOOR_Y - 2.0))
	# Basin
	_paint_crate(c, Vector2(1600.0, BASIN_Y - 46.0), 46.0)
	_paint_barrel(c, Vector2(1675.0, BASIN_Y - 2.0))
	_paint_sandbags(c, Vector2(3300.0, BASIN_Y - 34.0))
	_paint_crate(c, Vector2(3420.0, BASIN_Y - 46.0), 46.0)
	# East side
	_paint_sandbags(c, Vector2(4560.0, EAST_FLOOR_Y - 34.0))
	_paint_crate(c, Vector2(4480.0, EAST_FLOOR_Y - 50.0), 50.0)
	_paint_barrel(c, Vector2(4300.0, EAST_FLOOR_Y - 2.0))
	# Small fence on the west island
	_paint_fence(c, Vector2(820.0, _interp_y((_land("sky_west"))["top"], 820.0)), 4)
	_paint_fence(c, Vector2(4260.0, _interp_y((_land("sky_east"))["top"], 4260.0)), 4)


func _paint_crate(c: CanvasItem, pos: Vector2, size: float) -> void:
	var r := Rect2(pos, Vector2(size, size))
	c.draw_rect(Rect2(pos + Vector2(6, 7), r.size), Color(0.1, 0.1, 0.05, 0.18))
	c.draw_rect(r, Color("9a7448"))
	c.draw_rect(Rect2(pos + Vector2(3, 3), Vector2(size - 6, size * 0.14)), Color("b8905c"))
	c.draw_line(pos + Vector2(6, 6), pos + Vector2(size - 6, size - 6), Color("8a5d2e"), 4.0)
	c.draw_line(pos + Vector2(size - 6, 6), pos + Vector2(6, size - 6), Color("8a5d2e"), 4.0)
	c.draw_rect(r, Color("5a3a1c"), false, 3.0)


func _paint_barrel(c: CanvasItem, foot: Vector2) -> void:
	var w := 38.0
	var h := 52.0
	var body := Rect2(foot.x - w * 0.5, foot.y - h, w, h)
	c.draw_rect(body, Color("9c4a38"))
	c.draw_rect(Rect2(body.position.x + 4.0, body.position.y, 7.0, h), Color(1, 1, 1, 0.22))
	c.draw_rect(Rect2(body.position.x, body.position.y + 10.0, w, 5.0), Color("7b2f26"))
	c.draw_rect(Rect2(body.position.x, body.end.y - 15.0, w, 5.0), Color("7b2f26"))
	c.draw_rect(body, Color("4f2018"), false, 3.0)
	c.draw_rect(Rect2(body.position.x - 1.0, body.position.y - 4.0, w + 2.0, 6.0), Color("b96a58"))


func _paint_sandbags(c: CanvasItem, pos: Vector2) -> void:
	for row in 2:
		for col in 4 - row:
			var center := pos + Vector2(float(col) * 30.0 + float(row) * 15.0 + 16.0, float(row) * -17.0 + 24.0)
			c.draw_set_transform(center, 0.0, Vector2(1.0, 0.62))
			c.draw_circle(Vector2.ZERO, 17.0, Color("b9aa7c"))
			c.draw_circle(Vector2.ZERO, 17.0, Color("6b5d3a"), false, 2.0, true)
			c.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _paint_fence(c: CanvasItem, base: Vector2, posts: int) -> void:
	for i in posts:
		var x := base.x + float(i) * 34.0
		c.draw_rect(Rect2(x - 4.0, base.y - 42.0, 8.0, 44.0), Color("b98a56"))
		c.draw_rect(Rect2(x - 4.0, base.y - 42.0, 8.0, 44.0), Color("5a3a1c"), false, 2.0)
	c.draw_rect(Rect2(base.x - 4.0, base.y - 34.0, float(posts - 1) * 34.0 + 8.0, 7.0), Color("d0a470"))
	c.draw_rect(Rect2(base.x - 4.0, base.y - 34.0, float(posts - 1) * 34.0 + 8.0, 7.0), Color("5a3a1c"), false, 2.0)
	c.draw_rect(Rect2(base.x - 4.0, base.y - 18.0, float(posts - 1) * 34.0 + 8.0, 7.0), Color("d0a470"))
	c.draw_rect(Rect2(base.x - 4.0, base.y - 18.0, float(posts - 1) * 34.0 + 8.0, 7.0), Color("5a3a1c"), false, 2.0)


# ---------- bunkers ----------

func _paint_window(c: CanvasItem, win: Rect2, floor_y: float) -> void:
	c.draw_rect(Rect2(win.position - Vector2(5, 5), win.size + Vector2(10, 10)), Color("2b353b"))
	c.draw_rect(win, Color("6f98a8"))
	c.draw_rect(Rect2(win.position, Vector2(win.size.x, win.size.y * 0.45)), Color("9cc0cf"))
	c.draw_line(Vector2(win.position.x + win.size.x * 0.5, win.position.y), Vector2(win.position.x + win.size.x * 0.5, win.end.y), Color("2b353b"), 4.0)
	c.draw_line(Vector2(win.position.x, win.position.y + win.size.y * 0.5), Vector2(win.end.x, win.position.y + win.size.y * 0.5), Color("2b353b"), 4.0)
	c.draw_colored_polygon(PackedVector2Array([win.position + Vector2(8, 4), win.position + Vector2(24, 4), win.position + Vector2(12, 24), win.position + Vector2(4, 24)]), Color(1, 1, 1, 0.55))
	# warm light shaft falling on the floor
	c.draw_colored_polygon(PackedVector2Array([win.position + Vector2(0, win.size.y), win.end, Vector2(win.end.x + 80.0, floor_y), Vector2(win.position.x + 30.0, floor_y)]), Color(1.0, 0.95, 0.68, 0.11))


func _paint_west_bunker(c: CanvasItem) -> void:
	var fy := WEST_FLOOR_Y
	var roof := WEST_ROOF
	var inner := Rect2(0, roof.end.y, WEST_ROOM_END, fy - roof.end.y)
	c.draw_rect(inner, Color("5b6a72"))
	for i in 5:
		c.draw_rect(Rect2(10.0 + float(i) * 94.0, inner.position.y + 8.0, 84.0, inner.size.y - 12.0), Color("647780"))
	c.draw_rect(Rect2(inner.position, Vector2(inner.size.x, 20.0)), Color(0, 0, 0, 0.28))
	for i in 3:
		_paint_window(c, Rect2(60.0 + float(i) * 132.0, inner.position.y + 30.0, 78.0, 52.0), fy)
	# floor slab
	c.draw_rect(Rect2(0, fy - 3.0, WEST_ROOM_END + 10.0, 22.0), Color("8f9794"))
	c.draw_line(Vector2(0, fy - 3.0), Vector2(WEST_ROOM_END + 10.0, fy - 3.0), Color("c8cfcb"), 3.0)
	# bench, ammo crates, hanging lamp
	c.draw_rect(Rect2(36.0, fy - 34.0, 120.0, 10.0), Color("a37a47"))
	c.draw_rect(Rect2(46.0, fy - 24.0, 8.0, 22.0), Color("6d4e2c"))
	c.draw_rect(Rect2(138.0, fy - 24.0, 8.0, 22.0), Color("6d4e2c"))
	c.draw_rect(Rect2(380.0, fy - 36.0, 62.0, 34.0), Color("6f7d4f"))
	c.draw_rect(Rect2(380.0, fy - 36.0, 62.0, 34.0), Color("2f3a22"), false, 3.0)
	c.draw_line(Vector2(290.0, inner.position.y), Vector2(290.0, inner.position.y + 24.0), Color("2b353b"), 2.0)
	c.draw_circle(Vector2(290.0, inner.position.y + 30.0), 9.0, Color("ffe08a"))
	c.draw_circle(Vector2(290.0, inner.position.y + 30.0), 22.0, Color(1.0, 0.92, 0.55, 0.14))
	# stone-brick roof block
	c.draw_rect(roof, Color("a6aea6"))
	var row := 0
	var by := roof.position.y + 16.0
	while by < roof.end.y:
		c.draw_line(Vector2(roof.position.x, by), Vector2(roof.end.x, by), Color(0.2, 0.22, 0.2, 0.45), 2.0)
		var bx := roof.position.x + (22.0 if row % 2 == 0 else 54.0)
		while bx < roof.end.x:
			c.draw_line(Vector2(bx, by), Vector2(bx, minf(by + 16.0, roof.end.y)), Color(0.2, 0.22, 0.2, 0.4), 2.0)
			bx += 64.0
		by += 16.0
		row += 1
	c.draw_rect(Rect2(roof.position, Vector2(roof.size.x, 8.0)), Color("d4dad2"))
	c.draw_rect(Rect2(roof.position.x, roof.end.y - 7.0, roof.size.x, 7.0), Color("6d766f"))
	c.draw_rect(roof, OUTLINE, false, 2.0)
	# sandbag parapet and little antenna on the roof
	_paint_sandbags(c, Vector2(40.0, roof.position.y - 20.0))
	c.draw_line(Vector2(250.0, roof.position.y), Vector2(250.0, roof.position.y - 70.0), Color("44525a"), 4.0)
	c.draw_line(Vector2(232.0, roof.position.y - 52.0), Vector2(268.0, roof.position.y - 52.0), Color("44525a"), 3.0)
	c.draw_circle(Vector2(250.0, roof.position.y - 72.0), 4.0, Color("ff5a47"))


func _paint_east_bunker(c: CanvasItem) -> void:
	var fy := EAST_FLOOR_Y
	var roof := EAST_ROOF
	var inner := Rect2(EAST_ROOM_START - 8.0, roof.end.y, MAP_W - EAST_ROOM_START + 8.0, fy - roof.end.y)
	c.draw_rect(inner, Color("6a4d34"))
	var px := inner.position.x
	while px < MAP_W:
		c.draw_line(Vector2(px, inner.position.y), Vector2(px, fy), Color(0.15, 0.08, 0.03, 0.4), 3.0)
		px += 38.0
	c.draw_rect(Rect2(inner.position, Vector2(inner.size.x, 20.0)), Color(0, 0, 0, 0.28))
	for i in 3:
		_paint_window(c, Rect2(4790.0 + float(i) * 132.0, inner.position.y + 26.0, 78.0, 50.0), fy)
	c.draw_rect(Rect2(EAST_ROOM_START - 8.0, fy - 3.0, MAP_W - EAST_ROOM_START + 8.0, 22.0), Color("8d6a45"))
	c.draw_line(Vector2(EAST_ROOM_START - 8.0, fy - 3.0), Vector2(MAP_W, fy - 3.0), Color("d3ae7a"), 3.0)
	# table with a lantern, stacked crates
	c.draw_rect(Rect2(4800.0, fy - 38.0, 110.0, 9.0), Color("b98a56"))
	c.draw_rect(Rect2(4812.0, fy - 30.0, 8.0, 28.0), Color("6d4e2c"))
	c.draw_rect(Rect2(4890.0, fy - 30.0, 8.0, 28.0), Color("6d4e2c"))
	c.draw_rect(Rect2(4838.0, fy - 54.0, 18.0, 16.0), Color("ffe08a"))
	c.draw_rect(Rect2(4838.0, fy - 54.0, 18.0, 16.0), Color("3a2a1c"), false, 2.0)
	c.draw_circle(Vector2(4847.0, fy - 46.0), 28.0, Color(1.0, 0.92, 0.55, 0.14))
	_paint_crate(c, Vector2(5110.0, fy - 52.0), 52.0)
	_paint_crate(c, Vector2(5060.0, fy - 40.0), 40.0)
	# stone chimney (behind the roof logs)
	c.draw_rect(Rect2(5046.0, 1876.0, 44.0, 82.0), Color("9a9086"))
	c.draw_rect(Rect2(5046.0, 1876.0, 44.0, 82.0), OUTLINE, false, 1.5)
	for i in 3:
		c.draw_line(Vector2(5046.0, 1894.0 + float(i) * 18.0), Vector2(5090.0, 1894.0 + float(i) * 18.0), Color(0.2, 0.18, 0.15, 0.4), 2.0)
	c.draw_rect(Rect2(5040.0, 1868.0, 56.0, 12.0), Color("7d746b"))
	c.draw_rect(Rect2(5040.0, 1868.0, 56.0, 12.0), OUTLINE, false, 1.5)
	# log roof: three stacked logs with visible ring ends
	var log_h := roof.size.y / 3.0
	for i in 3:
		var ly := roof.position.y + float(i) * log_h
		var col := Color("a9753f") if i % 2 == 0 else Color("94622f")
		c.draw_rect(Rect2(roof.position.x, ly, roof.size.x, log_h), col)
		c.draw_rect(Rect2(roof.position.x, ly, roof.size.x, 5.0), Color(1, 1, 1, 0.18))
		c.draw_rect(Rect2(roof.position.x, ly, roof.size.x, log_h), OUTLINE, false, 1.5)
		var end := Vector2(roof.position.x, ly + log_h * 0.5)
		c.draw_circle(end, log_h * 0.5, Color("d9ad74"))
		c.draw_circle(end, log_h * 0.32, Color("b98a52"))
		c.draw_circle(end, log_h * 0.5, OUTLINE, false, 1.2, true)
		var gx := roof.position.x + 40.0 + float(i) * 23.0
		while gx < roof.end.x - 20.0:
			c.draw_line(Vector2(gx, ly + 5.0), Vector2(gx + 26.0, ly + 5.0), Color(0.25, 0.14, 0.05, 0.35), 2.0)
			gx += 91.0
	# sandbags on the roof, wooden sign
	_paint_sandbags(c, Vector2(4830.0, roof.position.y - 20.0))
	c.draw_rect(Rect2(4985.0, roof.position.y - 38.0, 6.0, 38.0), Color("6d4e2c"))
	c.draw_rect(Rect2(4955.0, roof.position.y - 62.0, 66.0, 26.0), Color("d0a470"))
	c.draw_rect(Rect2(4955.0, roof.position.y - 62.0, 66.0, 26.0), Color("5a3a1c"), false, 3.0)
	c.draw_line(Vector2(4965.0, roof.position.y - 50.0), Vector2(5011.0, roof.position.y - 50.0), Color("5a3a1c"), 3.0)
	c.draw_line(Vector2(4965.0, roof.position.y - 43.0), Vector2(4998.0, roof.position.y - 43.0), Color("5a3a1c"), 3.0)


# =====================================================================
#  ANIMATED WORLD FX (redrawn every frame, only what is on screen)
# =====================================================================

func _paint_fx(c: CanvasItem) -> void:
	_paint_cloud_shadows(c)
	_paint_pond_and_fall(c)
	for t in _trees:
		var p: Vector2 = t["pos"]
		if _view.has_point(p + Vector2(0, -90)):
			_paint_canopy(c, p, float(t["s"]))
	for fl in _flags:
		var base: Vector2 = fl["base"]
		if _view.has_point(base + Vector2(40, -60)):
			_paint_flag(c, base, float(fl["h"]), fl["color"] as Color)
	_paint_grass_blades(c)
	_paint_butterflies(c)


func _paint_cloud_shadows(c: CanvasItem) -> void:
	if _lite:
		return          # polygon clipping every frame: the single most expensive CPU job in this map
	for i in 3:
		var cx := fposmod(_elapsed * (12.0 + float(i) * 3.0) + float(i) * 1700.0, MAP_W + 2000.0) - 1000.0
		var cy := 1400.0 + float(i % 2) * 520.0 + float(i) * 60.0
		var full := Vector2(560.0, 360.0)
		var box := Rect2(cx - full.x, cy - full.y, full.x * 2.0, full.y * 2.0)
		if not _view.intersects(box):
			continue
		# three nested ellipses give a soft edge
		for layer in 3:
			var radii := full * (1.0 - float(layer) * 0.24)
			var ellipse := PackedVector2Array()
			for k in 40:
				var a := TAU * float(k) / 40.0
				ellipse.append(Vector2(cx + cos(a) * radii.x, cy + sin(a) * radii.y))
			for land in _lands:
				if not (land["rect"] as Rect2).intersects(box):
					continue
				var pieces := Geometry2D.intersect_polygons(land["poly"] as PackedVector2Array, ellipse)
				for piece in pieces:
					if piece.size() >= 3 and Geometry2D.triangulate_polygon(piece).size() >= 3:
						c.draw_colored_polygon(piece, Color(0.08, 0.16, 0.32, 0.045))


func _paint_pond_and_fall(c: CanvasItem) -> void:
	var fall_bottom := POND_SURFACE_Y
	var near_view := _view.intersects(Rect2(POND_LEFT - 60.0, FALL_TOP_Y - 40.0, POND_RIGHT - POND_LEFT + 120.0, fall_bottom - FALL_TOP_Y + 80.0))
	if not near_view:
		return
	# Pond
	var pond := PackedVector2Array([Vector2(POND_LEFT, POND_SURFACE_Y), Vector2(POND_RIGHT, POND_SURFACE_Y), Vector2(POND_RIGHT - 34.0, 2369.0), Vector2(POND_LEFT + 36.0, 2369.0)])
	c.draw_colored_polygon(pond, Color("2f6f8f"))
	c.draw_colored_polygon(PackedVector2Array([pond[0], pond[1], pond[1] + Vector2(-8.0, 8.0), pond[0] + Vector2(8.0, 8.0)]), Color("78b4c4"))
	for i in 6:
		var sx := POND_LEFT + 24.0 + fposmod(float(i) * 41.0 + _elapsed * 9.0, POND_RIGHT - POND_LEFT - 48.0)
		var sw := 10.0 + float(i % 3) * 6.0
		c.draw_line(Vector2(sx, POND_SURFACE_Y + 5.0 + float(i % 3) * 5.0), Vector2(sx + sw, POND_SURFACE_Y + 5.0 + float(i % 3) * 5.0), Color(1, 1, 1, 0.55), 2.0)
	# Waterfall ribbon
	var w := 24.0
	var ribbon := PackedVector2Array([Vector2(FALL_X, FALL_TOP_Y), Vector2(FALL_X + w, FALL_TOP_Y + 6.0), Vector2(FALL_X + w - 2.0, fall_bottom), Vector2(FALL_X + 2.0, fall_bottom)])
	c.draw_colored_polygon(ribbon, Color(0.62, 0.80, 0.88, 0.72))
	c.draw_line(Vector2(FALL_X + 2.0, FALL_TOP_Y + 4.0), Vector2(FALL_X + 2.0, fall_bottom), Color(0.85, 0.96, 1.0, 0.9), 3.0)
	var span := fall_bottom - FALL_TOP_Y
	for i in 16:
		var y := FALL_TOP_Y + fposmod(float(i) * 73.0 + _elapsed * 260.0, span)
		var x := FALL_X + 5.0 + float((i * 7) % 3) * 6.0
		c.draw_line(Vector2(x, y), Vector2(x, minf(y + 38.0, fall_bottom)), Color(1, 1, 1, 0.7), 3.0)
	# Foam where it lands
	for i in 5:
		var r := 7.0 + 4.0 * sin(_elapsed * 6.0 + float(i) * 1.4)
		c.draw_circle(Vector2(FALL_X + 4.0 + float(i) * 5.0, fall_bottom - 1.0), r, Color(1, 1, 1, 0.75))


func _paint_canopy(c: CanvasItem, base: Vector2, s: float) -> void:
	var sway := sin(_elapsed * 1.15 + base.x * 0.013) * 3.0 * s
	var top := base + Vector2(sway, -92.0 * s)
	var blobs := [Vector3(-34, 10, 32), Vector3(32, 12, 30), Vector3(0, -12, 40), Vector3(-18, -38, 28), Vector3(22, -34, 28), Vector3(0, 22, 30)]
	# a dark body first, so no sky shows through between the leaves
	for b in blobs:
		c.draw_circle(top + Vector2(float(b.x), float(b.y)) * s, float(b.z) * 0.92 * s, Color(0.10, 0.18, 0.09))
	var n := 0
	for b in blobs:
		for k in 22:
			var h1 := _hash01(float(n) * 1.37 + base.x * 0.01)
			var h2 := _hash01(float(n) * 2.11 + 7.3 + base.x * 0.013)
			var h3 := _hash01(float(n) * 3.77 + 3.1)
			n += 1
			var a := h1 * TAU
			var r := sqrt(h2) * float(b.z) * 1.02
			var off := Vector2(cos(a) * r, sin(a) * r * 0.9)
			var wob := Vector2(sin(_elapsed * 1.9 + float(n) * 0.7) * 1.6, cos(_elapsed * 1.5 + float(n) * 0.5) * 1.2) * s
			var center := top + (Vector2(float(b.x), float(b.y)) + off) * s + wob
			var lit := clampf(0.5 - off.y / (float(b.z) * 2.0) + (off.x / (float(b.z) * 3.0)) * 0.6 + (h3 - 0.5) * 0.35, 0.0, 1.0)
			c.draw_colored_polygon(_leaf_poly(center, h3 * TAU, 15.0 * s), _leaf_color(lit))


func _paint_flag(c: CanvasItem, base: Vector2, h: float, col: Color) -> void:
	var tip := base + Vector2(0.0, -h + 5.0)
	var upper := PackedVector2Array()
	var lower := PackedVector2Array()
	var n := 9
	for i in range(n + 1):
		var u := float(i) / float(n)
		var wave := sin(_elapsed * 5.2 - u * 5.5 + base.x * 0.1) * 6.0 * u
		upper.append(tip + Vector2(u * 88.0, wave))
		lower.append(tip + Vector2(u * 88.0, 46.0 + wave * 1.15))
	lower.reverse()
	var poly := PackedVector2Array(upper)
	poly.append_array(lower)
	c.draw_colored_polygon(poly, col)
	# lighter band and a dark outline
	var band := PackedVector2Array()
	for i in range(n + 1):
		band.append(upper[i] + Vector2(0.0, 15.0))
	c.draw_polyline(band, col.lightened(0.28), 9.0, true)
	var closed := PackedVector2Array(poly)
	closed.append(poly[0])
	c.draw_polyline(closed, OUTLINE, 1.2, true)


func _paint_grass_blades(c: CanvasItem) -> void:
	var gust := 0.6 + 0.4 * sin(_elapsed * 0.45)
	var step := 2 if _lite else 1
	for i in range(0, _blade_base.size(), step):
		var b := _blade_base[i]
		if not _view.has_point(b):
			continue
		var m := _blade_motion(i, gust)
		var h := _blade_h[i] * m.y * (1.15 if _lite else 1.0)
		var tip := b + Vector2(m.x + _blade_tilt[i] * h, -h)
		var col := GRASS
		match _blade_color[i]:
			1:
				col = GRASS_HI
			2:
				col = GRASS_DARK
		var blade := PackedVector2Array([b + Vector2(-4.0, 2.0), tip, b + Vector2(4.0, 2.0)])
		c.draw_polygon(blade, PackedColorArray([col.darkened(0.35), col.lightened(0.12), col.darkened(0.35)]))
		if not _lite:
			c.draw_line(blade[0], blade[1], GRASS_LINE, 1.0, true)
			c.draw_line(blade[1], blade[2], GRASS_LINE, 1.0, true)


func _paint_butterflies(c: CanvasItem) -> void:
	for bf in _butterflies:
		var center: Vector2 = bf["center"]
		var r: float = bf["r"]
		var t := _elapsed * float(bf["speed"]) + float(bf["phase"])
		var p := center + Vector2(sin(t) * r, sin(t * 2.0) * r * 0.35 + cos(t * 0.7) * r * 0.25)
		if not _view.has_point(p):
			continue
		var col: Color = bf["color"]
		var flap := absf(sin(_elapsed * 13.0 + float(bf["phase"])))
		var wing := 7.0
		c.draw_set_transform(p, 0.0, Vector2(maxf(flap, 0.18), 1.0))
		c.draw_circle(Vector2(-wing * 0.7, -2.0), wing * 0.8, col)
		c.draw_circle(Vector2(wing * 0.7, -2.0), wing * 0.8, col)
		c.draw_circle(Vector2(-wing * 0.5, 3.0), wing * 0.55, col.darkened(0.12))
		c.draw_circle(Vector2(wing * 0.5, 3.0), wing * 0.55, col.darkened(0.12))
		c.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		c.draw_line(p + Vector2(0, -5), p + Vector2(0, 6), Color("3a2a1c"), 2.0)


# =====================================================================
#  FOLIAGE HELPERS
# =====================================================================

func _hash01(x: float) -> float:
	return fposmod(sin(x * 12.9898) * 43758.5453, 1.0)


func _leaf_color(lit: float) -> Color:
	if lit < 0.5:
		return LEAF_DEEP.lerp(LEAF, lit * 2.0)
	return LEAF.lerp(LEAF_HI, (lit - 0.5) * 2.0)


func _leaf_poly(p: Vector2, ang: float, size: float) -> PackedVector2Array:
	var d := Vector2(cos(ang), sin(ang))
	var n := Vector2(-d.y, d.x)
	return PackedVector2Array([
		p - d * size * 0.5, p - d * size * 0.12 + n * size * 0.24,
		p + d * size * 0.5, p - d * size * 0.12 - n * size * 0.24])


# Upper half of an ellipse, left to right (a flat base along the ground). `sway` leans the top.
func _dome_points(center: Vector2, half_w: float, h: float, n: int, sway: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in range(n + 1):
		var a := PI * float(i) / float(n)
		pts.append(center + Vector2(-cos(a) * half_w + sway * sin(a), -sin(a) * h))
	return pts


# A soft contact shadow made of a few stacked ellipses.
func _soft_shadow(c: CanvasItem, center: Vector2, half_w: float, half_h: float) -> void:
	c.draw_set_transform(center, 0.0, Vector2(1.0, half_h / maxf(half_w, 1.0)))
	for i in 4:
		c.draw_circle(Vector2.ZERO, half_w * (1.0 - float(i) * 0.2), Color(0.03, 0.04, 0.02, 0.10))
	c.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


# =====================================================================
#  GROUND CONTACT: grass reacts to people walking through it
# =====================================================================

func _collect_pushers() -> void:
	_pushers.clear()
	for n in get_tree().get_nodes_in_group("player"):
		_add_pusher(n)
	for n in get_tree().get_nodes_in_group("bot"):
		_add_pusher(n)


func _add_pusher(n: Node) -> void:
	var b := n as CharacterBody2D
	if b == null or (b.get("dead") == true) or (b.get("is_dead") == true):
		return
	var feet := b.global_position + Vector2(0.0, 24.0)
	var power := clampf(absf(b.velocity.x) / 300.0, 0.0, 1.0)
	if (b.get("jetpack_active") == true) or (b.get("_jetting") == true):
		power = 2.0                           # jetpack downwash blows the grass flat
	_pushers.append(Vector3(feet.x, feet.y, power))


# Returns Vector2(lean in px, height multiplier) for grass blade i.
func _blade_motion(i: int, gust: float) -> Vector2:
	var b := _blade_base[i]
	var h := _blade_h[i]
	var wind := sin(_elapsed * 1.9 + b.x * 0.012 + _blade_phase[i]) * 0.55 + sin(_elapsed * 0.7 + b.x * 0.003) * 0.45
	var lean := wind * h * 0.34 * gust + h * 0.18
	var squash := 1.0
	for entry in _pushers:
		var pu: Vector3 = entry
		var dx := b.x - pu.x
		var reach := 30.0 + pu.z * 34.0
		if absf(dx) < reach and absf(b.y - pu.y) < 70.0 + pu.z * 40.0:
			var f := 1.0 - absf(dx) / reach
			lean += (1.0 if dx >= 0.0 else -1.0) * f * f * (10.0 + pu.z * 26.0)
			squash = minf(squash, 1.0 - f * 0.35)
	return Vector2(lean, squash)


# =====================================================================
#  HIDE BUSHES
# =====================================================================

func _build_hide_bushes() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 7741
	var idx := 0
	for spot in HIDE_BUSH_SPOTS:
		var base := _surface(String(spot[0]), float(spot[1]))
		var leaves: Array = []
		for i in 190:
			var a := rng.randf() * PI
			var r := pow(rng.randf(), 0.6)
			var xl := -cos(a) * r
			var yl := sin(a) * r
			var lit := clampf(0.15 + yl * 0.5 + xl * 0.28 + rng.randf() * 0.3, 0.0, 1.0)
			leaves.append({
				"p": Vector2(xl * HIDE_W * 0.5, -yl * HIDE_H * 0.92),
				"a": rng.randf() * TAU, "s": rng.randf_range(11.0, 19.0), "ph": rng.randf() * TAU,
				"lit": lit, "c": _leaf_color(lit),
			})
		leaves.sort_custom(func(l1, l2): return float(l1["lit"]) < float(l2["lit"]))
		var area := Area2D.new()
		area.name = "HideBush%d" % idx
		area.position = base + Vector2(0.0, -32.0)
		area.monitorable = false
		area.add_to_group("hide_bush")
		var shape := CollisionShape2D.new()
		var rect := RectangleShape2D.new()
		rect.size = Vector2(130.0, 64.0)
		shape.shape = rect
		area.add_child(shape)
		add_child(area)
		area.body_entered.connect(_on_hide_bush_body_entered.bind(area))
		_hide_bushes.append({"pos": base, "area": area, "leaves": leaves, "rustle": 0.0, "fade": 1.0})
		idx += 1


func _on_hide_bush_body_entered(body: Node2D, area: Area2D) -> void:
	if body.get("visuals") == null:
		return                                # only characters (player and bots) can hide
	_attach_cover.call_deferred(body, area)


func _attach_cover(body: Node, area: Area2D) -> void:
	if is_instance_valid(body) and is_instance_valid(area):
		BushCover.attach(body).enter(area)


func _update_hide_bushes(delta: float) -> void:
	for bush in _hide_bushes:
		var area: Area2D = bush["area"]
		var target_rustle := 0.0
		var player_in := false
		for b in area.get_overlapping_bodies():
			var cb := b as CharacterBody2D
			if cb == null:
				continue
			target_rustle = maxf(target_rustle, clampf(absf(cb.velocity.x) / 240.0 + (0.3 if absf(cb.velocity.y) > 60.0 else 0.0), 0.0, 1.0))
			if cb.is_in_group("player"):
				player_in = true
		bush["rustle"] = lerpf(float(bush["rustle"]), target_rustle, 1.0 - exp(-7.0 * delta))
		# when YOU are inside, the foliage thins out so you can still see yourself
		bush["fade"] = lerpf(float(bush["fade"]), 0.6 if player_in else 1.0, 1.0 - exp(-8.0 * delta))


# Back layer (static): shadow and a dark hollow, so the bush has depth behind the characters.
func _paint_hide_bush_back(c: CanvasItem, bush: Dictionary) -> void:
	var p: Vector2 = bush["pos"]
	_soft_shadow(c, p + Vector2(-10.0, 2.0), HIDE_W * 0.56, 9.0)
	c.draw_colored_polygon(_dome_points(p, HIDE_W * 0.42, HIDE_H * 0.78, 18, 0.0), Color(0.05, 0.09, 0.05, 0.9))


# Front layer (every frame, over the characters): short grass at the feet + the bush foliage.
func _paint_front(c: CanvasItem) -> void:
	var gust := 0.6 + 0.4 * sin(_elapsed * 0.45)
	for i in range(0, _blade_base.size(), 6 if _lite else 3):
		var b := _blade_base[i]
		if not _view.has_point(b):
			continue
		var m := _blade_motion(i, gust)
		var h := _blade_h[i] * 0.28 * m.y
		var tip := b + Vector2(m.x * 0.5 + _blade_tilt[i] * h, -h)
		var col := GRASS_DARK if _blade_color[i] == 2 else GRASS
		c.draw_polygon(PackedVector2Array([b + Vector2(-3.2, 3.0), tip, b + Vector2(3.2, 3.0)]),
			PackedColorArray([GRASS_DARK, col, GRASS_DARK]))
	for bush in _hide_bushes:
		var p: Vector2 = bush["pos"]
		if not _view.has_point(p + Vector2(0.0, -HIDE_H * 0.5)):
			continue
		var amp := 0.8 + 2.2 * gust + 7.0 * float(bush["rustle"])
		var fade := float(bush["fade"])
		var body_col := Color(0.08, 0.14, 0.07, 0.96 * fade)
		c.draw_colored_polygon(_dome_points(p, HIDE_W * 0.47, HIDE_H * 0.86, 20, sin(_elapsed * 1.3 + p.x) * amp * 0.6), body_col)
		var leaf_list: Array = bush["leaves"]
		for li in range(0, leaf_list.size(), 2 if _lite else 1):
			var lf: Dictionary = leaf_list[li]
			var lp: Vector2 = lf["p"]
			var hf := clampf(-lp.y / HIDE_H, 0.0, 1.0)
			var sway := sin(_elapsed * 1.6 + float(lf["ph"]) + p.x * 0.01) * amp * (0.25 + hf)
			var col: Color = lf["c"]
			col.a *= fade
			c.draw_colored_polygon(_leaf_poly(p + lp + Vector2(sway, 0.0), float(lf["a"]) + sway * 0.04, float(lf["s"])), col)
