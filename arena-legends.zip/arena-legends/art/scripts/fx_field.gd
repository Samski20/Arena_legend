class_name FXField
extends Node2D
## A tiny particle system drawn in a single pass. Zones and explosions fill it
## with particles using emit(FXField.P(...)). Make one field with additive = true
## for fire / glow / sparks, and one normal field for smoke / gas / debris.
##
## Particle keys: tex, pos, vel, life, s0 -> s1 (size, Vector2), c0 -> c1 (color).
## Optional: acc, drag, rot, spin, delay, anchor (0.5,0.5 = centered, 0.5,1 = base at pos),
## fade_in (fraction of life), hold (fraction of life before the color starts changing),
## grow (seconds to pop up from nothing), mode ("streak" = line, "box" = little chunk), trail.

var additive := false
var parts: Array = []


func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	if additive:
		var m := CanvasItemMaterial.new()
		m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		material = m


static func V(s: float) -> Vector2:
	return Vector2(s, s)


static func P(t: Texture2D, pos: Vector2, vel: Vector2, life: float, s0: Vector2, s1: Vector2,
		c0: Color, c1: Color, extra := {}) -> Dictionary:
	var d := {"tex": t, "pos": pos, "vel": vel, "life": life, "s0": s0, "s1": s1, "c0": c0, "c1": c1}
	d.merge(extra, true)
	return d


func emit(p: Dictionary) -> void:
	p["age"] = -float(p.get("delay", 0.0))
	parts.append(p)


func count() -> int:
	return parts.size()


func _process(delta: float) -> void:
	var i := parts.size() - 1
	while i >= 0:
		var p: Dictionary = parts[i]
		p["age"] += delta
		if p["age"] >= p["life"]:
			parts.remove_at(i)
		elif p["age"] > 0.0:
			var acc: Vector2 = p.get("acc", Vector2.ZERO)
			var drag := float(p.get("drag", 0.0))
			p["vel"] = (p["vel"] + acc * delta) * exp(-drag * delta)
			p["pos"] += p["vel"] * delta
			p["rot"] = float(p.get("rot", 0.0)) + float(p.get("spin", 0.0)) * delta
		i -= 1
	queue_redraw()


func _draw() -> void:
	for p in parts:
		var age: float = p["age"]
		if age <= 0.0:
			continue
		var life: float = p["life"]
		var t := clampf(age / life, 0.0, 1.0)
		var hold := float(p.get("hold", 0.0))
		var ct := 0.0 if t < hold else (t - hold) / maxf(1.0 - hold, 0.001)
		var col: Color = (p["c0"] as Color).lerp(p["c1"], ct)
		var fin := float(p.get("fade_in", 0.12))
		if fin > 0.0:
			col.a *= clampf(t / fin, 0.0, 1.0)
		var size: Vector2 = (p["s0"] as Vector2).lerp(p["s1"], t)
		var grow := float(p.get("grow", 0.0))
		if grow > 0.0:
			var g := clampf(age / grow, 0.0, 1.0)
			size *= 1.0 - pow(1.0 - g, 3.0)

		var mode := String(p.get("mode", "tex"))
		var pos: Vector2 = p["pos"]
		if mode == "streak":
			var v: Vector2 = p["vel"]
			draw_line(pos, pos - v * float(p.get("trail", 0.035)), col, size.x, true)
			continue
		draw_set_transform(pos, float(p.get("rot", 0.0)), Vector2.ONE)
		if mode == "box":
			draw_rect(Rect2(-size * 0.5, size), col)
		else:
			var anchor: Vector2 = p.get("anchor", Vector2(0.5, 0.5))
			var rect := Rect2(-size * anchor, size)
			var t2: Texture2D = p.get("tex")
			if t2 != null:
				draw_texture_rect(t2, rect, false, col)
			else:
				draw_circle(rect.get_center(), size.x * 0.5, col)       # fallback if art is missing
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
