class_name RecordsStore
extends RefCounted
## Local personal records per mode / map / difficulty.

const PATH := "user://records.cfg"

static var _loaded := false
static var _data: Dictionary = {}


static func ensure_loaded() -> void:
	if _loaded:
		return
	_loaded = true
	_data = {}
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	for section in cfg.get_sections():
		_data[section] = {}
		for key in cfg.get_section_keys(section):
			_data[section][key] = cfg.get_value(section, key)


static func _key(mode: String, map_id: String, difficulty: int) -> String:
	return "%s|%s|%d" % [mode, map_id, difficulty]


static func get_record(mode: String, map_id: String, difficulty: int) -> Dictionary:
	ensure_loaded()
	return _data.get(_key(mode, map_id, difficulty), {}).duplicate()


static func update_after_match(mode: String, map_id: String, difficulty: int, stats: Dictionary) -> void:
	ensure_loaded()
	var k := _key(mode, map_id, difficulty)
	var rec: Dictionary = _data.get(k, {
		"matches": 0, "kills": 0, "deaths": 0, "best_streak": 0,
		"highest_score": 0, "best_survival_sec": 0.0, "total_time_sec": 0.0
	})
	rec["matches"] = int(rec.get("matches", 0)) + 1
	rec["kills"] = int(rec.get("kills", 0)) + int(stats.get("kills", 0))
	rec["deaths"] = int(rec.get("deaths", 0)) + int(stats.get("deaths", 0))
	rec["best_streak"] = maxi(int(rec.get("best_streak", 0)), int(stats.get("kill_streak", 0)))
	rec["highest_score"] = maxi(int(rec.get("highest_score", 0)), int(stats.get("score", 0)))
	if mode == "survival":
		rec["best_survival_sec"] = maxf(float(rec.get("best_survival_sec", 0.0)), float(stats.get("duration_sec", 0.0)))
	rec["total_time_sec"] = float(rec.get("total_time_sec", 0.0)) + float(stats.get("duration_sec", 0.0))
	_data[k] = rec
	_persist()


static func _persist() -> void:
	var cfg := ConfigFile.new()
	for section in _data:
		for key in _data[section]:
			cfg.set_value(section, key, _data[section][key])
	cfg.save(PATH)
