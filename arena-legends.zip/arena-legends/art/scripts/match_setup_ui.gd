class_name MatchSetupUI
extends CanvasLayer
## Full match configuration UI with categories, presets, weapon/throwable selection, loadouts.

const MapRegistry = preload("res://art/scripts/map_registry.gd")

signal back_pressed
signal start_pressed(config: MatchConfig)

var config: MatchConfig
var _scroll: ScrollContainer
var _content: VBoxContainer
var _tab_btns: Array[Button] = []
var _pages: Dictionary = {}   # tab name -> Control
var _active_tab := "Rules"
var _weapon_checks: Dictionary = {}
var _throwable_checks: Dictionary = {}


func setup(cfg: MatchConfig) -> void:
	config = cfg.duplicate_config()
	layer = 121
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build()


func _build() -> void:
	var dim := ColorRect.new()
	dim.color = Color(UITheme.SCRIM.r, UITheme.SCRIM.g, UITheme.SCRIM.b, 0.9)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var insets := UITheme.safe_insets()
	root.offset_left = insets.x + 8
	root.offset_top = insets.y + 8
	root.offset_right = -insets.z - 8
	root.offset_bottom = -insets.w - 8
	add_child(root)

	var outer := VBoxContainer.new()
	outer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	outer.add_theme_constant_override("separation", 8)
	root.add_child(outer)

	# header
	var head_row := HBoxContainer.new()
	head_row.add_theme_constant_override("separation", 12)
	outer.add_child(head_row)
	var title := Label.new()
	title.text = "MATCH SETUP  ·  %s" % MatchConfig.mode_name(config.mode)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_font_size_override("font_size", 22)
	title.add_theme_font_override("font", UITheme.font(true))
	title.add_theme_color_override("font_color", UITheme.ON_SURFACE)
	head_row.add_child(title)

	# tabs
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 6)
	outer.add_child(tabs)
	for t in ["Rules", "Map", "Weapons", "Throwables", "Bots", "Loadouts", "Modifiers", "Presets"]:
		var b := Button.new()
		b.text = t
		b.custom_minimum_size = Vector2(0, 40)
		b.toggle_mode = true
		b.button_pressed = (t == _active_tab)
		UITheme.style_button(b, "tonal")
		b.add_theme_font_size_override("font_size", 13)
		b.pressed.connect(_switch_tab.bind(t))
		tabs.add_child(b)
		_tab_btns.append(b)

	# scroll body
	_scroll = ScrollContainer.new()
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	outer.add_child(_scroll)

	_content = VBoxContainer.new()
	_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_content.add_theme_constant_override("separation", 10)
	_scroll.add_child(_content)

	_build_pages()
	_show_tab(_active_tab)

	# footer
	var foot := HBoxContainer.new()
	foot.add_theme_constant_override("separation", 12)
	outer.add_child(foot)
	var back := Button.new()
	back.text = "BACK"
	back.custom_minimum_size = Vector2(120, 52)
	UITheme.style_button(back, "tonal")
	back.pressed.connect(func() -> void: back_pressed.emit())
	foot.add_child(back)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	foot.add_child(spacer)
	var start := Button.new()
	start.text = "START MATCH"
	start.custom_minimum_size = Vector2(180, 52)
	UITheme.style_button(start, "primary")
	start.add_theme_font_size_override("font_size", 18)
	start.pressed.connect(_on_start)
	foot.add_child(start)


func _switch_tab(t: String) -> void:
	_active_tab = t
	for b in _tab_btns:
		b.button_pressed = (b.text == t)
	_show_tab(t)


func _show_tab(t: String) -> void:
	for c in _content.get_children():
		c.visible = false
	if _pages.has(t):
		_pages[t].visible = true


func _build_pages() -> void:
	_pages["Rules"] = _page_rules()
	_pages["Map"] = _page_map()
	_pages["Weapons"] = _page_weapons()
	_pages["Throwables"] = _page_throwables()
	_pages["Bots"] = _page_bots()
	_pages["Loadouts"] = _page_loadouts()
	_pages["Modifiers"] = _page_modifiers()
	_pages["Presets"] = _page_presets()
	for k in _pages:
		_content.add_child(_pages[k])
		_pages[k].visible = false


func _section(title: String) -> VBoxContainer:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var lbl := Label.new()
	lbl.text = title
	lbl.add_theme_font_size_override("font_size", 16)
	lbl.add_theme_font_override("font", UITheme.font(true))
	lbl.add_theme_color_override("font_color", UITheme.PRIMARY)
	box.add_child(lbl)
	return box


func _cycle_row(parent: VBoxContainer, label: String, options: Array, labels: Array, current_idx: int, on_change: Callable) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	parent.add_child(row)
	var l := Label.new()
	l.text = label
	l.custom_minimum_size = Vector2(160, 0)
	l.add_theme_font_size_override("font_size", 15)
	l.add_theme_color_override("font_color", UITheme.ON_SURFACE)
	row.add_child(l)
	var b := Button.new()
	b.custom_minimum_size = Vector2(180, 44)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	UITheme.style_button(b, "tonal")
	var idx := clampi(current_idx, 0, options.size() - 1)
	b.text = "%s   ›" % labels[idx]
	b.set_meta("idx", idx)
	b.pressed.connect(func() -> void:
		var i: int = (int(b.get_meta("idx")) + 1) % options.size()
		b.set_meta("idx", i)
		b.text = "%s   ›" % labels[i]
		on_change.call(options[i], i))
	row.add_child(b)


func _toggle_row(parent: VBoxContainer, label: String, value: bool, on_change: Callable) -> void:
	var row := HBoxContainer.new()
	parent.add_child(row)
	var l := Label.new()
	l.text = label
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.add_theme_font_size_override("font_size", 15)
	l.add_theme_color_override("font_color", UITheme.ON_SURFACE)
	row.add_child(l)
	var b := Button.new()
	b.custom_minimum_size = Vector2(90, 40)
	b.text = "ON" if value else "OFF"
	UITheme.style_button(b, "primary" if value else "tonal")
	b.pressed.connect(func() -> void:
		var v := not (b.text == "ON")
		b.text = "ON" if v else "OFF"
		UITheme.style_button(b, "primary" if v else "tonal")
		on_change.call(v))
	row.add_child(b)


func _page_rules() -> VBoxContainer:
	var box := _section("Victory Conditions")
	var dur_idx := MatchConfig.DURATION_OPTIONS.find(config.duration_sec)
	if dur_idx < 0:
		dur_idx = 1
	_cycle_row(box, "Duration", MatchConfig.DURATION_OPTIONS, MatchConfig.DURATION_LABELS, dur_idx,
		func(v, _i): config.duration_sec = int(v))
	var kill_idx := MatchConfig.KILL_OPTIONS.find(config.kill_limit)
	if kill_idx < 0:
		kill_idx = 1
	_cycle_row(box, "Kill limit", MatchConfig.KILL_OPTIONS, MatchConfig.KILL_LABELS, kill_idx,
		func(v, _i): config.kill_limit = int(v))

	var psec := _section("Player")
	box.add_child(psec)
	_toggle_row(psec, "Player respawn", config.player_respawn, func(v): config.player_respawn = v)
	_cycle_row(psec, "Respawn delay", [1.0, 2.0, 3.0, 5.0, 8.0], ["1 s", "2 s", "3 s", "5 s", "8 s"],
		2, func(v, _i): config.player_respawn_delay = float(v))
	_toggle_row(psec, "Health regen", config.health_regen, func(v): config.health_regen = v)
	_toggle_row(psec, "Out-of-bounds damage", config.out_of_bounds_damage, func(v): config.out_of_bounds_damage = v)
	return box


func _page_map() -> VBoxContainer:
	var box := _section("Map")
	for info in MapRegistry.all_maps():
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 60)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		UITheme.style_button(b, "primary" if info["id"] == config.map_id else "tonal")
		b.text = "%s\n%s" % [info["name"], info["description"]]
		b.add_theme_font_size_override("font_size", 15)
		var mid: String = str(info["id"])
		b.pressed.connect(func() -> void:
			config.map_id = mid
			# refresh styles
			for c in box.get_children():
				if c is Button:
					UITheme.style_button(c, "tonal")
			UITheme.style_button(b, "primary"))
		box.add_child(b)
	return box


func _page_weapons() -> VBoxContainer:
	var box := _section("Weapon Spawning")
	_cycle_row(box, "Spawn rate", [0, 1, 2, 3, 4], MatchConfig.RATE_LABELS, config.weapon_spawn_rate,
		func(v, _i): config.weapon_spawn_rate = int(v))
	var max_idx := MatchConfig.MAX_PICKUP_OPTIONS.find(config.max_weapon_pickups)
	if max_idx < 0:
		max_idx = 2
	_cycle_row(box, "Max pickups", MatchConfig.MAX_PICKUP_OPTIONS,
		["3", "5", "10", "15", "20", "Unlimited"], max_idx,
		func(v, _i): config.max_weapon_pickups = int(v))

	var sel := _section("Weapon Selection")
	box.add_child(sel)
	var row := HBoxContainer.new()
	sel.add_child(row)
	for label in ["ALL", "NONE", "CUSTOM"]:
		var b := Button.new()
		b.text = label
		b.custom_minimum_size = Vector2(100, 42)
		UITheme.style_button(b, "primary" if (label == "ALL" and config.weapons_all) or (label == "NONE" and config.weapons_none) or (label == "CUSTOM" and not config.weapons_all and not config.weapons_none) else "tonal")
		b.pressed.connect(_set_weapon_mode.bind(label))
		row.add_child(b)

	var list := VBoxContainer.new()
	list.name = "WeaponList"
	sel.add_child(list)
	_weapon_checks.clear()
	for id in WeaponCatalog.PATHS:
		var w := WeaponCatalog.get_weapon(id)
		if w == null:
			continue
		var cb_row := HBoxContainer.new()
		list.add_child(cb_row)
		var chk := Button.new()
		var on := config.weapons_all or config.allowed_weapons.has(id)
		if config.weapons_none:
			on = false
		chk.text = "✓" if on else "○"
		chk.custom_minimum_size = Vector2(44, 40)
		UITheme.style_button(chk, "primary" if on else "tonal")
		var wid: String = str(id)
		chk.pressed.connect(func() -> void:
			config.weapons_all = false
			config.weapons_none = false
			var arr: Array = Array(config.allowed_weapons)
			if arr.has(wid):
				arr.erase(wid)
				chk.text = "○"
				UITheme.style_button(chk, "tonal")
			else:
				arr.append(wid)
				chk.text = "✓"
				UITheme.style_button(chk, "primary")
			config.allowed_weapons = PackedStringArray(arr))
		cb_row.add_child(chk)
		_weapon_checks[id] = chk
		var lbl := Label.new()
		lbl.text = "%s  (%s)" % [w.display_name, w.category]
		lbl.add_theme_font_size_override("font_size", 14)
		lbl.add_theme_color_override("font_color", UITheme.ON_SURFACE)
		cb_row.add_child(lbl)
	return box


func _set_weapon_mode(mode: String) -> void:
	config.weapons_all = (mode == "ALL")
	config.weapons_none = (mode == "NONE")
	if mode == "ALL":
		config.allowed_weapons = PackedStringArray()
	elif mode == "NONE":
		config.allowed_weapons = PackedStringArray()
	# refresh checkmarks
	for id in _weapon_checks:
		var chk: Button = _weapon_checks[id]
		var on := config.weapons_all or (not config.weapons_none and config.allowed_weapons.has(id))
		if config.weapons_none:
			on = false
		chk.text = "✓" if on else "○"
		UITheme.style_button(chk, "primary" if on else "tonal")


func _page_throwables() -> VBoxContainer:
	var box := _section("Throwable Spawning")
	_cycle_row(box, "Spawn rate", [0, 1, 2, 3, 4], MatchConfig.RATE_LABELS, config.throwable_spawn_rate,
		func(v, _i): config.throwable_spawn_rate = int(v))
	var max_idx := MatchConfig.MAX_PICKUP_OPTIONS.find(config.max_throwable_pickups)
	if max_idx < 0:
		max_idx = 1
	_cycle_row(box, "Max pickups", MatchConfig.MAX_PICKUP_OPTIONS,
		["3", "5", "10", "15", "20", "Unlimited"], max_idx,
		func(v, _i): config.max_throwable_pickups = int(v))

	var cat_row := HBoxContainer.new()
	box.add_child(cat_row)
	for cat in ["ALL", "NONE", "Grenades", "Explosives", "Tactical", "CUSTOM"]:
		var b := Button.new()
		b.text = cat
		b.custom_minimum_size = Vector2(0, 40)
		b.add_theme_font_size_override("font_size", 12)
		UITheme.style_button(b, "tonal")
		b.pressed.connect(_set_throwable_mode.bind(cat.to_lower()))
		cat_row.add_child(b)

	var list := VBoxContainer.new()
	box.add_child(list)
	_throwable_checks.clear()
	for id in ThrowableCatalog.IDS:
		var d := ThrowableCatalog.get_data(id)
		if d == null:
			continue
		var compatible := ThrowableCatalog.can_spawn_on(d, config.map_id)
		var cb_row := HBoxContainer.new()
		list.add_child(cb_row)
		var chk := Button.new()
		var on := config.throwables_all or config.allowed_throwables.has(id)
		if config.throwables_none:
			on = false
		chk.text = "✓" if on else "○"
		chk.custom_minimum_size = Vector2(44, 40)
		chk.disabled = not compatible
		UITheme.style_button(chk, "primary" if on else "tonal")
		var tid: String = str(id)
		chk.pressed.connect(func() -> void:
			config.throwables_all = false
			config.throwables_none = false
			config.throwable_category = ""
			var arr: Array = Array(config.allowed_throwables)
			if arr.has(tid):
				arr.erase(tid)
				chk.text = "○"
				UITheme.style_button(chk, "tonal")
			else:
				arr.append(tid)
				chk.text = "✓"
				UITheme.style_button(chk, "primary")
			config.allowed_throwables = PackedStringArray(arr))
		cb_row.add_child(chk)
		_throwable_checks[id] = chk
		var lbl := Label.new()
		lbl.text = id.replace("_", " ").capitalize()
		if not compatible:
			lbl.text += "  (not on this map)"
			lbl.add_theme_color_override("font_color", UITheme.ON_VARIANT)
		else:
			lbl.add_theme_color_override("font_color", UITheme.ON_SURFACE)
		lbl.add_theme_font_size_override("font_size", 14)
		cb_row.add_child(lbl)
	return box


func _set_throwable_mode(mode: String) -> void:
	config.throwables_all = (mode == "all")
	config.throwables_none = (mode == "none")
	config.throwable_category = ""
	if mode in ["grenades", "explosives", "tactical"]:
		config.throwables_all = false
		config.throwables_none = false
		config.throwable_category = mode
		config.allowed_throwables = config._throwables_in_category(mode, ThrowableCatalog.for_map(config.map_id))
	elif mode == "all":
		config.allowed_throwables = PackedStringArray()
	elif mode == "none":
		config.allowed_throwables = PackedStringArray()
	for id in _throwable_checks:
		var chk: Button = _throwable_checks[id]
		var on := false
		if config.throwables_all:
			on = true
		elif config.throwables_none:
			on = false
		elif config.throwable_category != "":
			on = config.allowed_throwables.has(id)
		else:
			on = config.allowed_throwables.has(id)
		chk.text = "✓" if on else "○"
		UITheme.style_button(chk, "primary" if on else "tonal")


func _page_bots() -> VBoxContainer:
	var box := _section("Bots")
	var cnt_idx := MatchConfig.BOT_COUNT_OPTIONS.find(config.bot_count)
	if cnt_idx < 0:
		cnt_idx = 3
	_cycle_row(box, "Bot count", MatchConfig.BOT_COUNT_OPTIONS,
		["0", "1", "2", "3", "4", "5", "6", "8", "10"], cnt_idx,
		func(v, _i): config.bot_count = int(v))
	_cycle_row(box, "Difficulty", [0, 1, 2, 3], ["Rookie", "Normal", "Veteran", "Legend"],
		config.bot_difficulty, func(v, _i): config.bot_difficulty = int(v))
	_toggle_row(box, "Bot respawn", config.bot_respawn, func(v): config.bot_respawn = v)
	_cycle_row(box, "Bot respawn delay", [1.0, 2.0, 3.0, 5.0, 8.0], ["1 s", "2 s", "3 s", "5 s", "8 s"],
		2, func(v, _i): config.bot_respawn_delay = float(v))
	return box


func _page_loadouts() -> VBoxContainer:
	var box := _section("Loadouts")
	_toggle_row(box, "Use loadouts", config.use_loadouts, func(v): config.use_loadouts = v)
	LoadoutStore.ensure_loaded()
	for ld in LoadoutStore.all_loadouts():
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 56)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		var selected: bool = config.selected_loadout_id == str(ld.get("id", ""))
		UITheme.style_button(b, "primary" if selected else "tonal")
		b.text = "%s\n%s + %s" % [ld.get("name", "?"), ld.get("primary", ""), ld.get("secondary", "")]
		b.add_theme_font_size_override("font_size", 14)
		var lid: String = str(ld.get("id", ""))
		b.pressed.connect(func() -> void:
			config.selected_loadout_id = lid
			config.use_loadouts = true
			for c in box.get_children():
				if c is Button and c != b:
					UITheme.style_button(c, "tonal")
			UITheme.style_button(b, "primary"))
		box.add_child(b)
	var hint := Label.new()
	hint.text = "Loadouts give starting weapons/throwables. Map pickups still work unless disabled."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.add_theme_font_size_override("font_size", 12)
	hint.add_theme_color_override("font_color", UITheme.ON_VARIANT)
	box.add_child(hint)
	return box


func _page_modifiers() -> VBoxContainer:
	var box := _section("Experimental Modifiers")
	_toggle_row(box, "Unlimited Ammo", config.mod_unlimited_ammo, func(v): config.mod_unlimited_ammo = v)
	_toggle_row(box, "Infinite Grenades", config.mod_infinite_grenades, func(v): config.mod_infinite_grenades = v)
	_toggle_row(box, "Infinite Jetpack Fuel", config.mod_infinite_jetpack, func(v): config.mod_infinite_jetpack = v)
	_toggle_row(box, "Infinite Health", config.mod_infinite_health, func(v): config.mod_infinite_health = v)
	_toggle_row(box, "No Weapon Reload", config.mod_no_reload, func(v): config.mod_no_reload = v)
	_toggle_row(box, "Increased Damage", config.mod_increased_damage, func(v): config.mod_increased_damage = v)
	_toggle_row(box, "Low Gravity", config.mod_low_gravity, func(v): config.mod_low_gravity = v)
	_toggle_row(box, "Fast Movement", config.mod_fast_movement, func(v): config.mod_fast_movement = v)
	_toggle_row(box, "Increased Explosion Force", config.mod_increased_explosion, func(v): config.mod_increased_explosion = v)
	_toggle_row(box, "No Respawn Delay", config.mod_no_respawn_delay, func(v): config.mod_no_respawn_delay = v)
	_toggle_row(box, "All Compatible Weapons", config.mod_all_weapons, func(v): config.mod_all_weapons = v)
	_toggle_row(box, "All Compatible Throwables", config.mod_all_throwables, func(v): config.mod_all_throwables = v)

	var unlim := Button.new()
	unlim.text = "ENABLE UNLIMITED MODE"
	unlim.custom_minimum_size = Vector2(0, 48)
	UITheme.style_button(unlim, "primary")
	unlim.pressed.connect(func() -> void:
		config.mod_unlimited_ammo = true
		config.mod_infinite_grenades = true
		config.mod_infinite_jetpack = true
		config.duration_sec = 0
		config.kill_limit = 0
		# rebuild page
		_pages["Modifiers"].queue_free()
		_pages["Modifiers"] = _page_modifiers()
		_content.add_child(_pages["Modifiers"])
		_show_tab("Modifiers"))
	box.add_child(unlim)
	return box


func _page_presets() -> VBoxContainer:
	var box := _section("Built-in Presets")
	for p in MatchConfig.builtin_presets():
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 48)
		b.text = p["name"]
		UITheme.style_button(b, "tonal")
		var cfg: MatchConfig = p["config"]
		b.pressed.connect(func() -> void:
			config = cfg.duplicate_config()
			config.mode = config.mode  # keep
			# stay on presets so user can tweak further
			UITheme.haptic(12))
		box.add_child(b)

	var custom_sec := _section("Saved Presets")
	box.add_child(custom_sec)
	PresetStore.ensure_loaded()
	for p in PresetStore.all_custom():
		var row := HBoxContainer.new()
		custom_sec.add_child(row)
		var b := Button.new()
		b.text = p.get("name", "?")
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.custom_minimum_size = Vector2(0, 44)
		UITheme.style_button(b, "tonal")
		var pid: String = str(p.get("id", ""))
		b.pressed.connect(func() -> void:
			var raw: Dictionary = p.get("config", {})
			config = MatchConfig.from_dict(raw)
			UITheme.haptic(12))
		row.add_child(b)
		var del := Button.new()
		del.text = "✕"
		del.custom_minimum_size = Vector2(44, 44)
		UITheme.style_button(del, "tonal")
		del.pressed.connect(func() -> void:
			PresetStore.delete_preset(pid)
			_pages["Presets"].queue_free()
			_pages["Presets"] = _page_presets()
			_content.add_child(_pages["Presets"])
			_show_tab("Presets"))
		row.add_child(del)

	var save_btn := Button.new()
	save_btn.text = "SAVE CURRENT AS PRESET"
	save_btn.custom_minimum_size = Vector2(0, 48)
	UITheme.style_button(save_btn, "primary")
	save_btn.pressed.connect(func() -> void:
		var name := "Custom %d" % (PresetStore.all_custom().size() + 1)
		PresetStore.save_preset(name, config)
		_pages["Presets"].queue_free()
		_pages["Presets"] = _page_presets()
		_content.add_child(_pages["Presets"])
		_show_tab("Presets")
		UITheme.haptic(15))
	box.add_child(save_btn)
	return box


func _on_start() -> void:
	var errs := config.validate()
	if not errs.is_empty():
		# simple notice
		var notice := AcceptDialog.new()
		notice.dialog_text = "\n".join(errs)
		notice.title = "Cannot start"
		add_child(notice)
		notice.popup_centered()
		return
	UITheme.haptic(18)
	start_pressed.emit(config)
