# Arena Legends map selection update

## Maps included
- **Abandoned Station** (`abandoned_station`): the existing map, preserved.

## How to use
1. Open the `arena-legends` project in the Godot version specified by `project.godot`.
2. Run the existing main scene.
3. The map selection screen opens automatically. Choose a map to start/resume the match.
4. Use the **MAP** button in the top-left corner to switch maps during play, or press **Esc** to open/close the selection screen.

## Adding future maps
Add a map entry to `art/scripts/map_registry.gd` with a unique ID, display name, scene path, and description. For map-specific throwable availability, update `art/scripts/throwable_catalog.gd` without removing existing map restrictions.

## Implementation notes
- `test_arena.tscn` now uses `art/scripts/arena_controller.gd` and contains a dedicated `MapHost` node.
- `arena_controller.gd` also moves the two weapon pickups that live in the main scene onto each map's surfaces when the map changes.
- The map selection controller updates the root `SpawnPoint`, player, and top-level bots when changing maps.
- The map was test-run headlessly in Godot 4.5 (no script errors); the project itself targets 4.7, so please check the Output panel once in your editor.

## Cavern Isles (new map)
Built from the layout sketch. Tunnels: a Long Tunnel (drop shaft in the west, skylight in the middle, pit mouth in the east) and an East Tunnel under the east ground (pit mouth to a wide hatch and a dead-end weapon alcove). Rocks: boulders, mounds, stalagmites and stalactites. Obstacles: solid crates, crate stacks, barrels, sandbag walls and plank barricades. Stone bunker (blue flag) west, log bunker (red flag) east. All in `art/scripts/cavern_isles.gd`; layout numbers are in sketch pixels in `_define_world()`, scaled by `S`. Not run in the Godot editor on my side, so please check the Output panel once.


## Cavern Isles polish pass
- **Steel bunker, two entrances.** The west (blue flag) bunker is now riveted steel. It has a doorway in each end wall (the original east one and a new west one). Each wall is only a short lintel under the roof, so both doorways are 224 px tall (player capsule 48 px, bot 60 px). Collision rectangles are the same ones that are painted. Edit `"solids"` / `"doors"` in the bunker entry of `_define_world()`.
- **Environment.** Rock clusters mix pebbles, stones (decoration, no collision) and rocks / boulders (solid, walkable domes). `_define_environment()` lists the clusters; every piece is skipped automatically if it would land on a pickup, throwable spawn, crate, the bunker, the player spawn, another rock, or a steep slope. Also added: moss and facets on rocks, rock strata, roots under the islands, a few flowers, and slightly craggier cliff faces (`ORGANIC_SIDE_AMP`).
- **Bot spawning.** Root cause: bots respawned at `start_position`, which was never updated when you changed map, so on Cavern Isles one bot respawned inside the centre island. `art/scripts/spawn_safety.gd` now checks every spawn (ground below, capsule + margin free of solids and other fighters, free box for stepping and lift-off, inside the playable rectangle). `bot.gd` uses it on every respawn and `arena_controller.gd` uses it when a map is chosen. A map can offer `get_bot_spawn_candidates()` and `get_playable_rect()` (group `bot_spawn_provider`); maps without them still get a spiral search around the preferred point.
- **Out of bounds (Mini Militia style).** No invisible walls on the left, right or top of Cavern Isles. `art/scripts/out_of_bounds.gd` measures the distance past the edge: a warning at 150 px, health drain from 400 px (10 hp/s, rising in a straight line to 60 hp/s at 1400 px), instant death at 2200 px. Healing is paused while it drains, the drain stops as soon as you are back inside the line, and at 0 health the normal `die()` and respawn run (an out-of-bounds death gives nobody a kill). Bots obey it too. All values are `oob_*` exports on the map node. The cloud floor stays solid and is wider than the whole zone; the camera limits and sky were widened to match.
- Not run in the Godot editor (none was available where this was written). Please open the project once and check the Output panel.


## Changes since: Labyrinth Outpost removed, mobile speed
- **Labyrinth Outpost was removed** (scene, script, registry entry, spawn tables). Maps now: Abandoned Station, Cavern Isles.
- **Cavern Isles on phones**: the terrain is baked once into texture tiles (see `bake_terrain` / `bake_scale` on the map node and
  `_bake_terrain()` in `cavern_isles.gd`), so a phone draws a handful of sprites instead of thousands of polygons plus a per-pixel
  shader every frame. Auto = on for phones/tablets; set it to On to test on PC. If a bake comes out blank the map falls back to the
  vector terrain by itself (Output shows a warning). The lantern glow redraws at 20 fps on phones.
- **No floor under Cavern Isles**: falling off the bottom is out of bounds and ends in death (see `out_of_bounds.gd`, `check_bottom`).
