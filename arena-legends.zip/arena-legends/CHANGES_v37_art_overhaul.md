# v37 – art overhaul (outfits, headgear, jetpacks)

All art is **painted procedurally** by the Python tools in `tools/` (no AI image generator was available in this
environment). Every picture can be repainted by an artist: same file names, sizes and pivots.

## What changed
- **Body / neck / head**: body parts are redrawn at 2x (`art/body/`), head lowered onto the collar (`HEAD_Y`), a collar
  piece per top covers the neck joint, smooth outlines.
- **Outfits** (`art/outfits/<slot>_<id>/`, `tools/outfitlib.py`, `tools/gen_outfit_art.py`): every top, bottom, boot, glove
  and body armour is a separately painted garment with its own silhouette, seams, pockets, straps and plates. Camouflage
  (8 patterns, one per colour swatch) on the Military Uniform and Military Trousers. New shoulder pauldrons and knee pads.
  Garments are independent slots, work on male/female and with bots' team colours.
- **Headgear** (`tools/gearlib.py` v2, `tools/gen_gear.py`): 16 pieces regenerated for every head shape: Combat Helmet,
  Visor Helmet, Beanie, Cap, **Beret**, **Bush Hat**, Headband, Goggles, Sunglasses, **Respirator**, Hood, Circlet,
  Comms Headset, Hero Cowl, Stalker Helm. A new `det` layer holds baked details (straps, rails, logos).
- **Jetpacks** (`tools/jetlib.py`, `tools/gen_jetpack_art.py`, `art/jetpacks/`, `art/scripts/look/jetpack_fx.gd`):
  nine different packs – Standard Twin Tank, Military Field Pack (canisters, MOLLE, hazard band), Heavy Turbine,
  Futuristic Drive (energy seams, emitter rings), Experimental Gyro, Gilded Regalia, Compact Boosters, Alien Bio-Drive and
  **Mechanical Wings** (fold on the ground, snap open and flap when thrusting). Each has its own flame style (fire, heavy,
  plasma, arc, gold, blue, green), exhaust/trail particles, ignition kick + burst and glow pulsing.
  Finish colours (`Jetpack finish`) still tint every pack. Jetpack mechanics are untouched (visual only).
- Partial-set cosmetics (Void Hunter, Solar Sentinel) now dress the new garments in their own look.

## Compatibility
- Appearance codes: existing ids unchanged; new ids `compact`, `alien`, `wings` (jetpack), `beret`, `boonie` (headgear).
- Old `slim` jetpack texture name maps to the Futuristic pack.

## Known limits
- The alien reference image was never received, so alien heads were not redrawn from it.
- Regenerate art: `python3 -I tools/gen_outfit_art.py all`, `python3 -I tools/gen_gear.py`, `python3 -I tools/gen_jetpack_art.py`
  (then re-import the project in Godot).
