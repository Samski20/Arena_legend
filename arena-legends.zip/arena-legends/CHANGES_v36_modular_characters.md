# v36 – modular characters

**Fixed:** legs missing in the customization preview (the rig's back layers drew behind the stage panel). The preview is the real in-game rig and now always shows the full character, fitted to the stage.

**Modular customization** – head shape, eyes, brows, hair, facial hair, headgear, top/armour/shoulders, gloves, trousers/knee pads, boots, jetpack/wings, back accessory are separate components.
Rule: your override for that cosmetic > the cosmetic's default > your own look. Each component has its own RESET (back to the cosmetic default) and a COSMETIC DEFAULT / CUSTOM / MY STYLE chip. Changing one never touches another.

**Art** (generated per head shape, so hair/beards/headgear fit): 10 human head shapes + Lumen and Hive skulls, 13 eye styles with colours, 7 brow styles, 18 hairstyles (with back layers and movement), 11 facial hair styles, 13 headgear pieces. New hero costume art (Comet Vanguard, original design) with a cape integrated with the jetpack flight system.
Creatures (Lumen, Insectoid) keep their anatomy and can wear shirt/trousers/boots/gloves via overlays; wings stay the jetpack.

**UI** – categories Body, Head, Eyes, Hair, Facial hair, Headgear, Upper body, Arms, Trousers, Footwear, Jetpack + Back, Cosmetics, Colours; live preview, TURN and HEAD/BODY inspect buttons.

**Multiplayer** – the same ids are sent over LAN (Appearance.encode/decode); every client draws from its own files. Old saves migrate.

**Known limits** – the alien reference picture was never received, so the alien was not redrawn from it (Lumen keeps its current design). Creatures cannot wear armour/knee pads/shoulder pads; hero costumes have locked bodies (head, eyes, hair, headgear, back remain editable).
