# v32: bot difficulty
- NEW art/scripts/bot_difficulty.gd: ROOKIE / NORMAL / VETERAN / LEGEND (max). One table (PROFILES) to tune.
- Menu (map menu): BOT DIFFICULTY button cycles the level, applies instantly, saved in settings.cfg (GameSettings.bot_difficulty). NORMAL = the old bots.
- bot.gd: crouch + energy shield (VETERAN, LEGEND), throws bombs (ballistic aim), random guns per life with per-gun fighting range / fire speed, loot drop on death (gun with partial ammo + unused bombs, all levels).
- Bots never use trap mines, decoys or portals.
