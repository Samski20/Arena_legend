# v33.6: mobile lobby dropdown + doubled score
- net/lan_menu.gd: MAP / TIME LIMIT / WEAPON SPAWNS / THROWABLES are now tap-to-cycle buttons (CycleChoice) instead of
  OptionButton drop-downs. On phones emulate_mouse_from_touch is off, so the drop-down's pop-up list never got the finger
  and the lobby froze. Tap = next value (Rare > Normal > Frequent > Plenty > Rare ...). Non-hosts see them greyed out.
- arena_controller.gd (net_prepare_match): Abandoned Station adds its own MatchManager inside the map, which kept drawing
  "YOU - BOTS (first to 10)" over the multiplayer score. Network matches now remove any MatchManager that is not the
  controller's own, so only the multiplayer scoreboard is shown.
- net/lan_menu.gd (v33.7): MAX PLAYERS and KILLS TO WIN are now [ - ] value [ + ] buttons (hold to repeat) instead of SpinBoxes,
  and tapping a text box (ROOM, YOUR NAME, IP, PORT) now focuses it and opens the phone keyboard. Same cause as the drop-down:
  with emulate_mouse_from_touch off, SpinBox / LineEdit never received the finger. Keyboard "done" or a tap elsewhere closes it.
